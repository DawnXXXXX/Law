"""
主工作流引擎
核心职责：意图识别（大模型）、任务分发、上下文管理

使用 CodeBuddy Agent SDK 进行意图识别和复杂任务处理
"""
import json
import re
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from .agent_sdk import CodeBuddyAgent, SDK_AVAILABLE


# ==================== 日志辅助函数 ====================

def log_thinking(step_name: str, content: str, max_len: int = 500):
    """输出思考日志"""
    timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    print(f"\n{'='*70}")
    print(f"🧠 [{timestamp}] {step_name}")
    print(f"{'─'*70}")
    if len(content) > max_len:
        print(content[:max_len] + "...")
        print(f"[... 共 {len(content)} 字符]")
    else:
        print(content)
    print("="*70)


class IntentType(str, Enum):
    """意图类型"""
    DOCUMENT_GENERATION = "document_generation"      # 文书生成
    DOCUMENT_MODIFICATION = "document_modification"  # 文书修改
    CONTRACT_SERVICE = "contract_service"            # 合同服务
    CONSULTATION = "consultation"                     # 法律咨询
    CASE_SEARCH = "case_search"                       # 案例检索
    LAW_SEARCH = "law_search"                         # 法规检索
    CHITCHAT = "chitchat"                            # 闲聊
    UNKNOWN = "unknown"                               # 未知


@dataclass
class WorkflowContext:
    """工作流上下文（所有工作流共享）"""
    # 会话信息
    session_id: str = ""
    conversation_id: int = 0
    project_id: Optional[int] = None
    
    # 意图信息
    intent: IntentType = IntentType.UNKNOWN
    intent_confidence: float = 0.0
    intent_reasoning: str = ""
    
    # 提取的信息
    document_type: str = ""          # 文书类型
    dispute_type: str = ""           # 纠纷类型
    collected_params: Dict[str, Any] = field(default_factory=dict)  # 收集的参数
    
    # 工作流状态
    current_workflow: str = ""       # 当前子工作流名称
    workflow_state: Dict[str, Any] = field(default_factory=dict)    # 子工作流状态
    
    # 附件文件
    attached_files: List[Dict[str, Any]] = field(default_factory=list)
    
    # 输出结果
    response: str = ""
    widget: Optional[Dict[str, Any]] = None
    workflow_output: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        return {
            "session_id": self.session_id,
            "conversation_id": self.conversation_id,
            "project_id": self.project_id,
            "intent": self.intent.value,
            "intent_confidence": self.intent_confidence,
            "document_type": self.document_type,
            "dispute_type": self.dispute_type,
            "collected_params": self.collected_params,
            "current_workflow": self.current_workflow,
            "workflow_state": self.workflow_state
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkflowContext":
        """从字典恢复"""
        ctx = cls()
        ctx.session_id = data.get("session_id", "")
        ctx.conversation_id = data.get("conversation_id", 0)
        ctx.project_id = data.get("project_id")
        intent_str = data.get("intent", "unknown")
        ctx.intent = IntentType(intent_str) if intent_str in [e.value for e in IntentType] else IntentType.UNKNOWN
        ctx.intent_confidence = data.get("intent_confidence", 0.0)
        ctx.document_type = data.get("document_type", "")
        ctx.dispute_type = data.get("dispute_type", "")
        ctx.collected_params = data.get("collected_params", {})
        ctx.current_workflow = data.get("current_workflow", "")
        ctx.workflow_state = data.get("workflow_state", {})
        return ctx


class IntentRecognizer:
    """
    意图识别器 - 使用 CodeBuddy Agent SDK
    """
    
    # 意图映射表：中文 -> 英文枚举值
    INTENT_MAP = {
        # 文书生成相关
        "文书起草": "document_generation",
        "文书生成": "document_generation",
        "生成文书": "document_generation",
        "创建文书": "document_generation",
        "写文书": "document_generation",
        "起草文书": "document_generation",
        "生成": "document_generation",
        "起草": "document_generation",
        "create_document": "document_generation",
        "generate_document": "document_generation",
        "document_generation": "document_generation",
        
        # 文书修改相关
        "文书修改": "document_modification",
        "修改文书": "document_modification",
        "文书调整": "document_modification",
        "修改内容": "document_modification",
        "修改": "document_modification",
        "edit_document": "document_modification",
        "document_modification": "document_modification",
        
        # 合同服务相关
        "合同起草": "contract_service",
        "合同审查": "contract_service",
        "合同服务": "contract_service",
        "合同咨询": "contract_service",
        "合同": "contract_service",
        "contract_service": "contract_service",
        
        # 法律咨询相关
        "法律咨询": "consultation",
        "咨询": "consultation",
        "法律问题": "consultation",
        "consultation": "consultation",
        
        # 案例检索相关
        "案例检索": "case_search",
        "查找案例": "case_search",
        "搜索案例": "case_search",
        "案例搜索": "case_search",
        "case_search": "case_search",
        
        # 法规检索相关
        "法规检索": "law_search",
        "查找法规": "law_search",
        "搜索法规": "law_search",
        "法条": "law_search",
        "法律条文": "law_search",
        "law_search": "law_search",
        
        # 闲聊相关
        "闲聊": "chitchat",
        "打招呼": "chitchat",
        "chitchat": "chitchat",
        
        # 未知
        "unknown": "unknown",
        "未知": "unknown",
    }
    
    # 意图识别系统提示词 - 基于CO-STAR框架 + Chain-of-Thought
    SYSTEM_PROMPT = """# Context (角色与背景)
你是"法智通"法律AI系统的意图识别引擎。你的唯一职责是分析用户输入，判断用户想要执行的操作类型，并输出结构化的分类结果。

# Objective (任务目标)
将用户的自然语言输入准确映射到以下8个预定义的意图类型之一：
- document_generation: 文书生成（起草/创建/写一份法律文书）
- document_modification: 文书修改（修改/编辑/调整已有文书）
- contract_service: 合同服务（合同审查/分析/起草）
- consultation: 法律咨询（询问法律问题/寻求建议）
- case_search: 案例检索（查找案例/判例/类似案件）
- law_search: 法规检索（查询法律法规/具体条文）
- chitchat: 闲聊（打招呼/测试/闲聊）
- unknown: 无法识别

# Style (思维链 - 分析步骤)
请按以下顺序思考：
1. 提取用户输入中的核心关键词
2. 判断关键词所属的法律业务领域
3. 匹配最接近的意图类型
4. 提取辅助信息（文书类型、纠纷类型等）
5. 输出JSON结果

# Tone (严谨、精确)
- intent字段必须且只能使用上述8个英文值之一
- confidence反映你对本次判断的确信程度(0.0-1.0)
- reasoning用中文简要说明判断依据

# Audience (下游系统)
你的输出将被程序自动解析，因此格式必须严格符合JSON规范。

# Response Format (输出格式)

## JSON Schema
{
  "intent": "必须是上述8个英文值之一",
  "confidence": "0.0到1.0之间的数字",
  "reasoning": "中文判断理由",
  "document_type": "文书类型，如：起诉状/答辩状/申请书，非文书类留空字符串",
  "dispute_type": "纠纷类型，如：劳动纠纷/离婚纠纷/合同纠纷，无则留空",
  "extracted_info": {"其他提取信息"},
  "intent_changed": "true或false"
}

## Few-shot Examples

### Example 1 - 文书生成
输入: "帮我用模板生成一个离婚纠纷的答辩状"
思考: 关键词=生成/模板/答辩状 → 属于文书创建 → 匹配document_generation
输出: {"intent": "document_generation", "confidence": 0.98, "reasoning": "用户明确要求使用模板生成离婚纠纷答辩状，属于文书生成意图", "document_type": "答辩状", "dispute_type": "离婚纠纷", "extracted_info": {}, "intent_changed": true}

### Example 2 - 文书修改
输入: "把第三段的违约金改成10%"
思考: 关键词=修改/改/违约金 → 属于已有内容修改 → 匹配document_modification
输出: {"intent": "document_modification", "confidence": 0.95, "reasoning": "用户要求修改文档中的具体条款内容（违约金比例），属于文书修改意图", "document_type": "", "dispute_type": "", "extracted_info": {"modification_target": "违约金比例", "new_value": "10%"}, "intent_changed": true}

### Example 3 - 法律咨询
_input: "公司没签劳动合同能要双倍工资吗"
思考: 关键词=公司/劳动合同/双倍工资 → 属于法律问题咨询 → 匹配consultation
输出: {"intent": "consultation", "confidence": 0.92, "reasoning": "用户咨询关于未签订劳动合同的法律后果问题，属于法律咨询意图", "document_type": "", "dispute_type": "劳动纠纷", "extracted_info": {}, "intent_changed": true}

### Example 4 - 案例检索
_input: "找一下类似的劳动仲裁案例"
思考: 关键词=找/类似/案例 → 要求查找判例 → 匹配case_search
输出: {"intent": "case_search", "confidence": 0.95, "reasoning": "用户要求查找类似的劳动仲裁相关案例，属于案例检索意图", "document_type": "", "dispute_type": "劳动纠纷", "extracted_info": {}, "intent_changed": true}

### Example 5 - 法规检索
_input: "民法典关于诉讼时效的规定"
思考: 关键词=民法典/诉讼时效/规定 → 查询法律条文 → 匹配law_search
输出: {"intent": "law_search", "confidence": 0.97, "reasoning": "用户查询民法典中关于诉讼时效的具体法条规定，属于法规检索意图", "document_type": "", "dispute_type": "", "extracted_info": {"target_law": "民法典", "topic": "诉讼时效"}, "intent_changed": true}

### Example 6 - 合同服务
_input: "帮我看下这份租赁合同有没有风险"
思考: 关键词=合同/审查/风险 → 合同类服务 → 匹配contract_service
输出: {"intent": "contract_service", "confidence": 0.93, "reasoning": "用户提供合同文件并要求进行风险评估，属于合同服务意图", "document_type": "租赁合同", "dispute_type": "", "extracted_info": {}, "intent_changed": true}

### Example 7 - 闲聊
_input: "你好，在吗？"
思考: 关键词=你好/在吗 → 打招呼 → 匹配chitchat
输出: {"intent": "chitchat", "confidence": 0.99, "reasoning": "用户发送问候语，属于闲聊意图", "document_type": "", "dispute_type": "", "extracted_info": {}, "intent_changed": false}

### Example 8 - 复杂输入
_input: "我想起诉前夫，他出轨还转移财产，需要准备什么材料"
思考: 关键词=起诉/出轨/转移财产/材料 → 涉及诉讼文书 → 匹配document_generation
输出: {"intent": "document_generation", "confidence": 0.91, "reasoning": "用户因婚姻纠纷（出轨、财产转移）准备提起诉讼，需要生成起诉相关文书，属于文书生成意图", "document_type": "起诉状", "dispute_type": "离婚纠纷", "extracted_info": {"key_facts": ["对方出轨", "转移财产"]}, "intent_changed": true}"""
    
    def __init__(self, agent: Optional[CodeBuddyAgent] = None):
        self.agent = agent
    
    async def recognize(
        self, 
        query: str, 
        history: List[Dict[str, str]] = None,
        previous_intent: str = ""
    ) -> Dict[str, Any]:
        """
        识别用户意图 - 使用 CodeBuddy Agent SDK
        
        Args:
            query: 用户查询
            history: 对话历史
            previous_intent: 之前的意图
            
        Returns:
            意图识别结果
        """
        # 构建上下文
        context_parts = []
        
        if history:
            context_parts.append("## 对话历史\n")
            for msg in history[-5:]:
                role = "用户" if msg.get("role") == "user" else "助手"
                content = msg.get('content', '')[:200]
                context_parts.append(f"{role}：{content}")
        
        if previous_intent:
            context_parts.append(f"\n## 之前的意图\n{previous_intent}")
        
        context_parts.append(f"\n## 当前用户查询\n{query}")
        context_parts.append("\n请分析以上内容，输出JSON格式的意图识别结果。")
        
        full_message = "\n".join(context_parts)
        
        log_thinking("意图识别 - 开始", f"用户查询: {query[:100]}...\n历史消息数: {len(history)}")
        log_thinking("意图识别 - 发送给Agent的消息", full_message[:300] + "..." if len(full_message) > 300 else full_message)
        
        # 使用 CodeBuddy Agent SDK
        if self.agent and SDK_AVAILABLE:
            try:
                log_thinking("意图识别 - 等待Agent响应", "Agent正在分析意图...")
                response = await self.agent.chat(
                    message=full_message,
                    session_id="intent_recognition",
                    agent_type="default"
                )
                log_thinking("意图识别 - Agent响应", response.content[:500] + "..." if len(response.content) > 500 else response.content)
                
                result = self._parse_response(response.content, previous_intent)
                log_thinking("意图识别 - 解析结果", f"意图: {result.get('intent')}\n置信度: {result.get('confidence')}\n推理: {result.get('reasoning', '')[:200]}")
                
                # 如果 Agent 返回 unknown 或低置信度，使用后备识别
                if result.get("intent") == "unknown" or result.get("confidence", 0) < 0.6:
                    log_thinking("意图识别 - 置信度低，启用后备识别", "")
                    fallback_result = self._fallback_recognition(query)
                    # 优先使用后备识别的结果
                    if fallback_result.get("confidence", 0) > result.get("confidence", 0):
                        log_thinking("意图识别 - 使用后备识别结果", f"意图: {fallback_result.get('intent')}")
                        return fallback_result
                
                return result
            except Exception as e:
                log_thinking("意图识别 - Agent调用失败", f"错误: {e}")
                print(f"Agent SDK 意图识别失败: {e}")
        
        # 后备：简单关键词匹配
        log_thinking("意图识别 - 使用后备关键词匹配", "")
        fallback_result = self._fallback_recognition(query)
        log_thinking("意图识别 - 后备识别结果", f"意图: {fallback_result.get('intent')}")
        return fallback_result
    
    def _parse_response(self, response: str, previous_intent: str) -> Dict[str, Any]:
        """解析 Agent 响应 - 增强容错能力，确保100%识别"""
        
        # 策略1: 尝试解析标准JSON格式
        try:
            json_str = self._extract_json(response)
            print(f"[_parse_response] 提取的JSON: {json_str[:200]}")
            data = json.loads(json_str)
            
            # 提取原始意图
            raw_intent = data.get("intent", "")
            if raw_intent:
                intent = self._map_intent(raw_intent)
                print(f"[_parse_response] 原始意图: {raw_intent} -> 映射后: {intent}")
                return {
                    "intent": intent,
                    "confidence": float(data.get("confidence", 0.5)),
                    "reasoning": data.get("reasoning", ""),
                    "document_type": data.get("document_type", ""),
                    "dispute_type": data.get("dispute_type", ""),
                    "extracted_info": data.get("extracted_info", {}),
                    "intent_changed": data.get("intent_changed", intent != previous_intent)
                }
        except Exception as e:
            print(f"[_parse_response] JSON解析失败: {e}，尝试其他策略...")
        
        # 策略2: 使用正则表达式直接提取 intent 字段
        print(f"[_parse_response] 使用正则表达式提取意图...")
        intent = self._extract_intent_regex(response)
        if intent != "unknown":
            print(f"[_parse_response] 正则提取成功: {intent}")
            return {
                "intent": intent,
                "confidence": 0.8,
                "reasoning": "通过正则表达式从响应中提取",
                "intent_changed": True
            }
        
        # 策略3: 从响应内容中匹配关键词
        print(f"[_parse_response] 使用关键词匹配...")
        matched_intent = self._match_intent_from_text(response)
        if matched_intent:
            print(f"[_parse_response] 关键词匹配: {matched_intent}")
            return {
                "intent": matched_intent,
                "confidence": 0.7,
                "reasoning": "从响应文本中关键词匹配",
                "intent_changed": True
            }
        
        # 所有策略都失败
        print(f"[_parse_response] 所有解析策略都失败，返回unknown")
        return {"intent": "unknown", "confidence": 0.0, "intent_changed": True}
    
    def _extract_intent_regex(self, text: str) -> str:
        """使用正则表达式从文本中提取意图"""
        # 匹配 intent: "xxx" 或 "intent": "xxx" 格式
        patterns = [
            r'intent["\s:]+["\']([^"\']+)["\']',  # intent: "document_generation"
            r'"intent"\s*:\s*"([^"]+)"',          # "intent": "document_generation"
            r"'intent'\s*:\s*'([^']+)'",          # 'intent': 'document_generation'
            r'intent["\s=]+(\w+)',                 # intent = document_generation
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                raw_intent = match.group(1).strip()
                mapped = self._map_intent(raw_intent)
                if mapped != "unknown":
                    return mapped
        
        return "unknown"
    
    def _match_intent_from_text(self, text: str) -> Optional[str]:
        """从文本内容中匹配意图关键词"""
        text_lower = text.lower()
        
        # 按优先级匹配
        intent_keywords = [
            # 文书生成 - 最高优先级
            (["document_generation", "文书生成", "生成文书", "create_document", "generate_document", "起诉状", "答辩状", "申请书", "上诉状"], "document_generation"),
            # 文书修改
            (["document_modification", "文书修改", "修改文书", "edit_document"], "document_modification"),
            # 合同服务
            (["contract_service", "合同服务", "合同", "合同审查", "合同起草"], "contract_service"),
            # 法律咨询
            (["consultation", "法律咨询", "法律问题", "咨询"], "consultation"),
            # 案例检索
            (["case_search", "案例检索", "案例", "案件", "判例"], "case_search"),
            # 法规检索
            (["law_search", "法规检索", "法规", "法条", "法律条文"], "law_search"),
            # 闲聊
            (["chitchat", "闲聊", "你好", "hi", "hello"], "chitchat"),
        ]
        
        for keywords, intent in intent_keywords:
            for kw in keywords:
                if kw.lower() in text_lower:
                    return intent
        
        return None
    
    def _map_intent(self, raw_intent: str) -> str:
        """将原始意图映射为标准英文意图"""
        if not raw_intent:
            return "unknown"
        
        # 精确匹配
        if raw_intent in self.INTENT_MAP:
            return self.INTENT_MAP[raw_intent]
        
        # 模糊匹配 - 检查是否包含关键词
        for key, value in self.INTENT_MAP.items():
            if key in raw_intent or raw_intent in key:
                return value
        
        # 尝试部分匹配
        for key, value in self.INTENT_MAP.items():
            if key in ["文书起草", "文书生成", "生成文书", "起草文书"]:
                if "文书" in raw_intent or "生成" in raw_intent or "起草" in raw_intent:
                    return "document_generation"
            if key in ["文书修改", "修改文书"]:
                if "文书" in raw_intent and "修改" in raw_intent:
                    return "document_modification"
            if key == "合同服务" or key == "contract_service":
                if "合同" in raw_intent:
                    return "contract_service"
            if key in ["案例检索", "case_search"]:
                if "案例" in raw_intent or "案件" in raw_intent:
                    return "case_search"
            if key in ["法规检索", "law_search"]:
                if "法规" in raw_intent or "法条" in raw_intent:
                    return "law_search"
            if key in ["法律咨询", "consultation"]:
                if "咨询" in raw_intent:
                    return "consultation"
        
        # 无法识别
        print(f"[_map_intent] 无法识别的意图: {raw_intent}")
        return "unknown"
    
    def _extract_json(self, text: str) -> str:
        """提取JSON字符串"""
        text = text.strip()
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            return text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            if end > 0:
                return text[start:end].strip()
        if "{" in text and "}" in text:
            start = text.find("{")
            return text[start:text.rfind("}") + 1]
        return text
    
    def _fallback_recognition(self, query: str) -> Dict[str, Any]:
        """后备意图识别（关键词匹配）"""
        query_lower = query.lower()
        
        # 模板 + 文书类型 = 文书生成（优先级最高）
        if "模板" in query or "使用模板" in query_lower:
            doc_type = self._extract_document_type(query_lower)
            if doc_type:
                return {
                    "intent": "document_generation",
                    "confidence": 0.9,
                    "document_type": doc_type,
                    "intent_changed": True
                }
        
        # 文书修改关键词
        modify_keywords = ["修改", "改一下", "调整", "改动", "编辑", "更正", "变更"]
        if any(kw in query_lower for kw in modify_keywords):
            return {"intent": "document_modification", "confidence": 0.7, "intent_changed": True}
        
        # 文书生成关键词
        generate_keywords = ["生成", "起草", "创建", "写一份", "帮我写", "生成一份"]
        if any(kw in query_lower for kw in generate_keywords):
            doc_type = self._extract_document_type(query_lower)
            return {
                "intent": "document_generation",
                "confidence": 0.7,
                "document_type": doc_type,
                "intent_changed": True
            }
        
        # 合同关键词
        contract_keywords = ["合同", "协议", "协议书"]
        if any(kw in query_lower for kw in contract_keywords):
            return {"intent": "contract_service", "confidence": 0.7, "intent_changed": True}
        
        # 案例检索关键词
        if any(kw in query_lower for kw in ["案例", "判例", "裁判文书"]):
            return {"intent": "case_search", "confidence": 0.7, "intent_changed": True}
        
        # 闲聊
        greeting_keywords = ["你好", "hi", "hello", "嗨", "在吗"]
        if any(kw in query_lower for kw in greeting_keywords):
            return {"intent": "chitchat", "confidence": 0.9, "intent_changed": True}
        
        return {"intent": "consultation", "confidence": 0.5, "intent_changed": True}
    
    def _extract_document_type(self, query: str) -> str:
        """提取文书类型"""
        doc_types = [
            "起诉状", "答辩状", "申请书", "上诉状", "反诉状",
            "离婚协议", "劳动合同", "租赁合同", "买卖合同",
            "授权委托书", "财产保全申请书", "执行申请书"
        ]
        for dt in doc_types:
            if dt in query:
                return dt
        return ""


class MainWorkflow:
    """
    主工作流
    
    使用 CodeBuddy Agent SDK 进行意图识别和任务分发
    
    工作流程：
    1. 接收用户消息
    2. 调用 CodeBuddy Agent SDK 识别意图
    3. 根据意图分发到对应的工具子工作流
    4. 工具子工作流处理完成后返回结果
    """
    
    def __init__(self, agent: Optional[CodeBuddyAgent] = None):
        """
        初始化主工作流
        
        Args:
            agent: CodeBuddy Agent SDK 实例
        """
        self.agent = agent
        self.recognizer = IntentRecognizer(agent)
        
        # 子工作流注册表
        self.sub_workflows: Dict[str, Callable] = {}
    
    def register_workflow(self, name: str, workflow: Callable):
        """注册子工作流"""
        self.sub_workflows[name] = workflow
    
    async def execute(
        self,
        message: str,
        context: WorkflowContext,
        history: List[Dict[str, str]] = None,
        db=None
    ) -> WorkflowContext:
        """
        执行主工作流
        
        Args:
            message: 用户消息
            context: 工作流上下文
            history: 对话历史
            db: 数据库会话（用于访问模板等数据）
            
        Returns:
            更新后的上下文
        """
        # 更新上下文中的消息
        context.session_id = context.session_id or f"sess_{datetime.now().timestamp()}"
        
        # ===== 步骤1: 意图识别（使用 CodeBuddy Agent SDK） =====
        previous_intent = context.current_workflow
        intent_result = await self.recognizer.recognize(
            message, 
            history,
            previous_intent
        )
        
        # 更新上下文中的意图
        intent_str = intent_result.get("intent", "unknown")
        try:
            context.intent = IntentType(intent_str)
        except:
            context.intent = IntentType.UNKNOWN
        context.intent_confidence = intent_result.get("confidence", 0.0)
        context.intent_reasoning = intent_result.get("reasoning", "")
        
        # 更新提取的信息
        if intent_result.get("document_type"):
            context.document_type = intent_result.get("document_type")
        if intent_result.get("dispute_type"):
            context.dispute_type = intent_result.get("dispute_type")
        
        # ===== 步骤2: 意图变更检测 =====
        intent_changed = intent_result.get("intent_changed", True)
        if intent_changed and previous_intent and previous_intent in self.sub_workflows:
            # 检查是否为重大意图变更
            if self._is_significant_intent_change(context.intent, previous_intent):
                context.collected_params = {}  # 清空参数
                context.workflow_state = {}
        
        # ===== 步骤3: 分发到子工作流 =====
        workflow_key = self._get_workflow_key(context)
        context.current_workflow = workflow_key
        
        log_thinking("📤 工作流分发", f"意图: {context.intent.value}\n置信度: {context.intent_confidence}\n工作流: {workflow_key}")
        
        if workflow_key in self.sub_workflows:
            workflow_func = self.sub_workflows[workflow_key]
            log_thinking(f"🔄 执行子工作流: {workflow_key}", "开始执行...")
            context = await workflow_func(
                message, 
                context, 
                history,
                self.agent,  # 传递 Agent SDK 实例
                db           # 传递数据库会话
            )
            log_thinking(f"✅ 子工作流执行完成: {workflow_key}", f"响应长度: {len(context.response) if context.response else 0} 字符")
        else:
            context.response = "抱歉，暂不支持此功能。"
            log_thinking("⚠️ 工作流分发失败", f"未找到工作流: {workflow_key}")
        
        return context
    
    def _get_workflow_key(self, context: WorkflowContext) -> str:
        """根据意图获取工作流键"""
        intent = context.intent
        
        if intent == IntentType.DOCUMENT_GENERATION:
            return "document_generation"
        elif intent == IntentType.DOCUMENT_MODIFICATION:
            return "document_modification"
        elif intent == IntentType.CONTRACT_SERVICE:
            return "contract_service"
        elif intent == IntentType.CASE_SEARCH:
            return "case_search"
        elif intent == IntentType.LAW_SEARCH:
            return "law_search"
        elif intent == IntentType.CONSULTATION:
            return "consultation"
        elif intent == IntentType.CHITCHAT:
            return "chitchat"
        
        return "consultation"  # 默认走咨询
    
    def _is_significant_intent_change(self, new_intent: IntentType, current_workflow: str) -> bool:
        """判断是否为重大意图变更"""
        # 文书生成 <-> 文书修改 不算重大变更（可能是在生成后要修改）
        if current_workflow in ["document_generation", "document_modification"]:
            if new_intent in [IntentType.DOCUMENT_GENERATION, IntentType.DOCUMENT_MODIFICATION]:
                return False
        return True


# ==================== 单例 ====================

_main_workflow: Optional[MainWorkflow] = None


def get_main_workflow(agent: Optional[CodeBuddyAgent] = None) -> MainWorkflow:
    """获取主工作流实例"""
    global _main_workflow
    if _main_workflow is None:
        _main_workflow = MainWorkflow(agent)
    return _main_workflow

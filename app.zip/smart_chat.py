"""
智能对话服务
整合主工作流和工具子工作流，提供统一的对话接口

架构：
- SmartChatService: 智能对话服务入口
- MainWorkflow: 主工作流（意图识别 + 分发）使用 CodeBuddy Agent SDK
- 工具子工作流: 具体业务逻辑，使用 CodeBuddy Agent SDK 处理复杂任务
- TemplateService: 模板服务，从数据库获取模板信息

默认使用 LangChain 版本（USE_LANGCHAIN=true）
"""
from typing import Dict, Any, Optional, List

import os

# 功能开关：默认启用 LangChain 版本
USE_LANGCHAIN = os.environ.get("USE_LANGCHAIN", "true").lower() == "true"

if USE_LANGCHAIN:
    # 使用 LangChain 版本
    from .langchain_core.main_chain import HybridChatService, run_main_chain
    
    class SmartChatService(HybridChatService):
        """
        LangChain 版本的对话服务
        
        继承自 HybridChatService，直接使用 LangChain/LangGraph 实现。
        """
        pass
    
    def get_chat_service() -> SmartChatService:
        """获取对话服务实例（LangChain版本）"""
        global _chat_service
        if _chat_service is None:
            _chat_service = SmartChatService()
        return _chat_service
    
    _chat_service: Optional[SmartChatService] = None
    
else:
    # 使用旧版实现（保留以兼容）
    from .main_workflow import MainWorkflow, WorkflowContext, get_main_workflow
    from .workflows import register_all_workflows
    from .agent_sdk import CodeBuddyAgent, SDK_AVAILABLE
    
    class SmartChatService:
        """
        智能对话服务（旧版）
        
        使用主工作流 + 工具子工作流架构：
        1. 接收用户消息
        2. 调用主工作流执行（意图识别 + 分发）
        3. 子工作流处理具体业务（使用 CodeBuddy Agent SDK）
        4. 返回结果
        """
        
        def __init__(self):
            # 初始化 CodeBuddy Agent SDK
            self.agent: Optional[CodeBuddyAgent] = None
            if SDK_AVAILABLE:
                try:
                    self.agent = CodeBuddyAgent()
                except Exception as e:
                    print(f"[SmartChatService] CodeBuddy Agent SDK 初始化失败: {e}")
            
            # 初始化主工作流（传入 Agent SDK 实例）
            self.main_workflow = get_main_workflow(self.agent)
            
            # 注册所有子工作流
            register_all_workflows(self.main_workflow)
        
        async def chat(
            self,
            message: str,
            conversation_id: int,
            project_id: Optional[int] = None,
            history: Optional[List[Dict[str, str]]] = None,
            workflow_state: Optional[Dict[str, Any]] = None,
            db=None,
            attached_files: Optional[List[Dict[str, Any]]] = None
        ) -> Dict[str, Any]:
            """
            处理对话请求
            
            Args:
                message: 用户消息
                conversation_id: 会话ID
                project_id: 项目ID
                history: 对话历史
                workflow_state: 工作流状态
                db: 数据库会话
                attached_files: 附件文件列表
                
            Returns:
                处理结果
            """
            # 构建上下文
            # 判断 workflow_state 是否为字典
            if workflow_state and isinstance(workflow_state, dict):
                session_id = workflow_state.get("session_id", f"sess_{conversation_id}")
                current_workflow = workflow_state.get("current_workflow", "")
                workflow_state_dict = workflow_state.get("workflow_state", {})
                collected_params = workflow_state.get("collected_params", {})
                document_type = workflow_state.get("document_type", "")
            else:
                session_id = f"sess_{conversation_id}"
                current_workflow = ""
                workflow_state_dict = {}
                collected_params = {}
                document_type = ""
            
            context = WorkflowContext(
                session_id=session_id,
                conversation_id=conversation_id,
                project_id=project_id,
                current_workflow=current_workflow,
                workflow_state=workflow_state_dict,
                collected_params=collected_params,
                document_type=document_type,
                attached_files=attached_files or []
            )
            
            # 执行主工作流
            context = await self.main_workflow.execute(
                message=message,
                context=context,
                history=history or [],
                db=db  # 传递数据库会话
            )
            
            # 构建返回结果（返回字典而非 WorkflowContext）
            return {
                "content": context.response,
                "intent": context.intent.value,
                "confidence": context.intent_confidence,
                "workflow_state": {
                    "session_id": context.session_id,
                    "current_workflow": context.current_workflow,
                    "workflow_state": context.workflow_state,
                    "collected_params": context.collected_params,
                    "document_type": context.document_type
                },
                "widget": context.widget,
                "workflow_output": context.workflow_output
            }
        
        async def close(self):
            """关闭服务"""
            if self.agent:
                await self.agent.close()


    # ==================== 单例 ====================

    _chat_service: Optional[SmartChatService] = None


    def get_chat_service() -> SmartChatService:
        """获取对话服务实例"""
        global _chat_service
        if _chat_service is None:
            _chat_service = SmartChatService()
        return _chat_service




"""
工具子工作流模块

设计原则：
1. 子工作流不处理意图识别，只负责业务逻辑
2. 继承主工作流传入的上下文
3. 使用 CodeBuddy Agent SDK 处理复杂任务
4. 每个子工作流定义清晰的节点流程

包含的子工作流：
- document_generation_workflow: 文书生成工作流
- document_modification_workflow: 文书修改工作流
- contract_workflow: 合同服务工作流
"""
import json
from typing import Dict, Any, Optional, List, Callable, Tuple
from dataclasses import dataclass
from enum import Enum
import httpx
from datetime import datetime

from .main_workflow import WorkflowContext, IntentType
from .langchain_core.memory import get_memory

# 法律API配置
LAW_API_BASE = "https://openapi.delilegal.com"
LAW_API_APPID = "QthdBErlyaYvyXul"
LAW_API_SECRET = "EC5D455E6BD348CE8E18BE05926D2EBE"


# ==================== 日志辅助函数 ====================

def log_step(step_name: str, content: str, max_len: int = 500):
    """输出工作流步骤日志"""
    timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    print(f"\n{'='*70}")
    print(f"📌 [{timestamp}] {step_name}")
    print(f"{'─'*70}")
    if len(content) > max_len:
        print(content[:max_len] + "...")
        print(f"[... 共 {len(content)} 字符]")
    else:
        print(content)
    print("="*70)


def log_result(step_name: str, result: Any, max_len: int = 300):
    """输出工作流结果日志"""
    timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    result_str = str(result)
    print(f"\n{'='*70}")
    print(f"✅ [{timestamp}] {step_name} - 结果")
    print(f"{'─'*70}")
    if len(result_str) > max_len:
        print(result_str[:max_len] + "...")
        print(f"[... 共 {len(result_str)} 字符]")
    else:
        print(result_str)
    print("="*70)


def _extract_keywords_from_text(text: str, must_contain: list) -> str:
    """从文本中提取关键词（降级方案）"""
    import re
    
    # 常见法律主题词
    legal_terms = [
        "离婚", "工伤", "劳动", "合同", "房屋", "买卖", "租赁", "继承",
        "抚养", "赔偿", "人身损害", "交通事故", "医疗", "保险", "借贷",
        "担保", "侵权", "违约", "合伙", "股权", "知识产权", "商标", "专利",
        "交通事故", "醉驾", "盗窃", "诈骗", "抢劫", "故意伤害", "强奸",
        "行政", "复议", "诉讼", "仲裁", "执行", "破产", "公司法", "婚姻法",
        "民法典", "刑法", "劳动合同法", "消费者权益保护法"
    ]
    
    keywords = []
    
    # 优先匹配长词（2-4字）
    for term in legal_terms:
        if term in text and term not in keywords:
            keywords.append(term)
    
    # 如果没有匹配到，从文本中提取连续的中文字符（2-4字）
    if not keywords:
        chinese_chars = re.findall(r'[\u4e00-\u9fa5]{2,4}', text)
        for chars in chinese_chars:
            if chars not in keywords and len(keywords) < 3:
                keywords.append(chars)
    
    # 返回第一个关键词
    return " ".join(keywords[:2]) if keywords else text[:10]


# ==================== 工具子工作流基类 ====================

class WorkflowPhase(str, Enum):
    """工作流阶段"""
    # 文书生成
    SELECT_TEMPLATE = "select_template"           # 选择模板
    COLLECT_PARAMS = "collect_params"             # 收集参数
    CONFIRM_GENERATE = "confirm_generate"         # 确认生成
    GENERATING = "generating"                      # 生成中
    
    # 文书修改
    SELECT_DOCUMENT = "select_document"            # 选择文档
    COLLECT_MODIFICATION = "collect_modification"  # 收集修改内容
    CONFIRM_MODIFY = "confirm_modify"              # 确认修改
    
    # 通用
    COMPLETED = "completed"                        # 完成
    ERROR = "error"                                # 错误


@dataclass
class NodeResult:
    """节点执行结果"""
    phase: WorkflowPhase
    response: str
    widget: Optional[Dict[str, Any]] = None
    extracted_params: Dict[str, Any] = None
    next_phase: Optional[WorkflowPhase] = None
    can_proceed: bool = True
    error: str = ""


# ==================== 模板管理器（使用数据库） ====================

class TemplateManager:
    """
    模板管理器
    
    使用模板服务从数据库获取模板信息
    """
    
    def __init__(self, db=None):
        self.db = db
        self._cache: Dict[int, Dict[str, Any]] = {}
        self._cache_all: Optional[List[Dict[str, Any]]] = None
    
    async def get_all_templates(self) -> List[Dict[str, Any]]:
        """获取所有模板"""
        from .services.template_service import TemplateService
        
        if self.db:
            service = TemplateService(self.db)
            templates = await service.get_all_templates()
            self._cache_all = templates
            return templates
        return self._cache_all or []
    
    async def get_templates_by_category(self) -> Dict[str, List[Dict]]:
        """按分类获取模板列表"""
        templates = await self.get_all_templates()
        
        categories = {}
        for template in templates:
            cat = template.get("category", "other") or "other"
            if cat not in categories:
                categories[cat] = []
            categories[cat].append({
                "id": template["id"],
                "name": template["name"],
                "description": template.get("description", "")
            })
        
        return categories
    
    async def get_template(self, name_or_id: str) -> Optional[Dict]:
        """根据名称或ID获取模板（支持模糊搜索）"""
        from .services.template_service import TemplateService
        
        print(f"[TemplateManager.get_template] 查找: {name_or_id!r}")
        
        if not self.db:
            print("[TemplateManager.get_template] db 为 None")
            return None
        
        service = TemplateService(self.db)
        
        # 尝试按ID查找
        if name_or_id.isdigit():
            template_id = int(name_or_id)
            template = await service.get_template_by_id(template_id)
            if template:
                print(f"[TemplateManager.get_template] ID匹配成功: {template['name']}")
                return template
        
        # 精确按名称查找
        template = await service.get_template_by_name(name_or_id)
        if template:
            print(f"[TemplateManager.get_template] 精确匹配成功: {template['name']}")
            return template
        
        # 模糊搜索
        print(f"[TemplateManager.get_template] 执行模糊搜索...")
        templates = await service.search_templates(name_or_id)
        if templates:
            print(f"[TemplateManager.get_template] 模糊搜索成功: {templates[0]['name']}")
            return templates[0]
        
        print(f"[TemplateManager.get_template] 未找到匹配模板")
        return None
    
    async def get_template_params(self, template_name: str) -> Dict[str, Dict]:
        """获取模板参数定义"""
        template = await self.get_template(template_name)
        if not template:
            return {}
        
        placeholder_dict = template.get("placeholder_dict", {})
        return self._convert_to_params_def(placeholder_dict)
    
    @staticmethod
    def _convert_to_params_def(placeholder_dict: Dict) -> Dict[str, Dict]:
        """
        将占位符字典转换为标准参数定义格式
        
        支持两种格式：
        1. 标准格式: {"key": {"label": "...", "required": true, ...}}
        2. 示例值格式: {"key": "示例值"} → 自动转换为标准格式
        
        示例值格式中，Unicode符号（如 ☑ □ √ 等）会保留在description中
        """
        params = {}
        for key, value in placeholder_dict.items():
            if isinstance(value, dict):
                params[key] = value
            else:
                # 示例值格式：自动转换为参数定义
                str_value = str(value) if value is not None else ""
                # 判断是否包含选择框格式的Unicode符号
                has_checkbox = any(s in str_value for s in ["☑", "□", "√", "■", "×", "○", "●"])
                
                params[key] = {
                    "label": key,
                    "required": not has_checkbox and bool(str_value.strip()),  # 有选择框的可选，其他必填
                    "type": "checkbox" if has_checkbox else "text",
                    "description": str_value  # 保留原始值，包括 Unicode 符号
                }
        
        return params
    
    def find_template_by_id(self, template_id: int) -> Optional[Tuple[str, Dict]]:
        """根据ID查找模板"""
        if self._cache.get(template_id):
            t = self._cache[template_id]
            return t.get("name"), t
        
        if self._cache_all:
            for t in self._cache_all:
                if t.get("id") == template_id:
                    return t.get("name"), t
        
        return None
    
    def clear_cache(self):
        """清空缓存"""
        self._cache.clear()
        self._cache_all = None


# ==================== CodeBuddy Agent SDK 封装 ====================

class WorkflowAgentService:
    """
    工作流 AI 服务 - 使用 CodeBuddy Agent SDK
    
    使用 Agent SDK 处理复杂任务：
    1. 参数提取
    2. 模板内容生成
    3. 文书修改处理
    """
    
    # 参数提取提示词 - 基于CO-STAR框架
    PARAM_EXTRACTION_PROMPT = """# Context (角色)
你是"法智通"系统的参数提取引擎，负责从用户对话中提取结构化的法律文书参数。

# Objective (任务)
分析用户的自然语言回复，提取与模板参数定义相匹配的信息值。

# Style (处理逻辑)
1. 逐一检查参数定义中的每个字段
2. 在用户输入中寻找对应信息
3. 将找到的值转换为标准格式（日期、金额等）
4. 标记缺失的必填参数

# Template Information
## 模板类型: {template_name}

## 参数定义:
{params_def}

## 已收集的参数:
{collected_params}

# User Input
{user_input}

# Response Format
输出严格JSON格式，不含额外文本：
```json
{
  "extracted": {
    "参数名": "提取到的值",
    "未提供的参数名": ""
  },
  "missing_required": ["缺失的必填参数名列表"],
  "confidence": 0.85,
  "notes": "简要说明提取情况"
}
```

# Examples

Example 1 - 提取起诉状参数:
用户输入: "我叫张三，要告李四借了我5万块钱不还"
参数定义包含: plaintiff(原告), defendant(被告), loan_amount(借款金额), dispute_reason(纠纷原因)
输出: {{"extracted": {{"plaintiff": "张三", "defendant": "李四", "loan_amount": "50000", "dispute_reason": "借款不还"}}, "missing_required": [], "confidence": 0.95, "notes": "成功提取所有关键参数"}}

Example 2 - 部分信息提取:
用户输入: "公司叫某某科技公司"
参数定义包含: company_name(公司名称), employee_name(员工姓名), incident_date(事发日期)
输出: {{"extracted": {{"company_name": "某某科技", "employee_name": "", "incident_date": ""}}, "missing_required": ["employee_name", "incident_date"], "confidence": 0.6, "notes": "仅提取到公司名称，需继续询问员工信息和日期"}}"""

    # 文书修改处理提示词 - 基于CO-STAR框架
    MODIFICATION_PROMPT = """# Context (角色)
你是"法智通"系统的文书修改分析引擎，负责理解用户的修改需求并生成结构化的修改指令。

# Objective (任务)
分析用户对法律文书的修改要求，输出精确的、可执行的修改指令。

# Style (分析步骤)
1. 识别用户要求的修改类型（替换/新增/删除/格式调整）
2. 定位需要修改的内容位置
3. 提取修改前后的文本内容
4. 判断修改的合理性和完整性

# Document Context
## 当前文书内容（摘要）:
{document_content}

## 用户修改需求:
{user_input}

# Response Format
```json
{
  "modification_type": "replace|add|delete|reformat",
  "location": "修改位置的描述",
  "location_hint": "用于定位原文的关键词",
  "original_text": "被修改的原文本",
  "new_text": "修改后的新文本",
  "reason": "修改原因说明"
}
```

# Examples

Example 1 - 替换内容:
文书: "...违约金为合同总金额的20%..."
用户: 把违约金改成10%
输出: {{"modification_type": "replace", "location": "违约金条款", "location_hint": "违约金", "original_text": "违约金为合同总金额的20%", "new_text": "违约金为合同总金额的10%", "reason": "用户要求降低违约金比例"}}

Example 2 - 新增内容:
文书: (包含当事人信息部分)
用户: 加上被告有固定住所
输出: {{"modification_type": "add", "location": "被告信息段落", "location_hint": "被告", "original_text": "", "new_text": "被告有固定住所，便于送达诉讼文书", "reason": "补充被告住所信息"}}"""

    # 文书生成提示词 - 基于CO-STAR框架
    DOCUMENT_GENERATION_PROMPT = """# Context (角色)
你是"法智通"系统的专业法律文书起草引擎，负责根据用户提供的参数生成规范、完整的法律文书。

# Objective (任务)
基于给定的文书类型和参数，生成符合中国法律文书格式规范的完整文书。

# Style (起草要求)
1. **格式规范** - 严格遵循该类文书的法定格式
2. **内容完整** - 包含所有必要的法律要素
3. **语言准确** - 使用标准的法律术语
4. **逻辑清晰** - 按照事实→理由→请求的逻辑展开

# Document Specification
## 文书类型: {document_type}

## 已收集的参数:
{params_json}

# Content Structure (通用法律文书结构)
1. 标题（文书名称）
2. 当事人信息（原告/被告/申请人/被申请人等）
3. 诉讼请求/核心诉求
4. 事实与理由（详细叙述案件事实和法律依据）
5. 证据清单（如有）
6. 落款（日期、签名等）

# Response Format
直接输出完整的法律文书正文，无需额外说明或JSON包装。
使用Markdown格式，标题用##，段落之间空行。

# Examples

Example - 民事起诉状:
参数: plaintiff=张三, defendant=李四, dispute=借款纠纷, amount=50000元
输出格式:
```
## 民事起诉状

**原告**: 张三，男，汉族，XXXX年X月X日出生，住址...

**被告**: 李四，男，汉族，XXXX年X月X日出生，住址...

### 诉讼请求
一、判令被告偿还借款本金50000元；
二、判令被告支付利息...；

### 事实与理由
XXXX年X月X日，被告因资金周转需要向原告借款...
（详细叙述借款事实、还款约定、违约情况）

### 此致
XX市XX区人民法院

具状人：张三
XXXX年X月X日
```"""

    def __init__(self, agent=None):
        self.agent = agent
    
    async def extract_params(
        self,
        user_input: str,
        template_name: str,
        collected_params: Dict[str, Any],
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """
        从用户输入中提取参数 - 使用 CodeBuddy Agent SDK
        
        Args:
            user_input: 用户输入
            template_name: 模板名称
            collected_params: 已收集的参数
            conversation_history: 对话历史列表 [{"role": "user"|"assistant", "content": "..."}]
            
        Returns:
            提取结果
        """
        from .services.template_service import TemplateService
        
        # 获取参数定义
        params_def = {}
        # 尝试从上下文获取参数定义
        if hasattr(self, '_params_cache') and template_name in self._params_cache:
            params_def = self._params_cache[template_name]
        else:
            # 使用默认结构
            params_def = {
                "原告姓名": {"label": "原告姓名", "required": True, "type": "text"},
                "被告姓名": {"label": "被告姓名", "required": True, "type": "text"},
                "原告地址": {"label": "原告地址", "required": True, "type": "text"},
                "被告地址": {"label": "被告地址", "required": True, "type": "text"},
                "起诉原因": {"label": "起诉原因", "required": True, "type": "textarea"}
            }
        
        # 格式化对话历史
        if conversation_history:
            history_text = self._format_conversation_history(conversation_history)
        else:
            history_text = "（无历史记录）"
        
        prompt = self.PARAM_EXTRACTION_PROMPT.format(
            template_name=template_name,
            params_def=json.dumps(params_def, ensure_ascii=False, indent=2),
            collected_params=json.dumps(collected_params, ensure_ascii=False, indent=2),
            conversation_history=history_text,
            user_input=user_input
        )
        
        if self.agent:
            try:
                response = await self.agent.chat(
                    message=prompt,
                    session_id="param_extraction",
                    agent_type="default"
                )
                return self._parse_extraction_response(response.content)
            except Exception as e:
                print(f"参数提取失败: {e}")
        
        return {"extracted": {}, "missing_required": [], "confidence": 0.0}
    
    async def process_modification(
        self,
        user_input: str,
        document_content: str
    ) -> Dict[str, Any]:
        """
        处理文书修改 - 使用 CodeBuddy Agent SDK
        
        Args:
            user_input: 用户修改需求
            document_content: 文书内容
            
        Returns:
            修改指令
        """
        prompt = self.MODIFICATION_PROMPT.format(
            document_content=document_content[:3000],
            user_input=user_input
        )
        
        if self.agent:
            try:
                response = await self.agent.chat(
                    message=prompt,
                    session_id="modification_processing",
                    agent_type="default"
                )
                return self._parse_modification_response(response.content)
            except Exception as e:
                print(f"修改处理失败: {e}")
        
        return {"modification_type": "unknown", "reason": "处理失败"}
    
    async def generate_document_content(
        self,
        document_type: str,
        params: Dict[str, Any]
    ) -> str:
        """
        生成文书内容 - 使用 CodeBuddy Agent SDK
        
        Args:
            document_type: 文书类型
            params: 填充参数
            
        Returns:
            文书内容
        """
        prompt = self.DOCUMENT_GENERATION_PROMPT.format(
            document_type=document_type,
            params_json=json.dumps(params, ensure_ascii=False, indent=2)
        )
        
        if self.agent:
            try:
                response = await self.agent.chat(
                    message=prompt,
                    session_id="document_generation",
                    agent_type="default"
                )
                return response.content
            except Exception as e:
                print(f"文书生成失败: {e}")
        
        return "文书生成失败，请稍后重试。"
    
    def _format_conversation_history(self, history: List[Dict[str, str]]) -> str:
        """格式化对话历史为可读文本"""
        if not history:
            return "（无历史记录）"
        
        lines = []
        for msg in history[-10:]:  # 只取最近10条，避免过长
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if role == "user":
                lines.append(f"【用户】: {content[:200]}")
            elif role == "assistant":
                lines.append(f"【助手】: {content[:200]}")
            else:
                lines.append(f"【{role}】: {content[:100]}")
        
        return "\n".join(lines)
    
    def _parse_extraction_response(self, response: str) -> Dict[str, Any]:
        """解析参数提取响应"""
        try:
            json_str = self._extract_json(response)
            data = json.loads(json_str)
            return data
        except:
            return {"extracted": {}, "missing_required": [], "confidence": 0.0}
    
    def _parse_modification_response(self, response: str) -> Dict[str, Any]:
        """解析修改响应"""
        try:
            json_str = self._extract_json(response)
            data = json.loads(json_str)
            return data
        except:
            return {"modification_type": "unknown", "reason": "解析失败"}
    
    def _extract_json(self, text: str) -> str:
        """提取JSON"""
        text = text.strip()
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            return text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            if end > 0:
                return text[start:end].strip()
        if "{" in text and "}" in text:
            start = text.find("{")
            return text[start:text.rfind("}") + 1]
        return text


# ==================== 工具函数 ====================

async def generate_document(
    document_type: str,
    params: Dict[str, Any],
    project_id: int = None,
    agent=None
) -> Dict[str, Any]:
    """
    生成文书
    
    调用模板API生成文书
    
    Args:
        document_type: 文书类型
        params: 填充参数
        project_id: 项目ID
        agent: CodeBuddy Agent SDK 实例
        
    Returns:
        生成结果
    """
    from app.config import settings
    import os
    
    # 使用 Agent SDK 生成文书内容
    workflow_agent = WorkflowAgentService(agent)
    content = await workflow_agent.generate_document_content(document_type, params)
    
    output_dir = os.path.join(settings.UPLOAD_DIR, "generated")
    os.makedirs(output_dir, exist_ok=True)
    
    # 提取主要当事人姓名作为文件名的一部分
    name_key = next((
        params.get(k) for k in ["原告姓名", "答辩人姓名", "申请人姓名", "乙方姓名", "承租人"]
        if params.get(k)
    ), "draft")
    
    filename = f"{document_type}_{name_key}.docx"
    filepath = os.path.join(output_dir, filename)
    
    # TODO: 调用实际的文档生成API保存为docx
    # 目前返回结果
    
    return {
        "success": True,
        "file_path": filepath,
        "file_name": filename,
        "document_type": document_type,
        "params_used": params,
        "content_preview": content[:500] + "..." if len(content) > 500 else content
    }


async def modify_document(
    file_path: str,
    modifications: List[Dict[str, Any]],
    agent=None
) -> Dict[str, Any]:
    """
    修改文书
    
    调用文档修改API
    
    Args:
        file_path: 文件路径
        modifications: 修改指令列表
        agent: CodeBuddy Agent SDK
        
    Returns:
        修改结果
    """
    # TODO: 调用实际的文档修改API
    return {
        "success": True,
        "file_path": file_path,
        "modifications_applied": len(modifications)
    }


# ==================== 子工作流定义 ====================

async def document_generation_workflow(
    message: str,
    context: WorkflowContext,
    history: List[Dict[str, str]],
    agent=None,
    db=None
) -> WorkflowContext:
    """
    文书生成工作流
    
    节点流程：
    1. 选择模板 → 显示模板列表Widget（从数据库获取）
    2. 收集参数 → 使用 Agent SDK 提取参数，追问缺失参数
    3. 确认生成 → 用户确认后调用API
    4. 返回结果
    
    Args:
        message: 用户消息
        context: 工作流上下文
        history: 对话历史
        agent: CodeBuddy Agent SDK 实例
        db: 数据库会话
        
    Returns:
        更新后的上下文
    """
    workflow_state = context.workflow_state
    current_phase = workflow_state.get("phase", WorkflowPhase.SELECT_TEMPLATE)
    
    # 初始化服务和模板管理器
    workflow_agent = WorkflowAgentService(agent)
    template_manager = TemplateManager(db)
    
    # ===== 节点1: 选择模板 =====
    if current_phase == WorkflowPhase.SELECT_TEMPLATE:
        print(f"[document_generation_workflow] context.document_type = {context.document_type!r}")
        
        # 如果用户已经指定了文书类型
        if context.document_type:
            template = await template_manager.get_template(context.document_type)
            print(f"[document_generation_workflow] get_template('{context.document_type}') 结果: {template}")
            if template:
                workflow_state["template_id"] = template["id"]
                workflow_state["template_name"] = template["name"]
                workflow_state["phase"] = WorkflowPhase.COLLECT_PARAMS
                return _build_collect_params_response(context, workflow_state, template)
        
        # 显示模板选择列表（从数据库获取）
        templates_by_cat = await template_manager.get_templates_by_category()
        
        # 输出模板检索情况
        total_templates = sum(len(templates) for templates in templates_by_cat.values())
        print(f"{'='*70}")
        print(f"📋 [模板检索] 找到 {total_templates} 个模板，共 {len(templates_by_cat)} 个分类")
        for cat_name, templates in templates_by_cat.items():
            print(f"   📁 {cat_name}: {len(templates)} 个")
            for t in templates[:5]:  # 每个分类最多显示5个
                print(f"      - {t.get('name', '未知')}")
            if len(templates) > 5:
                print(f"      ... 等共 {len(templates)} 个")
        print(f"{'='*70}\n")
        
        if not templates_by_cat:
            context.response = """📝 **文书生成**

暂无可用的文书模板。

请先在【模板管理】中上传文书模板后再试。

或者告诉我您想要的文书类型，我会尽量帮您起草。
"""
            return context
        
        context.response = "请问您要生成什么类型的文书？"
        context.widget = {
            "type": "template_selector",
            "title": "选择文书模板",
            "categories": [
                {"name": cat_name, "templates": templates}
                for cat_name, templates in templates_by_cat.items()
            ]
        }
        return context
    
    # ===== 节点2: 收集参数 =====
    elif current_phase == WorkflowPhase.COLLECT_PARAMS:
        template_id = workflow_state.get("template_id")
        template_name = workflow_state.get("template_name")
        
        if not template_id:
            # 用户在选择模板 - 尝试识别用户选择的模板
            template = await _detect_template_from_message(message, template_manager)
            if template:
                workflow_state["template_id"] = template["id"]
                workflow_state["template_name"] = template["name"]
                template_name = template["name"]
            else:
                workflow_state["phase"] = WorkflowPhase.SELECT_TEMPLATE
                return await document_generation_workflow(message, context, history, agent, db)
        
        # 获取参数定义
        if not template_name:
            template = await template_manager.get_template(str(template_id))
            template_name = template["name"] if template else "未知模板"
        
        params_def = await template_manager.get_template_params(template_name)
        if not params_def:
            # 使用通用参数
            params_def = {
                "原告姓名": {"label": "原告姓名", "required": True, "type": "text"},
                "被告姓名": {"label": "被告姓名", "required": True, "type": "text"},
                "地址": {"label": "地址", "required": True, "type": "text"},
                "诉求": {"label": "诉求/请求", "required": True, "type": "textarea"}
            }
        
        collected = workflow_state.get("collected_params", context.collected_params)
        
        # 使用 LangChain Memory 工具获取对话历史
        memory_service = get_memory()
        memory_history = await memory_service.get_chat_history(context.conversation_id)
        
        # 使用 Agent SDK 提取参数（使用 Memory 中的对话历史以便理解上下文）
        extraction_result = await workflow_agent.extract_params(
            message, template_name, collected, conversation_history=memory_history
        )
        
        # 更新已收集参数
        extracted = extraction_result.get("extracted", {})
        collected.update(extracted)
        workflow_state["collected_params"] = collected
        context.collected_params = collected
        
        # 检查缺失的必填参数
        missing_required = []
        for key, info in params_def.items():
            if info.get("required", False) and (key not in collected or not collected[key]):
                missing_required.append(key)
        
        if missing_required:
            # 追问缺失参数
            context.response = _build_missing_params_prompt(template_name, params_def, missing_required, collected)
            context.widget = _build_params_form(params_def, collected)
            return context
        
        # 参数完整，进入确认阶段
        workflow_state["phase"] = WorkflowPhase.CONFIRM_GENERATE
        return _build_confirm_generate_response(context, workflow_state)
    
    # ===== 节点3: 确认生成 =====
    elif current_phase == WorkflowPhase.CONFIRM_GENERATE:
        message_lower = message.lower()
        
        # 检查用户是否取消
        if any(kw in message_lower for kw in ["取消", "算了", "不生成"]):
            workflow_state["phase"] = WorkflowPhase.SELECT_TEMPLATE
            workflow_state["collected_params"] = {}
            context.response = "好的，已取消。请问还有什么需要帮助的？"
            return context
        
        # 检查是否继续修改参数
        if any(kw in message_lower for kw in ["修改", "改一下", "调整", "重新"]):
            workflow_state["phase"] = WorkflowPhase.COLLECT_PARAMS
            return await document_generation_workflow(message, context, history, agent, db)
        
        # 确认生成
        template_name = workflow_state.get("template_name", context.document_type)
        params = workflow_state.get("collected_params", {})
        
        workflow_state["phase"] = WorkflowPhase.GENERATING
        
        # 调用生成
        try:
            result = await generate_document(template_name, params, context.project_id, agent)
            
            workflow_state["phase"] = WorkflowPhase.COMPLETED
            workflow_state["output"] = result
            
            context.response = f"""✅ 文书生成成功！

📄 文件名：{result.get('file_name')}
📁 保存位置：{result.get('file_path')}

文书预览：
{result.get('content_preview', '')}

是否有需要调整的地方？"""
            
            context.widget = {
                "type": "card",
                "title": "文书生成成功",
                "actions": [
                    {"type": "button", "label": "查看文书", "action": "open_document"},
                    {"type": "button", "label": "进行调整", "action": "modify_document"},
                    {"type": "button", "label": "生成其他", "action": "new_document"}
                ]
            }
            context.workflow_output = result
            
        except Exception as e:
            workflow_state["phase"] = WorkflowPhase.ERROR
            context.response = f"生成失败：{str(e)}"
        
        return context
    
    # ===== 默认 =====
    workflow_state["phase"] = WorkflowPhase.SELECT_TEMPLATE
    return await document_generation_workflow(message, context, history, agent, db)


async def document_modification_workflow(
    message: str,
    context: WorkflowContext,
    history: List[Dict[str, str]],
    agent=None,
    db=None
) -> WorkflowContext:
    """
    文书修改工作流
    
    节点流程：
    1. 文本收集节点 → 显示引导语，收集用户修改需求
    2. 封装变量 → 将用户输入封装成修改指令（使用 Agent SDK）
    3. 确认修改 → 用户确认
    4. 执行修改 → 调用API
    
    Args:
        message: 用户消息
        context: 工作流上下文
        history: 对话历史
        agent: CodeBuddy Agent SDK 实例
        db: 数据库会话
        
    Returns:
        更新后的上下文
    """
    workflow_state = context.workflow_state
    current_phase = workflow_state.get("phase", WorkflowPhase.COLLECT_MODIFICATION)
    
    workflow_agent = WorkflowAgentService(agent)
    
    # ===== 节点1: 文本收集节点 =====
    if current_phase == WorkflowPhase.COLLECT_MODIFICATION:
        # 检查是否有关联的文档
        if not workflow_state.get("document_path"):
            context.response = """📝 **文书修改**

请告诉我您想修改什么内容：

1. 可以在编辑器中直接选择文字后告诉我修改要求
2. 或者描述您想要修改的内容，例如：
   - "把第三段的地址改成xxx"
   - "在第二段后面加一句话"
   - "删除第四段"
   - "把所有的甲方改成乙方"

请提供具体的修改需求，我会帮您完成修改。
"""
            context.widget = {
                "type": "input",
                "title": "修改需求",
                "placeholder": "请描述您的修改需求...",
                "multiline": True
            }
            return context
        
        # 已有文档，进入处理阶段
        workflow_state["phase"] = WorkflowPhase.CONFIRM_MODIFY
        return await document_modification_workflow(message, context, history, agent, db)
    
    # ===== 节点2: AI处理修改需求 =====
    elif current_phase == WorkflowPhase.CONFIRM_MODIFY:
        # 获取文档内容
        document_content = workflow_state.get("document_content", "")
        if not document_content:
            # 如果没有文档内容，询问用户
            context.response = """请先告诉我您要修改哪份文书，或者上传文书文件。

或者直接描述您的修改需求，我会根据您描述的位置进行修改。
"""
            context.widget = {
                "type": "input",
                "title": "修改需求",
                "placeholder": "请描述您的修改需求..."
            }
            workflow_state["phase"] = WorkflowPhase.COLLECT_MODIFICATION
            return context
        
        # 使用 Agent SDK 处理修改需求
        mod_result = await workflow_agent.process_modification(message, document_content)
        
        workflow_state["modification_request"] = mod_result
        workflow_state["modification_input"] = message
        
        # 确认修改
        context.response = _build_modification_confirm_message(mod_result)
        context.widget = {
            "type": "confirm",
            "title": "确认修改",
            "message": "是否执行以上修改？",
            "actions": [
                {"type": "button", "label": "确认修改", "action": "apply_modification", "primary": True},
                {"type": "button", "label": "取消", "action": "cancel"}
            ]
        }
        
        # 进入等待确认状态
        workflow_state["confirming"] = True
        return context
    
    # ===== 节点3: 执行修改 =====
    elif workflow_state.get("confirming"):
        message_lower = message.lower()
        
        if any(kw in message_lower for kw in ["确认", "是的", "执行", "好的", "apply"]):
            # 执行修改
            mod_result = workflow_state.get("modification_request", {})
            doc_path = workflow_state.get("document_path", "")
            
            modifications = [{
                "type": mod_result.get("modification_type", "replace"),
                "original": mod_result.get("original_text", ""),
                "new": mod_result.get("new_text", ""),
                "location": mod_result.get("location", "")
            }]
            
            try:
                result = await modify_document(doc_path, modifications, agent)
                
                context.response = """✅ 修改成功！

文书已更新。您可以：
- 查看修改后的文书
- 继续修改其他内容
- 生成其他文书
"""
                context.widget = {
                    "type": "card",
                    "title": "修改完成",
                    "actions": [
                        {"type": "button", "label": "查看文书", "action": "open_document"},
                        {"type": "button", "label": "继续修改", "action": "continue_modify"},
                        {"type": "button", "label": "生成其他", "action": "new_document"}
                    ]
                }
                workflow_state["phase"] = WorkflowPhase.COMPLETED
                workflow_state["confirming"] = False
                
            except Exception as e:
                context.response = f"修改失败：{str(e)}"
            
            return context
        
        # 取消或继续修改
        if any(kw in message_lower for kw in ["取消", "算了"]):
            workflow_state["phase"] = WorkflowPhase.COLLECT_MODIFICATION
            workflow_state["confirming"] = False
            return await document_modification_workflow(message, context, history, agent, db)
        
        # 继续修改 - 重新处理
        workflow_state["phase"] = WorkflowPhase.CONFIRM_MODIFY
        workflow_state["confirming"] = False
        return await document_modification_workflow(message, context, history, agent, db)
    
    # ===== 默认 =====
    workflow_state["phase"] = WorkflowPhase.COLLECT_MODIFICATION
    return await document_modification_workflow(message, context, history, agent, db)


async def contract_workflow(
    message: str,
    context: WorkflowContext,
    history: List[Dict[str, str]],
    agent=None,
    db=None
) -> WorkflowContext:
    """
    合同服务工作流
    
    支持：起草合同、审查合同、修改合同
    """
    workflow_state = context.workflow_state
    current_phase = workflow_state.get("phase", "select_action")
    
    if current_phase == "select_action":
        context.response = """📜 **合同服务**

**审查合同** - 分析合同条款，识别风险

请上传合同文件或粘贴合同文本，我来帮您审查。
"""
        context.widget = {
            "type": "card",
            "title": "合同服务",
            "actions": [
                {"type": "button", "label": "审查合同", "action": "review_contract"},
            ]
        }
        return context
    
    # TODO: 使用 Agent SDK 实现具体功能
    context.response = "功能开发中，请稍候..."
    return context


async def consultation_workflow(
    message: str,
    context: WorkflowContext,
    history: List[Dict[str, str]],
    agent=None,
    db=None
) -> WorkflowContext:
    """
    法律咨询工作流 - 使用 CodeBuddy Agent SDK
    
    重要：必须先从知识库调用相关法条和案例，再进行回答
    """
    # 知识库检索结果
    knowledge_results = {
        "laws": [],
        "cases": [],
        "search_keywords": []
    }
    
    # ===== 步骤1: 调用知识库检索 =====
    if agent:
        try:
            # 构建关键词提取 prompt - 基于CO-STAR框架
            keyword_prompt = f"""# Context (角色)
你是"法智通"系统的关键词提取引擎，负责从法律问题中提炼核心检索词。

# Objective (任务)
从用户问题中提取2-4个最核心的法律检索关键词，用于法规和案例的语义检索。

# Style (提取原则)
1. 优先选择法律专业术语（如：离婚纠纷、劳动争议、违约责任）
2. 包含纠纷类型或法律关系（如：借贷、侵权、合同）
3. 避免通用词（如：怎么、什么、是否）
4. 关键词之间用空格分隔

# User Question
{message}

# Examples

输入: "公司没签劳动合同能要双倍工资吗"
输出: 劳动合同 未签书面合同 双倍工资

输入: "邻居装修噪音扰民怎么办"
输出: 相邻关系 噪音污染 侵权责任

输入: "离婚时财产怎么分割"
输出: 离婚 夫妻共同财产 财产分割

# Your Output
关键词："""
            
            # 提取检索关键词（使用独立的 session）
            keywords = ""
            try:
                keywords_response = await agent.chat(keyword_prompt, session_id="kw_extract")
                # 确保获取的是字符串内容
                if hasattr(keywords_response, 'content'):
                    keywords = keywords_response.content.strip()
                elif isinstance(keywords_response, str):
                    keywords = keywords_response.strip()
                else:
                    keywords = str(keywords_response).strip()
                
                knowledge_results["search_keywords"] = keywords.split() if keywords else []
                print(f"\n{'='*70}")
                print(f"📚 [知识库检索] 提取关键词: {keywords}")
                print(f"{'─'*70}")
            except Exception as e:
                print(f"[consultation_workflow] 关键词提取失败: {e}")
                import traceback
                traceback.print_exc()
                keywords = ""
            
            # 调用外部法律 API 检索法规
            if keywords:
                # 法规检索
                try:
                    import httpx
                    keyword_list = [k.strip() for k in keywords.split() if k.strip()]
                    
                    request_data = {
                        "pageNo": 1,
                        "pageSize": 3,
                        "sortField": "correlation",
                        "sortOrder": "desc",
                        "condition": {
                            "keywords": keyword_list,
                            "fieldName": "semantic"
                        }
                    }
                    
                    headers = {
                        "Content-Type": "application/json",
                        "appid": LAW_API_APPID,
                        "secret": LAW_API_SECRET
                    }
                    
                    async with httpx.AsyncClient(timeout=30.0) as client:
                        law_response = await client.post(
                            f"{LAW_API_BASE}/api/qa/v3/search/queryListLaw",
                            json=request_data,
                            headers=headers
                        )
                        law_result = law_response.json()
                        
                        if law_result.get("success"):
                            laws = law_result.get("body", {}).get("data", [])
                            knowledge_results["laws"] = laws
                            print(f"📖 [知识库检索] 找到 {len(laws)} 条法规")
                            for i, law in enumerate(laws[:3], 1):
                                print(f"   {i}. {law.get('lawName', '未知')}")
                        else:
                            print(f"📖 [知识库检索] 法规检索失败")
                except Exception as e:
                    print(f"📖 [知识库检索] 法规检索异常: {e}")
                
                # 案例检索
                try:
                    request_data = {
                        "pageNo": 1,
                        "pageSize": 3,
                        "sortField": "correlation",
                        "sortOrder": "desc",
                        "condition": {
                            "keywordArr": keyword_list
                        }
                    }
                    
                    async with httpx.AsyncClient(timeout=30.0) as client:
                        case_response = await client.post(
                            f"{LAW_API_BASE}/api/qa/v3/search/queryListCase",
                            json=request_data,
                            headers=headers
                        )
                        case_result = case_response.json()
                        
                        if case_result.get("success"):
                            cases = case_result.get("body", {}).get("data", [])
                            knowledge_results["cases"] = cases
                            print(f"⚖️ [知识库检索] 找到 {len(cases)} 个案例")
                            for i, case in enumerate(cases[:3], 1):
                                print(f"   {i}. {case.get('caseName', '未知')}")
                        else:
                            print(f"⚖️ [知识库检索] 案例检索失败")
                except Exception as e:
                    print(f"⚖️ [知识库检索] 案例检索异常: {e}")
                
                print(f"{'='*70}\n")
        except Exception as e:
            print(f"[consultation_workflow] 知识库检索失败: {e}")
    
    # ===== 步骤2: 构建包含知识库结果的 prompt =====
    if agent:
        try:
            # 构建上下文
            history_text = ""
            for msg in history[-5:]:
                role = "用户" if msg.get("role") == "user" else "助手"
                history_text += f"{role}：{msg.get('content', '')}\n"
            
            # 格式化知识库结果
            laws_context = ""
            if knowledge_results["laws"]:
                laws_context += "\n\n## 相关法规\n"
                for i, law in enumerate(knowledge_results["laws"], 1):
                    laws_context += f"{i}. **{law.get('lawName', '未知法规')}**\n"
                    if law.get('lawText'):
                        laws_context += f"   {law['lawText'][:300]}...\n"
            
            cases_context = ""
            if knowledge_results["cases"]:
                cases_context += "\n\n## 相关案例\n"
                for i, case in enumerate(knowledge_results["cases"], 1):
                    cases_context += f"{i}. **{case.get('caseName', '未知案例')}**\n"
                    if case.get('court'):
                        cases_context += f"   法院：{case['court']}\n"
                    if case.get('caseNo'):
                        cases_context += f"   案号：{case['caseNo']}\n"
                    if case.get('brief'):
                        cases_context += f"   摘要：{case['brief'][:200]}...\n"
            
            # 构建法律咨询 prompt - 基于CO-STAR框架
            prompt = f"""# Context (角色)
你是"法智通"系统的法律咨询专家。当前你正在参与一次法律咨询对话，你的任务是基于系统提供的知识库内容回答用户问题。

# Objective (目标)
根据【对话历史】和【知识库内容】，对用户的法律问题给出专业、准确、易懂的回答。

# Style (回答风格)
1. **基于事实** - 回答必须引用知识库中的法条或案例，不编造信息
2. **结构清晰** - 使用分点陈述，便于阅读理解
3. **专业准确** - 引用法条时注明具体法律名称和条款号
4. **通俗易懂** - 避免过度学术化，让非专业人士也能理解

# Knowledge Base Content (你的唯一知识来源)
以下是你本次回答可用的全部参考资料：

{laws_context}

{cases_context}

# Conversation History
{history_text}

# User Question
{message}

# Response Guidelines

## 正确回答示例:
---
**关于未签订劳动合同的法律问题**

您好！根据《中华人民共和国劳动合同法》的规定：

**一、法律规定**
- 第十条：建立劳动关系应当订立书面劳动合同。
- 第八十二条：用人单位自用工之日起超过一个月不满一年未与劳动者订立书面劳动合同的，应当向劳动者每月支付二倍的工资。

**二、您的权利**
如果您所在公司未与您签订书面劳动合同，您可以主张：
1. 要求公司补签书面合同
2. 主张支付双倍工资差额（最多11个月）

**三、建议**
建议先与公司协商，如协商不成可向劳动监察部门投诉或申请劳动仲裁。
---

## Response Guidelines (回答准则)
- 基于知识库内容作答，如无相关资料请如实说明
- 输出专业的法律咨询文本"""
            
            response = await agent.chat(
                message=prompt,
                session_id=f"consultation_{context.session_id}",
                agent_type="legal_advisor"
            )
            context.response = response.content
            
            # 记录知识库调用结果到上下文
            context.workflow_output = {
                "knowledge_retrieved": True,
                "laws_count": len(knowledge_results["laws"]),
                "cases_count": len(knowledge_results["cases"]),
                "keywords": knowledge_results["search_keywords"]
            }
            
        except Exception as e:
            context.response = f"处理咨询时遇到问题：{str(e)}"
    else:
        context.response = """💬 您好！我是法律AI助手。

我可以帮您解答：
- 法律问题咨询
- 法规条文解读
- 权利义务说明

请描述您的问题，我会尽力为您解答。

*温馨提示：对于复杂法律问题，建议咨询专业律师。*
"""
    
    return context


async def chitchat_workflow(
    message: str,
    context: WorkflowContext,
    history: List[Dict[str, str]],
    agent=None,
    db=None
) -> WorkflowContext:
    """闲聊工作流"""
    message_lower = message.lower()
    
    if any(kw in message_lower for kw in ["你好", "hi", "hello", "嗨"]):
        context.response = """👋 你好！

我是法律AI助手，除了法律咨询，我也乐意和您简单聊聊天。

有什么我可以帮您的吗？
- 📝 帮您生成法律文书
- 📜 审查或起草合同
- ⚖️ 了解诉讼流程
- 💬 解答法律问题
"""
    else:
        context.response = """好的，让我们继续。

请问您需要什么帮助？
"""
    
    return context


# ==================== 辅助函数 ====================

async def _detect_template_from_message(message: str, template_manager: TemplateManager) -> Optional[Dict]:
    """从消息中检测用户选择的模板"""
    message_lower = message.lower()
    
    # 获取所有模板
    templates = await template_manager.get_all_templates()
    
    for template in templates:
        name = template.get("name", "")
        name_lower = name.lower()
        
        # 精确匹配
        if name_lower in message_lower:
            return template
        
        # 关键词匹配
        if "离婚" in message_lower and "离婚" in name_lower:
            return template
        if "民事" in message_lower and "民事" in name_lower:
            return template
        if "劳动" in message_lower and "劳动" in name_lower:
            return template
        if "租赁" in message_lower and "租赁" in name_lower:
            return template
        if "合同" in message_lower and "合同" in name_lower:
            return template
    
    return None


def _build_collect_params_response(context: WorkflowContext, workflow_state: Dict, template: Dict = None) -> WorkflowContext:
    """构建收集参数响应"""
    template_name = workflow_state.get("template_name", context.document_type)
    
    context.response = f"好的，您要生成【{template_name}】。\n\n请提供以下信息：\n"
    
    # 从工作流状态获取参数定义
    params_def = workflow_state.get("params_def", {})
    collected = workflow_state.get("collected_params", {})
    
    required_params = [(k, v) for k, v in params_def.items() if v.get("required")]
    for i, (key, info) in enumerate(required_params, 1):
        context.response += f"{i}. {info.get('label', key)}"
        if key in collected and collected[key]:
            context.response += f" ✅ 已填写：{collected[key]}"
        context.response += "\n"
    
    context.widget = _build_params_form(params_def, collected)
    
    return context


def _build_missing_params_prompt(
    template_name: str,
    params_def: Dict,
    missing: List[str],
    collected: Dict
) -> str:
    """构建缺失参数追问"""
    prompt = f"好的，我已收集到以下信息：\n"
    
    for key, value in collected.items():
        if value:
            label = params_def.get(key, {}).get("label", key)
            prompt += f"✅ {label}：{value}\n"
    
    prompt += "\n还缺少以下必填信息，请补充：\n"
    for key in missing:
        label = params_def.get(key, {}).get("label", key)
        prompt += f"• {label}\n"
    
    return prompt


def _build_params_form(params_def: Dict, collected: Dict) -> Dict:
    """构建参数表单Widget"""
    fields = []
    for key, info in params_def.items():
        fields.append({
            "name": key,
            "label": info.get("label", key),
            "type": info.get("type", "text"),
            "required": info.get("required", False),
            "value": collected.get(key, ""),
            "placeholder": f"请输入{info.get('label', key)}"
        })
    
    return {
        "type": "form",
        "title": "填写信息",
        "fields": fields
    }


def _build_confirm_generate_response(context: WorkflowContext, workflow_state: Dict) -> WorkflowContext:
    """构建确认生成响应"""
    template_name = workflow_state.get("template_name", context.document_type)
    params = workflow_state.get("collected_params", {})
    
    context.response = f"✅ 所有信息已收集完毕！\n\n📋 {template_name}\n"
    for key, value in params.items():
        if value:
            context.response += f"• {key}：{value}\n"
    
    context.response += "\n是否确认生成文书？"
    
    context.widget = {
        "type": "confirm",
        "title": "确认生成",
        "message": "是否确认生成文书？",
        "actions": [
            {"type": "button", "label": "确认生成", "action": "confirm", "primary": True},
            {"type": "button", "label": "继续修改", "action": "modify"}
        ]
    }
    
    return context


def _build_modification_confirm_message(mod_result: Dict) -> str:
    """构建修改确认消息"""
    msg = "📝 我理解您想要：\n\n"
    
    mod_type = mod_result.get("modification_type", "unknown")
    if mod_type == "replace":
        msg += "**替换内容**\n"
        if mod_result.get("original_text"):
            msg += f"原文本：\"{mod_result.get('original_text')[:50]}...\"\n"
        if mod_result.get("new_text"):
            msg += f"新文本：\"{mod_result.get('new_text')[:50]}...\"\n"
    elif mod_type == "add":
        msg += "**添加内容**\n"
        if mod_result.get("new_text"):
            msg += f"添加内容：\"{mod_result.get('new_text')[:50]}...\"\n"
    elif mod_type == "delete":
        msg += "**删除内容**\n"
        if mod_result.get("original_text"):
            msg += f"删除内容：\"{mod_result.get('original_text')[:50]}...\"\n"
    else:
        msg += f"{mod_result.get('reason', '执行修改')}\n"
    
    if mod_result.get("location"):
        msg += f"\n📍 位置：{mod_result.get('location')}\n"
    
    return msg


# ==================== 工作流注册 ====================

def register_all_workflows(main_workflow):
    """注册所有子工作流到主工作流"""
    main_workflow.register_workflow("document_generation", document_generation_workflow)
    main_workflow.register_workflow("document_modification", document_modification_workflow)
    main_workflow.register_workflow("contract_service", contract_workflow)
    main_workflow.register_workflow("consultation", consultation_workflow)
    main_workflow.register_workflow("chitchat", chitchat_workflow)
    main_workflow.register_workflow("case_search", case_search_workflow)
    main_workflow.register_workflow("law_search", law_search_workflow)


# ==================== 案例检索工作流 ====================

async def case_search_workflow(
    message: str,
    context: WorkflowContext,
    history: List[Dict[str, str]],
    agent=None,
    db=None
) -> WorkflowContext:
    """
    案例检索工作流
    根据关键词检索相关案例，并返回案例信息
    
    Args:
        message: 用户消息
        context: 工作流上下文
        history: 对话历史
        agent: CodeBuddy Agent SDK 实例
        db: 数据库会话
        
    Returns:
        更新后的上下文
    """
    print(f"[case_search_workflow] 收到请求: {message[:100]}")
    log_step("案例检索工作流 - 开始", f"用户请求: {message}")
    
    try:
        # 分割用户消息，提取案例检索相关的部分
        # 用户可能同时说多个需求，只处理案例检索相关的
        message_parts = message.replace("，", ",").split(",")
        
        # 案例检索关键词提取
        case_keywords = []
        
        # 使用 Agent 提取搜索关键词
        if agent:
            search_prompt = f"""从以下用户请求中提取案例检索的关键词。

【核心要求】严格区分"案例检索"和"法规检索"：
- "案例检索"相关词：案例、案件、判例、裁判文书、判决
- "法规检索"相关词：法律、法规、法条、法典、规定、条款

用户请求：{message}

【任务】只提取与"案例检索"相关的关键词，忽略"法规检索"相关内容。

【关键要求】
- 输出2-4个字的核心关键词（简洁格式）
- 多个关键词用空格分隔
- 只提取最相关的一个或两个关键词
- 如果用户请求中只有法规检索没有案例检索，返回空
- 正确示例：工伤保险 劳动争议
- 无效示例：房屋买卖（属于法规而非案例）

【输出格式】
仅输出关键词文本"""
            
            log_step("案例检索 - 提取关键词", f"调用Agent提取关键词...")
            try:
                keywords_response = await agent.chat(search_prompt, session_id="case_kw_extract")
                keywords = keywords_response.content.strip() if hasattr(keywords_response, 'content') else str(keywords_response).strip()
                log_result("案例检索 - 关键词提取结果", keywords)
            except Exception as e:
                print(f"[case_search_workflow] 关键词提取失败: {e}")
                # 降级：直接从原消息中提取
                keywords = _extract_keywords_from_text(message, ["案例", "案件", "判例", "纠纷"])
        else:
            keywords = _extract_keywords_from_text(message, ["案例", "案件", "判例", "纠纷"])
        
        # 如果没有提取到关键词，使用原消息中的核心词
        if not keywords or len(keywords) < 2:
            keywords = _extract_keywords_from_text(message, [])
        
        # 调用外部法律API检索案例
        try:
            # 提取关键词列表
            keyword_list = [k.strip() for k in keywords.replace("，", ",").split(",") if k.strip()]
            if not keyword_list:
                keyword_list = [keywords]
            
            # 构建API请求
            request_data = {
                "pageNo": 1,
                "pageSize": 5,
                "sortField": "correlation",
                "sortOrder": "desc",
                "condition": {
                    "keywordArr": keyword_list
                }
            }
            
            headers = {
                "Content-Type": "application/json",
                "appid": LAW_API_APPID,
                "secret": LAW_API_SECRET
            }
            
            url = f"{LAW_API_BASE}/api/qa/v3/search/queryListCase"
            
            log_step("案例检索 - API调用", f"URL: {url}\n请求参数: {json.dumps(request_data, ensure_ascii=False)}")
            
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(url, json=request_data, headers=headers)
                response.raise_for_status()
                api_result = response.json()
            
            log_step("案例检索 - API响应", f"成功: {api_result.get('success')}\n数据条数: {len(api_result.get('body', {}).get('data', []))}")
            
            # 解析API响应
            cases = api_result.get("body", {}).get("data", []) if api_result.get("success") else []
            
            if cases:
                case_list = []
                for case in cases:
                    case_list.append({
                        "id": case.get("caseId", ""),
                        "title": case.get("caseName", ""),
                        "court": case.get("court", ""),
                        "caseNumber": case.get("caseNo", ""),
                        "caseType": case.get("caseType", ""),
                        "judgmentDate": case.get("judgmentDate", ""),
                        "summary": case.get("brief", ""),
                        "fullText": case.get("caseFullText", "")
                    })
                
                context.response = f"""🔍 **案例检索结果**

找到 {len(cases)} 个相关案例：

"""
                for i, case in enumerate(case_list, 1):
                    context.response += f"""**{i}. {case['title']}**"""
                    if case.get('court'):
                        context.response += f"\n🏛️ 法院：{case['court']}"
                    if case.get('caseNumber'):
                        context.response += f"\n📋 案号：{case['caseNumber']}"
                    if case.get('caseType'):
                        context.response += f"\n⚖️ 案件类型：{case['caseType']}"
                    if case.get('judgmentDate'):
                        context.response += f"\n📅 判决日期：{case['judgmentDate']}"
                    if case.get('summary'):
                        context.response += f"\n📝 摘要：{case['summary'][:200]}..."
                    context.response += "\n\n---\n\n"
                
                context.response += """
💡 **使用说明**：
- 告诉我您关心的问题，我可以根据这些案例为您分析
- 如需生成法律文书，我可以基于这些案例起草
"""
                context.workflow_output = {"cases": case_list}
            else:
                context.response = """🔍 **案例检索结果**

未找到相关案例。

建议您：
1. 换个关键词重新搜索
2. 扩大搜索范围（如用"纠纷"代替具体的纠纷类型）
3. 告诉我具体需要的案例类型，我会尽量为您查找
"""
        except Exception as e:
            print(f"[case_search_workflow] API调用失败: {e}")
            context.response = f"案例检索失败：{str(e)}"
            log_step("案例检索 - 失败", f"错误: {e}")
            
    except Exception as e:
        print(f"[case_search_workflow] 错误: {e}")
        context.response = f"案例检索失败：{str(e)}"
        log_step("案例检索 - 失败", f"错误: {e}")
    
    log_result("案例检索 - 最终结果", context.response[:200] if context.response else "无响应")
    return context


# ==================== 法规检索工作流 ====================

async def law_search_workflow(
    message: str,
    context: WorkflowContext,
    history: List[Dict[str, str]],
    agent=None,
    db=None
) -> WorkflowContext:
    """
    法规检索工作流
    根据关键词检索相关法律法规，并返回法条信息
    
    Args:
        message: 用户消息
        context: 工作流上下文
        history: 对话历史
        agent: CodeBuddy Agent SDK 实例
        db: 数据库会话
        
    Returns:
        更新后的上下文
    """
    print(f"[law_search_workflow] 收到请求: {message[:100]}")
    log_step("法规检索工作流 - 开始", f"用户请求: {message}")
    
    try:
        # 使用 Agent 提取搜索关键词
        if agent:
            search_prompt = f"""从以下用户请求中提取法规检索的关键词。

【核心要求】严格区分"法规检索"和"案例检索"：
- "法规检索"相关词：法律、法规、法条、法典、规定、条款
- "案例检索"相关词：案例、案件、判例、裁判文书、判决

用户请求：{message}

【任务】只提取与"法规检索"相关的关键词，忽略"案例检索"相关内容。

【关键要求】
- 输出2-4个字的核心关键词（简洁格式）
- 多个关键词用空格分隔
- 只提取最相关的一个或两个关键词
- 如果用户请求中只有案例检索没有法规检索，返回空
- 正确示例：劳动合同法 房屋买卖
- 无效示例：工伤保险（属于案例而非法规）

【输出格式】
仅输出关键词文本"""
            
            try:
                keywords_response = await agent.chat(search_prompt, session_id="law_kw_extract")
                keywords = keywords_response.content.strip() if hasattr(keywords_response, 'content') else str(keywords_response).strip()
                log_result("法规检索 - 关键词提取结果", keywords)
            except Exception as e:
                print(f"[law_search_workflow] 关键词提取失败: {e}")
                # 降级：直接从原消息中提取
                keywords = _extract_keywords_from_text(message, ["法规", "法律", "法条", "规定", "条款"])
        else:
            keywords = _extract_keywords_from_text(message, ["法规", "法律", "法条", "规定", "条款"])
        
        # 如果没有提取到关键词，使用原消息中的核心词
        if not keywords or len(keywords) < 2:
            keywords = _extract_keywords_from_text(message, [])
        
        # 调用外部法律API检索法规
        try:
            # 提取关键词列表
            keyword_list = [k.strip() for k in keywords.replace("，", ",").split(",") if k.strip()]
            if not keyword_list:
                keyword_list = [keywords]
            
            # 构建API请求
            request_data = {
                "pageNo": 1,
                "pageSize": 5,
                "sortField": "correlation",
                "sortOrder": "desc",
                "condition": {
                    "keywords": keyword_list,
                    "fieldName": "semantic"
                }
            }
            
            headers = {
                "Content-Type": "application/json",
                "appid": LAW_API_APPID,
                "secret": LAW_API_SECRET
            }
            
            url = f"{LAW_API_BASE}/api/qa/v3/search/queryListLaw"
            
            log_step("法规检索 - API调用", f"URL: {url}\n关键词: {keyword_list}")
            
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(url, json=request_data, headers=headers)
                response.raise_for_status()
                api_result = response.json()
            
            log_step("法规检索 - API响应", f"成功: {api_result.get('success')}\n数据条数: {len(api_result.get('body', {}).get('data', []))}")
            
            # 解析API响应
            laws = api_result.get("body", {}).get("data", []) if api_result.get("success") else []
            
            if laws:
                law_list = []
                for law in laws:
                    law_list.append({
                        "id": law.get("lawId", ""),
                        "title": law.get("lawName", ""),
                        "lawType": law.get("lawType", ""),
                        "effectiveStatus": law.get("effectiveStatus", ""),
                        "content": law.get("lawText", ""),
                        "publishDate": law.get("publishDate", "")
                    })
                
                context.response = f"""📖 **法规检索结果**

找到 {len(laws)} 条相关法规：

"""
                for i, law in enumerate(law_list, 1):
                    context.response += f"""**{i}. {law['title']}**"""
                    if law.get('lawType'):
                        context.response += f"\n📚 法规类型：{law['lawType']}"
                    if law.get('effectiveStatus'):
                        context.response += f"\n📌 效力状态：{law['effectiveStatus']}"
                    if law.get('publishDate'):
                        context.response += f"\n📅 发布日期：{law['publishDate']}"
                    if law.get('content'):
                        content_preview = law['content'][:300] if law['content'] else ""
                        context.response += f"\n\n```\n{content_preview}...\n```"
                    context.response += "\n\n---\n\n"
                
                context.response += """
💡 **使用说明**：
- 上述法条内容仅供参考，具体适用请结合案情判断
- 如需基于这些法规起草文书，我可以帮您生成
"""
                context.workflow_output = {"laws": law_list}
            else:
                context.response = """📖 **法规检索结果**

未找到相关法规。

建议您：
1. 换个关键词重新搜索
2. 尝试使用法律全称（如"中华人民共和国婚姻法"）
3. 告诉我具体需要的法律类型，我会尽量为您查找
"""
        except Exception as e:
            print(f"[law_search_workflow] API调用失败: {e}")
            context.response = f"法规检索失败：{str(e)}"
            log_step("法规检索 - 失败", f"错误: {e}")
            
    except Exception as e:
        print(f"[law_search_workflow] 错误: {e}")
        context.response = f"法规检索失败：{str(e)}"
        log_step("法规检索 - 失败", f"错误: {e}")
    
    log_result("法规检索 - 最终结果", context.response[:200] if context.response else "无响应")
    return context

"""
CodeBuddy Agent SDK 封装
- 主 LLM: CodeBuddy SDK (API Key 认证)
- 备用 LLM: 元器 API (当 CodeBuddy 认证失败时自动切换)
"""
import os
import asyncio
from typing import Optional, List, Dict, Any
from datetime import datetime
from dataclasses import dataclass, field

# 统一配置
from .config import settings

# 官方 CodeBuddy Agent SDK
try:
    from codebuddy_agent_sdk import (
        query,
        CodeBuddyAgentOptions,
        AssistantMessage,
        TextBlock,
        ResultMessage,
    )
    SDK_AVAILABLE = True
except ImportError:
    SDK_AVAILABLE = False


# ==================== 数据模型 ====================

@dataclass
class FileReference:
    """文件引用"""
    file_path: str
    start_line: int
    end_line: int
    content: str
    summary: Optional[str] = None


@dataclass
class Message:
    """对话消息"""
    role: str
    content: str
    file_refs: List[FileReference] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class AgentResponse:
    """Agent 响应"""
    content: str
    file_changes: List[Dict[str, Any]] = field(default_factory=list)
    citations: List[Dict[str, Any]] = field(default_factory=list)
    task_id: Optional[str] = None


# ==================== Agent SDK 封装类 ====================

class CodeBuddyAgent:
    """CodeBuddy Agent 封装类"""

    def __init__(self):
        if not SDK_AVAILABLE:
            raise RuntimeError("CodeBuddy Agent SDK 未安装")

        # 会话管理
        self.sessions: Dict[str, List[Message]] = {}
        self.current_session_id: Optional[str] = None

    def _get_system_prompt(self, agent_type: str = "default") -> str:
        return "你是一个专业的法律AI助手，擅长合同审查、法律咨询和文书起草。"

    # ==================== 核心功能 ====================

    def _call_codebuddy(self, message: str, system_prompt: str) -> Optional[str]:
        """
        调用 CodeBuddy SDK
        返回响应内容，如果认证失败返回 None（触发备用 LLM）
        """
        import httpx as _htx  # noqa: F811 - 用于备用方案

        api_key = settings.CODEBUDDY_API_KEY
        if not api_key:
            print("[CodeBuddy] API Key 未配置")
            return None

        # 构建环境变量
        env_vars = {
            "CODEBUDDY_INTERNET_ENVIRONMENT": settings.CODEBUDDY_INTERNET_ENVIRONMENT,
            "CODEBUDDY_API_KEY": api_key,
        }

        options = CodeBuddyAgentOptions(
            system_prompt=system_prompt,
            permission_mode="bypassPermissions",
            env=env_vars,
        )

        response_content = ""
        try:
            # 同步执行异步 query
            async def _query():
                nonlocal response_content
                async for msg in query(prompt=message, options=options):
                    msg_type = type(msg).__name__
                    if msg_type == "AssistantMessage":
                        content = getattr(msg, 'content', [])
                        if isinstance(content, list):
                            for block in content:
                                if isinstance(block, TextBlock):
                                    response_content += block.text
                                elif hasattr(block, 'text'):
                                    response_content += block.text
                    elif msg_type == "ResultMessage":
                        result = getattr(msg, 'result', None)
                        if result and isinstance(result, dict):
                            if 'text' in result:
                                response_content = result['text']
                            elif 'content' in result:
                                response_content = result['content']
                return response_content

            if os.name == 'nt':
                loop = asyncio.ProactorEventLoop()
            else:
                loop = asyncio.new_event_loop()

            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(_query())
            finally:
                loop.close()

            return response_content or None

        except Exception as e:
            error_str = str(e)
            if "401" in error_str or "Authentication" in error_str:
                print(f"[CodeBuddy] API Key 认证失败: {error_str}")
                return None
            print(f"[CodeBuddy] SDK 错误: {error_str}")
            raise

    def _run_query_sync(self, message: str, system_prompt: str = "") -> str:
        """
        LangChain 同步查询方法
        由 LawChatLLM 调用，直接使用元器 API
        """
        return self._call_yuanqi(message)

    def _call_yuanqi(self, message: str) -> str:
        """调用元器 API"""
        import httpx

        token = settings.YUANQI_API_TOKEN
        assistant_id = settings.YUANQI_ASSISTANT_ID

        if not token:
            return "抱歉，AI 服务暂时不可用。请稍后重试或联系管理员。"

        print("[CodeBuddy] 使用元器 API...")
        try:
            response = httpx.post(
                'https://yuanqi.tencent.com/openapi/v1/agent/chat/completions',
                headers={
                    'Authorization': f'Bearer {token}',
                    'Content-Type': 'application/json'
                },
                json={
                    "assistant_id": assistant_id,
                    "user_id": "username",
                    "stream": False,
                    "messages": [{"role": "user", "content": [{"type": "text", "text": message}]}]
                },
                timeout=60.0
            )
            if response.status_code == 200:
                data = response.json()
                content = ""
                for choice in data.get("choices", []):
                    msg_content = choice.get("message", {}).get("content", "")
                    if msg_content:
                        content += msg_content
                return content or "（空响应）"
            else:
                return f"AI 服务暂时不可用（错误码: {response.status_code}）"
        except Exception as e:
            return f"AI 服务暂时不可用: {e}"

    def query(self, message: str, system_prompt: str = "") -> str:
        """发送查询：直接使用元器 API"""
        return self._call_yuanqi(message)

    # ==================== 公共接口 ====================

    async def chat(
        self,
        message: str,
        session_id: Optional[str] = None,
        agent_type: str = "default",
        file_refs: Optional[List[FileReference]] = None
    ) -> AgentResponse:
        """发送消息给 Agent"""
        if session_id is None:
            session_id = str(datetime.now().timestamp())

        if session_id not in self.sessions:
            self.sessions[session_id] = []

        user_msg = Message(role="user", content=message, file_refs=file_refs or [])
        self.sessions[session_id].append(user_msg)

        context_parts = [message]
        if file_refs:
            for ref in file_refs:
                if ref.summary:
                    context_parts.append(f"[文件摘要: {ref.file_path}]\n{ref.summary}")
                context_parts.append(f"[引用内容: {ref.file_path}:{ref.start_line}-{ref.end_line}]\n{ref.content}")

        full_message = "\n".join(context_parts)
        system_prompt = self._get_system_prompt(agent_type)

        try:
            response_content = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.query(full_message, system_prompt)
            )

            assistant_msg = Message(role="assistant", content=response_content)
            self.sessions[session_id].append(assistant_msg)

            return AgentResponse(content=response_content)

        except Exception as e:
            return AgentResponse(content=f"Agent 调用失败: {e}")

    async def stream_chat(self, message: str, session_id: Optional[str] = None, **kwargs):
        """流式发送消息"""
        response = await self.chat(message, session_id, **kwargs)
        for char in response.content:
            yield char
            await asyncio.sleep(0.01)

    async def close(self):
        """关闭连接"""


# ==================== 便捷函数 ====================

async def chat_with_agent(message: str, session_id: Optional[str] = None) -> str:
    agent = CodeBuddyAgent()
    try:
        response = await agent.chat(message=message, session_id=session_id)
        return response.content
    finally:
        await agent.close()

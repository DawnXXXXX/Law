"""
OnlyOffice 文档转换服务
"""
import os
import requests
import base64
from typing import Optional
from urllib.parse import urljoin


class OnlyOfficeConverter:
    """OnlyOffice Document Server 转换器"""
    
    def __init__(self, server_url: str = "http://localhost:8888", jwt_secret: str = None):
        """
        初始化转换器
        
        Args:
            server_url: OnlyOffice Document Server 地址
            jwt_secret: JWT 密钥（可选，用于验证）
        """
        self.server_url = server_url.rstrip('/')
        self.jwt_secret = jwt_secret
        
        # API 端点
        self.converter_url = urljoin(server_url, "/ConvertService.ashx")
        selfhealth_url = urljoin(server_url, "/healthcheck")
    
    def is_available(self) -> bool:
        """检查 Document Server 是否可用"""
        try:
            response = requests.get(self.health_url, timeout=5)
            return response.status_code == 200
        except Exception:
            return False
    
    def convert_file(self, file_path: str, output_format: str = "html", 
                     output_dir: Optional[str] = None) -> Optional[str]:
        """
        转换文件到指定格式
        
        Args:
            file_path: 源文件路径（支持 .docx, .xlsx, .pptx, .pdf 等）
            output_format: 输出格式（html, pdf, docx, xlsx, pptx, txt）
            output_dir: 输出目录，None 则与源文件同目录
            
        Returns:
            输出文件路径，失败返回 None
        """
        if not os.path.exists(file_path):
            print(f"文件不存在: {file_path}")
            return None
        
        # 读取文件
        with open(file_path, 'rb') as f:
            file_content = f.read()
        
        # 获取文件扩展名
        file_ext = os.path.splitext(file_path)[1].lower().lstrip('.')
        file_name = os.path.basename(file_path)
        
        # 确定输出文件
        if output_dir is None:
            output_dir = os.path.dirname(file_path)
        os.makedirs(output_dir, exist_ok=True)
        
        output_name = os.path.splitext(file_name)[0] + f'.{output_format}'
        output_path = os.path.join(output_dir, output_name)
        
        try:
            # 构建转换请求
            # OnlyOffice Document Server 支持异步转换，这里使用同步方式
            payload = {
                "async": False,
                "filetype": file_ext,
                "outputtype": output_format,
                "file": base64.b64encode(file_content).decode('utf-8'),
                "title": file_name,
                "url": "",  # 可以使用 URL 替代 file 参数
            }
            
            # 添加 JWT token（如果配置了密钥）
            headers = {}
            if self.jwt_secret:
                import json
                import hashlib
                import hmac
                
                # 生成 JWT token
                payload_json = json.dumps(payload)
                
                # 简单的 HS256 JWT 实现
                import time
                header_b64 = base64.urlsafe_b64encode(
                    json.dumps({"alg": "HS256", "typ": "JWT"}).encode()
                ).decode().rstrip('=')
                
                now = int(time.time())
                payload_with_iat = {**payload, "iat": now, "exp": now + 3600}
                payload_b64 = base64.urlsafe_b64encode(
                    json.dumps(payload_with_iat).encode()
                ).decode().rstrip('=')
                
                signature = hmac.new(
                    self.jwt_secret.encode(),
                    f"{header_b64}.{payload_b64}".encode(),
                    hashlib.sha256
                ).digest()
                signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')
                
                token = f"{header_b64}.{payload_b64}.{signature_b64}"
                headers["Authorization"] = f"Bearer {token}"
            
            # 发送转换请求
            response = requests.post(
                self.converter_url,
                json=payload,
                headers=headers,
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                
                if result.get("error"):
                    print(f"转换错误: {result['error']}")
                    return None
                
                # 获取转换后的文件
                if "fileUrl" in result:
                    # 下载转换后的文件
                    file_url = result["fileUrl"]
                    if not file_url.startswith('http'):
                        file_url = urljoin(self.server_url, file_url)
                    
                    file_response = requests.get(file_url, timeout=30)
                    if file_response.status_code == 200:
                        # HTML 文件可能包含多个资源文件
                        if output_format == "html":
                            # 保存主 HTML 文件
                            with open(output_path, 'w', encoding='utf-8') as f:
                                f.write(file_response.text)
                            
                            # 对于 HTML，返回包含内容的完整 HTML
                            return output_path
                        else:
                            with open(output_path, 'wb') as f:
                                f.write(file_response.content)
                            return output_path
                else:
                    print(f"转换响应格式错误: {result}")
                    return None
            else:
                print(f"请求失败: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            print(f"转换异常: {str(e)}")
            return None


def convert_with_callback(file_path: str, output_format: str = "html",
                          server_url: str = "http://localhost:8888",
                          jwt_secret: str = None) -> dict:
    """
    使用回调模式转换文件（推荐用于大文件）
    
    Returns:
        {"task_id": str, "status": str}
    """
    import json
    import time
    import hashlib
    import hmac
    
    # 读取文件
    with open(file_path, 'rb') as f:
        file_content = f.read()
    
    file_ext = os.path.splitext(file_path)[1].lower().lstrip('.')
    file_name = os.path.basename(file_path)
    
    # 异步转换请求
    payload = {
        "async": True,
        "filetype": file_ext,
        "outputtype": output_format,
        "file": base64.b64encode(file_content).decode('utf-8'),
        "title": file_name,
        "url": "",
    }
    
    headers = {"Content-Type": "application/json"}
    if jwt_secret:
        now = int(time.time())
        payload_with_iat = {**payload, "iat": now, "exp": now + 3600}
        payload_b64 = base64.urlsafe_b64encode(
            json.dumps(payload_with_iat).encode()
        ).decode().rstrip('=')
        header_b64 = base64.urlsafe_b64encode(
            json.dumps({"alg": "HS256", "typ": "JWT"}).encode()
        ).decode().rstrip('=')
        signature = hmac.new(
            jwt_secret.encode(),
            f"{header_b64}.{payload_b64}".encode(),
            hashlib.sha256
        ).digest()
        signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')
        token = f"{header_b64}.{payload_b64}.{signature_b64}"
        headers["Authorization"] = f"Bearer {token}"
    
    response = requests.post(
        f"{server_url}/ConvertService.ashx",
        json=payload,
        headers=headers,
        timeout=30
    )
    
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": f"请求失败: {response.status_code}"}


def get_conversion_status(task_id: str, server_url: str = "http://localhost:8888") -> dict:
    """
    获取转换任务状态
    
    Returns:
        {"status": str, "progress": int, "result_url": str}
    """
    try:
        response = requests.get(
            f"{server_url}/ConvertService.ashx?targetId={task_id}",
            timeout=10
        )
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        return {"error": str(e)}
    return {"status": "unknown"}

"""
Word文档处理工具 - 读取段落和执行修改
"""
import os
import hashlib
from typing import List, Dict, Any, Optional
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

# 备份目录 - 统一存放所有文档备份
BACKUP_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data", "backups")

def _get_backup_path(original_path: str) -> str:
    """生成备份文件路径（放在统一备份目录）"""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    # 用文件路径的 hash 作为文件名，避免路径过长或特殊字符问题
    path_hash = hashlib.md5(original_path.encode('utf-8')).hexdigest()[:16]
    filename = os.path.basename(original_path)
    return os.path.join(BACKUP_DIR, f"{path_hash}_{filename}.bak")


class ParagraphInfo:
    """段落信息"""
    def __init__(self, index: int, text: str, style: str = None, alignment: str = None):
        self.index = index
        self.text = text
        self.style = style
        self.alignment = alignment
    
    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "text": self.text,
            "style": self.style,
            "alignment": self.alignment
        }


class TableCellInfo:
    """表格单元格信息"""
    def __init__(self, row: int, col: int, text: str, rowspan: int = 1, colspan: int = 1):
        self.row = row
        self.col = col
        self.text = text
        self.rowspan = rowspan
        self.colspan = colspan
    
    def to_dict(self) -> dict:
        return {
            "row": self.row,
            "col": self.col,
            "text": self.text,
            "rowspan": self.rowspan,
            "colspan": self.colspan
        }


class TableInfo:
    """表格信息"""
    def __init__(self, index: int, rows: int, cols: int, cells: List[List[str]], merged_cells: List[Dict] = None):
        self.index = index
        self.rows = rows
        self.cols = cols
        self.cells = cells  # 二维数组形式的单元格文本
        self.merged_cells = merged_cells or []  # 合并单元格信息
    
    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "rows": self.rows,
            "cols": self.cols,
            "cells": self.cells,
            "merged_cells": self.merged_cells
        }


def read_docx_paragraphs(file_path: str) -> Dict[str, Any]:
    """
    读取Word文档，返回段落列表和文档结构
    
    Args:
        file_path: 文件路径
        
    Returns:
        {
            "file_name": str,
            "paragraphs": [ParagraphInfo],
            "tables": [TableInfo],
            "paragraph_count": int,
            "table_count": int
        }
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    # 确保绝对路径
    if not os.path.isabs(file_path):
        file_path = os.path.abspath(file_path)
    
    doc = Document(file_path)
    paragraphs = []
    tables = []
    
    W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    
    # 读取段落
    for idx, para in enumerate(doc.paragraphs):
        text = para.text.strip()
        if text:  # 只保留非空段落
            alignment = None
            if para.alignment == WD_ALIGN_PARAGRAPH.CENTER:
                alignment = "center"
            elif para.alignment == WD_ALIGN_PARAGRAPH.RIGHT:
                alignment = "right"
            elif para.alignment == WD_ALIGN_PARAGRAPH.JUSTIFY:
                alignment = "justify"
            
            paragraphs.append(ParagraphInfo(
                index=idx,
                text=para.text,
                style=para.style.name if para.style else None,
                alignment=alignment
            ))
    
    # 读取表格 - 使用body元素遍历完整文档结构
    body = doc._element.body
    table_index = 0
    
    # 遍历body下的所有直接子元素
    for child in body:
        # 判断是否是表格
        if child.tag.endswith('}tbl'):
            table_elem = child
            
            # 获取gridCol确定列数
            grid_cols = table_elem.findall(f'.//{{{W}}}gridCol')
            cols = len(grid_cols) if grid_cols else 1
            
            # 获取实际行数
            trs = table_elem.findall(f'.//{{{W}}}tr')
            rows = len(trs) if trs else 0
            
            # 提取每个单元格的内容
            cells_matrix = []
            merged_cells_info = []
            
            for row_idx, tr in enumerate(trs):
                row_cells = []
                col_idx = 0
                
                for tc in tr.findall(f'{{{W}}}tc'):
                    # 获取单元格属性
                    tcPr = tc.find(f'{{{W}}}tcPr')
                    rowspan = 1
                    colspan = 1
                    
                    if tcPr is not None:
                        # 检查横向合并（使用 gridSpan 属性，这是最常见的方式）
                        gridSpan = tcPr.find(f'{{{W}}}gridSpan')
                        if gridSpan is not None:
                            val = gridSpan.get(f'{{{W}}}val', '1')
                            colspan = int(val) if val.isdigit() else 1
                        
                        # 也支持旧的 hMerge 属性
                        hMerge = tcPr.find(f'{{{W}}}hMerge')
                        if hMerge is not None:
                            val = hMerge.get(f'{{{W}}}val', 'continue')
                            if val == 'continue':
                                # 继续合并，跳过但增加col_idx
                                col_idx += 1
                                continue
                            elif val != '0' and gridSpan is None:  # 只有没有gridSpan时才处理hMerge
                                colspan = int(val) if val.isdigit() else 1
                        
                        # 检查纵向合并
                        vMerge = tcPr.find(f'{{{W}}}vMerge')
                        if vMerge is not None:
                            val = vMerge.get(f'{{{W}}}val', 'continue')
                            if val == 'continue':
                                # 继续合并，使用上一行的值
                                if row_idx > 0 and col_idx < len(cells_matrix[row_idx - 1]):
                                    row_cells.append(cells_matrix[row_idx - 1][col_idx])
                                col_idx += 1
                                continue
                            elif val != '0':
                                rowspan = int(val) if str(val).isdigit() else 1
                    
                    # 获取单元格文本
                    cell_text = ''
                    for p in tc.iter(f'{{{W}}}p'):
                        para_text = ''
                        for t in p.iter(f'{{{W}}}t'):
                            if t.text:
                                para_text += t.text
                        if para_text:
                            cell_text += para_text + '\n'
                    cell_text = cell_text.strip()
                    
                    # 记录合并信息
                    if rowspan > 1 or colspan > 1:
                        merged_cells_info.append({
                            "row": row_idx,
                            "col": col_idx,
                            "rowspan": rowspan,
                            "colspan": colspan
                        })
                    
                    # 将单元格内容添加到row_cells（只添加一次，后续位置用空字符串补齐）
                    row_cells.append(cell_text)
                    # 记录此单元格跨越的列数，后续位置需要用空字符串补齐
                    for _ in range(colspan - 1):
                        row_cells.append('')
                    col_idx += colspan
                
                # 补齐空单元格
                while len(row_cells) < cols:
                    row_cells.append('')
                
                cells_matrix.append(row_cells)
            
            tables.append(TableInfo(
                index=table_index,
                rows=rows,
                cols=cols,
                cells=cells_matrix,
                merged_cells=merged_cells_info
            ))
            table_index += 1
    
    return {
        "file_name": os.path.basename(file_path),
        "file_path": file_path,
        "paragraphs": [p.to_dict() for p in paragraphs],
        "tables": [t.to_dict() for t in tables],
        "paragraph_count": len(paragraphs),
        "table_count": len(tables)
    }


def apply_docx_modifications(file_path: str, modifications: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    应用修改到Word文档
    
    Args:
        file_path: 文件路径
        modifications: 修改列表，格式：
            段落修改：[{
                "type": "modify|add|delete",
                "index": int,  # 段落索引（优先使用，精确匹配）
                "text": str,  # 原文本（用于定位）
                "new_text": str,  # 新文本（用于modify类型）
                "insert_index": int,  # 插入位置（用于add类型）
                "insert_text": str,  # 插入的文本（用于add类型）
            }]
            表格单元格修改：[{
                "type": "cell_modify|cell_delete",
                "index": str,  # 单元格索引，格式 "t0_r1_c2" (table, row, col)，如 "t0_r1_c2" 表示第0个表格第1行第2列
                OR
                "table_index": int,  # 表格索引（从0开始）
                "row": int,  # 行索引（从0开始）
                "col": int,  # 列索引（从0开始）
                "text": str,  # 原文本（用于定位，可选）
                "new_text": str,  # 新文本（用于cell_modify类型）
            }]
    
    Returns:
        {
            "success": bool,
            "message": str,
            "applied_count": int,
            "failed_count": int,
            "failed_modifications": []
        }
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    if not os.path.isabs(file_path):
        file_path = os.path.abspath(file_path)
    
    # 加载文档
    doc = Document(file_path)
    
    applied_count = 0
    failed_count = 0
    failed_modifications = []
    W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    
    # 辅助函数：在段落中替换文本，保留样式
    def do_replace(para, orig_text, new_txt):
        """在段落中替换文本，保留样式"""
        if para.text == orig_text:
            if para.runs:
                first_run = para.runs[0]
                first_run.text = new_txt
                for run in para.runs[1:]:
                    run.text = ""
            else:
                para.text = new_txt
        else:
            remaining = orig_text
            for run in para.runs:
                if not remaining:
                    break
                if remaining in run.text:
                    run.text = run.text.replace(remaining, new_txt)
                    remaining = ""
                else:
                    if run.text in remaining:
                        remaining = remaining.replace(run.text, "", 1)
            if remaining:
                return False
        return True
    
    # 辅助函数：获取表格元素
    def get_table_element(doc, table_index):
        """获取指定索引的表格元素"""
        body = doc._element.body
        table_count = 0
        for child in body:
            if child.tag.endswith('}tbl'):
                if table_count == table_index:
                    return child
                table_count += 1
        return None
    
    # 辅助函数：设置单元格文本（保留格式，支持多段落换行）
    def set_cell_text(tc, new_text):
        """
        设置单元格文本，保留原有格式，支持多段落换行
        换行符 \\n 会创建新的段落
        """
        from docx.oxml import OxmlElement
        from copy import deepcopy
        
        # 获取原有段落的样式信息（如果有）
        first_para = tc.find(f'{{{W}}}p')
        pPr_copy = None
        if first_para is not None:
            pPr = first_para.find(f'{{{W}}}pPr')
            if pPr is not None:
                pPr_copy = deepcopy(pPr)
        
        # 删除所有现有段落
        for p in tc.findall(f'{{{W}}}p'):
            tc.remove(p)
        
        # 将文本按换行符分割成多行
        lines = new_text.split('\n')
        
        for line in lines:
            new_para = OxmlElement('w:p')
            # 复制原有段落样式
            if pPr_copy is not None:
                new_para.append(deepcopy(pPr_copy))
            
            # 创建run和文本
            new_run = OxmlElement('w:r')
            new_text_elem = OxmlElement('w:t')
            new_text_elem.text = line
            # 保留空格
            new_text_elem.set(f'{{{W}}}space', 'preserve')
            new_run.append(new_text_elem)
            new_para.append(new_run)
            tc.append(new_para)
    
    # 辅助函数：替换单元格中的占位符文本（保留格式）
    def replace_in_cell(tc, original_text, new_text):
        """
        替换单元格中的占位符文本，保留原有格式（字体、大小、加粗等）
        """
        from docx.oxml import OxmlElement
        from copy import deepcopy
        
        # 获取原始单元格文本
        original_cell_text = get_cell_text(tc)
        
        # 如果原文本不在单元格中，直接返回
        if original_text not in original_cell_text:
            return False
        
        replaced = False
        
        # 遍历所有段落中的所有 run，查找并替换包含占位符的文本
        for p in tc.findall(f'{{{W}}}p'):
            for r in p.findall(f'{{{W}}}r'):
                # 获取 run 中的所有文本元素
                text_elements = r.findall(f'{{{W}}}t')
                if not text_elements:
                    continue
                
                # 合并 run 中的所有文本（run 可能包含多个 t 元素）
                run_full_text = ''.join(t.text or '' for t in text_elements)
                
                if original_text in run_full_text:
                    # 找到了包含占位符的 run，需要替换
                    
                    # 保留原始 run 的属性 (rPr)
                    rPr = r.find(f'{{{W}}}rPr')
                    
                    # 如果占位符跨越多个 t 元素，需要特殊处理
                    if run_full_text == original_text:
                        # 简单情况：整个 run 就是占位符
                        if len(text_elements) == 1:
                            text_elements[0].text = new_text
                        else:
                            # 保留第一个 t 元素，删除其余的
                            text_elements[0].text = new_text
                            for t in text_elements[1:]:
                                r.remove(t)
                    else:
                        # 复杂情况：run 中只有部分是占位符
                        # 需要将 run 拆分成多个 run
                        idx = run_full_text.find(original_text)
                        before_text = run_full_text[:idx]
                        after_text = run_full_text[idx + len(original_text):]
                        
                        # 创建替换后的 run
                        if len(text_elements) == 1:
                            # 简单情况：只有一个 t 元素
                            t = text_elements[0]
                            t.text = before_text + new_text + after_text
                        else:
                            # 复杂情况：需要重新组织 t 元素
                            # 清空所有 t 元素，重新设置
                            all_text = before_text + new_text + after_text
                            first_t = text_elements[0]
                            first_t.text = all_text
                            # 删除多余的 t 元素
                            for t in text_elements[1:]:
                                r.remove(t)
                    
                    replaced = True
                    break  # 只替换第一个匹配的占位符
        
        return replaced
        
        return True
    
    # 辅助函数：获取单元格文本
    def get_cell_text(tc):
        """获取单元格中的文本"""
        text = ''
        for p in tc.iter(f'{{{W}}}p'):
            para_text = ''
            for t in p.iter(f'{{{W}}}t'):
                if t.text:
                    para_text += t.text
            if para_text:
                text += para_text + '\n'
        return text.strip()
    
    # 辅助函数：解析单元格索引 "t2_r0_c1" -> (table_index, row, col)
    def parse_cell_index(index_str):
        """
        解析单元格索引字符串
        支持格式：
        - "t2_r0_c1" -> (2, 0, 1)
        - "t0_r1_c2" -> (0, 1, 2)
        """
        import re
        match = re.match(r't(\d+)_r(\d+)_c(\d+)', index_str)
        if match:
            return int(match.group(1)), int(match.group(2)), int(match.group(3))
        return None, None, None
    
    for mod in modifications:
        try:
            mod_type = mod.get("type")
            
            # ============== 表格单元格修改 ==============
            if mod_type in ["cell_modify", "cell_delete"]:
                # 优先使用 index 字段（如 "t2_r0_c1"），否则使用单独的字段
                index_str = mod.get("index")
                if index_str:
                    table_index, row, col = parse_cell_index(str(index_str))
                    if table_index is None:
                        failed_count += 1
                        failed_modifications.append({
                            "modification": mod,
                            "reason": f"无效的单元格索引格式: {index_str}，正确格式如: t2_r0_c1"
                        })
                        continue
                else:
                    table_index = mod.get("table_index")
                    row = mod.get("row")
                    col = mod.get("col")
                
                original_text = mod.get("text", "")
                new_text = mod.get("new_text", "")
                
                if table_index is None or row is None or col is None:
                    failed_count += 1
                    failed_modifications.append({
                        "modification": mod,
                        "reason": "cell_modify/cell_delete 需要提供 index 参数 (如: t2_r0_c1) 或 table_index, row, col 参数"
                    })
                    continue
                
                # 获取表格
                table_elem = get_table_element(doc, table_index)
                if table_elem is None:
                    failed_count += 1
                    failed_modifications.append({
                        "modification": mod,
                        "reason": f"表格索引 {table_index} 不存在"
                    })
                    continue
                
                # 获取所有行
                rows = table_elem.findall(f'.//{{{W}}}tr')
                if row < 0 or row >= len(rows):
                    failed_count += 1
                    failed_modifications.append({
                        "modification": mod,
                        "reason": f"行索引 {row} 超出范围（表格共有 {len(rows)} 行）"
                    })
                    continue
                
                # 获取指定行的所有单元格
                tr = rows[row]
                cells = tr.findall(f'{{{W}}}tc')
                
                # 遍历单元格找到对应列（考虑合并单元格）
                target_cell = None
                current_col = 0
                cell_debug_info = []  # 调试信息
                
                for cell in cells:
                    tcPr = cell.find(f'{{{W}}}tcPr')
                    skip_this = False
                    cell_colspan = 1  # 默认colspan为1
                    
                    if tcPr is not None:
                        # 首先检查 gridSpan（最常用的横向合并方式）
                        gridSpan = tcPr.find(f'{{{W}}}gridSpan')
                        if gridSpan is not None:
                            val = gridSpan.get(f'{{{W}}}val', '1')
                            cell_colspan = int(val) if val.isdigit() else 1
                        
                        # 也支持旧的 hMerge 属性
                        hMerge = tcPr.find(f'{{{W}}}hMerge')
                        if hMerge is not None:
                            val = hMerge.get(f'{{{W}}}val', 'continue')
                            if val == 'continue':
                                current_col += 1
                                skip_this = True
                    
                    # 记录单元格信息用于调试
                    cell_text_preview = get_cell_text(cell)[:15].replace('\n', ' ')
                    cell_debug_info.append(f"col={current_col}(span={cell_colspan})'{cell_text_preview}...'")
                    
                    if skip_this:
                        continue
                    
                    # 检查目标列是否在当前单元格的跨度范围内
                    if current_col <= col < current_col + cell_colspan:
                        target_cell = cell
                        break
                    # 移动到下一个可用列位置（考虑当前单元格的colspan）
                    current_col += cell_colspan
                
                if target_cell is None:
                    reason = f"列索引 {col} 超出范围（行有 {len(cells)} 个单元格，逻辑列追踪到 {current_col}）"
                    print(f"[apply_docx_modifications] ⚠️ {reason}")
                    print(f"  调试信息: 查找 index={index_str}, row={row}, col={col}")
                    print(f"  行单元格: {' | '.join(cell_debug_info)}")
                    failed_count += 1
                    failed_modifications.append({
                        "modification": mod,
                        "reason": reason
                    })
                    continue
                
                # 检查原文本是否在单元格中（单元格可能包含多个占位符）
                cell_text = get_cell_text(target_cell)
                if original_text and original_text not in cell_text:
                    failed_count += 1
                    failed_modifications.append({
                        "modification": mod,
                        "reason": f"单元格({row},{col})原文不匹配：期望「{original_text[:30]}...」，实际「{cell_text[:50]}...」"
                    })
                    continue
                
                # 执行修改
                if mod_type == "cell_modify":
                    # 使用 replace_in_cell 只替换占位符，保留其他内容
                    if replace_in_cell(target_cell, original_text, new_text):
                        applied_count += 1
                    else:
                        # 如果 replace_in_cell 失败（可能占位符格式略有不同），使用 set_cell_text 作为后备
                        set_cell_text(target_cell, cell_text.replace(original_text, new_text, 1))
                        applied_count += 1
                elif mod_type == "cell_delete":
                    # 删除操作也使用 replace_in_cell
                    if original_text:
                        replace_in_cell(target_cell, original_text, "")
                    else:
                        set_cell_text(target_cell, "")
                    applied_count += 1
            
            # ============== 段落修改 ==============
            elif mod_type == "modify":
                new_text = mod.get("new_text", "")
                idx = mod.get("index")
                original_text = mod.get("text", "")
                
                if idx is not None and 0 <= idx < len(doc.paragraphs):
                    para = doc.paragraphs[idx]
                    if original_text and para.text != original_text:
                        if original_text not in para.text:
                            failed_count += 1
                            failed_modifications.append({
                                "modification": mod,
                                "reason": f"索引{idx}处原文不匹配：期望「{original_text[:20]}...」，实际「{para.text[:20]}...」"
                            })
                            continue
                    
                    if do_replace(para, original_text or para.text, new_text):
                        applied_count += 1
                    else:
                        failed_count += 1
                        failed_modifications.append({"modification": mod, "reason": "替换失败"})
                else:
                    found = False
                    for para in doc.paragraphs:
                        if original_text in para.text:
                            if do_replace(para, original_text, new_text):
                                found = True
                                applied_count += 1
                                break
                    
                    if not found:
                        failed_count += 1
                        failed_modifications.append({"modification": mod, "reason": "未找到匹配的原文"})
            
            elif mod_type == "delete":
                idx = mod.get("index")
                original_text = mod.get("text", "")
                
                if idx is not None and 0 <= idx < len(doc.paragraphs):
                    para = doc.paragraphs[idx]
                    if original_text and para.text != original_text:
                        if original_text not in para.text:
                            failed_count += 1
                            failed_modifications.append({
                                "modification": mod,
                                "reason": f"索引{idx}处原文不匹配"
                            })
                            continue
                    para.text = ""
                    applied_count += 1
                else:
                    found = False
                    for i, para in enumerate(doc.paragraphs):
                        if original_text in para.text:
                            para.text = ""
                            found = True
                            applied_count += 1
                            break
                    
                    if not found:
                        failed_count += 1
                        failed_modifications.append({
                            "modification": mod,
                            "reason": "未找到匹配的原文"
                        })
            
            elif mod_type == "add":
                insert_index = mod.get("insert_index", -1)
                insert_text = mod.get("insert_text", "")
                
                if insert_index >= 0 and insert_index < len(doc.paragraphs):
                    ref_para = doc.paragraphs[insert_index]
                    ref_para.insert_paragraph_before(insert_text)
                    applied_count += 1
                else:
                    doc.add_paragraph(insert_text)
                    applied_count += 1
            
            else:
                failed_count += 1
                failed_modifications.append({
                    "modification": mod,
                    "reason": f"不支持的修改类型: {mod_type}"
                })
                
        except Exception as e:
            failed_count += 1
            failed_modifications.append({
                "modification": mod,
                "reason": str(e)
            })
    
    # 保存文档
    if applied_count > 0:
        backup_path = _get_backup_path(file_path)
        if os.path.exists(file_path):
            import shutil
            shutil.copy2(file_path, backup_path)
        
        doc.save(file_path)
    
    # 打印详细的失败信息用于调试
    if failed_count > 0:
        print(f"[apply_docx_modifications] 失败数量: {failed_count}/{applied_count + failed_count}")
        for i, fail in enumerate(failed_modifications[:10]):  # 最多打印10条
            mod = fail.get("modification", {})
            print(f"  [{i+1}] 类型={mod.get('type')}, 索引={mod.get('index')}, 原文={mod.get('text', '')[:30]}, 原因={fail.get('reason', '')[:50]}")
        if len(failed_modifications) > 10:
            print(f"  ... 还有 {len(failed_modifications) - 10} 条失败记录")
    
    return {
        "success": failed_count == 0,
        "message": "修改完成" if failed_count == 0 else f"部分修改失败",
        "applied_count": applied_count,
        "failed_count": failed_count,
        "failed_modifications": failed_modifications,
        "backup_path": backup_path if applied_count > 0 else None
    }


def get_paragraph_by_index(file_path: str, index: int) -> Optional[Dict[str, Any]]:
    """
    获取指定索引的段落信息
    
    Args:
        file_path: 文件路径
        index: 段落索引
        
    Returns:
        段落信息字典，如果索引无效返回None
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    if not os.path.isabs(file_path):
        file_path = os.path.abspath(file_path)
    
    doc = Document(file_path)
    
    if index < 0 or index >= len(doc.paragraphs):
        return None
    
    para = doc.paragraphs[index]
    return {
        "index": index,
        "text": para.text,
        "style": para.style.name if para.style else None,
        "alignment": str(para.alignment) if para.alignment else None
    }


def restore_from_backup(file_path: str, keep_backup: bool = True) -> Dict[str, Any]:
    """
    从备份文件恢复文档
    
    Args:
        file_path: 原文件路径
        keep_backup: 是否保留备份文件（默认True）
        
    Returns:
        {
            "success": bool,
            "message": str,
            "restored_path": str or None
        }
    """
    if not os.path.isabs(file_path):
        file_path = os.path.abspath(file_path)
    
    backup_path = _get_backup_path(file_path)
    
    if not os.path.exists(backup_path):
        return {
            "success": False,
            "message": f"未找到备份文件: {backup_path}",
            "restored_path": None
        }
    
    try:
        import shutil
        
        if keep_backup:
            # 保留备份，将备份内容恢复到原文件
            shutil.copy2(backup_path, file_path)
        else:
            # 删除备份，将备份内容恢复到原文件
            shutil.copy2(backup_path, file_path)
            os.remove(backup_path)
        
        return {
            "success": True,
            "message": "恢复成功",
            "restored_path": file_path,
            "backup_removed": not keep_backup
        }
        
    except Exception as e:
        return {
            "success": False,
            "message": f"恢复失败: {str(e)}",
            "restored_path": None
        }


def get_backup_info(file_path: str) -> Dict[str, Any]:
    """
    获取备份文件信息
    
    Args:
        file_path: 原文件路径
    
    Returns:
        {
            "has_backup": bool,
            "backup_path": str,
            "backup_exists": bool,
            "backup_size": int or None,
            "backup_modified_time": str or None
        }
    """
    if not os.path.isabs(file_path):
        file_path = os.path.abspath(file_path)
    
    backup_path = _get_backup_path(file_path)
    backup_exists = os.path.exists(backup_path)
    
    result = {
        "has_backup": backup_exists,
        "backup_path": backup_path,
        "backup_exists": backup_exists,
        "backup_size": None,
        "backup_modified_time": None
    }
    
    if backup_exists:
        import datetime
        stat = os.stat(backup_path)
        result["backup_size"] = stat.st_size
        result["backup_modified_time"] = datetime.datetime.fromtimestamp(
            stat.st_mtime
        ).strftime("%Y-%m-%d %H:%M:%S")
    
    return result

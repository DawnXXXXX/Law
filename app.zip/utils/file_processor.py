"""
文件处理工具
支持 OnlyOffice Document Server 和 python-docx 两种方式处理 Word 文档
"""
import os
from typing import Optional
from .onlyoffice_converter import OnlyOfficeConverter


def extract_text_from_file(file_path: str, file_ext: str) -> str:
    """从各种格式的文件中提取文本内容"""
    try:
        # 确保路径是绝对路径
        if not os.path.isabs(file_path):
            file_path = os.path.abspath(file_path)
        
        if file_ext == 'txt':
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        
        elif file_ext == 'docx':
            return extract_from_docx(file_path)
        
        elif file_ext == 'pdf':
            return extract_from_pdf(file_path)
        
        elif file_ext in ['png', 'jpg', 'jpeg']:
            return "[图片文件，无法直接提取文本]"
        
        else:
            return "[不支持的文件格式]"
    
    except Exception as e:
        return f"[文件读取错误: {str(e)}]"


def extract_html_from_docx(file_path: str, use_onlyoffice: bool = True) -> str:
    """
    从 Word 文档提取带格式的 HTML 内容
    
    优先使用 OnlyOffice Document Server（更好的格式还原），失败则使用 python-docx
    
    Args:
        file_path: 文件路径
        use_onlyoffice: 是否优先使用 OnlyOffice
    """
    # 确保路径是绝对路径
    if not os.path.isabs(file_path):
        file_path = os.path.abspath(file_path)
    
    # 尝试使用 OnlyOffice
    if use_onlyoffice:
        html = _extract_html_via_onlyoffice(file_path)
        if html:
            return html
    
    # 回退到 python-docx
    return _extract_html_via_python_docx(file_path)


def _extract_html_via_onlyoffice(file_path: str) -> Optional[str]:
    """通过 OnlyOffice Document Server 转换文档为 HTML"""
    try:
        # 动态导入配置
        try:
            from ..config import settings
            server_url = settings.ONLYOFFICE_SERVER_URL
            jwt_secret = settings.ONLYOFFICE_JWT_SECRET if settings.ONLYOFFICE_ENABLED else None
        except ImportError:
            server_url = "http://localhost:8888"
            jwt_secret = None
        
        converter = OnlyOfficeConverter(
            server_url=server_url,
            jwt_secret=jwt_secret
        )
        
        # 检查服务是否可用
        if not converter.is_available():
            print("OnlyOffice 服务不可用，回退到 python-docx")
            return None
        
        # 转换文件
        output_path = converter.convert_file(file_path, output_format="html")
        
        if output_path and os.path.exists(output_path):
            with open(output_path, 'r', encoding='utf-8') as f:
                html_content = f.read()
            
            # 包装成完整 HTML 文档（如果需要）
            if not html_content.strip().startswith('<!DOCTYPE') and not html_content.strip().startswith('<html'):
                html_content = f'''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
body {{ 
    font-family: 'Microsoft YaHei', 'SimSun', Arial, sans-serif; 
    font-size: 14px; 
    line-height: 1.8;
}}
table {{
    border-collapse: collapse;
    width: 100%;
    margin: 16px 0;
}}
table, table th, table td {{
    border: 1px solid #333;
    padding: 8px;
}}
</style>
</head>
<body>
{html_content}
</body>
</html>'''
            
            # 清理临时文件
            try:
                os.remove(output_path)
            except:
                pass
            
            return html_content
        
        return None
        
    except Exception as e:
        print(f"OnlyOffice 转换失败: {str(e)}")
        return None


def _extract_html_via_python_docx(file_path: str) -> str:
    """使用 python-docx 提取 HTML（备选方案）"""
    try:
        from docx import Document
        from docx.shared import Pt, Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
        
        doc = Document(file_path)
        
        def get_cell_html(cell) -> str:
            """获取单元格的 HTML 内容"""
            cell_html_parts = []
            for para in cell.paragraphs:
                para_text = ''
                for run in para.runs:
                    text = run.text or ''
                    if run.bold:
                        text = f'<strong>{text}</strong>'
                    if run.italic:
                        text = f'<em>{text}</em>'
                    if run.underline:
                        text = f'<u>{text}</u>'
                    para_text += text
                if para_text.strip():
                    alignment = para.alignment
                    if alignment == WD_ALIGN_PARAGRAPH.CENTER:
                        cell_html_parts.append(f'<p style="text-align:center">{para_text}</p>')
                    elif alignment == WD_ALIGN_PARAGRAPH.RIGHT:
                        cell_html_parts.append(f'<p style="text-align:right">{para_text}</p>')
                    else:
                        cell_html_parts.append(f'<p>{para_text}</p>')
            return ''.join(cell_html_parts) or '<p></p>'
        
        def get_para_html(para) -> str:
            """获取段落的 HTML 内容"""
            if not para.text.strip():
                return '<p>&nbsp;</p>'
            
            para_text = ''
            for run in para.runs:
                text = run.text or ''
                if run.bold:
                    text = f'<strong>{text}</strong>'
                if run.italic:
                    text = f'<em>{text}</em>'
                if run.underline:
                    text = f'<u>{text}</u>'
                para_text += text
            
            # 获取样式
            style_name = para.style.name if para.style else 'Normal'
            
            if style_name.startswith('Heading'):
                level = style_name[-1] if style_name[-1].isdigit() else '1'
                heading_styles = {
                    '1': 'font-size:22px;border-bottom:2px solid #333;padding-bottom:8px;margin:16px 0 8px 0;color:#1a1a1a;',
                    '2': 'font-size:18px;margin:16px 0 8px 0;color:#1a1a1a;',
                    '3': 'font-size:16px;margin:16px 0 8px 0;color:#1a1a1a;',
                }
                h_style = heading_styles.get(level, 'margin:16px 0 8px 0;color:#1a1a1a;')
                return f'<h{level} style="{h_style}">{para_text}</h{level}>\n'
            elif style_name in ['Quote', 'Intense Quote', 'Block Text']:
                return f'<blockquote style="border-left:4px solid #ccc;padding:8px 16px;margin:12px 0;background:#f9f9f9;color:#555;">{para_text}</blockquote>\n'
            elif style_name == 'List Paragraph':
                return f'<li style="margin:4px 0;">{para_text}</li>\n'
            else:
                alignment = para.alignment
                if alignment == WD_ALIGN_PARAGRAPH.CENTER:
                    return f'<p style="text-align:center;margin:8px 0;">{para_text}</p>\n'
                elif alignment == WD_ALIGN_PARAGRAPH.RIGHT:
                    return f'<p style="text-align:right;margin:8px 0;">{para_text}</p>\n'
                else:
                    return f'<p style="margin:8px 0;">{para_text}</p>\n'
        
        def get_table_html(table) -> str:
            """获取表格的 HTML 内容"""
            rows = table.rows
            if not rows:
                return ''
            
            html = ['<table style="border-collapse:collapse;width:100%;margin:16px 0;font-size:13px;table-layout:fixed;border:1px solid #333;">\n']
            
            # 收集所有行（使用原始 XML 遍历避免合并单元格重复）
            for row_idx, row in enumerate(rows):
                html.append('  <tr>\n')
                
                # 直接遍历行中的 tc (table cell) 元素
                tr = row._tr
                for tc in tr.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}tc'):
                    # 获取单元格内容
                    cell_elem = tc
                    paragraphs = cell_elem.findall('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p')
                    
                    cell_html_parts = []
                    for para in paragraphs:
                        para_text = ''
                        for r in para.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'):
                            text = r.text or ''
                            # 检查父元素的格式
                            rPr = r.getparent().getparent() if r.getparent() is not None else None
                            if rPr is not None:
                                b = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}b')
                                i = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}i')
                                u = rPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}u')
                                if b is not None:
                                    text = f'<strong>{text}</strong>'
                                if i is not None:
                                    text = f'<em>{text}</em>'
                                if u is not None:
                                    text = f'<u>{text}</u>'
                            para_text += text
                        
                        # 检查段落对齐
                        pPr = para.getparent().getparent() if para.getparent() is not None else None
                        alignment = 'left'
                        if pPr is not None:
                            jc = pPr.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}jc')
                            if jc is not None:
                                val = jc.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                                if val == 'center':
                                    alignment = 'center'
                                elif val == 'right':
                                    alignment = 'right'
                                elif val == 'both':
                                    alignment = 'justify'
                        
                        if para_text.strip():
                            cell_html_parts.append(f'<p style="text-align:{alignment}">{para_text}</p>')
                    
                    cell_html = ''.join(cell_html_parts) or '<p></p>'
                    
                    # 检查跨列跨行
                    tcPr = cell_elem.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}tcPr')
                    grid_span = ''
                    row_span = ''
                    if tcPr is not None:
                        gridSpan = tcPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}gridSpan')
                        if gridSpan is not None:
                            span = gridSpan.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                            if span and int(span) > 1:
                                grid_span = f' colspan="{span}"'
                        vMerge = tcPr.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}vMerge')
                        if vMerge is not None:
                            val = vMerge.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                            if val == 'continue':
                                continue  # 跳过被合并的单元格
                    
                    # 判断是否是表头行
                    is_header = row_idx == 0
                    tag = 'th' if is_header else 'td'
                    if is_header:
                        cell_style = 'background:#f0f0f0;font-weight:bold;text-align:center;'
                    else:
                        cell_style = ''
                    
                    html.append(f'    <{tag}{grid_span}{row_span} style="border:1px solid #333;padding:8px 10px;vertical-align:top;text-align:left;word-wrap:break-word;{cell_style}">{cell_html}</{tag}>\n')
                
                html.append('  </tr>\n')
            
            html.append('</table>\n')
            return ''.join(html)
        
        # 构建 HTML
        html_parts = []
        
        # 获取文档所有元素（交替段落和表格）
        doc_element = doc.element.body
        
        # 分离段落和表格
        paras = doc.paragraphs
        tables = doc.tables
        
        # 方法1: 按文档顺序交替处理
        para_idx = 0
        table_idx = 0
        para_count = len(paras)
        table_count = len(tables)
        
        # 遍历 body 的子元素
        for child in doc_element:
            tag_name = child.tag.split('}')[-1] if '}' in child.tag else child.tag
            
            if tag_name == 'p':
                if para_idx < para_count:
                    html_parts.append(get_para_html(paras[para_idx]))
                    para_idx += 1
            elif tag_name == 'tbl':
                if table_idx < table_count:
                    html_parts.append(get_table_html(tables[table_idx]))
                    table_idx += 1
        
        # 组合完整 HTML
        html_content = ''.join(html_parts)
        
        # 返回带内联样式的 body 片段（供 v-html 直接渲染）
        body_style = "font-family:'Microsoft YaHei','SimSun','Times New Roman',Arial,sans-serif;font-size:14px;line-height:1.8;color:#333;"
        styled_html = f'<div style="{body_style}">\n{html_content}\n</div>'
        return styled_html
        
    except ImportError:
        return "[需要安装 python-docx 库来读取 Word 文档]"
    except Exception as e:
        return f"[Word文档读取错误: {str(e)}]"


def extract_from_docx(file_path: str) -> str:
    """从 Word 文档提取纯文本"""
    try:
        from docx import Document
        doc = Document(file_path)
        text = []
        for para in doc.paragraphs:
            text.append(para.text)
        
        # 提取表格内容
        for table in doc.tables:
            for row in table.rows:
                row_text = [cell.text for cell in row.cells]
                text.append(' | '.join(row_text))
        
        return '\n'.join(text)
    except ImportError:
        return "[需要安装 python-docx 库来读取 Word 文档]"


def extract_from_pdf(file_path: str) -> str:
    """从 PDF 文件提取文本"""
    try:
        from PyPDF2 import PdfReader
        reader = PdfReader(file_path)
        text = []
        for page in reader.pages:
            text.append(page.extract_text())
        return '\n'.join(text)
    except ImportError:
        return "[需要安装 PyPDF2 库来读取 PDF 文件]"


def extract_from_image(file_path: str) -> str:
    """从图片提取文本（OCR）"""
    # TODO: 实现 OCR 功能
    return "[图片文件，建议使用 OCR 功能提取文本]"

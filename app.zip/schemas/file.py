"""
文件相关 Schema
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class FileBase(BaseModel):
    """文件基础"""
    name: str = Field(..., min_length=1, max_length=255)


class FileCreate(FileBase):
    """创建文件"""
    project_id: int
    folder_id: Optional[int] = None
    content: Optional[str] = None


class FileUpdate(BaseModel):
    """更新文件"""
    content: Optional[str] = None
    version_note: Optional[str] = None


class FileResponse(BaseModel):
    """文件响应"""
    file_id: int = Field(..., alias="id")
    project_id: int
    folder_id: Optional[int] = None
    name: str
    file_type: str
    size: int = 0
    summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class FileContentResponse(BaseModel):
    """文件内容响应"""
    content: str
    file_name: str


class FileUploadResponse(BaseModel):
    """文件上传响应"""
    file_id: int
    name: str
    summary: Optional[str] = None
    size: int


class FolderCreate(BaseModel):
    """创建文件夹"""
    name: str = Field(..., min_length=1, max_length=255)
    parent_id: Optional[int] = None


class FolderResponse(BaseModel):
    """文件夹响应"""
    id: int
    project_id: int
    parent_id: Optional[int] = None
    name: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class FolderUpdate(BaseModel):
    """更新文件夹"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    parent_id: Optional[int] = None  # 移动到指定文件夹，None表示移到根目录


class FileMoveRequest(BaseModel):
    """移动文件请求"""
    target_folder_id: Optional[int] = None  # 目标文件夹，None表示移到根目录


class FolderMoveRequest(BaseModel):
    """移动文件夹请求"""
    target_parent_id: Optional[int] = None  # 目标父文件夹，None表示移到根目录


# ========== 摘要相关 Schema ==========

class SummaryCreate(BaseModel):
    """创建摘要"""
    content: str = Field(..., min_length=1)
    created_by: Optional[str] = "AI"


class SummaryUpdate(BaseModel):
    """更新摘要"""
    content: str = Field(..., min_length=1)
    created_by: Optional[str] = "AI"


class SummaryResponse(BaseModel):
    """摘要响应"""
    id: int
    file_id: int
    content: str
    version: int
    created_by: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True

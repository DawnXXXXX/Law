"""
AI工具相关 Schema
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class AiToolBase(BaseModel):
    """AI工具基础"""
    name: str
    display_name: str
    description: Optional[str] = None
    category: str


class AiToolCreate(AiToolBase):
    """创建AI工具"""
    pass


class AiToolUpdate(BaseModel):
    """更新AI工具"""
    enabled: Optional[int] = None
    display_name: Optional[str] = None
    description: Optional[str] = None


class AiToolResponse(BaseModel):
    """AI工具响应"""
    id: int
    name: str
    display_name: str
    description: Optional[str] = None
    category: str
    enabled: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class AiToolListResponse(BaseModel):
    """AI工具列表响应"""
    tools: List[AiToolResponse]
    total: int

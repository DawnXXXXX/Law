"""
知识库相关 Schema
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class CategoryBase(BaseModel):
    """分类基础"""
    name: str = Field(..., min_length=1, max_length=255)


class CategoryCreate(CategoryBase):
    """创建分类"""
    parent_id: Optional[int] = None


class CategoryResponse(BaseModel):
    """分类响应"""
    id: int
    name: str
    parent_id: Optional[int] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class DocumentBase(BaseModel):
    """文档基础"""
    title: str = Field(..., min_length=1, max_length=255)


class DocumentCreate(DocumentBase):
    """创建/收藏文档"""
    category_id: Optional[int] = None
    content: Optional[str] = None
    doc_type: str = "law"  # law, case, template
    file_path: Optional[str] = None
    law_id: Optional[str] = None
    notes: Optional[str] = None


class DocumentResponse(BaseModel):
    """文档响应"""
    document_id: int = Field(..., alias="id")
    category_id: Optional[int] = None
    title: str
    doc_type: str
    notes: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class KnowledgeSearchRequest(BaseModel):
    """知识库搜索请求"""
    keyword: str = Field(..., min_length=1)
    doc_type: Optional[str] = None


class LawCollectionRequest(BaseModel):
    """收藏法条请求"""
    law_id: Optional[str] = None
    title: str = Field(..., min_length=1, max_length=255)
    content: Optional[str] = None
    publisher: Optional[str] = None
    publish_date: Optional[str] = None
    notes: Optional[str] = None

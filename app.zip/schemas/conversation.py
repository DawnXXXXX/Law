"""
对话相关 Schema
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class ConversationBase(BaseModel):
    """对话基础"""
    title: Optional[str] = None


class ConversationCreate(ConversationBase):
    """创建对话"""
    project_id: Optional[int] = None


class ConversationResponse(BaseModel):
    """对话响应"""
    conversation_id: int = Field(..., alias="id")
    project_id: Optional[int] = None
    title: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class MessageCreate(BaseModel):
    """发送消息"""
    project_id: Optional[int] = None
    conversation_id: Optional[int] = None
    message: str = Field(..., min_length=1)
    attached_file_ids: Optional[List[int]] = None


class MessageResponse(BaseModel):
    """消息响应"""
    message_id: int = Field(..., alias="id")
    conversation_id: int
    role: str
    content: str
    workflow_state: Optional[dict] = None  # 工作流状态
    created_at: datetime
    
    class Config:
        from_attributes = True


class ChatRequest(BaseModel):
    """聊天请求"""
    project_id: Optional[int | str] = Field(default=None, description="项目ID")
    conversation_id: Optional[int | str] = Field(default=None, description="会话ID")
    # message 允许为空字符串，以支持 Widget 点击操作（如模板选择按钮）
    message: str = Field(default="")
    # attached_file_ids 支持整数ID或文件名字符串
    attached_file_ids: Optional[List[int | str]] = None
    collected_params: Optional[dict] = None  # 收集的表单参数
    workflow_state: Optional[dict] = None  # 工作流状态（用于多轮对话）


class ChatResponse(BaseModel):
    """聊天响应（非流式）"""
    message_id: int
    role: str = "assistant"
    content: str
    file_refs: Optional[List[dict]] = None
    task_id: Optional[str] = None
    widget: Optional[dict] = None  # UI Widget 配置

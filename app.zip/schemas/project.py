"""
项目相关 Schema
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class FileTreeItem(BaseModel):
    """文件树项"""
    id: str  # 使用路径作为标识符
    name: str
    type: str  # "directory" or "file"
    path: Optional[str] = None  # 文件/文件夹的相对路径
    mime: Optional[str] = None
    size: Optional[int] = None
    summary: Optional[str] = None
    updated_at: Optional[datetime] = None
    children: Optional[List["FileTreeItem"]] = None
    
    class Config:
        from_attributes = True


class ProjectBase(BaseModel):
    """项目基础"""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None


class ProjectCreate(ProjectBase):
    """创建项目"""
    pass


class ProjectUpdate(BaseModel):
    """更新项目"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    status: Optional[str] = None
    summary: Optional[str] = None


class ProjectResponse(BaseModel):
    """项目响应"""
    project_id: int = Field(..., alias="id")
    name: str
    description: Optional[str] = None
    status: str = "active"
    summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class ProjectDetailResponse(ProjectResponse):
    """项目详情响应（包含文件树）"""
    file_tree: List[FileTreeItem] = []


class ProjectListResponse(BaseModel):
    """项目列表响应"""
    total: int
    items: List[ProjectResponse]


# 解决前向引用
FileTreeItem.model_rebuild()

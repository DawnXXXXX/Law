"""
Law Studio - FastAPI 应用入口
"""
import sys
import io
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from .config import settings
from .database import init_db
from .routers import (
    projects_router,
    files_router,
    chat_router,
    knowledge_router,
    ai_tools_router,
    agent_router,
    plugins_router,
    templates_router
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动时初始化数据库
    init_db()
    print("[OK] Database initialized")
    yield
    # 关闭时的清理工作（如有需要）
    print("[BYE] App closing")


# 创建 FastAPI 应用
app = FastAPI(
    title="Law Studio 法律助手平台",
    version=settings.APP_VERSION,
    description="专业法律AI助手平台 API 接口文档",
    docs_url="/docs",
    redoc_url=None,  # 禁用 ReDoc
    openapi_url="/openapi.json",  # OpenAPI JSON 地址
    lifespan=lifespan
)

# 配置 CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(projects_router)
app.include_router(files_router)
app.include_router(chat_router)
app.include_router(knowledge_router)
app.include_router(ai_tools_router)
app.include_router(agent_router)
app.include_router(plugins_router)
app.include_router(templates_router)


@app.get("/")
async def root():
    """根路径"""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs"
    }


@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "healthy"}

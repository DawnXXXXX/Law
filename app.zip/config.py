"""
Law Studio - 法律AI助手平台后端配置
"""
from pydantic_settings import BaseSettings
from typing import Optional
import os

# 获取项目根目录
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class Settings(BaseSettings):
    """应用配置"""
    
    # 应用配置
    APP_NAME: str = "Law Studio"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # 服务器配置
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # 数据库配置
    DATABASE_URL: str = f"sqlite+aiosqlite:///{os.path.join(BASE_DIR, 'data', 'lawstudio.db').replace(os.sep, '/')}"
    
    # 文件存储配置（使用绝对路径）
    UPLOAD_DIR: str = os.path.join(BASE_DIR, "data", "uploads")
    MAX_FILE_SIZE: int = 10 * 1024 * 1024  # 10MB
    
    # CodeBuddy Agent SDK 配置
    # CodeBuddy Agent SDK 配置
    CODEBUDDY_API_KEY: Optional[str] = None
    CODEBUDDY_ASSISTANT_ID: Optional[str] = "2040365056239076416"
    CODEBUDDY_INTERNET_ENVIRONMENT: str = "internal"  # 中国版
    
    # 元器 API 备用 LLM 配置
    YUANQI_API_TOKEN: str = ""
    YUANQI_ASSISTANT_ID: str = "2040365056239076416"
    
    # 腾讯混元 LLM 配置
    HUNYUAN_API_KEY: Optional[str] = None
    HUNYUAN_BASE_URL: str = "https://hunyuan.cloud.tencent.com"
    HUNYUAN_MODEL: str = "hunyuan-pro"
    
    # 子流程意图分类配置
    INTENT_CLASSIFIER_LLM: str = "ollama"  # 可选: ollama, hunyuan, deepseek, codebuddy, none
    INTENT_CLASSIFIER_USE_LLM: bool = True   # 是否使用 LLM 进行意图分类（False 则只用规则）
    
    # 类案检索服务配置
    SENTENCE_MODEL_NAME: str = "paraphrase-MiniLM-L6-v2"
    SENTENCE_MODEL_BATCH_SIZE: int = 8
    
    # 合同审查规则库路径
    CONTRACT_RULES_PATH: Optional[str] = None   # 默认 data/contract_rules.json
    
    # 得理法律 API 配置
    LAW_API_BASE_URL: str = "https://openapi.delilegal.com"
    LAW_API_APPID: str = ""
    LAW_API_SECRET: str = ""
    
    # 本地 Ollama LLM 配置
    OLLAMA_BASE_URL: str = "http://localhost:11434/v1"
    OLLAMA_MODEL: str = "qwen3.5:9b"
    OLLAMA_TEMPERATURE: float = 0.7
    
    # CORS 配置
    CORS_ORIGINS: list = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
    ]
    
    # OnlyOffice Document Server 配置
    ONLYOFFICE_ENABLED: bool = True
    ONLYOFFICE_SERVER_URL: str = "http://localhost:8888"
    ONLYOFFICE_JWT_SECRET: Optional[str] = None
    
    class Config:
        env_file = os.path.join(BASE_DIR, ".env")
        case_sensitive = True


settings = Settings()

# 确保上传目录存在
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "data"), exist_ok=True)

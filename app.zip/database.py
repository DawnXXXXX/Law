"""
数据库配置和初始化
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from .config import settings

# 数据库 URL 处理
original_url = settings.DATABASE_URL

# 处理异步 SQLite URL (sqlite+aiosqlite:///)
if original_url.startswith("sqlite+aiosqlite:///"):
    async_url = original_url
    sync_url = original_url.replace("sqlite+aiosqlite:///", "sqlite:///")
elif original_url.startswith("sqlite:///"):
    async_url = original_url.replace("sqlite:///", "sqlite+aiosqlite:///")
    sync_url = original_url
else:
    # 其他数据库（如 PostgreSQL）
    async_url = original_url
    sync_url = original_url

# 异步引擎
async_engine = create_async_engine(
    async_url,
    echo=settings.DEBUG,
    future=True
)

# 异步会话工厂
AsyncSessionLocal = sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)

# 同步引擎
sync_engine = create_engine(sync_url, echo=settings.DEBUG)

SyncSessionLocal = sessionmaker(
    bind=sync_engine,
    autocommit=False,
    autoflush=False
)


async def get_db():
    """获取数据库会话"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


def init_db():
    """初始化数据库表（同步版本）"""
    # 导入所有模型类，SQLAlchemy 会自动将它们的表注册到 Base.metadata
    from .models import Project, Folder, File, Conversation, Message
    from .models import KnowledgeCategory, KnowledgeDocument, AiTool, FileSummary
    from .models.models import Base

    Base.metadata.create_all(bind=sync_engine)

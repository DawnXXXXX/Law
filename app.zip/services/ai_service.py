"""
AI 服务层
"""
import json
import asyncio
from typing import List, Dict, Any, Optional, AsyncIterator

from ..config import settings


class AIService:
    """AI 服务封装"""
    
    def __init__(self):
        self.api_key = settings.CODEBUDDY_API_KEY
        self.assistant_id = settings.CODEBUDDY_ASSISTANT_ID
    
    async def chat(
        self,
        message: str,
        project_context: Optional[Dict] = None,
        attached_files: Optional[List[Dict]] = None
    ) -> Dict[str, Any]:
        """
        发送聊天消息（非流式）
        
        Args:
            message: 用户消息
            project_context: 项目上下文
            attached_files: 附件文件列表
        
        Returns:
            AI 响应内容
        """
        # 构建上下文信息
        context_parts = []
        if project_context:
            context_parts.append(f"项目ID: {project_context.get('project_id')}")
        
        if attached_files:
            context_parts.append("\n相关文件内容:")
            for f in attached_files:
                context_parts.append(f"\n【{f['file_name']}】\n{f['content'][:500]}...")
        
        context = "\n".join(context_parts) if context_parts else ""
        
        # 构建提示词 - 基于CO-STAR框架
        system_prompt = """# Context (角色)
你是"法智通"法律AI助手，具备丰富的中国法律法规知识和实务经验。

# Professional Background (专业背景)
- 精通《民法典》《劳动合同法》《公司法》《民事诉讼法》等主要法律
- 熟悉司法实践中的常见问题和裁判规则
- 擅长将复杂的法律概念用通俗易懂的语言解释清楚

# Objective (任务目标)
回答用户提出的法律问题，提供专业、准确、实用的建议。

# Style & Tone (风格与语气)
1. **准确性优先** - 引用具体法律条文作为依据
2. **结构清晰** - 使用分点陈述，便于理解
3. **语言平实** - 避免过度专业化的术语
4. **负责任态度** - 对不确定的内容明确说明，不误导用户

# Response Format
直接输出回答内容。如涉及法律条文引用，请注明法律名称和条款号。
对于复杂问题，按以下结构组织：
1. 结论先行（简要回答）
2. 法律依据（相关法条）
3. 详细说明
4. 实务建议（如有）

# Important Note
请在回答末尾添加：*温馨提示：以上信息仅供参考，具体情况请咨询专业律师获取针对性行动方案*"""
        
        user_content = message
        if context:
            user_content = f"{context}\n\n用户问题: {message}"
        
        # 如果配置了 CodeBuddy API，使用 CodeBuddy
        if self.api_key and self.assistant_id:
            try:
                return await self._call_codebuddy(user_content, system_prompt)
            except Exception as e:
                # 如果 CodeBuddy 调用失败，返回友好的错误提示
                return self._get_fallback_response(message)
        
        # 默认返回友好的引导回复
        return self._get_fallback_response(message)
    
    async def stream_chat(
        self,
        message: str,
        project_context: Optional[Dict] = None,
        attached_files: Optional[List[Dict]] = None
    ) -> AsyncIterator[str]:
        """
        发送聊天消息（流式）
        
        Yields:
            响应文本片段
        """
        response = await self.chat(message, project_context, attached_files)
        content = response["content"]
        
        # 模拟流式输出
        for i in range(0, len(content), 20):
            await asyncio.sleep(0.05)  # 模拟延迟
            yield content[i:i+20]
    
    async def analyze_contract(self, content: str) -> Dict[str, Any]:
        """合同语义分析"""
        system_prompt = """# Context (角色)
你是"法智通"系统的合同法律专家，负责对合同文件进行深度语义分析。

# Professional Background
- 拥有10年+合同法实务经验
- 精通《民法典》合同编及相关司法解释
- 具备商业合同审查的专业能力

# Objective (任务目标)
对用户提供的合同文本进行全面、深入的语义分析。

# Analysis Dimensions (分析维度)
1. **合同概要** - 类型、主体、标的等基本信息
2. **核心条款解析** - 权利义务、履行方式、违约责任等关键内容
3. **法律风险提示** - 可能存在的风险点和注意事项
4. **改进建议** - 优化合同的具体建议（如有）

# Response Format
使用结构化格式输出：
## 一、合同概要
(基本信息总结)

## 二、主要条款分析
(逐条或分类分析)

## 三、关键风险点
(列出并说明风险等级)

## 四、专业建议
(如有)"""
        
        if self.api_key and self.assistant_id:
            try:
                result = await self._call_codebuddy(content, system_prompt)
                return {"analysis": result["content"]}
            except:
                pass
        
        return self._get_contract_analysis_fallback()
    
    async def contract_risk_review(self, content: str, contract_type: Optional[str] = None) -> Dict[str, Any]:
        """合同风险审查"""
        contract_type = contract_type or "一般合同"
        system_prompt = f"""# Context (角色)
你是"法智通"系统的合同风险审查专家，专门负责识别和评估合同中的法律风险。

# Professional Background
- 资深合同审查律师，处理过500+份各类合同
- 精通风险识别方法论，能发现隐蔽的法律陷阱
- 熟悉各行业合同的典型风险模式

# Objective (任务目标)
对{contract_type}进行全面的风险审查，按严重程度分级标注。

# Risk Classification Standard (风险分级标准)
- 🔴 **高风险** - 可能导致重大经济损失或法律责任
- 🟡 **中风险** - 需要注意但可接受的条款
- 🟢 **低风险** - 相对有利的条款

# Review Dimensions (审查维度)
1. 当事人主体资格与权限
2. 标的物条款的明确性
3. 价款/报酬及支付条件
4. 履行期限、地点、方式
5. 违约责任条款（是否公平、具体）
6. 争议解决机制
7. 其他特殊条款

# Response Format
## 风险审查报告

### 🔴 高风险项 (X项)
| 序号 | 条款位置 | 风险描述 | 建议措施 |
|------|---------|---------|---------|

### 🟡 中风险项 (X项)
...

### 🟢 低风险项 (X项)
...

### 总体评价
(对合同整体风险的总结判断)"""
        
        if self.api_key and self.assistant_id:
            try:
                result = await self._call_codebuddy(content, system_prompt)
                return {"review": result["content"], "risk_level": "medium"}
            except:
                pass
        
        return self._get_risk_review_fallback()
    
    async def draft_document(
        self,
        document_type: str,
        description: str,
        context: Optional[str] = None
    ) -> str:
        """起草文档"""
        templates = {
            "lawsuit": "起诉状",
            "defense": "答辩状",
            "proxy": "授权委托书",
            "contract": "合同",
            "opinion": "法律意见书"
        }
        
        doc_name = templates.get(document_type, "法律文书")
        
        system_prompt = f"""# Context (角色)
你是"法智通"系统的法律文书起草专家，负责生成符合中国法律规范的专业文书。

# Professional Background (专业背景)
- 精通各类法律文书的法定格式和撰写规范
- 具备丰富的实务文书起草经验
- 擅长将用户需求转化为专业的法律语言

# Objective (任务目标)
起草一份完整、规范的【{doc_name}】。

# User Requirements
{description}
{chr(10) + '## 附加背景信息' + chr(10) + context if context else ''}

# Drafting Standards (起草标准)
1. **格式规范** - 严格遵循该类文书的法定格式要求
2. **要素齐全** - 包含所有必要的法律要素和程序要件
3. **表述精准** - 使用准确的法律术语，避免歧义
4. **逻辑清晰** - 按"事实→理由→请求"的逻辑展开
5. **保护权益** - 合理维护当事人的合法权益

# Document Structure (通用结构)
1. 文书标题（如：民事起诉状）
2. 当事人基本信息
3. 诉讼请求/核心诉求
4. 事实与理由（详细叙述）
5. 法律依据引用
6. 落款与日期

# Response Format
直接输出完整的文书正文。
使用Markdown格式，标题用##，各部分之间空行分隔。"""
        
        if self.api_key and self.assistant_id:
            try:
                result = await self._call_codebuddy(system_prompt, "")
                return result["content"]
            except:
                pass
        
        return self._get_draft_fallback(doc_name, description)
    
    async def _call_codebuddy(self, content: str, system_prompt: str) -> Dict[str, Any]:
        """调用 CodeBuddy API"""
        import aiohttp
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        payload = {
            "assistant_id": self.assistant_id,
            "user_id": "law_studio_user",
            "stream": False,
            "messages": [
                {
                    "role": "system",
                    "content": [{"type": "text", "text": system_prompt}]
                },
                {
                    "role": "user",
                    "content": [{"type": "text", "text": content}]
                }
            ]
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.codebuddy.ai/openapi/v1/agent/chat/completions",
                headers=headers,
                json=payload
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return {"content": data.get("content", "处理中...")}
                else:
                    raise Exception(f"API调用失败: {response.status}")
    
    def _get_fallback_response(self, message: str) -> Dict[str, Any]:
        """获取备用响应（当API不可用时）"""
        lower_msg = message.lower()
        
        if "劳动合同" in message:
            return {
                "content": """根据您的问题，这是关于劳动合同的法律咨询。

**相关法律依据：**
《劳动合同法》第10条：建立劳动关系，应当订立书面劳动合同。
《劳动合同法》第35条：用人单位与劳动者协商一致，可以变更劳动合同约定的内容。

**建议：**
1. 保留好劳动合同原件
2. 如有争议，可先与用人单位协商
3. 必要时可申请劳动仲裁

如果您能提供更具体的情况，我可以给出更精准的分析。"""
            }
        elif "起诉" in message or "诉讼" in message:
            return {
                "content": """关于起诉/诉讼程序，我可以为您提供以下指引：

**民事诉讼基本流程：**
1. 准备起诉材料（起诉状、证据目录等）
2. 向有管辖权的人民法院递交起诉状
3. 缴纳诉讼费用
4. 等待法院立案审查
5. 参加庭审

**起诉状应包含：**
- 原告、被告基本信息
- 具体的诉讼请求
- 事实与理由
- 证据清单

如需更详细的指导，请告诉我您的具体案件类型。"""
            }
        elif "合同" in message:
            return {
                "content": """关于合同法律问题，我可以为您提供以下帮助：

**合同审查要点：**
1. 合同主体是否具备相应资质
2. 合同标的和数量是否明确
3. 权利义务条款是否对等
4. 违约责任条款是否合理
5. 争议解决方式是否可行

**常见合同风险：**
- 格式条款的不利解释风险
- 违约金约定过高的风险
- 管辖约定不利的风险

请告诉我您具体想了解哪类合同，我可以提供更有针对性的分析。"""
            }
        else:
            return {
                "content": f"""感谢您的咨询！您的问题是："{message}"

作为法律AI助手，我可以帮助您：

1. **法律条文查询** - 检索相关法律法规
2. **合同审查** - 分析合同条款和风险
3. **文书起草** - 帮助起草起诉状、合同等
4. **案例参考** - 提供相关判例参考

请提供更多具体信息，以便我为您提供更精准的法律建议。

**您可以尝试：**
- "分析劳动合同法第35条"
- "审查这份租赁合同"
- "帮我起草一份起诉状"
- "查找违法解除劳动合同的案例" """
            }
    
    def _get_contract_analysis_fallback(self) -> Dict[str, Any]:
        """合同分析的备用结果"""
        return {
            "analysis": """【合同语义分析】

**一、合同主体分析**
- 合同各方身份和资质
- 主体资格合法有效

**二、合同主要条款**
1. 标的条款
2. 数量质量条款
3. 价款报酬条款
4. 履行期限、地点和方式
5. 违约责任条款

**三、权利义务分析**
- 甲方主要权利义务
- 乙方主要权利义务

**四、风险提示**
- 需要注意的关键条款
- 潜在的法律风险

*注：以上为通用分析框架，请上传具体合同以获取详细分析。*"""
        }
    
    def _get_risk_review_fallback(self) -> Dict[str, Any]:
        """风险审查的备用结果"""
        return {
            "review": """【合同风险审查报告】

**高风险条款（需重点关注）**
1. 违约金条款 - 金额可能过高
2. 免责条款 - 范围可能过宽
3. 终止条款 - 条件可能过于苛刻

**中风险条款（建议协商）**
1. 付款期限条款
2. 争议解决条款 - 管辖约定可能不利

**低风险条款（相对有利）**
1. 合同目的明确
2. 双方权利义务基本对等

**改进建议**
1. 建议对违约金条款设定上限
2. 建议增加不可抗力条款
3. 建议明确争议解决方式

*注：以上为通用审查框架，请上传具体合同以获取精准审查。*""",
            "risk_level": "medium",
            "high_risk_count": 3,
            "medium_risk_count": 2,
            "low_risk_count": 2
        }
    
    def _get_draft_fallback(self, doc_type: str, description: str) -> str:
        """文书起草的备用结果"""
        return f"""【{doc_type}】(草案)

**当事人信息**
甲方（原告/债权人）：
乙方（被告/债务人）：

**{doc_type}请求/事项**

根据您提供的要求："{description}"

**事实与理由**

1. 时间、地点、人物等基本事实
2. 事件发展经过
3. 相关法律依据

**证据清单**
1. 证据一：证据名称及证明内容
2. 证据二：证据名称及证明内容

**落款**
{'原告' if doc_type == '起诉状' else '申请人'}：（签名）
日期：年 月 日

---
*注：此为通用模板，请根据实际情况补充具体内容。如需更专业的文书定制，请提供详细的案件背景信息。*"""

"""
模板服务
封装模板数据库操作，供工作流使用
"""
import json
import os
from typing import Dict, Any, Optional, List, Tuple
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import Template


class TemplateService:
    """
    模板服务
    
    从数据库获取模板信息，供工作流使用
    """
    
    def __init__(self, db: Optional[AsyncSession] = None):
        self.db = db
    
    async def get_all_templates(self) -> List[Dict[str, Any]]:
        """获取所有启用的模板"""
        if not self.db:
            return []
        
        query = select(Template).where(Template.is_active == 1).order_by(Template.created_at.desc())
        result = await self.db.execute(query)
        templates = result.scalars().all()
        
        return [self._template_to_dict(t) for t in templates]
    
    async def get_template_by_id(self, template_id: int) -> Optional[Dict[str, Any]]:
        """根据ID获取模板"""
        if not self.db:
            return None
        
        query = select(Template).where(Template.id == template_id, Template.is_active == 1)
        result = await self.db.execute(query)
        template = result.scalar_one_or_none()
        
        return self._template_to_dict(template) if template else None
    
    async def get_template_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """根据名称获取模板"""
        print(f"[TemplateService.get_template_by_name] 搜索: {name!r}")
        if not self.db:
            print("[TemplateService.get_template_by_name] db 为 None，返回 None")
            return None
        
        query = select(Template).where(Template.name == name, Template.is_active == 1)
        result = await self.db.execute(query)
        template = result.scalar_one_or_none()
        
        if template:
            print(f"[TemplateService.get_template_by_name] 找到: {template.name}")
        else:
            # 调试：列出所有模板名称
            all_query = select(Template).where(Template.is_active == 1)
            all_result = await self.db.execute(all_query)
            all_templates = all_result.scalars().all()
            print(f"[TemplateService.get_template_by_name] 未找到，所有模板: {[t.name for t in all_templates]}")
        
        return self._template_to_dict(template) if template else None
    
    async def search_templates(self, keyword: str) -> List[Dict[str, Any]]:
        """
        模糊搜索模板 - 根据关键词搜索模板名称
        
        支持：
        - 精确匹配：名称完全相同
        - 包含匹配：关键词在名称中
        - 反向包含：模板名在关键词中
        - 分词匹配：关键词被空格/特殊字符分隔后，每个词都在名称中
        """
        print(f"[TemplateService.search_templates] 搜索关键词: {keyword!r}")
        if not self.db or not keyword:
            return []
        
        all_templates = await self.get_all_templates()
        keyword_lower = keyword.lower()
        results = []
        
        for template in all_templates:
            name = template.get("name", "")
            name_lower = name.lower()
            
            # 精确匹配
            if name_lower == keyword_lower:
                results.append(template)
                continue
            
            # 关键词在模板名中，或模板名在关键词中
            if keyword_lower in name_lower or name_lower in keyword_lower:
                results.append(template)
                continue
            
            # 分词匹配：关键词被空格、"纠纷"、"民事'等分隔
            separators = [" ", "纠纷", "民事", "刑事", "行政", "合同", "劳动"]
            search_words = [keyword_lower]
            for sep in separators:
                new_words = []
                for word in search_words:
                    new_words.extend(word.split(sep))
                search_words = new_words
            search_words = [w for w in search_words if w.strip()]
            
            # 所有分词都在模板名中
            if all(word in name_lower for word in search_words):
                results.append(template)
        
        print(f"[TemplateService.search_templates] 找到 {len(results)} 个模板: {[t['name'] for t in results]}")
        return results
    
    async def get_templates_by_category(self, category: str) -> List[Dict[str, Any]]:
        """根据分类获取模板"""
        if not self.db:
            return []
        
        query = select(Template).where(
            Template.category == category,
            Template.is_active == 1
        ).order_by(Template.created_at.desc())
        result = await self.db.execute(query)
        templates = result.scalars().all()
        
        return [self._template_to_dict(t) for t in templates]
    
    async def get_templates_grouped_by_category(self) -> Dict[str, List[Dict[str, Any]]]:
        """获取按分类分组的模板列表"""
        templates = await self.get_all_templates()
        
        grouped = {}
        for template in templates:
            category = template.get("category", "other") or "other"
            if category not in grouped:
                grouped[category] = []
            grouped[category].append({
                "id": template["id"],
                "name": template["name"],
                "description": template.get("description", "")
            })
        
        return grouped
    
    async def get_template_params(self, template_id: int) -> Dict[str, Any]:
        """获取模板参数定义"""
        template = await self.get_template_by_id(template_id)
        if not template:
            return {}
        
        placeholder_dict = template.get("placeholder_dict", {})
        return self._convert_to_params_def(placeholder_dict)
    
    @staticmethod
    def _convert_to_params_def(placeholder_dict: Dict) -> Dict[str, Any]:
        """
        将占位符字典转换为标准参数定义格式
        
        仅支持一种格式（方案二）：每个字段包含完整的元信息
        {"key": {"label": "...", "example": "...", "required": true, "type": "text"}}
        """
        params = {}
        for key, value in placeholder_dict.items():
            if isinstance(value, dict):
                # 方案二格式：直接使用元信息
                params[key] = {
                    "label": value.get("label", key),
                    "required": value.get("required", True),
                    "type": value.get("type", "text"),
                    "description": value.get("example", value.get("description", ""))
                }
            else:
                # 旧格式兼容：纯示例值 → 自动推断
                str_value = str(value) if value is not None else ""
                has_checkbox = any(s in str_value for s in ["☑", "□", "√", "■", "×", "○", "●"])
                params[key] = {
                    "label": key,
                    "required": not has_checkbox and bool(str_value.strip()),
                    "type": "checkbox" if has_checkbox else "text",
                    "description": str_value
                }
        
        return params
    
    async def validate_params(self, template_id: int, provided_params: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        验证参数是否完整
        
        Returns:
            (is_complete, missing_params)
        """
        params_def = await self.get_template_params(template_id)
        
        missing = []
        for key, info in params_def.items():
            if info.get("required", False) and (key not in provided_params or not provided_params[key]):
                missing.append(key)
        
        return len(missing) == 0, missing
    
    def _template_to_dict(self, template: Template) -> Dict[str, Any]:
        """将模板模型转换为字典"""
        if not template:
            return {}
        
        # 优先从磁盘文件读取字典（如果存在）
        placeholder_dict = {}
        if template.dictionary_path and os.path.exists(template.dictionary_path):
            try:
                with open(template.dictionary_path, 'r', encoding='utf-8') as f:
                    placeholder_dict = json.load(f)
                print(f"[TemplateService] 从文件加载字典: {template.dictionary_path}")
            except Exception as e:
                print(f"[TemplateService] 从文件加载字典失败: {e}, 使用数据库中的字典")
                placeholder_dict = json.loads(template.placeholder_dict) if template.placeholder_dict else {}
        else:
            # 使用数据库中的字典
            placeholder_dict = json.loads(template.placeholder_dict) if template.placeholder_dict else {}
        
        return {
            "id": template.id,
            "name": template.name,
            "description": template.description,
            "category": template.category,
            "blank_template_path": template.blank_template_path,
            "placeholder_template_path": template.placeholder_template_path,
            "dictionary_path": template.dictionary_path,
            "placeholder_dict": placeholder_dict,
            "author": template.author,
            "tags": template.tags,
            "version": template.version,
            "is_active": template.is_active,
            "created_at": template.created_at.isoformat() if template.created_at else None,
            "updated_at": template.updated_at.isoformat() if template.updated_at else None
        }


# ==================== 同步版本（用于无数据库上下文） ====================

class SyncTemplateService:
    """
    同步模板服务
    
    用于不需要数据库会话的场景，返回空数据
    实际使用时应该使用异步版本
    """
    
    def __init__(self):
        self._db = None
    
    async def get_all_templates(self) -> List[Dict[str, Any]]:
        """获取所有模板"""
        # 返回空列表，实际调用时应使用异步版本
        return []
    
    async def get_template_by_id(self, template_id: int) -> Optional[Dict[str, Any]]:
        return None
    
    async def get_template_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        return None
    
    async def get_templates_by_category(self, category: str) -> List[Dict[str, Any]]:
        return []
    
    async def get_templates_grouped_by_category(self) -> Dict[str, List[Dict[str, Any]]]:
        return {}
    
    async def get_template_params(self, template_id: int) -> Dict[str, Any]:
        return {}
    
    async def validate_params(self, template_id: int, provided_params: Dict[str, Any]) -> Tuple[bool, List[str]]:
        return False, ["模板服务未初始化"]

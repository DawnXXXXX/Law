"""
数据模型包
"""
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from sqlalchemy.ext.declarative import declarative_base

# 在 models 中定义 Base，避免循环导入
Base = declarative_base()


class Project(Base):
    """项目模型"""
    __tablename__ = "projects"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String(50), default="active")  # active, archived, completed
    summary = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # 关联
    files = relationship("File", back_populates="project", cascade="all, delete-orphan")
    folders = relationship("Folder", back_populates="project", cascade="all, delete-orphan")
    conversations = relationship("Conversation", back_populates="project", cascade="all, delete-orphan")


class Folder(Base):
    """文件夹模型"""
    __tablename__ = "folders"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    parent_id = Column(Integer, ForeignKey("folders.id", ondelete="CASCADE"), nullable=True)
    name = Column(String(255), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # 关联
    project = relationship("Project", back_populates="folders")
    parent = relationship("Folder", remote_side=[id], backref="children")
    files = relationship("File", back_populates="folder")


class File(Base):
    """文件模型"""
    __tablename__ = "files"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    folder_id = Column(Integer, ForeignKey("folders.id", ondelete="SET NULL"), nullable=True)
    name = Column(String(255), nullable=False)
    file_type = Column(String(100), nullable=False)  # docx, pdf, png, txt, mime types
    file_path = Column(String(500), nullable=True)  # 实际存储路径
    content = Column(Text, nullable=True)  # 文本内容
    size = Column(Integer, default=0)
    summary = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # 关联
    project = relationship("Project", back_populates="files")
    folder = relationship("Folder", back_populates="files")
    summaries = relationship("FileSummary", back_populates="file", cascade="all, delete-orphan")


class Conversation(Base):
    """对话会话模型"""
    __tablename__ = "conversations"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=True)
    title = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # 关联
    project = relationship("Project", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")


class Message(Base):
    """消息模型"""
    __tablename__ = "messages"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    role = Column(String(20), nullable=False)  # user, assistant
    content = Column(Text, nullable=False)
    file_refs = Column(Text, nullable=True)  # JSON格式存储文件引用
    workflow_state = Column(Text, nullable=True)  # JSON格式存储工作流状态
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # 关联
    conversation = relationship("Conversation", back_populates="messages")


class KnowledgeCategory(Base):
    """知识库分类模型"""
    __tablename__ = "knowledge_categories"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    parent_id = Column(Integer, ForeignKey("knowledge_categories.id", ondelete="CASCADE"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # 关联
    parent = relationship("KnowledgeCategory", remote_side=[id], backref="children")
    documents = relationship("KnowledgeDocument", back_populates="category")


class KnowledgeDocument(Base):
    """知识库文档模型"""
    __tablename__ = "knowledge_documents"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    category_id = Column(Integer, ForeignKey("knowledge_categories.id", ondelete="SET NULL"), nullable=True)
    title = Column(String(255), nullable=False)
    doc_type = Column(String(50), nullable=False)  # law, case, template
    content = Column(Text, nullable=True)
    file_path = Column(String(500), nullable=True)
    law_id = Column(String(255), nullable=True)  # 外部法律API的ID
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # 关联
    category = relationship("KnowledgeCategory", back_populates="documents")


class AiTool(Base):
    """AI工具权限模型"""
    __tablename__ = "ai_tools"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)  # 工具唯一标识
    display_name = Column(String(255), nullable=False)  # 显示名称
    description = Column(Text, nullable=True)  # 功能描述
    category = Column(String(50), nullable=False)  # 分类: file, knowledge, search, ai
    enabled = Column(Integer, default=1)  # 0=禁用, 1=启用
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class FileSummary(Base):
    """文件摘要模型"""
    __tablename__ = "file_summaries"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    file_id = Column(Integer, ForeignKey("files.id", ondelete="CASCADE"), nullable=False)
    content = Column(Text, nullable=False)  # 摘要内容
    version = Column(Integer, default=1)  # 摘要版本号
    created_by = Column(String(100), nullable=True)  # 生成者（AI/用户）
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # 关联
    file = relationship("File", back_populates="summaries")


class Template(Base):
    """文书模板模型"""
    __tablename__ = "templates"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(255), nullable=False)  # 模板名称
    description = Column(Text, nullable=True)  # 模板描述
    category = Column(String(100), nullable=True)  # 分类：民事、刑事、行政等
    author = Column(String(100), nullable=True)  # 作者
    tags = Column(Text, nullable=True)  # 标签，JSON格式存储
    version = Column(String(20), default="1.0")  # 版本号
    
    # 文件路径
    blank_template_path = Column(String(500), nullable=True)  # 空白模板路径
    placeholder_template_path = Column(String(500), nullable=True)  # 带占位符模板路径
    dictionary_path = Column(String(500), nullable=True)  # 占位符字典JSON路径
    placeholder_dict = Column(Text, nullable=True)  # 占位符字典JSON内容
    
    is_active = Column(Integer, default=1)  # 是否启用：0=禁用，1=启用
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

"""
类案检索服务 (SimilarCaseRetrievalService)

封装 Sentence-BERT 模型，提供案情与案例间的语义相似度计算。
"""

from __future__ import annotations

from typing import Any, Dict, List

import numpy as np


class SimilarCaseRetrievalService:
    """
    语义相似度案例检索服务
    - 模型: paraphrase-MiniLM-L6-v2 (~90MB)
    - 分批编码 batch_size=8, L2归一化 + 余弦相似度
    """

    def __init__(self, model_name: str = "paraphrase-MiniLM-L6-v2", batch_size: int = 8):
        self._model_name = model_name
        self._batch_size = batch_size
        from sentence_transformers import SentenceTransformer
        import os
        # 解决 PyTorch 2.6 weights_only 问题
        os.environ["TORCH_FORCE_WEIGHTS_ONLY_LOAD"] = "0"
        # 获取 backend 目录作为基础路径 (从 services -> langchain_core -> app -> backend)
        _backend_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        # 模型下载到了 HuggingFace 缓存格式目录
        _local_model_path = os.path.join(_backend_dir, "models", "models--sentence-transformers--paraphrase-MiniLM-L6-v2", "snapshots", "c9a2bfebc254878aee8c3aca9e6844d5bbb102d1")
        print(f"[SimilarCase] 加载本地模型 {_local_model_path}...")
        self._model = SentenceTransformer(_local_model_path)
        print(f"[SimilarCase] 就绪")

    def retrieve_similar_cases(
        self,
        user_case: str,
        candidate_cases: List[Dict[str, Any]],
        top_k: int = 3,
        text_field: str = "summary",
    ) -> List[Dict[str, Any]]:
        """
        输入案情+候选案例 → 按 similarity_score 降序返回 Top K
        原地修改 candidate_cases 添加 similarity_score 字段
        """
        if not candidate_cases or not user_case:
            return candidate_cases

        # 提取候选文本
        valid_pairs = []
        for idx, case in enumerate(candidate_cases):
            # 优先使用 content 字段（全文），截取前3000字符
            text = case.get("content") or case.get(text_field) or case.get("full_text") or case.get("summary") or ""
            if text.strip():
                valid_pairs.append((idx, text[:3000]))
            else:
                case["similarity_score"] = 0.0
                print(f"[SimilarCase] 案例{idx}无有效文本: title={case.get('title','N/A')[:50]}")

        if not valid_pairs:
            return candidate_cases

        indices = [p[0] for p in valid_pairs]
        texts = [p[1] for p in valid_pairs]

        # 编码（L2归一化）
        query_vec = self._model.encode([user_case], normalize_embeddings=True)
        cand_vecs = self._model.encode(texts, normalize_embeddings=True, batch_size=self._batch_size)

        # 余弦相似度 = 归一化向量点积
        scores = (cand_vecs @ query_vec.T).flatten()

        for i, idx in enumerate(indices):
            candidate_cases[idx]["similarity_score"] = float(scores[i])
        
        # 调试：打印前3个候选的相似度和标题
        for c in candidate_cases[:3]:
            print(f"[SimilarCase] 候选: {c.get('title','N/A')[:30]}... 相似度={c.get('similarity_score', 0):.4f}")

        # 精确匹配检测：用户案情与候选案例内容完全匹配（100%相似）
        user_case_clean = user_case.strip()
        for case in candidate_cases:
            content = case.get("content", "") or case.get("summary", "") or ""
            content_clean = content.strip()
            if user_case_clean and content_clean:
                # 计算字符级别的重叠度（简单精确匹配）
                # 如果用户案情是案例内容的子串，或者相似度超过95%，标记为精确匹配
                if user_case_clean in content_clean or content_clean in user_case_clean:
                    case["similarity_score"] = max(case.get("similarity_score", 0), 0.99)
                    case["exact_match"] = True
                    print(f"[SimilarCase] 精确匹配检测: {case.get('title','N/A')[:30]}... 设为 0.99")

        candidate_cases.sort(key=lambda x: x.get("similarity_score", 0), reverse=True)
        return candidate_cases[:top_k]

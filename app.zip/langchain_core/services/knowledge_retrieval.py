"""
知识检索编排服务 - 替代 consultation_chain.py 中的并行检索逻辑

职责:
- 并行执行法规和案例检索
- 格式化知识库内容供 Prompt 使用

消除的问题:
- consultation_chain.py:72-93 _retrieve_knowledge() 逻辑外泄到 Chain 内部
"""

from typing import Any, Dict, List, Optional
import dataclasses

from ..tools import parallel_knowledge_search
from .response_formatter import ResponseFormatter


@dataclasses.dataclass
class KnowledgeContext:
    """知识检索上下文"""
    laws: List[Dict]
    cases: List[Dict]
    keywords: str

    @property
    def laws_count(self) -> int:
        return len([l for l in self.laws if not l.get("error")])

    @property
    def cases_count(self) -> int:
        return len([c for c in self.cases if not c.get("error")])


class KnowledgeRetrievalService:
    """
    知识检索编排服务

    并行执行法规和案例检索，格式化结果供 Prompt 使用。
    """

    def __init__(self):
        pass

    async def retrieve(self, keywords: str) -> KnowledgeContext:
        """
        根据关键词并行检索法规和案例

        使用 tools.py 的 parallel_knowledge_search() 实现并行调用。

        Args:
            keywords: 检索关键词

        Returns:
            KnowledgeContext 包含 laws/cases/keywords
        """
        if not keywords:
            return KnowledgeContext(laws=[], cases=[], keywords="")

        result = await parallel_knowledge_search(keywords)

        return KnowledgeContext(
            laws=result.get("laws", []),
            cases=result.get("cases", []),
            keywords=keywords,
        )

    def format_for_prompt(
        self,
        laws: List[Dict],
        cases: List[Dict],
    ) -> str:
        """
        格式化为 Prompt 文本块

        Args:
            laws: 法规列表
            cases: 案例列表

        Returns:
            格式化的知识库文本
        """
        return ResponseFormatter.format_knowledge_for_prompt(laws, cases)

    def get_metadata(self, context: KnowledgeContext) -> Dict[str, Any]:
        """
        获取检索元数据

        Args:
            context: 知识检索上下文

        Returns:
            元数据字典
        """
        return {
            "laws_count": context.laws_count,
            "cases_count": context.cases_count,
            "keywords": context.keywords.split() if context.keywords else [],
        }

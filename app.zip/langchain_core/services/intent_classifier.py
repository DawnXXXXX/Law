"""
意图识别服务 - 替代 intent_chain.py 中的 IntentChainAdapter

职责:
- LLM 驱动的意图分类
- 规则兜底的降级方案
- 意图值标准化（中文→英文映射）

消除的问题:
- intent_chain.py:169 内部调用 get_intent_llm()
"""

from typing import Any, Dict, List, Optional
import re

from ..parsers import IntentResult, intent_parser, LegacyJsonParser
from ..prompts import INTENT_PROMPT


class RuleBasedIntentFallback:
    """
    基于关键词规则的意图降级识别

    当 LLM 不可用时使用的规则兜底方案。
    """

    # 意图关键词映射
    INTENT_RULES = {
        "document_generation": [
            "写", "起草", "生成", "创建", "制作",
            "起诉状", "答辩状", "申请书", "合同", "协议",
        ],
        "document_modification": [
            "修改", "改", "调整", "换", "更正", "编辑",
        ],
        "case_search": [
            "查找案例", "搜索案例", "检索案例",
        ],
        "case_analysis": [
            "分析案例", "案例分析", "类案分析", "案情分析", "案件分析",
            "分析这个案件", "分析我的案子",
        ],
        "law_search": [
            "法规", "法条", "法律", "第几条", "条文", "规定",
        ],
        "contract_service": [
            "合同", "协议", "审查合同", "起草合同",
        ],
        "consultation": [
            "咨询", "法律问题", "请问", "问一下",
        ],
        "chitchat": [
            "你好", "hi", "hello", "嗨", "天气",
        ],
    }

    def classify(self, query: str) -> str:
        """
        基于关键词规则进行意图分类

        Args:
            query: 用户查询

        Returns:
            意图字符串
        """
        lower_query = query.lower()

        # 优先匹配文书生成和修改（因为它们有更多特定关键词）
        for intent, keywords in self.INTENT_RULES.items():
            for keyword in keywords:
                if keyword in lower_query:
                    return intent

        return "unknown"


class IntentClassifier:
    """
    意图识别服务

    支持:
    - LLM 驱动的精确分类
    - 规则兜底的降级方案
    - 意图值标准化
    """

    def __init__(self, llm: Any):
        """
        初始化意图分类器

        Args:
            llm: LawChatLLM 实例（通过构造函数注入，不再内部 import）
        """
        self._llm = llm
        self._chain = None
        self._fallback = RuleBasedIntentFallback()

    def _build_chain(self) -> Any:
        """构建 LCEL Chain（懒加载）"""
        from langchain_core.runnables import RunnableLambda

        if self._chain is not None:
            return self._chain

        def _build_input(dct: Dict[str, Any]) -> Dict[str, Any]:
            return {
                "user_input": dct.get("user_input", ""),
                "history": dct.get("history", ""),
                "format_instructions": intent_parser.get_format_instructions(),
            }

        def _parse_output(llm_response: str) -> IntentResult:
            try:
                return intent_parser.parse(llm_response)
            except Exception as e:
                print(f"[intent_classifier] Pydantic解析失败: {e}")
                fallback = LegacyJsonParser.safe_parse(llm_response)

                if fallback and isinstance(fallback, dict):
                    return IntentResult(
                        intent=fallback.get("intent", "unknown"),
                        confidence=float(fallback.get("confidence", 0.5)),
                        reasoning=fallback.get("reasoning", ""),
                        document_type=fallback.get("document_type", ""),
                        dispute_type=fallback.get("dispute_type", ""),
                        extracted_info=fallback.get("extracted_info", {}),
                    )

                return IntentResult(
                    intent="unknown",
                    confidence=0.0,
                    reasoning=f"解析失败: {str(e)}",
                )

        def _normalize_intent(result: IntentResult) -> Dict[str, Any]:
            # 标准化 intent 值
            valid_intents = {
                "document_generation", "document_modification", "contract_service",
                "consultation", "case_search", "case_analysis", "law_search", "chitchat", "unknown",
            }

            raw_intent = result.intent if result.intent else "unknown"
            if raw_intent not in valid_intents:
                intent_map = {
                    "文书生成": "document_generation",
                    "起草": "document_generation",
                    "文书修改": "document_modification",
                    "修改": "document_modification",
                    "合同服务": "contract_service",
                    "合同": "contract_service",
                    "法律咨询": "consultation",
                    "咨询": "consultation",
                    "案例检索": "case_search",
                    "案例": "case_search",
                    "案例分析": "case_analysis",
                    "案件分析": "case_analysis",
                    "类案分析": "case_analysis",
                    "法规检索": "law_search",
                    "法规": "law_search",
                    "闲聊": "chitchat",
                }
                raw_intent = intent_map.get(raw_intent, "unknown")

            return {
                "intent": raw_intent,
                "confidence": result.confidence,
                "reasoning": result.reasoning,
                "document_type": result.document_type or "",
                "dispute_type": result.dispute_type or "",
                "extracted_info": result.extracted_info or {},
                "intent_changed": True,
                "_raw_result": result,
            }

        # 构建 LCEL 管道
        from langchain_core.runnables import RunnableLambda as RLambda

        chain = (
            RLambda(_build_input)
            | INTENT_PROMPT
            | self._llm
            | RLambda(lambda x: x.content if hasattr(x, 'content') else str(x))
            | RLambda(_parse_output)
            | RLambda(_normalize_intent)
        )

        self._chain = chain
        return chain

    def _format_history(self, history: Optional[List[Dict]]) -> str:
        """格式化对话历史"""
        if not history:
            return ""

        lines = []
        for msg in history[-5:]:
            role = "用户" if msg.get("role") == "user" else "助手"
            content = msg.get('content', '')[:200]
            lines.append(f"{role}：{content}")

        return "\n".join(lines)

    async def classify(
        self,
        query: str,
        history: Optional[List[Dict]] = None,
        previous_intent: str = "",
    ) -> Dict[str, Any]:
        """
        执行意图识别

        Args:
            query: 用户查询
            history: 对话历史 [{"role":"user/assistant","content":"..."}]
            previous_intent: 之前的意图

        Returns:
            意图识别字典
        """
        # 尝试使用 LLM
        if self._llm is None:
            return self._classify_by_rules(query, previous_intent)

        try:
            chain = self._build_chain()

            history_text = self._format_history(history)
            if previous_intent:
                history_text += f"\n## 之前的意图\n{previous_intent}"

            result = await chain.ainvoke({
                "user_input": query,
                "history": history_text,
            })

            return {
                "intent": result["intent"],
                "confidence": result["confidence"],
                "reasoning": result["reasoning"],
                "document_type": result["document_type"],
                "dispute_type": result["dispute_type"],
                "extracted_info": result["extracted_info"],
                "intent_changed": result["intent_changed"],
            }

        except Exception as e:
            print(f"[intent_classifier] LLM 分类失败，降级为规则: {e}")
            return self._classify_by_rules(query, previous_intent)

    def _classify_by_rules(
        self,
        query: str,
        previous_intent: str = "",
    ) -> Dict[str, Any]:
        """使用规则兜底进行分类"""
        intent = self._fallback.classify(query)

        return {
            "intent": intent,
            "confidence": 0.3,  # 规则兜底使用较低置信度
            "reasoning": "规则兜底分类",
            "document_type": "",
            "dispute_type": "",
            "extracted_info": {},
            "intent_changed": True,
        }

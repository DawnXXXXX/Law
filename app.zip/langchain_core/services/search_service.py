"""
统一检索服务 - 替代 router_graph.py 中的 _handle_case_search 和 _handle_law_search

职责:
- 关键词提取（使用 LLM）
- 案例/法规检索
- 结果格式化

消除的问题:
- router_graph.py:294,336 内部调用 get_intent_llm()
- router_graph.py:290-371 ~70行重复代码（case/law handler 结构几乎相同）
"""

from typing import Any, Dict, List, Optional
import dataclasses

from ..tools import search_cases, search_laws
from ..prompts import KEYWORD_EXTRACT_PROMPT
from .response_formatter import ResponseFormatter


@dataclasses.dataclass
class SearchResults:
    """检索结果"""
    type: str              # "cases" | "laws"
    items: List[Dict]
    formatted: str         # Markdown 格式化的响应文本
    count: int             # 有效结果数
    has_error: bool


class SearchService:
    """
    统一检索服务

    消除 case/law search handler 的重复代码，统一关键词提取逻辑。
    """

    def __init__(self, llm: Any):
        """
        初始化检索服务

        Args:
            llm: LLM 实例（用于关键词提取）
        """
        self._llm = llm
        self._kw_prompt_template = KEYWORD_EXTRACT_PROMPT

    async def _extract_keywords(self, query: str) -> str:
        """
        使用 LLM 提取检索关键词

        Args:
            query: 用户查询

        Returns:
            关键词字符串
        """
        if not self._llm:
            # 没有 LLM 时使用简单降级
            return query[:50]

        try:
            kw_prompt = self._kw_prompt_template.format(input_text=query)
            response = await self._llm.ainvoke(kw_prompt)
            return response.content.strip() if hasattr(response, 'content') else query[:50]
        except Exception as e:
            print(f"[search_service] 关键词提取失败: {e}")
            return query[:50]

    async def search_cases(self, query: str) -> SearchResults:
        """
        执行案例检索

        Args:
            query: 用户查询

        Returns:
            SearchResults 包含原始结果和格式化文本
        """
        # 提取关键词
        keywords = await self._extract_keywords(query)

        # 执行检索
        cases = await search_cases.ainvoke(keywords)

        # 格式化输出
        formatted = ResponseFormatter.format_cases(cases)

        valid_cases = [c for c in cases if not c.get("error")]

        return SearchResults(
            type="cases",
            items=cases,
            formatted=formatted,
            count=len(valid_cases),
            has_error=not valid_cases,
        )

    async def search_laws(self, query: str) -> SearchResults:
        """
        执行法规检索

        Args:
            query: 用户查询

        Returns:
            SearchResults 包含原始结果和格式化文本
        """
        # 提取关键词
        keywords = await self._extract_keywords(query)

        # 执行检索
        laws = await search_laws.ainvoke(keywords)

        # 格式化输出
        formatted = ResponseFormatter.format_laws(laws)

        valid_laws = [l for l in laws if not l.get("error")]

        return SearchResults(
            type="laws",
            items=laws,
            formatted=formatted,
            count=len(valid_laws),
            has_error=not valid_laws,
        )

    async def search_both(self, query: str) -> Dict[str, SearchResults]:
        """
        同时检索案例和法规

        Args:
            query: 用户查询

        Returns:
            {"cases": SearchResults, "laws": SearchResults}
        """
        import asyncio

        cases_task = self.search_cases(query)
        laws_task = self.search_laws(query)

        cases_result, laws_result = await asyncio.gather(cases_task, laws_task)

        return {
            "cases": cases_result,
            "laws": laws_result,
        }

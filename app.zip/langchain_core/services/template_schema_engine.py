"""
模板 Schema 驱动的文书填充引擎

设计原则:
- 引擎是通用解释器，不硬编码任何选项内容
- 所有规则写在 JSON schema 里
- conditional_block 支持注册表模式，便于扩展
"""

from typing import Any, Dict, List, Optional
import json


# ==================== 默认格式化符号 ====================

DEFAULT_CHECKED_SYMBOL = "☑"
DEFAULT_UNCHECKED_SYMBOL = "□"
DEFAULT_SEPARATOR = "    "  # 4个空格，符合法律文书格式


# ==================== Schema Lite 生成 ====================

def generate_llm_lite_schema(schema: Dict[str, Any]) -> Dict[str, Any]:
    """
    从完整 schema 生成 LLM 可见的 lite 版本
    
    LLM 只需要知道:
    - label (用于显示)
    - type (text/textarea/checkbox/radio/single_choice/multi_choice)
    - required (是否必填)
    - options (如果是选择类字段，列出所有选项)
    
    不需要告诉 LLM:
    - formatting 规则 (☑/□ 位置、分隔符等)
    - conditional_blocks 逻辑
    
    Args:
        schema: 完整模板 schema
        
    Returns:
        LLM 用的精简版参数定义
    """
    lite = {}
    fields = schema.get("fields", schema)  # 兼容两种写法
    
    for key, field_def in fields.items():
        # 跳过仅供引擎使用的元字段
        if key.startswith("_") or key in ["checkbox_formatting", "conditional_blocks"]:
            continue
            
        lite_field = {
            "label": field_def.get("label", key),
            "type": field_def.get("type", "text"),
            "required": field_def.get("required", False),
        }
        
        # 选择类字段需要 options 列表
        if field_def.get("type") in ["checkbox", "radio", "single_choice", "multi_choice"]:
            if "options" in field_def:
                lite_field["options"] = field_def["options"]
            elif "example" in field_def:
                # 从 example 推断 options
                # 例如: "男☑ 女□" 或 "一般授权☑ 特别授权□ 无□"
                example = field_def.get("example", "")
                # 去掉 ☑/□ 符号，拆分选项
                import re
                options = re.sub(r'[☑□]', '', example).split()
                if options:
                    lite_field["options"] = options
        
        lite[key] = lite_field
    
    return lite


# ==================== Checkbox/Radio 格式化引擎 ====================

def format_checkbox_display(
    selected_value: str,
    field_def: Dict[str, Any],
    checked_symbol: str = DEFAULT_CHECKED_SYMBOL,
    unchecked_symbol: str = DEFAULT_UNCHECKED_SYMBOL,
    separator: str = DEFAULT_SEPARATOR,
) -> str:
    """
    通用 checkbox/radio 格式化函数
    
    根据 schema 定义，将 LLM 返回的选中值格式化为完整显示字符串
    
    例如:
        selected_value = "男"
        options = ["男", "女"]
        → "男☑    女□"
        
        selected_value = "一般授权"
        options = ["一般授权", "特别授权", "无"]
        → "一般授权☑    特别授权□    无□"
    
    Args:
        selected_value: LLM 返回的选中值（如 "男"）
        field_def: 字段定义
        checked_symbol: 选中符号
        unchecked_symbol: 未选中符号
        separator: 选项之间的分隔符
        
    Returns:
        格式化后的显示字符串
    """
    if not selected_value:
        return ""
    
    options = field_def.get("options", [])
    if not options:
        # 尝试从 example 推断
        import re
        example = field_def.get("example", "")
        options = re.sub(r'[☑□]', '', example).split()
    
    if not options:
        # 没有 options，直接返回原值
        return selected_value
    
    # 构建格式化结果
    result_parts = []
    for opt in options:
        if opt == selected_value or opt in str(selected_value):
            result_parts.append(f"{opt}{checked_symbol}")
        else:
            result_parts.append(f"{opt}{unchecked_symbol}")
    
    return separator.join(result_parts)


def format_split_checkbox_display(
    selected_value: str,
    field_def: Dict[str, Any],
    checked_symbol: str = DEFAULT_CHECKED_SYMBOL,
    unchecked_symbol: str = DEFAULT_UNCHECKED_SYMBOL,
) -> Dict[str, str]:
    """
    Split 模式：为每个选项生成单独的显示字段
    
    用于模板中选项分散在不同位置的场景：
        有：{{ has_agent_display }}     → 填充后：有：☑
        ... (中间其他字段)
        无 ：{{ has_agent_display2 }}   → 填充后：无 ：□
    
    Args:
        selected_value: LLM 返回的选中值
        field_def: 字段定义
        checked_symbol: 选中符号
        unchecked_symbol: 未选中符号
        
    Returns:
        字典，如 {"has_agent_display": "☑", "has_agent_display2": "□"}
    """
    if not selected_value:
        return {}
    
    options = field_def.get("options", [])
    if not options:
        import re
        example = field_def.get("example", "")
        options = re.sub(r'[☑□]', '', example).split()
    
    if not options:
        return {}
    
    result = {}
    for i, opt in enumerate(options):
        if i == 0:
            key_suffix = "_display"
        else:
            key_suffix = f"_display{i + 1}"
        
        if opt == selected_value or opt in str(selected_value):
            result[key_suffix] = checked_symbol
        else:
            result[key_suffix] = unchecked_symbol
    
    return result


def format_multi_choice_display(
    selected_values: List[str],
    field_def: Dict[str, Any],
    checked_symbol: str = DEFAULT_CHECKED_SYMBOL,
    unchecked_symbol: str = DEFAULT_UNCHECKED_SYMBOL,
    separator: str = DEFAULT_SEPARATOR,
) -> str:
    """
    多选 checkbox 格式化函数
    
    selected_values 是选中值的列表（如 ["一般授权", "特别授权"]）
    """
    if not selected_values:
        return ""
    
    if isinstance(selected_values, str):
        # 逗号分隔的字符串
        selected_values = [v.strip() for v in selected_values.split(",")]
    
    options = field_def.get("options", [])
    if not options:
        import re
        example = field_def.get("example", "")
        options = re.sub(r'[☑□]', '', example).split()
    
    if not options:
        return ", ".join(selected_values)
    
    result_parts = []
    for opt in options:
        if opt in selected_values:
            result_parts.append(f"{opt}{checked_symbol}")
        else:
            result_parts.append(f"{opt}{unchecked_symbol}")
    
    return separator.join(result_parts)


# ==================== Conditional Block 处理器 ====================

# 处理器注册表 - 便于扩展新类型
BLOCK_HANDLERS: Dict[str, callable] = {}


def register_block_handler(block_type: str):
    """装饰器：注册 conditional_block 处理器"""
    def decorator(func: callable):
        BLOCK_HANDLERS[block_type] = func
        return func
    return decorator


@register_block_handler("show_or_hide")
def handle_show_or_hide(block: Dict[str, Any], params: Dict[str, str]) -> Dict[str, str]:
    """
    处理 show_or_hide 类型条件块
    
    行为:
    - 如果 trigger 字段的值在 show_when 列表中，不干预
    - 否则，将 affected_fields 中的所有字段设置为空字符串
    
    例如:
        trigger: "has_agent"
        show_when: ["有"]
        affected_fields: ["agent_name", "agent_unit", "agent_job_title", "agent_phone"]
        
        has_agent="有" → 不干预，正常填充
        has_agent="无" → agent_name="", agent_unit="", agent_job_title="", agent_phone=""
    """
    trigger = block.get("trigger")
    show_when = block.get("show_when", [])
    affected_fields = block.get("affected_fields", [])
    
    if not trigger or not affected_fields:
        return params
    
    trigger_value = params.get(trigger, "")
    
    # 如果 trigger 值不在 show_when 中，清空 affected_fields
    if trigger_value not in show_when:
        for field in affected_fields:
            params[field] = ""
    
    return params


@register_block_handler("clear_detail")
def handle_clear_detail(block: Dict[str, Any], params: Dict[str, str]) -> Dict[str, str]:
    """
    处理 clear_detail 类型条件块
    
    行为:
    - 如果 trigger 字段的值在 clear_when 列表中，清空 detail_field
    - 否则，不干预
    
    例如:
        trigger: "divorce_opinion"
        clear_when: ["确认"]
        detail_field: "divorce_objection_content"
        
        divorce_opinion="确认" → divorce_objection_content=""
        divorce_opinion="异议" → 不干预，保留异议内容
    """
    trigger = block.get("trigger")
    clear_when = block.get("clear_when", [])
    detail_field = block.get("detail_field")
    
    if not trigger or not detail_field:
        return params
    
    trigger_value = params.get(trigger, "")
    
    # 如果 trigger 值在 clear_when 中，清空 detail_field
    if trigger_value in clear_when:
        params[detail_field] = ""
    
    return params


def process_conditional_blocks(
    schema: Dict[str, Any],
    params: Dict[str, str]
) -> Dict[str, str]:
    """
    处理 schema 中定义的所有 conditional_blocks
    
    按顺序执行所有处理器，处理器可以修改 params
    
    Args:
        schema: 完整模板 schema
        params: LLM 返回的参数
        
    Returns:
        处理后的参数
    """
    blocks = schema.get("conditional_blocks", [])
    
    for block in blocks:
        block_type = block.get("type")
        handler = BLOCK_HANDLERS.get(block_type)
        
        if handler:
            params = handler(block, params)
        else:
            # 未知的 block 类型，跳过并记录警告
            import warnings
            warnings.warn(f"未知的 conditional_block 类型: {block_type}，跳过")
    
    return params


# ==================== 格式化显示字段 ====================

def format_display_fields(
    schema: Dict[str, Any],
    params: Dict[str, str]
) -> Dict[str, str]:
    """
    将 LLM 返回的原始参数格式化为显示字段
    
    例如:
        输入: {"gender": "男", "has_agent": "有", "agent_authority": "一般授权"}
        输出: {
            "gender": "男",
            "gender_display": "男☑    女□",
            "has_agent": "有",
            "has_agent_display": "有☑    无□",
            "agent_authority": "一般授权",
            "agent_authority_display": "一般授权☑    特别授权□    无□",
            ...
        }
    
    Args:
        schema: 完整模板 schema
        params: LLM 返回的参数
        
    Returns:
        添加了 _display 字段的参数
    """
    result = dict(params)
    fields = schema.get("fields", schema)
    
    # 获取格式化配置
    formatting = schema.get("checkbox_formatting", {})
    checked_symbol = formatting.get("checked_symbol", DEFAULT_CHECKED_SYMBOL)
    unchecked_symbol = formatting.get("unchecked_symbol", DEFAULT_UNCHECKED_SYMBOL)
    separator = formatting.get("separator", DEFAULT_SEPARATOR)
    
    for key, field_def in fields.items():
        field_type = field_def.get("type", "text")
        
        # 只处理 checkbox/radio 类字段
        if field_type in ["checkbox", "radio", "single_choice"]:
            selected_value = params.get(key)
            if selected_value:
                display_mode = field_def.get("display_mode", "full")
                
                if display_mode == "split":
                    # Split 模式：为每个选项生成单独字段
                    split_results = format_split_checkbox_display(
                        selected_value,
                        field_def,
                        checked_symbol,
                        unchecked_symbol
                    )
                    for suffix, value in split_results.items():
                        result[f"{key}{suffix}"] = value
                else:
                    # 默认 full 模式：完整选项列表
                    display_value = format_checkbox_display(
                        selected_value,
                        field_def,
                        checked_symbol,
                        unchecked_symbol,
                        separator
                    )
                    result[f"{key}_display"] = display_value
        
        elif field_type in ["multi_choice"]:
            selected_value = params.get(key)
            if selected_value:
                display_value = format_multi_choice_display(
                    selected_value,
                    field_def,
                    checked_symbol,
                    unchecked_symbol,
                    separator
                )
                result[f"{key}_display"] = display_value
    
    return result


# ==================== 主填充流程 ====================

def preprocess_params(
    schema: Dict[str, Any],
    params: Dict[str, str]
) -> Dict[str, str]:
    """
    预处理参数的核心入口
    
    流程:
    1. 处理 conditional_blocks（清空需要隐藏的字段）
    2. 格式化 display 字段
    
    Args:
        schema: 完整模板 schema
        params: LLM 返回的原始参数
        
    Returns:
        处理后的参数，可以直接用于模板填充
    """
    # 1. 处理条件块
    params = process_conditional_blocks(schema, params)
    
    # 2. 格式化显示字段
    params = format_display_fields(schema, params)
    
    return params


# ==================== 字段映射 ====================

def map_collected_to_schema_fields(
    schema: Dict[str, Any],
    collected_params: Dict[str, Any],
) -> Dict[str, str]:
    """
    将 collected_params（中文键名/嵌套字典）映射到 schema 字段键名（英文）。

    策略（按优先级）：
    1. 直接匹配 schema field key（如 collected_params["defendant_name"]）
    2. 通过 label 直接匹配（如 label="被告姓名" → collected_params["被告姓名"]）
    3. 嵌套字典匹配：label 分解为角色前缀+后缀（如 "被告姓名" → "被告" + "姓名"）
    4. 短标签匹配：无角色前缀的 label 在所有嵌套字典中查找
    """
    fields = schema.get("fields", schema) if isinstance(schema, dict) else {}
    if not fields:
        return dict(collected_params)

    mapped = {}

    # 1. 直接匹配 schema field key
    for fk in fields:
        v = collected_params.get(fk)
        if v and isinstance(v, str) and v.strip():
            mapped[fk] = v.strip()
        elif isinstance(v, list):
            joined = "\n".join(str(item) for item in v if item)
            if joined:
                mapped[fk] = joined

    # 构建 label → field_key 反向映射
    label_to_field = {}
    for fk, fd in fields.items():
        label = fd.get("label", "")
        if label:
            label_to_field[label] = fk

    # 2. 通过 label 直接匹配
    for label, fk in label_to_field.items():
        if fk in mapped:
            continue
        v = collected_params.get(label)
        if v and isinstance(v, str) and v.strip():
            mapped[fk] = v.strip()
        elif isinstance(v, list):
            joined = "\n".join(str(item) for item in v if item)
            if joined:
                mapped[fk] = joined

    # 收集所有嵌套字典
    nested_dicts = {}
    for k, v in collected_params.items():
        if isinstance(v, dict) and k not in ("__conditional_blocks__", "checkbox_formatting"):
            nested_dicts[k] = v

    if not nested_dicts:
        return mapped

    # 角色名称映射（用于确定字段属于哪方）
    ROLE_MAP = {
        "defendant": ["被告", "被告信息", "答辩人", "答辩人信息", "被申请人", "被申请人信息"],
        "plaintiff": ["原告", "原告信息", "申请人", "申请人信息"],
        "agent": ["代理人", "代理人信息", "委托代理人", "委托代理人信息"],
    }

    def _get_preferred_roles(field_key: str) -> list:
        fk_lower = field_key.lower()
        for role_keyword, role_names in ROLE_MAP.items():
            if role_keyword in fk_lower:
                return role_names
        return []

    # 已知的角色前缀列表，按长度降序排列
    ALL_ROLE_PREFIXES = []
    for role_names in ROLE_MAP.values():
        ALL_ROLE_PREFIXES.extend(role_names)
    ALL_ROLE_PREFIXES.sort(key=len, reverse=True)

    # 3 & 4. 嵌套字典匹配
    for label, fk in label_to_field.items():
        if fk in mapped:
            continue

        preferred_roles = _get_preferred_roles(fk)

        if preferred_roles:
            search_dicts = [(dn, dv) for dn, dv in nested_dicts.items() if dn in preferred_roles]
            search_dicts += [(dn, dv) for dn, dv in nested_dicts.items() if dn not in preferred_roles]
        else:
            search_dicts = list(nested_dicts.items())

        # 尝试分解 label 为 角色前缀 + 字段后缀
        remainder = None
        matched_prefix = None
        for prefix in ALL_ROLE_PREFIXES:
            if label.startswith(prefix):
                remainder = label[len(prefix):]
                matched_prefix = prefix
                break

        for dict_name, dict_val in search_dicts:
            if not isinstance(dict_val, dict):
                continue

            # 3a. 完整 label 匹配嵌套 dict 的 key
            if label in dict_val:
                v = dict_val[label]
                if v and isinstance(v, str) and v.strip():
                    mapped[fk] = v.strip()
                    break
                elif isinstance(v, list):
                    joined = "\n".join(str(item) for item in v if item)
                    if joined:
                        mapped[fk] = joined
                        break

            # 3b. label 分解后匹配
            if remainder and remainder in dict_val:
                if matched_prefix and (matched_prefix in dict_name or dict_name.startswith(matched_prefix)):
                    v = dict_val[remainder]
                    if v and isinstance(v, str) and v.strip():
                        mapped[fk] = v.strip()
                        break

            # 4. 短标签匹配
            if not remainder and len(label) <= 5:
                found = False
                for nk, nv in dict_val.items():
                    if not isinstance(nv, str) or not nv.strip():
                        continue
                    if nk == label:
                        mapped[fk] = nv.strip()
                        found = True
                        break
                    if label in nk and len(label) >= 2:
                        mapped[fk] = nv.strip()
                        found = True
                        break
                if found:
                    break

    print(f"[map_collected_to_schema] 映射结果: {list(mapped.keys())} (共{len(mapped)}/{len(fields)}个字段)")
    unmapped = [k for k in fields if k not in mapped]
    if unmapped:
        print(f"[map_collected_to_schema] 未映射字段: {unmapped}")

    return mapped


def fill_template_with_schema(
    template_path: str,
    schema: Dict[str, Any],
    params: Dict[str, str]
) -> Dict[str, Any]:
    """
    使用 schema 驱动的引擎填充模板
    
    Args:
        template_path: 模板文件路径
        schema: 完整模板 schema
        params: LLM 返回的参数
        
    Returns:
        修改列表，可直接传给 apply_docx_modifications
    """
    from ..utils.docx_processor import read_docx_paragraphs
    import re
    
    # 预处理参数
    processed_params = preprocess_params(schema, params)
    
    # 读取文档
    doc_content = read_docx_paragraphs(template_path)
    
    modifications = []
    
    # 构建占位符格式列表
    placeholder_formats = [
        "{{ {key} }}",      # {{ key }}
        "{{ {key}}}",       # {{key}}
        "{{{ {key} }}}",    # {{{ key }}}
    ]
    
    for param_key, param_value in processed_params.items():
        if not param_value:
            continue
        
        # 处理段落中的占位符
        for para in doc_content.get("paragraphs", []):
            para_text = para.get("text", "")
            
            for fmt in placeholder_formats:
                placeholder = fmt.format(key=param_key)
                if placeholder in para_text:
                    modifications.append({
                        "type": "modify",
                        "index": para.get("index"),
                        "text": placeholder,
                        "new_text": param_value
                    })
                    break
            
            # 处理带默认值的占位符 {{ key:"default" }}
            pattern = "{{ " + re.escape(param_key) + ':"[^"]*"}}'
            match = re.search(pattern, para_text)
            if match:
                modifications.append({
                    "type": "modify",
                    "index": para.get("index"),
                    "text": match.group(0),
                    "new_text": param_value
                })
        
        # 处理表格单元格中的占位符
        for table_idx, table_info in enumerate(doc_content.get("tables", [])):
            for row_idx, row in enumerate(table_info.get("cells", [])):
                for col_idx, cell_text in enumerate(row):
                    if not cell_text:
                        continue
                    
                    cell_index = f"t{table_idx}_r{row_idx}_c{col_idx}"
                    
                    for fmt in placeholder_formats:
                        placeholder = fmt.format(key=param_key)
                        if placeholder in cell_text:
                            modifications.append({
                                "type": "cell_modify",
                                "index": cell_index,
                                "text": placeholder,
                                "new_text": param_value
                            })
                            break
    
    return modifications

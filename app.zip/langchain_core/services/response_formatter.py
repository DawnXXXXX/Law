"""
响应格式化服务 - 统一格式化散落在多个文件中的输出逻辑

职责:
- router_graph.py:310-323 案例结果 Markdown 格式化
- router_graph.py:352-365 法规结果 Markdown 格式化
- memory.py:252-305 知识库 Prompt 文本格式化
- document_gen_graph.py:597-669 参数表单/确认/缺失提示

设计: 纯静态方法，无状态，可直接测试
"""

from typing import Any, Dict, List, Optional

# 导出上下文压缩功能
from .context_compressor import (
    compress_conversation_history,
    compress_conversation_history_async,
    format_history_for_prompt_with_compression,
    SUMMARIZE_THRESHOLD,
    PRESERVE_RECENT_COUNT,
)


class ResponseFormatter:
    """统一响应格式化器"""

    # ==================== 知识库格式化 ====================

    @staticmethod
    def format_knowledge_for_prompt(
        laws: List[Dict],
        cases: List[Dict],
    ) -> str:
        """
        将法规和案例格式化为 Prompt 可用的文本块

        迁移自 memory.py:252-305 format_knowledge_for_prompt()

        Args:
            laws: 法规列表 (来自 search_laws tool)
            cases: 案例列表 (来自 search_cases tool)

        Returns:
            格式化后的知识库文本
        """
        parts = []

        # 法规部分
        if laws and any(not l.get("error") for l in laws):
            valid_laws = [l for l in laws if not l.get("error")]
            law_parts = []
            for i, law in enumerate(valid_laws[:5], 1):
                law_parts.append(f"{i}. **{law.get('title', '未知法规')}**")
                if law.get('effective_status'):
                    law_parts.append(f"   效力状态: {law['effective_status']}")
                if law.get('content'):
                    content_preview = law['content'][:400] + ("..." if len(law['content']) > 400 else "")
                    law_parts.append(f"   \n```\n{content_preview}\n```")

            if law_parts:
                parts.append("\n## 相关法规\n" + "\n".join(law_parts))

        # 案例部分
        if cases and any(not c.get("error") for c in cases):
            valid_cases = [c for c in cases if not c.get("error")]
            case_parts = []
            for i, case in enumerate(valid_cases[:3], 1):
                case_parts.append(f"{i}. **{case.get('title', '未知案例')}**")
                if case.get('court'):
                    case_parts.append(f"   法院: {case['court']}")
                if case.get('case_number'):
                    case_parts.append(f"   案号: {case['case_number']}")
                if case.get('summary'):
                    summary_preview = case['summary'][:250] + ("..." if len(case['summary']) > 250 else "")
                    case_parts.append(f"   摘要: {summary_preview}")

            if case_parts:
                parts.append("\n## 相关案例\n" + "\n".join(case_parts))

        if not parts:
            return "（暂无相关知识库内容）"

        return "\n\n".join(parts)

    # ==================== 案例格式化 ====================

    @staticmethod
    def format_cases(cases: List[Dict]) -> str:
        """
        格式化案例检索结果为 Markdown

        迁移自 router_graph.py:310-323

        Args:
            cases: 案例列表

        Returns:
            格式化的 Markdown 响应文本
        """
        if not cases:
            return "未找到相关案例。请尝试更换关键词。"

        valid_cases = [c for c in cases if not c.get("error")]
        if not valid_cases:
            return "未找到相关案例。请尝试更换关键词。"

        lines = [f"**案例检索结果**\n\n找到 **{len(valid_cases)}** 个相关案例：\n"]

        for i, case in enumerate(valid_cases, 1):
            lines.append(f"**{i}. {case.get('title', '未知')}**")
            if case.get('court'):
                lines.append(f"   法院：{case['court']}")
            if case.get('case_number'):
                lines.append(f"   案号：{case['case_number']}")
            if case.get('summary'):
                preview = case['summary'][:200]
                lines.append(f"   摘要: {preview}...")
            lines.append("")

        lines.append("---\n\n告诉我您关心的问题，我可以根据这些案例为您分析。")

        return "\n".join(lines)

    # ==================== 法规格式化 ====================

    @staticmethod
    def format_laws(laws: List[Dict]) -> str:
        """
        格式化法规检索结果为 Markdown

        迁移自 router_graph.py:352-365

        Args:
            laws: 法规列表

        Returns:
            格式化的 Markdown 响应文本
        """
        if not laws:
            return "未找到相关法规。请尝试更换关键词。"

        valid_laws = [l for l in laws if not l.get("error")]
        if not valid_laws:
            return "未找到相关法规。请尝试更换关键词。"

        lines = [f"**法规检索结果**\n\n找到 **{len(valid_laws)}** 条相关法规：\n"]

        for i, law in enumerate(valid_laws, 1):
            lines.append(f"**{i}. {law.get('title', '未知')}**")
            if law.get('law_type'):
                lines.append(f"   类型：{law['law_type']}")
            if law.get('effective_status'):
                lines.append(f"   效力：{law['effective_status']}")
            if law.get('content'):
                preview = (law['content'][:300]) + ("..." if len(law['content']) > 300 else "")
                lines.append(f"\n```\n{preview}\n```")
            lines.append("")

        lines.append("---\n\n如需基于这些法规起草文书，我可以帮您生成。")

        return "\n".join(lines)

    # ==================== 文书生成参数表单格式化 ====================

    @staticmethod
    def build_params_widget(
        params_def: Dict[str, Any],
        collected: Dict[str, str],
    ) -> Dict[str, Any]:
        """
        构建参数表单 Widget

        迁移自 document_gen_graph.py:636-656

        Args:
            params_def: 参数定义字典 {name: {label, required, type}}
            collected: 已收集的参数值 {name: value}

        Returns:
            Widget 配置字典
        """
        fields = []
        for key, info in params_def.items():
            fields.append({
                "name": key,
                "label": info.get("label", key),
                "type": info.get("type", "text"),
                "required": info.get("required", False),
                "value": collected.get(key, ""),
                "placeholder": f"请输入{info.get('label', key)}",
            })

        return {
            "type": "form",
            "title": "填写信息",
            "fields": fields,
        }

    @staticmethod
    def build_confirm_text(
        template_name: str,
        params: Dict[str, str],
    ) -> str:
        """
        构建确认文本

        迁移自 document_gen_graph.py:659-668

        Args:
            template_name: 模板名称
            params: 已收集的参数

        Returns:
            确认提示文本
        """
        text = f"✅ 所有信息已收集完毕！\n\n📋 **{template_name}**\n"

        for key, value in params.items():
            if value:
                text += f"• {key}：{value}\n"

        text += "\n是否确认生成文书？"
        return text

    @staticmethod
    def build_missing_prompt(
        template_name: str,
        params_def: Dict[str, Any],
        missing: List[str],
        collected: Dict[str, str],
    ) -> str:
        """
        构建缺失参数追问提示

        迁移自 document_gen_graph.py:614-633

        Args:
            template_name: 模板名称
            params_def: 参数定义
            missing: 缺失的参数名列表
            collected: 已收集的参数

        Returns:
            追问提示文本
        """
        prompt = f"好的，我已收集到以下信息：\n"

        for key, value in collected.items():
            if value:
                label = params_def.get(key, {}).get("label", key)
                prompt += f"✅ {label}：{value}\n"

        prompt += "\n还缺少以下**必填信息**，请补充：\n"
        for key in missing:
            label = params_def.get(key, {}).get("label", key)
            prompt += f"• {label}\n"

        # 添加引导提示
        prompt += "\n---\n💡 **提示**：您可以直接在下方对话框中用自然语言描述这些信息，例如：\n"
        prompt += f"   \"我的被告叫张三，出生于1985年3月，工作单位是XX公司...\"\n"
        prompt += f"   系统会自动提取并填充这些信息。您也可以点击上方的【填写表单】按钮进行手动输入。"

        return prompt

    # ==================== 通用格式化 ====================

    @staticmethod
    def format_history_for_prompt(messages: List[Dict[str, str]]) -> str:
        """
        将消息列表格式化为 Prompt 文本（精简版）

        Args:
            messages: 消息列表 [{"role": "human/ai", "content": "..."}]

        Returns:
            格式化的对话文本
        """
        if not messages:
            return "(无对话历史)"

        lines = []
        for msg in messages[-3:]:  # 最近3条，减少 token
            role_label = "用户" if msg.get("role") == "human" else "助手"
            content = msg.get("content", "")[:100]  # 截断到100字符
            lines.append(f"{role_label}：{content}")

        return "\n".join(lines)

    # ==================== 文书生成提示构建 ====================

    @staticmethod
    def build_param_collect_prompt(
        template_name: str,
        params_def: Dict[str, Any],
        collected: Dict[str, str],
        pending: List[str],
    ) -> str:
        """
        构建参数收集提示

        迁移自 document_chat_service.py:_build_param_collect_prompt()

        Args:
            template_name: 模板名称
            params_def: 参数定义字典
            collected: 已收集的参数
            pending: 待收集的参数名列表

        Returns:
            格式化的提示文本
        """
        prompt = f"好的，您要生成【{template_name}】。\n\n"

        if collected:
            prompt += "✅ 已收集的信息：\n"
            for key, value in collected.items():
                label = params_def.get(key, {}).get("label", key)
                prompt += f"   • {label}：{value}\n"
            prompt += "\n"

        if pending:
            prompt += "📝 请继续提供以下信息：\n"
            for i, param_key in enumerate(pending, 1):
                param_info = params_def.get(param_key, {})
                label = param_info.get("label", param_key)
                desc = param_info.get("description", "")
                prompt += f"   {i}. {label}"
                if desc:
                    prompt += f"（{desc}）"
                prompt += "\n"

        # 添加引导提示
        prompt += "\n---\n💡 **提示**：您可以直接用自然语言描述这些信息，例如：\n"
        prompt += f"   \"被告叫张三，1985年出生...\"\n"
        prompt += "   系统会自动提取并填充这些信息。"

        return prompt

    @staticmethod
    def build_generation_confirm_widget(
        template_name: str,
        collected: Dict[str, str],
    ) -> Dict[str, Any]:
        """
        构建生成确认 Widget

        迁移自 document_chat_service.py:_build_generation_confirm()

        Args:
            template_name: 模板名称
            collected: 已收集的参数

        Returns:
            Widget 配置字典
        """
        # 构建已收集信息的摘要
        summary_lines = []
        for key, value in collected.items():
            if value:
                summary_lines.append(f"• {key}：{value}")

        return {
            "type": "dialog",
            "title": "确认生成",
            "content": f"【{template_name}】\n\n📋 已收集的信息：\n" + "\n".join(summary_lines) + "\n\n是否确认生成文书？",
            "actions": [
                {"type": "button", "label": "确认生成", "action": "confirm_generate", "primary": True},
                {"type": "button", "label": "继续修改", "action": "continue_edit"}
            ]
        }

    @staticmethod
    def build_generation_success_message(result: Dict[str, Any]) -> str:
        """
        构建生成成功消息

        迁移自 document_chat_service.py:_build_generation_success_message()

        Args:
            result: 生成结果字典

        Returns:
            成功提示文本
        """
        return f"""✅ 文书生成成功！

📄 文件名：{result.get('file_name', '文书.docx')}
📁 保存位置：{result.get('file_path', '生成中...')}

是否有需要调整的地方？"""

    @staticmethod
    def build_generation_success_widget(result: Dict[str, Any]) -> Dict[str, Any]:
        """
        构建生成成功 Widget

        迁移自 document_chat_service.py:_build_generation_success_widget()

        Args:
            result: 生成结果字典

        Returns:
            Widget 配置字典
        """
        return {
            "type": "document_generated",
            "title": "文书生成成功",
            "document": {
                "name": result.get("file_name", "文书.docx"),
                "path": result.get("file_path", ""),
                "preview_url": result.get("preview_url", "")
            },
            "actions": [
                {"type": "button", "label": "查看文书", "action": "open_preview", "primary": True},
                {"type": "button", "label": "下载文件", "action": "download"},
                {"type": "button", "label": "进行调整", "action": "start_modification"}
            ]
        }

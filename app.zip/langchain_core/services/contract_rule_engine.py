"""
合同规则引擎 (ContractRuleEngine)

基于 JSON 规则库的合同条款风险预筛引擎。
支持 AND / OR / ABSENCE 三种匹配逻辑。
规则库路径: data/contract_rules.json
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Sequence

from ...config import settings


@dataclass
class RuleMatchResult:
    """单条规则命中结果"""
    rule_id: str
    risk_type: str
    risk_level: str           # high / medium / low
    matched_text: str         # 命中的原文片段
    clause_index: int         # 条款索引
    description: str          # 风险描述（模板填充后）
    suggestion: str           # 修改建议（模板填充后）
    detected_value: str = ""
    need_llm_confirm: bool = False
    llm_prompt_extra: str = ""


@dataclass
class ScanResult:
    """扫描汇总"""
    suspected_risks: List[RuleMatchResult] = field(default_factory=list)
    total_clauses: int = 0
    high_risk_count: int = 0
    medium_risk_count: int = 0
    low_risk_count: int = 0


class ContractRuleEngine:
    """合同风险规则引擎 — 从 JSON 规则库加载规则并逐条匹配"""

    DEFAULT_RULES_PATH = Path(settings.UPLOAD_DIR).parent.parent / "data" / "contract_rules.json"

    def __init__(self, rules_path: str | None = None):
        path = Path(rules_path or self.DEFAULT_RULES_PATH)
        with open(path, "r", encoding="utf-8") as f:
            self._rules: List[Dict[str, Any]] = json.load(f)
        print(f"[RuleEngine] 已加载 {len(self._rules)} 条规则")

    def scan_clauses(
        self, clauses: Sequence[Dict[str, Any]], text_field: str = "content"
    ) -> ScanResult:
        """
        对每条条款逐一执行规则匹配

        Args:
            clauses: 条款列表，每项需含 text_field 字段
            text_field: 用于匹配的文本字段名

        Returns:
            ScanResult 包含所有命中的疑似风险项
        """
        result = ScanResult(total_clauses=len(clauses))

        for c_idx, clause in enumerate(clauses):
            text = clause.get(text_field, "")

            for rule in self._rules:
                match = self._match_rule(rule, text, c_idx)
                if match:
                    result.suspected_risks.append(match)
                    level = match.risk_level
                    if level == "high":
                        result.high_risk_count += 1
                    elif level == "medium":
                        result.medium_risk_count += 1
                    else:
                        result.low_risk_count += 1

        return result

    def _match_rule(self, rule: Dict[str, Any], text: str, clause_index: int) -> RuleMatchResult | None:
        """对单条文本执行单条规则的匹配判断"""
        logic = rule.get("logic", "AND")
        keywords = rule.get("keywords", [])
        pattern = rule.get("regex", "")
        matched_text = ""

        if logic == "ABSENCE":
            # 缺失检测：关键词存在但正则不匹配 → 说明该有内容的地方没有
            if keywords and any(kw in text for kw in keywords):
                if pattern and not re.search(pattern, text, re.DOTALL):
                    matched_text = text[:200]  # 标记整段
                elif not pattern:
                    matched_text = text[:200]
            if not matched_text:
                return None
        elif logic == "OR":
            if not any(kw in text for kw in keywords):
                return None
            matched_text = self._extract_matched_segment(text, keywords, pattern)
        else:  # AND（默认）
            if not all(kw in text for kw in keywords):
                return None
            matched_text = self._extract_matched_segment(text, keywords, pattern)

        # 提取检测值（用于模板填充）
        detected_value = ""
        if pattern:
            m = re.search(pattern, text, re.DOTALL)
            if m:
                detected_value = m.group(0)[:100]

        desc = rule.get("default_description", "").replace("{detected_value}", detected_value)
        sug = rule.get("default_suggestion", "").replace("{detected_value}", detected_value)

        return RuleMatchResult(
            rule_id=rule["rule_id"],
            risk_type=rule["risk_type"],
            risk_level=rule.get("risk_level", "medium"),
            matched_text=matched_text[:300],
            clause_index=clause_index,
            description=desc,
            suggestion=sug,
            detected_value=detected_value,
            need_llm_confirm=rule.get("need_llm_confirm", False),
            llm_prompt_extra=rule.get("llm_prompt_extra", ""),
        )

    @staticmethod
    def _extract_matched_segment(text: str, keywords: List[str], pattern: str) -> str:
        """从文本中提取包含关键字的上下文片段"""
        if pattern:
            m = re.search(pattern, text, re.DOTALL)
            if m:
                return m.group(0)[:300]

        # 回退：找第一个关键字前后各取50字
        for kw in keywords:
            pos = text.find(kw)
            if pos >= 0:
                start = max(0, pos - 50)
                end = min(len(text), pos + len(kw) + 150)
                return text[start:end]
        return text[:200]

"""
模板管理服务 - 替代 document_gen_graph.py 中的 select_template_node 业务逻辑

职责:
- 模板精确匹配
- 模板模糊匹配
- 按分类列出所有模板
- 获取模板参数定义

消除的问题:
- document_gen_graph.py:71 ContextVar _db_context（改为构造函数注入）
- document_gen_graph.py:131-230 100行纯业务逻辑外泄到 Graph 节点
"""

from typing import Any, Dict, List, Optional
import dataclasses

from .response_formatter import ResponseFormatter


@dataclasses.dataclass
class TemplateMatchResult:
    """模板匹配结果"""
    template_id: Optional[int]
    template_name: Optional[str]
    params_def: Dict                       # 参数定义
    response_text: str                     # 预生成提示文本
    widget: Dict                           # 表单Widget
    matched: bool                          # 是否匹配成功


@dataclasses.dataclass
class TemplateCategory:
    """模板分类"""
    name: str
    templates: List[Dict]


class TemplateService:
    """
    模板查询与匹配服务

    通过构造函数注入 db，不再使用 ContextVar 隐式传参。
    """

    def __init__(self, db: Any):
        """
        初始化模板服务

        Args:
            db: 数据库会话（通过构造函数注入，不再使用 ContextVar）
        """
        self._db = db
        self._mgr = None

    def _get_manager(self):
        """获取 TemplateManager 实例（懒加载）"""
        if self._mgr is None:
            from app.workflows import TemplateManager
            self._mgr = TemplateManager(self._db)
        return self._mgr

    async def get_template_by_id(self, template_id: int) -> Optional[Dict[str, Any]]:
        """
        根据ID获取模板

        Args:
            template_id: 模板ID

        Returns:
            模板信息字典，不存在则返回 None
        """
        mgr = self._get_manager()
        return await mgr.get_template(str(template_id))

    async def match_template(
        self,
        document_type: str = "",
        message: str = "",
    ) -> TemplateMatchResult:
        """
        匹配最佳模板（精确→模糊→返回未匹配）

        迁移自 document_gen_graph.py:150-183

        Args:
            document_type: 文书类型（来自意图识别）
            message: 用户消息（用于模糊匹配）

        Returns:
            TemplateMatchResult
        """
        mgr = self._get_manager()

        # 场景A: 已指定文书类型 → 尝试自动匹配模板
        if document_type:
            try:
                # 先尝试精确匹配
                template = await mgr.get_template(document_type)

                if not template:
                    # 尝试从消息内容中检测
                    templates_all = await mgr.get_all_templates()
                    for t in templates_all:
                        if document_type in t.get("name", "") or t.get("name", "") in message:
                            template = t
                            break

                if template:
                    params_def = await mgr.get_template_params(template["name"])

                    return TemplateMatchResult(
                        template_id=template.get("id"),
                        template_name=template.get("name"),
                        params_def=params_def,
                        response_text=f"好的，您要生成【{template['name']}】。\n\n请提供以下信息：\n{self._format_param_list(params_def)}",
                        widget=ResponseFormatter.build_params_widget(params_def, {}),
                        matched=True,
                    )
            except Exception as e:
                print(f"[template_service] 模板查询异常: {e}")

        return TemplateMatchResult(
            template_id=None,
            template_name=None,
            params_def={},
            response_text="",
            widget={},
            matched=False,
        )

    async def list_categories(self) -> List[TemplateCategory]:
        """
        按分类列出所有模板（用于选择界面）

        迁移自 document_gen_graph.py:188-223

        Returns:
            模板分类列表
        """
        mgr = self._get_manager()

        try:
            # TemplateManager.get_templates_by_category() 返回 Dict[str, List[Dict]]
            categories = await mgr.get_templates_by_category()

            return [
                TemplateCategory(name=cat_name, templates=templates)
                for cat_name, templates in categories.items()
            ]
        except Exception as e:
            print(f"[template_service] 加载模板分类失败: {e}")
            import traceback
            traceback.print_exc()
            return []

    async def get_params_def(self, template_name: str) -> Dict[str, Any]:
        """
        获取模板参数定义

        Args:
            template_name: 模板名称

        Returns:
            参数定义字典
        """
        mgr = self._get_manager()
        return await mgr.get_template_params(template_name)

    def _format_param_list(self, params_def: Dict[str, Any]) -> str:
        """格式化参数列表为文本"""
        required = [(k, v) for k, v in params_def.items() if v.get("required")]
        optional = [(k, v) for k, v in params_def.items() if not v.get("required")]

        lines = []
        for i, (key, info) in enumerate(required, 1):
            lines.append(f"{i}. **{info.get('label', key)}** （必填）")

        if optional:
            lines.append("\n可选信息：")
            for key, info in optional:
                lines.append(f"- {info.get('label', key)}")

        return "\n".join(lines)

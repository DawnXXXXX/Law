"""
LangChain 服务层 - 统一导出

从 graphs/chains 中提取的 10 个独立服务层。
"""

from .response_formatter import ResponseFormatter
from .conversation_memory import (
    ConversationMemoryService,
    ConversationMemory,
    SimpleChatMemory,
    get_memory,
    reset_memory,
    get_consultation_memory,
    create_consultation_memory,
)
from .knowledge_retrieval import KnowledgeRetrievalService, KnowledgeContext
from .intent_classifier import IntentClassifier, RuleBasedIntentFallback
from .search_service import SearchService, SearchResults
from .template_service import TemplateService, TemplateMatchResult, TemplateCategory
from .document_gen_service import DocumentGenerationService, CollectParamsResult, GenerationResult
from .document_mod_service import (
    DocumentModificationService,
    ModifyClassification,
    ExecutionResult,
)
from .similar_case_service import SimilarCaseRetrievalService
from .contract_rule_engine import ContractRuleEngine, RuleMatchResult, ScanResult

__all__ = [
    # 8 + 2 个服务类
    "IntentClassifier",
    "RuleBasedIntentFallback",
    "SearchService",
    "SearchResults",
    "KnowledgeRetrievalService",
    "KnowledgeContext",
    "ConversationMemoryService",
    "ConversationMemory",
    "SimpleChatMemory",
    "TemplateService",
    "TemplateMatchResult",
    "TemplateCategory",
    "DocumentGenerationService",
    "CollectParamsResult",
    "GenerationResult",
    "DocumentModificationService",
    "ModifyClassification",
    "ExecutionResult",
    "ResponseFormatter",
    # 四大模块新增
    "SimilarCaseRetrievalService",
    "ContractRuleEngine",
    "RuleMatchResult",
    "ScanResult",
    # 向后兼容别名
    "get_memory",
    "reset_memory",
    "get_consultation_memory",
    "create_consultation_memory",
]

"""
上下文压缩服务 - 智能压缩对话历史以节省 Token

核心功能:
1. 当对话历史超过阈值时，自动对早期消息进行摘要
2. 只保留最近 2 条消息原文，其余转为摘要
3. 使用 LLM 生成高质量摘要

使用方式:
    from app.langchain_core.services.context_compressor import compress_conversation_history

    # 同步调用
    compressed = compress_conversation_history(messages)

    # 异步调用
    compressed = await compress_conversation_history_async(messages, llm)
"""

import asyncio
from typing import List, Dict, Optional, Any

from ..prompts import HISTORY_SUMMARIZE_PROMPT
from ..llm_factory import get_primary_llm


# ==================== 配置 ====================

# 触发摘要的消息数量阈值
SUMMARIZE_THRESHOLD = 3

# 摘要后保留的原文消息数量
PRESERVE_RECENT_COUNT = 2


# ==================== 核心函数 ====================

def _format_messages_for_summary(messages: List[Dict[str, str]]) -> str:
    """
    将消息列表格式化为摘要提示的文本

    Args:
        messages: 消息列表 [{"role": "human/ai", "content": "..."}]

    Returns:
        格式化的历史文本
    """
    lines = []
    for msg in messages:
        role = "用户" if msg.get("role") == "human" else "助手"
        content = msg.get("content", "")
        lines.append(f"{role}：{content}")
    return "\n".join(lines)


def compress_conversation_history(
    messages: List[Dict[str, str]],
    llm: Optional[Any] = None,
    threshold: int = SUMMARIZE_THRESHOLD,
    preserve_count: int = PRESERVE_RECENT_COUNT,
) -> List[Dict[str, str]]:
    """
    压缩对话历史（同步版本）

    当消息数量超过阈值时，对早期消息进行摘要，只保留最近的 preserve_count 条原文。

    Args:
        messages: 原始消息列表
        llm: LLM 实例（可选，默认使用主 LLM）
        threshold: 触发摘要的消息数量阈值
        preserve_count: 摘要后保留的原文消息数量

    Returns:
        压缩后的消息列表
    """
    # 不需要压缩
    if len(messages) <= threshold:
        return messages

    # 获取 LLM
    if llm is None:
        llm = get_primary_llm()

    # 分割消息：需要摘要的 + 保留原文的
    to_summarize = messages[:-preserve_count] if preserve_count > 0 else messages
    to_preserve = messages[-preserve_count:] if preserve_count > 0 else []

    # 生成摘要
    history_text = _format_messages_for_summary(to_summarize)

    try:
        prompt = HISTORY_SUMMARIZE_PROMPT.format_prompt(history_text=history_text)
        response = llm.invoke(prompt.to_messages())
        summary = response.content if hasattr(response, 'content') else str(response)
    except Exception as e:
        # 降级：简单拼接
        summary = f"[历史摘要：{len(to_summarize)}轮对话]"
        for msg in to_summarize[-3:]:  # 只取最后3条拼接
            role = "用户" if msg.get("role") == "human" else "助手"
            content = msg.get("content", "")[:50]
            summary += f"{role}：{content}；"

    # 构建压缩后的消息
    compressed = [
        {
            "role": "system",
            "content": f"[历史摘要] {summary}"
        }
    ]
    compressed.extend(to_preserve)

    return compressed


async def compress_conversation_history_async(
    messages: List[Dict[str, str]],
    llm: Optional[Any] = None,
    threshold: int = SUMMARIZE_THRESHOLD,
    preserve_count: int = PRESERVE_RECENT_COUNT,
) -> List[Dict[str, str]]:
    """
    压缩对话历史（异步版本）

    当消息数量超过阈值时，对早期消息进行摘要，只保留最近的 preserve_count 条原文。

    Args:
        messages: 原始消息列表
        llm: LLM 实例（可选，默认使用主 LLM）
        threshold: 触发摘要的消息数量阈值
        preserve_count: 摘要后保留的原文消息数量

    Returns:
        压缩后的消息列表
    """
    # 不需要压缩
    if len(messages) <= threshold:
        return messages

    # 获取 LLM
    if llm is None:
        llm = get_primary_llm()

    # 分割消息：需要摘要的 + 保留原文的
    to_summarize = messages[:-preserve_count] if preserve_count > 0 else messages
    to_preserve = messages[-preserve_count:] if preserve_count > 0 else []

    # 生成摘要
    history_text = _format_messages_for_summary(to_summarize)

    try:
        prompt = HISTORY_SUMMARIZE_PROMPT.format_prompt(history_text=history_text)
        response = await llm.ainvoke(prompt.to_messages())
        summary = response.content if hasattr(response, 'content') else str(response)
    except Exception as e:
        # 降级：简单拼接
        summary = f"[历史摘要：{len(to_summarize)}轮对话]"
        for msg in to_summarize[-3:]:
            role = "用户" if msg.get("role") == "human" else "助手"
            content = msg.get("content", "")[:50]
            summary += f"{role}：{content}；"

    # 构建压缩后的消息
    compressed = [
        {
            "role": "system",
            "content": f"[历史摘要] {summary}"
        }
    ]
    compressed.extend(to_preserve)

    return compressed


# ==================== 与 ResponseFormatter 集成 ====================

def format_history_for_prompt_with_compression(
    messages: List[Dict[str, str]],
    enable_compression: bool = True,
    llm: Optional[Any] = None,
) -> str:
    """
    带压缩的对话历史格式化

    集成到 ResponseFormatter 的 format_history_for_prompt 逻辑中。

    Args:
        messages: 消息列表
        enable_compression: 是否启用压缩
        llm: LLM 实例

    Returns:
        格式化的对话文本
    """
    if not messages:
        return "(无对话历史)"

    if enable_compression and len(messages) > SUMMARIZE_THRESHOLD:
        # 使用压缩
        compressed = compress_conversation_history(messages, llm)
        return _format_compressed_messages(compressed)
    else:
        # 不压缩，直接格式化
        return _format_simple_messages(messages)


def _format_compressed_messages(messages: List[Dict[str, str]]) -> str:
    """格式化压缩后的消息（支持摘要标记）"""
    lines = []
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")

        if role == "system" and content.startswith("[历史摘要]"):
            # 摘要消息显示为独立行
            lines.append(f"\n{content}\n")
        else:
            role_label = "用户" if role == "human" else "助手"
            lines.append(f"{role_label}：{content}")

    return "\n".join(lines)


def _format_simple_messages(messages: List[Dict[str, str]]) -> str:
    """简单格式化消息（无压缩）"""
    lines = []
    for msg in messages[-3:]:  # 只取最近3条
        role_label = "用户" if msg.get("role") == "human" else "助手"
        content = msg.get("content", "")[:100]
        lines.append(f"{role_label}：{content}")
    return "\n".join(lines)

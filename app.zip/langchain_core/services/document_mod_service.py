"""
文书修改引擎 - 替代 document_mod_graph.py 中的 L1/L2/L3 执行器

职责:
- 修改请求分类（L1/L2/L3）
- L1 文本替换执行
- L2 语义改写执行
- L3 知识增强执行
- 版本差异计算

消除的问题:
- document_mod_graph.py:124,137 内部调用 get_generation_llm()
- document_mod_graph.py:218 内部调用 get_generation_llm()
- document_mod_graph.py:551,554 内部调用 get_generation_llm()
- document_mod_graph.py:571,574 内部调用 get_generation_llm()
- 共 6 处 get_generation_llm() 调用
"""

from typing import Any, Dict, List, Optional
import dataclasses
import re
import difflib
from datetime import datetime

from ..parsers import modify_classify_parser, LegacyJsonParser
from ..prompts import MODIFY_CLASSIFY_PROMPT, MODIFY_REWRITE_PROMPT, MODIFY_ENHANCE_PROMPT
from .response_formatter import ResponseFormatter


@dataclasses.dataclass
class ModifyClassification:
    """修改请求分类"""
    modification_level: str           # "L1_text_replace" | "L2_semantic_rewrite" | "L3_knowledge_enhanced"
    legal_topics: List[str]
    estimated_complexity: str
    requires_knowledge: bool


@dataclasses.dataclass
class ExecutionResult:
    """修改执行结果"""
    content: str                      # 修改后内容
    diff: str                         # 差异文本
    level: str                        # 执行的级别
    version: int = 0


class DocumentModificationService:
    """
    文书修改引擎

    支持 L1/L2/L3 三种修改级别，通过构造函数注入 LLM。
    """

    def __init__(
        self,
        llm: Any,
        knowledge_service: Any = None,
    ):
        """
        初始化文书修改服务

        Args:
            llm: LLM 实例（注入，不再内部 import）
            knowledge_service: 知识检索服务（用于 L3 增强）
        """
        self._llm = llm
        self._knowledge_svc = knowledge_service

    async def classify_modification(
        self,
        request: str,
        document_content: str,
    ) -> ModifyClassification:
        """
        分析用户修改请求，分类为 L1/L2/L3

        迁移自 document_mod_graph.py:113-175

        Args:
            request: 用户修改请求
            document_content: 当前文书内容

        Returns:
            ModifyClassification
        """
        if self._llm is None:
            return self._classify_by_rules(request)

        try:
            prompt = MODIFY_CLASSIFY_PROMPT.format(
                document_content=document_content[:3000],
                user_request=request,
            )

            response = await self._llm.ainvoke(prompt)
            resp_text = response.content if hasattr(response, 'content') else str(response)

            parsed = modify_classify_parser.parse(resp_text)

            return ModifyClassification(
                modification_level=parsed.modification_level,
                legal_topics=list(parsed.legal_topics),
                estimated_complexity=parsed.estimated_complexity,
                requires_knowledge=parsed.requires_knowledge,
            )

        except Exception as e:
            print(f"[doc_mod_service] 分类失败: {e}")
            return self._classify_by_rules(request)

    async def execute(
        self,
        level: str,
        content: str,
        request: str,
        knowledge: Dict[str, Any] = None,
    ) -> ExecutionResult:
        """
        根据级别执行修改

        Args:
            level: 修改级别 "L1_text_replace" | "L2_semantic_rewrite" | "L3_knowledge_enhanced"
            content: 当前文书内容
            request: 用户修改请求
            knowledge: 知识检索结果（用于 L3）

        Returns:
            ExecutionResult
        """
        if level == "L1_text_replace":
            new_content = self._exec_l1(content, request)
        elif level == "L3_knowledge_enhanced":
            new_content = await self._exec_l3(content, request, knowledge or {})
        else:
            new_content = await self._exec_l2(content, request)

        diff = self.compute_diff(content, new_content)

        return ExecutionResult(
            content=new_content,
            diff=diff,
            level=level,
        )

    # ==================== 内部执行方法 ====================

    def _exec_l1(self, content: str, request: str) -> str:
        """
        L1: 简单文本替换

        使用正则表达式匹配替换模式。
        """
        # 尝试从请求中提取 "把A改成B" 模式
        match = re.search(r'把(.+?)改成(.+)', request)
        if match:
            old_text = match.group(1).strip()
            new_text = match.group(2).strip()
            return content.replace(old_text, new_text)

        # 尝试 "将A改为B" 或 "把A换为B"
        match = re.search(r'将?(.+?)[改换成](.+)', request)
        if match:
            old_text = match.group(1).strip()
            new_text = match.group(2).strip()
            return content.replace(old_text, new_text)

        # 无法识别具体替换内容，原样返回
        return content

    async def _exec_l2(self, content: str, request: str) -> str:
        """
        L2: 语义改写（使用 LLM）
        """
        if self._llm is None:
            print(f"[doc_mod_service:L2] 无 LLM，降级为 L1")
            return self._exec_l1(content, request)

        try:
            prompt = MODIFY_REWRITE_PROMPT.format(
                original_content=content,
                instruction=request,
            )

            response = await self._llm.ainvoke(prompt)
            return response.content if hasattr(response, 'content') else str(response)
        except Exception as e:
            print(f"[doc_mod_service:L2] 改写失败: {e}")
            return content

    async def _exec_l3(
        self,
        content: str,
        request: str,
        knowledge: Dict[str, Any],
    ) -> str:
        """
        L3: 知识增强改写（使用 LLM + 法规/案例）
        """
        if self._llm is None:
            print(f"[doc_mod_service:L3] 无 LLM，降级为 L2")
            return await self._exec_l2(content, request)

        try:
            laws = knowledge.get("laws", [])
            cases = knowledge.get("cases", [])

            laws_text = "\n".join(
                f"- {l.get('title', '')}: {(l.get('content', '') or '')[:200]}"
                for l in laws[:3]
            )
            cases_text = "\n".join(
                f"- {c.get('title', '')}: {(c.get('summary', '') or '')[:200]}"
                for c in cases[:2]
            )

            prompt = MODIFY_ENHANCE_PROMPT.format(
                original_content=content,
                instruction=request,
                laws_context=laws_text or "(无相关法规)",
                cases_context=cases_text or "(无相关案例)",
            )

            response = await self._llm.ainvoke(prompt)
            return response.content if hasattr(response, 'content') else str(response)
        except Exception as e:
            print(f"[doc_mod_service:L3] 增强改写失败: {e}")
            return await self._exec_l2(content, request)

    # ==================== 规则分类（兜底） ====================

    @staticmethod
    def _classify_by_rules(request: str) -> ModifyClassification:
        """
        基于规则快速分类（LLM 不可用时的降级方案）

        迁移自 document_mod_graph.py:496-509 _classify_by_rules()
        """
        l1_patterns = ["改成", "改为", "替换成", "换成", "把.*改", "将.*改为"]
        l3_patterns = ["法条", "法律依据", "根据.*法", "引用", "案例", "参照"]

        for pattern in l3_patterns:
            if re.search(pattern, request):
                return ModifyClassification(
                    modification_level="L3_knowledge_enhanced",
                    legal_topics=[],
                    estimated_complexity="high",
                    requires_knowledge=True,
                )

        for pattern in l1_patterns:
            if re.search(pattern, request):
                return ModifyClassification(
                    modification_level="L1_text_replace",
                    legal_topics=[],
                    estimated_complexity="low",
                    requires_knowledge=False,
                )

        return ModifyClassification(
            modification_level="L2_semantic_rewrite",
            legal_topics=[],
            estimated_complexity="medium",
            requires_knowledge=False,
        )

    @staticmethod
    def _extract_legal_topics(request: str) -> List[str]:
        """从请求中提取可能的法律主题词"""
        legal_terms = [
            "劳动合同", "民法典", "合同法", "公司法", "婚姻法", "劳动法",
            "违约金", "赔偿", "侵权", "债务", "股权", "知识产权",
            "诉讼时效", "管辖权", "证据", "仲裁", "执行",
        ]

        found = []
        for term in legal_terms:
            if term in request:
                found.append(term)

        return found[:3]

    # ==================== 工具方法 ====================

    @staticmethod
    def compute_diff(old_text: str, new_text: str) -> str:
        """
        计算两段文本的差异

        迁移自 document_mod_graph.py:597-624 compute_diff()

        Args:
            old_text: 原文
            new_text: 新文

        Returns:
            人类可读的差异描述
        """
        if old_text == new_text:
            return "(无变更)"

        old_lines = old_text.splitlines(keepends=True)
        new_lines = new_text.splitlines(keepends=True)

        diff_lines = list(difflib.unified_diff(old_lines, new_lines, lineterm="", n=3))

        if len(diff_lines) > 50:
            return (
                f"... 共 {len(diff_lines)} 行变更 ...\n"
                + "".join(diff_lines[:20])
                + f"\n... (省略中间部分) ...\n"
                + "".join(diff_lines[-20:])
            )

        return "".join(diff_lines) if diff_lines else "(内容已更新)"

    @staticmethod
    def extract_target_version(request: str, current_ver: int) -> Optional[int]:
        """
        从用户消息中提取目标回滚版本号

        迁移自 document_mod_graph.py:627-644 _extract_target_version()

        Args:
            request: 用户消息
            current_ver: 当前版本号

        Returns:
            目标版本号，或 None
        """
        patterns = [
            r'[Vv]?(\d+)',
            r'第\s*(\d+)\s*版',
            r'version\s*(\d+)',
            r'回滚?\s*到?.*?(\d+)',
        ]

        for pattern in patterns:
            match = re.search(pattern, request)
            if match:
                ver = int(match.group(1))
                if 1 <= ver <= current_ver:
                    return ver

        return None

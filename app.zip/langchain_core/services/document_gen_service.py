"""
文书生成编排服务

职责:
- 参数提取（LLM）
- 参数合并与缺失检查
- 文书生成
- 文件保存
"""

from typing import Any, Dict, List, Optional
import dataclasses
import json
import os

# 注意: business_chains 的导入延迟到函数内部，避免循环导入
from .response_formatter import ResponseFormatter
from .template_schema_engine import generate_llm_lite_schema, preprocess_params


@dataclasses.dataclass
class CollectParamsResult:
    """参数收集结果"""
    collected_params: Dict[str, str]
    missing_required: List[str]
    response_text: str
    widget: Dict
    phase: str                              # "collect_params" | "confirm"


@dataclasses.dataclass
class GenerationResult:
    """文书生成结果"""
    content: str
    file_path: str
    filename: str
    preview: str
    response_text: str
    widget: Dict


class DocumentGenerationService:
    """
    文书生成编排服务

    通过构造函数注入 LLM 和 TemplateService，不再内部调用 get_generation_llm()。
    """

    def __init__(
        self,
        llm: Any,
        template_service: Any = None,
        output_dir: str = None,
    ):
        """
        初始化文书生成服务

        Args:
            llm: LLM 实例（注入，不再内部 import）
            template_service: 模板服务实例（可选）
            output_dir: 输出目录（默认使用 settings.UPLOAD_DIR）
        """
        self._llm = llm
        self._template_svc = template_service
        self._output_dir = output_dir

    def _get_output_dir(self) -> str:
        """获取输出目录"""
        if self._output_dir:
            return self._output_dir
        try:
            from ...config import settings
            return os.path.join(settings.UPLOAD_DIR, "generated")
        except Exception:
            return "./output"

    def _save_as_docx(self, content: str, filepath: str) -> bool:
        """
        将文本内容保存为 docx 文件

        Args:
            content: 文书文本内容
            filepath: 保存路径

        Returns:
            是否保存成功
        """
        try:
            from docx import Document
            from docx.shared import Pt
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            from docx.oxml.ns import qn

            doc = Document()

            # 设置默认字体（支持中文）
            style = doc.styles['Normal']
            style.font.name = '宋体'
            style._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
            style.font.size = Pt(12)

            # 按换行符分割内容，添加到文档
            lines = content.split('\n')
            for line in lines:
                line = line.strip()
                if not line:
                    # 空行
                    doc.add_paragraph()
                elif line.startswith('#'):
                    # 标题
                    heading = doc.add_heading(line.replace('#', '').strip(), level=1)
                    heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
                else:
                    # 普通段落
                    p = doc.add_paragraph(line)
                    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

            doc.save(filepath)
            print(f"[doc_gen_service] 文书已保存: {filepath}")
            return True

        except ImportError:
            # python-docx 未安装，保存为纯文本
            txt_path = filepath.replace('.docx', '.txt')
            with open(txt_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"[doc_gen_service] python-docx 未安装，已保存为文本: {txt_path}")
            return True
        except Exception as e:
            print(f"[doc_gen_service] 保存文书失败: {e}")
            return False

    async def collect_params(
        self,
        user_message: str,
        template_name: str,
        params_def: Dict[str, Any],
        collected_params: Dict[str, str],
    ) -> CollectParamsResult:
        """
        参数收集步骤

        迁移自 document_gen_graph.py:233-325
        - 调用 LLM 提取参数
        - 合并到已收集参数
        - 检查缺失的必填参数
        - 返回追问或确认

        Args:
            user_message: 用户消息
            template_name: 模板名称
            params_def: 参数定义（可能是新schema格式或旧字典格式）
            collected_params: 已收集的参数

        Returns:
            CollectParamsResult
        """
        if not params_def:
            # 无参数定义时使用默认参数
            params_def = {
                "原告姓名": {"label": "原告姓名", "required": True, "type": "text"},
                "被告姓名": {"label": "被告姓名", "required": True, "type": "text"},
                "诉求": {"label": "诉求/请求", "required": True, "type": "textarea"},
            }

        # 判断是否为新schema格式（包含 _version 或 fields 字段）
        is_new_schema = "_version" in params_def or "fields" in params_def
        
        # 生成 LLM 可见的 lite 版本
        if is_new_schema:
            llm_params_def = generate_llm_lite_schema(params_def)
        else:
            llm_params_def = params_def

        # 使用参数提取 Chain（延迟导入避免循环依赖）
        try:
            from ..chains.business_chains import create_param_extraction_chain
            extract_chain = create_param_extraction_chain(self._llm)

            extraction_result = await extract_chain.ainvoke({
                "user_input": user_message,
                "template_name": template_name,
                "params_def": llm_params_def,
                "collected_params": collected_params,
            })

            # 更新已收集参数（合并）- 使用精确 key 匹配
            # 注意：参数 key 已通过提示词工程确保与 params_def 一致
            extracted = extraction_result.get("extracted", {})
            new_collected = {**collected_params}
            
            print(f"[doc_gen_service] LLM提取的参数: {list(extracted.keys())}")
            print(f"[doc_gen_service] 当前已有参数: {list(new_collected.keys())}")
            
            for key, value in extracted.items():
                if not value:
                    continue
                    
                # 精确匹配：key 必须与 params_def（用于检查）或 llm_params_def 中的完全一致
                if key in params_def or key in llm_params_def:
                    new_collected[key] = value
                    print(f"[doc_gen_service] 匹配成功: {key} = {value}")
                else:
                    # 提示词工程应该保证 key 正确，这里仅记录警告
                    print(f"[doc_gen_service] ⚠️ 警告: key '{key}' 不在参数定义中，忽略该参数")
            
            print(f"[doc_gen_service] 合并后参数: {list(new_collected.keys())}")

            # 检查缺失的必填参数（使用 llm_params_def，跳过非 dict 值）
            missing = [
                key for key, info in llm_params_def.items()
                if isinstance(info, dict) and info.get("required", False) and not new_collected.get(key)
            ]

            # 优先使用 LLM 生成的 response_text
            llm_response = extraction_result.get("response_text", "")

            if missing:
                # 如果 LLM 没有生成响应，使用后端拼接（降级）
                response_text = llm_response if llm_response else ResponseFormatter.build_missing_prompt(
                    template_name, params_def, missing, new_collected
                )
                return CollectParamsResult(
                    collected_params=new_collected,
                    missing_required=missing,
                    response_text=response_text,
                    widget=ResponseFormatter.build_params_widget(llm_params_def, new_collected),
                    phase="collect_params",
                )
            else:
                # 参数已齐全，使用 LLM 的响应（如果有）
                response_text = llm_response if llm_response else ResponseFormatter.build_confirm_text(template_name, new_collected)
                return CollectParamsResult(
                    collected_params=new_collected,
                    missing_required=[],
                    response_text=response_text,
                    widget={
                        "type": "confirm",
                        "title": "确认生成",
                        "message": f"【{template_name}】所有信息已收集完毕，是否确认生成？",
                        "actions": [
                            {"type": "button", "label": "确认生成", "action": "confirm", "primary": True},
                            {"type": "button", "label": "继续修改", "action": "modify"},
                        ],
                    },
                    phase="confirm",
                )

        except Exception as e:
            import traceback
            print(f"[doc_gen_service] 参数提取失败: {e}")
            print(traceback.format_exc())
            return CollectParamsResult(
                collected_params=collected_params,
                missing_required=[],
                response_text=f"参数处理遇到问题，请重新输入信息。错误: {str(e)}",
                widget={},
                phase="collect_params",
            )

    async def generate(
        self,
        template_name: str,
        collected_params: Dict[str, str],
        output_dir: Optional[str] = None,
        template_id: Optional[int] = None,
        project_id: Optional[int] = None,
    ) -> GenerationResult:
        """
        执行文书生成 - 基于模板填充

        工作流程（节点6：填充模板）：
        1. 获取模板的占位符模板文件路径
        2. 复制模板到项目目录
        3. 用收集的参数替换占位符
        4. 保存文件

        Args:
            template_name: 模板名称
            collected_params: 已收集的参数
            output_dir: 输出目录（可选，不传则使用默认目录）
            template_id: 模板ID（必填，用于获取模板文件路径）
            project_id: 项目ID（必填，用于确定保存目录）

        Returns:
            GenerationResult
        """
        import shutil
        import json as json_lib

        try:
            template_path = None
            template_real_name = template_name
            placeholder_def = {}

            # 1. 获取模板的占位符模板文件路径
            is_new_schema = False
            if template_id and self._template_svc:
                try:
                    template_info = await self._template_svc.get_template_by_id(template_id)
                    if template_info:
                        template_path = template_info.get("placeholder_template_path")
                        template_real_name = template_info.get("name", template_name)
                        placeholder_def = template_info.get("placeholder_dict", {})
                        print(f"[doc_gen_service] 找到模板: {template_real_name}, 路径: {template_path}")
                        
                        # 判断是否为新 schema 格式
                        is_new_schema = "_version" in placeholder_def or "fields" in placeholder_def
                        print(f"[doc_gen_service] Schema格式: {'新(2.0)' if is_new_schema else '旧(1.0)'}")
                        print(f"[doc_gen_service] placeholder_def keys: {list(placeholder_def.keys())[:10]}...")
                except Exception as e:
                    print(f"[doc_gen_service] 获取模板路径失败: {e}")

            # 2. 验证参数完整性 + 字段映射
            mapped_params = dict(collected_params)  # 默认使用原始参数
            if placeholder_def:
                from .template_schema_engine import map_collected_to_schema_fields
                
                # 【修复】将中文键名映射到 schema 英文键名
                if is_new_schema and "fields" in placeholder_def:
                    mapped_params = map_collected_to_schema_fields(placeholder_def, collected_params)
                    print(f"[doc_gen_service] 字段映射: {len(mapped_params)}/{len(placeholder_def.get('fields', {}))}个字段已映射")
                
                # 新格式使用 fields 下的必填检查，旧格式直接用 keys
                if is_new_schema and "fields" in placeholder_def:
                    fields_to_check = placeholder_def.get("fields", {})
                    missing_params = [k for k, v in fields_to_check.items() 
                                     if v.get("required", False) and (k not in mapped_params or not mapped_params.get(k))]
                else:
                    missing_params = [k for k in placeholder_def.keys() 
                                     if k not in mapped_params or not mapped_params.get(k)]
                if missing_params:
                    return GenerationResult(
                        content="",
                        file_path="",
                        filename="",
                        preview="",
                        response_text=f"缺少必填参数: {', '.join(missing_params)}",
                        widget={},
                    )

            # 3. 补充未填写的非必要参数为空字符串
            if placeholder_def and is_new_schema and "fields" in placeholder_def:
                # 对于新格式，遍历所有非必要的字段，如果未提供值，则设为空字符串
                for field_key, field_info in placeholder_def.get("fields", {}).items():
                    if not field_info.get("required", False) and field_key not in mapped_params:
                        mapped_params[field_key] = ""
                        print(f"[doc_gen_service] 设置非必要参数 '{field_key}' 为空字符串")
            elif placeholder_def and not is_new_schema:
                # 对于旧格式，遍历所有不在mapped_params中的字段，设为空字符串
                for field_key in placeholder_def.keys():
                    if field_key not in mapped_params:
                        mapped_params[field_key] = ""
                        print(f"[doc_gen_service] 设置非必要参数 '{field_key}' 为空字符串")

            # 4. 构建保存路径
            if project_id:
                from ...config import settings
                save_dir = os.path.join(settings.UPLOAD_DIR, f"project_{project_id}")
            elif output_dir:
                save_dir = output_dir
            else:
                save_dir = self._get_output_dir()

            os.makedirs(save_dir, exist_ok=True)

            name_key = next(
                (mapped_params.get(k) or collected_params.get(k) for k in ["答辩人姓名", "defendant_name", "原告姓名", "申请人姓名", "乙方姓名", "承租人"] if (mapped_params.get(k) or collected_params.get(k))),
                "draft",
            )
            filename = f"{template_real_name}_{name_key}.docx"
            filepath = os.path.join(save_dir, filename)

            # 5. 根据是否有模板文件，选择不同的处理方式
            if template_path and os.path.exists(template_path):
                # 方式A：基于模板文件填充
                print(f"[doc_gen_service] 使用模板填充模式: {template_path}")

                # 复制模板到目标位置
                shutil.copy2(template_path, filepath)
                print(f"[doc_gen_service] 模板已复制到: {filepath}")

                # 使用新引擎预处理参数（conditional_blocks + 格式化）
                if is_new_schema:
                    print(f"[doc_gen_service] 使用新引擎预处理参数...")
                    processed_params = preprocess_params(placeholder_def, mapped_params)
                    print(f"[doc_gen_service] 预处理完成，生成字段: {list(processed_params.keys())}")
                else:
                    # 旧格式：直接使用 collected_params（保持原有行为）
                    processed_params = dict(collected_params)
                    print(f"[doc_gen_service] 使用旧格式处理")

                # 读取文档获取当前内容
                from ...utils.docx_processor import apply_docx_modifications, read_docx_paragraphs
                import re

                doc_content = read_docx_paragraphs(filepath)

                # 构建替换修改列表（使用预处理后的参数）
                modifications = []
                for param_key, param_value in processed_params.items():
                    # 修改条件，允许空字符串通过，但仍跳过None值
                    if param_value is None:
                        continue

                    # 占位符格式: {{ key }}（有空格）和 {{key}}（无空格）
                    # 以及 {{{key}}} 和 {{ key:"default" }}
                    placeholder_no_space = f"{{{{ {param_key}}}}}"  # {{key}} 无空格
                    placeholder_spaced = f"{{{{ {param_key} }}}}"  # {{ key }} 有空格
                    placeholder_alt = f"{{{{{param_key}}}}}"  # {{{key}}}
                    placeholder_default = f"{{{{ {param_key}:"  # {{key:"default"}}

                    # 1. 处理段落中的占位符
                    for para in doc_content.get("paragraphs", []):
                        para_text = para.get("text", "")

                        if placeholder_no_space in para_text:
                            modifications.append({
                                "type": "modify",
                                "index": para.get("index"),
                                "text": placeholder_no_space,
                                "new_text": param_value
                            })
                        elif placeholder_spaced in para_text:
                            modifications.append({
                                "type": "modify",
                                "index": para.get("index"),
                                "text": placeholder_spaced,
                                "new_text": param_value
                            })
                        elif placeholder_alt in para_text:
                            modifications.append({
                                "type": "modify",
                                "index": para.get("index"),
                                "text": placeholder_alt,
                                "new_text": param_value
                            })
                        elif placeholder_default in para_text:
                            # 处理带默认值的占位符 {{ key:"default" }}
                            escaped_key = re.escape(param_key)
                            pattern = "{{ " + escaped_key + ':"[^"]*"}}'
                            match = re.search(pattern, para_text)
                            if match:
                                modifications.append({
                                    "type": "modify",
                                    "index": para.get("index"),
                                    "text": match.group(0),
                                    "new_text": param_value
                                })

                    # 2. 处理表格单元格中的占位符
                    for table_idx, table_info in enumerate(doc_content.get("tables", [])):
                        for row_idx, row in enumerate(table_info.get("cells", [])):
                            for col_idx, cell_text in enumerate(row):
                                if not cell_text:
                                    continue
                                    
                                cell_index = f"t{table_idx}_r{row_idx}_c{col_idx}"
                                
                                if placeholder_no_space in cell_text:
                                    modifications.append({
                                        "type": "cell_modify",
                                        "index": cell_index,
                                        "text": placeholder_no_space,
                                        "new_text": param_value
                                    })
                                elif placeholder_spaced in cell_text:
                                    modifications.append({
                                        "type": "cell_modify",
                                        "index": cell_index,
                                        "text": placeholder_spaced,
                                        "new_text": param_value
                                    })
                                elif placeholder_alt in cell_text:
                                    modifications.append({
                                        "type": "cell_modify",
                                        "index": cell_index,
                                        "text": placeholder_alt,
                                        "new_text": param_value
                                    })

                print(f"[doc_gen_service] 找到 {len(modifications)} 个占位符待替换")

                # 执行替换
                if modifications:
                    result = apply_docx_modifications(filepath, modifications)
                    if not result.get("success"):
                        print(f"[doc_gen_service] apply_docx_modifications 失败: {result.get('message')}，使用降级方案")
                        # 降级方案：直接操作 XML
                        from docx import Document
                        doc = Document(filepath)
                        for para in doc.paragraphs:
                            for param_key, param_value in processed_params.items():
                                if param_value is None:
                                    continue
                                placeholder = f"{{{{ {param_key}}}}}"
                                placeholder_spaced = f"{{{{ {param_key} }}}}"
                                if placeholder in para.text:
                                    para.text = para.text.replace(placeholder, param_value)
                                if placeholder_spaced in para.text:
                                    para.text = para.text.replace(placeholder_spaced, param_value)
                        for table in doc.tables:
                            for row in table.rows:
                                for cell in row.cells:
                                    for param_key, param_value in processed_params.items():
                                        if param_value is None:
                                            continue
                                        placeholder = f"{{{{ {param_key}}}}}"
                                        placeholder_spaced = f"{{{{ {param_key} }}}}"
                                        if placeholder in cell.text:
                                            cell.text = cell.text.replace(placeholder, param_value)
                                        if placeholder_spaced in cell.text:
                                            cell.text = cell.text.replace(placeholder_spaced, param_value)
                        doc.save(filepath)
                        print(f"[doc_gen_service] 降级方案完成")

                print(f"[doc_gen_service] 模板填充完成: {filepath}")

                # 注册文件到项目数据库
                if project_id:
                    try:
                        from ...models import File as FileModel
                        from ...database import SessionLocal
                        db = SessionLocal()
                        try:
                            # 检查文件是否已存在
                            existing = db.query(FileModel).filter(
                                FileModel.project_id == project_id,
                                FileModel.name == filename
                            ).first()
                            
                            if existing:
                                # 更新现有记录
                                existing.file_path = filepath
                                existing.content = filled_content[:5000] if filled_content else ""
                                print(f"[doc_gen_service] 更新文件记录: {filename}")
                            else:
                                # 创建新记录
                                db_file = FileModel(
                                    project_id=project_id,
                                    name=filename,
                                    file_type="docx",
                                    file_path=filepath,
                                    content=filled_content[:5000] if filled_content else "",
                                    size=os.path.getsize(filepath) if os.path.exists(filepath) else 0
                                )
                                db.add(db_file)
                                print(f"[doc_gen_service] 注册新文件到项目树: {filename}")
                            
                            db.commit()
                        finally:
                            db.close()
                    except Exception as e:
                        print(f"[doc_gen_service] 文件注册失败: {e}")

                # 读取填充后的内容用于预览
                filled_content = ""
                try:
                    from ...utils.file_processor import extract_text_from_file
                    filled_content = extract_text_from_file(filepath, "docx")
                except Exception as e:
                    print(f"[doc_gen_service] 读取填充内容失败: {e}")
                    filled_content = f"文书已生成并保存至: {filepath}"

            else:
                # 方式B：无模板时使用 LLM 生成（降级方案）
                print(f"[doc_gen_service] 无模板文件，使用 LLM 生成模式")

                from ..chains.business_chains import create_generation_chain
                gen_chain = create_generation_chain(self._llm)

                gen_result = await gen_chain.ainvoke({
                    "document_type": template_name,
                    "params_json": json_lib.dumps(collected_params, ensure_ascii=False),
                })

                filled_content = gen_result.get("content", "")

                # 保存为 docx 文件
                self._save_as_docx(filled_content, filepath)

            preview = filled_content[:500] + ("..." if len(filled_content) > 500 else "")

            return GenerationResult(
                content=filled_content,
                file_path=filepath,
                filename=filename,
                preview=preview,
                response_text=f"""✅ 文书生成成功！

📄 文件名：{filename}
📁 保存位置：{save_dir}
请刷新后查看文书内容
是否有需要调整的地方？""",
                widget={
                    "type": "card",
                    "title": "文书生成成功",
                    "actions": [
                        {"type": "button", "label": "查看文书", "action": "open_document"},
                        {"type": "button", "label": "进行调整", "action": "modify_document"},
                        {"type": "button", "label": "生成其他", "action": "new_document"},
                    ],
                },
            )

        except Exception as e:
            print(f"[doc_gen_service] 生成失败: {e}")
            import traceback
            traceback.print_exc()

            return GenerationResult(
                content="",
                file_path="",
                filename="",
                preview="",
                response_text=f"文书生成失败：{str(e)}",
                widget={},
            )

"""
会话记忆服务 - 替代 memory.py 中的全局单例和 LawConsultationMemory

职责:
- 按 conversation_id 隔离不同会话
- 自动注入知识库检索结果到上下文
- 支持上下文压缩以控制 Token 消耗

消除的问题:
- memory.py:230 全局单例 _consultation_memory
- 全局状态导致的并发不安全
"""

from typing import Any, Dict, List, Optional

# 尝试导入 langchain_community 的 memory 实现
try:
    from langchain.memory import (
        ConversationBufferMemory,
        ConversationBufferWindowMemory,
        ConversationTokenBufferMemory,
    )
    COMMUNITY_AVAILABLE = True
except ImportError:
    COMMUNITY_AVAILABLE = False
    ConversationBufferMemory = None
    ConversationBufferWindowMemory = None
    ConversationTokenBufferMemory = None


class SimpleChatMemory:
    """
    轻量级对话内存管理器

    当 langchain-community 未安装时使用的降级实现。
    """

    def __init__(
        self,
        max_messages: int = 10,
        max_tokens: int = 2000,
        return_messages: bool = True,
    ):
        self.messages: List[Dict[str, str]] = []
        self.max_messages = max_messages
        self.max_tokens = max_tokens
        self.return_messages = return_messages

    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        """保存一轮对话"""
        user_msg = list(inputs.values())[0] if inputs else ""
        ai_msg = list(outputs.values())[0] if outputs else ""

        self.messages.append({"role": "human", "content": user_msg})
        self.messages.append({"role": "ai", "content": ai_msg})

        # 简单裁剪
        if len(self.messages) > self.max_messages * 2:
            self.messages = self.messages[-self.max_messages * 2:]

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """加载对话历史"""
        if self.return_messages:
            return {"chat_history": self.messages.copy()}
        else:
            text = "\n".join(
                f"{'用户' if m['role'] == 'human' else '助手'}: {m['content']}"
                for m in self.messages
            )
            return {"chat_history": text}

    def clear(self) -> None:
        """清空内存"""
        self.messages.clear()

    @property
    def memory_variables(self) -> List[str]:
        return ["chat_history"]


class ConversationMemoryService:
    """
    会话记忆服务

    替代全局单例 LawConsultationMemory，支持依赖注入。

    特性:
    1. 按 conversation_id 隔离不同会话
    2. 自动注入知识库检索结果到上下文
    3. 支持上下文压缩以控制 Token 消耗
    """

    def __init__(self):
        # {conversation_id: SimpleChatMemory}
        self._sessions: Dict[str, SimpleChatMemory] = {}

    def get_session(self, conversation_id: int) -> SimpleChatMemory:
        """获取或创建会话的 Memory 实例"""
        key = str(conversation_id)
        if key not in self._sessions:
            self._sessions[key] = SimpleChatMemory(
                max_messages=20,
                max_tokens=3000,
                return_messages=True,
            )
        return self._sessions[key]

    async def save_consultation_turn(
        self,
        conversation_id: int,
        user_message: str,
        assistant_response: str,
        knowledge_context: Optional[Dict] = None,
    ) -> None:
        """
        保存一轮法律咨询对话

        Args:
            conversation_id: 会话ID
            user_message: 用户问题
            assistant_response: 助手回答
            knowledge_context: 本次查询的知识库结果（可选）
        """
        session = self.get_session(conversation_id)
        session.save_context(
            inputs={"input": user_message},
            outputs={"output": assistant_response},
        )

    async def get_chat_history(self, conversation_id: int) -> List[Dict[str, str]]:
        """
        获取指定会话的对话历史

        Returns:
            对话消息列表 [{"role": "human/ai", "content": "..."}]
        """
        session = self.get_session(conversation_id)
        variables = session.load_memory_variables({})
        return variables.get("chat_history", [])

    def clear_session(self, conversation_id: int) -> None:
        """清空指定会话的内存"""
        key = str(conversation_id)
        if key in self._sessions:
            self._sessions[key].clear()
            del self._sessions[key]

    def clear_all(self) -> None:
        """清空所有会话"""
        self._sessions.clear()

    # ==================== 工厂方法 ====================

    @staticmethod
    def create(strategy: str = "simple", **kwargs) -> "ConversationMemoryService":
        """
        创建内存服务实例

        Args:
            strategy: 内存管理策略（目前只支持 simple）
            **kwargs: 保留参数，兼容未来扩展

        Returns:
            ConversationMemoryService 实例
        """
        return ConversationMemoryService()


# =====================================================================
# 全局默认实例（向后兼容）
# =====================================================================

_default_memory: Optional[ConversationMemoryService] = None


def get_memory() -> ConversationMemoryService:
    """获取全局记忆实例（兼容旧代码过渡期使用）"""
    global _default_memory
    if _default_memory is None:
        _default_memory = ConversationMemoryService()
    return _default_memory


def reset_memory():
    """重置全局法律咨询内存（测试用）"""
    global _default_memory
    if _default_memory is not None:
        _default_memory.clear_all()
    _default_memory = None


# =====================================================================
# 兼容层：供旧代码调用的别名
# =====================================================================

def create_memory(
    strategy: str = "token_budget",
    **kwargs
) -> Any:
    """创建 Memory 实例的工厂函数（兼容旧接口）"""
    if not COMMUNITY_AVAILABLE:
        if strategy == "window":
            return SimpleChatMemory(max_messages=kwargs.get("k", 10))
        else:
            return SimpleChatMemory(max_tokens=kwargs.get("max_token_limit", 2000))

    if strategy == "token_budget":
        llm = kwargs.get("llm")
        if not llm:
            raise ValueError("token_budget 策略需要传入 llm 参数")
        return ConversationTokenBufferMemory(
            llm=llm,
            max_token_limit=kwargs.get("max_token_limit", 2000),
            memory_key="chat_history",
            return_messages=True,
        )
    elif strategy == "window":
        return ConversationBufferWindowMemory(
            k=kwargs.get("k", 10),
            memory_key="chat_history",
            return_messages=True,
        )
    elif strategy == "unlimited":
        return ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True,
        )
    else:
        raise ValueError(f"未知的 memory 策略: {strategy}")


def create_consultation_memory() -> ConversationMemoryService:
    """创建法律咨询专用内存管理器（兼容旧接口）"""
    return ConversationMemoryService()


# 为了向后兼容，提供旧的函数别名
def get_consultation_memory() -> ConversationMemoryService:
    """获取或创建全局法律咨询内存（向后兼容）"""
    return get_memory()


# 向后兼容别名
ConversationMemory = ConversationMemoryService

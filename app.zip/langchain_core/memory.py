"""
Memory 配置工厂 - LangChain 对话历史管理

**注意**: 核心逻辑已迁移到 services/conversation_memory.py
此文件保留用于向后兼容。

支持两种策略:
1. ConversationTokenBufferMemory - 按Token预算动态压缩（推荐）
2. ConversationBufferWindowMemory - 固定窗口大小
"""

from typing import Any, Dict, List, Optional, Callable

# 使用 langchain_community 的 memory 实现
try:
    from langchain.memory import (
        ConversationBufferMemory,
        ConversationBufferWindowMemory,
        ConversationTokenBufferMemory,
    )
    COMMUNITY_AVAILABLE = True
except ImportError:
    COMMUNITY_AVAILABLE = False
    # 降级：提供简单的内存实现
    ConversationBufferMemory = None
    ConversationBufferWindowMemory = None
    ConversationTokenBufferMemory = None

# 导入新服务层的实现
from .services.conversation_memory import (
    ConversationMemoryService,
    SimpleChatMemory,
    get_memory,
    reset_memory,
    get_consultation_memory,
    create_consultation_memory,
)

# 为了向后兼容，也导出 format_knowledge_for_prompt 和 format_history_for_prompt
from .services.response_formatter import ResponseFormatter

# 导出上下文压缩功能
from .services.context_compressor import (
    compress_conversation_history,
    compress_conversation_history_async,
    format_history_for_prompt_with_compression,
)

def format_knowledge_for_prompt(laws: List[Dict], cases: List[Dict]) -> str:
    """格式化为 Prompt 可用的文本块（向后兼容别名）"""
    return ResponseFormatter.format_knowledge_for_prompt(laws, cases)

def format_history_for_prompt(
    messages: List[Dict[str, str]],
    enable_compression: bool = True,
) -> str:
    """
    将消息列表格式化为 Prompt 文本

    当消息数量超过 3 条时，自动启用上下文压缩以节省 token。

    Args:
        messages: 消息列表 [{"role": "human/ai", "content": "..."}]
        enable_compression: 是否启用上下文压缩（默认 True）

    Returns:
        格式化的对话文本
    """
    return format_history_for_prompt_with_compression(messages, enable_compression)


# =====================================================================
# 自定义 Memory（当 langchain-community 不可用时的降级方案）
# =====================================================================

class SimpleChatMemory:
    """
    轻量级对话内存管理器
    
    当 langchain-community 未安装时使用的降级实现。
    提供与 LangChain Memory 类似的接口。
    """
    
    def __init__(
        self,
        max_messages: int = 10,
        max_tokens: int = 2000,
        return_messages: bool = True,
    ):
        self.messages: List[Dict[str, str]] = []
        self.max_messages = max_messages
        self.max_tokens = max_tokens
        self.return_messages = return_messages
    
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        """保存一轮对话"""
        user_msg = list(inputs.values())[0] if inputs else ""
        ai_msg = list(outputs.values())[0] if outputs else ""
        
        self.messages.append({"role": "human", "content": user_msg})
        self.messages.append({"role": "ai", "content": ai_msg})
        
        # 简单裁剪
        if len(self.messages) > self.max_messages * 2:
            self.messages = self.messages[-self.max_messages * 2:]
    
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """加载对话历史"""
        if self.return_messages:
            return {"chat_history": self.messages.copy()}
        else:
            text = "\n".join(
                f"{'用户' if m['role'] == 'human' else '助手'}: {m['content']}"
                for m in self.messages
            )
            return {"chat_history": text}
    
    def clear(self) -> None:
        """清空内存"""
        self.messages.clear()
    
    @property
    def memory_variables(self) -> List[str]:
        return ["chat_history"]


class LawConsultationMemory:
    """
    法律咨询专用 Memory
    
    特性：
    1. 按 conversation_id 隔离不同会话
    2. 自动注入知识库检索结果到上下文
    3. 支持上下文压缩以控制Token消耗
    """
    
    def __init__(self):
        # {conversation_id: SimpleChatMemory}
        self._sessions: Dict[str, SimpleChatMemory] = {}
    
    def get_session(self, conversation_id: int) -> SimpleChatMemory:
        """获取或创建会话的Memory实例"""
        key = str(conversation_id)
        if key not in self._sessions:
            self._sessions[key] = SimpleChatMemory(
                max_messages=20,
                max_tokens=3000,
                return_messages=True,
            )
        return self._sessions[key]
    
    async def save_consultation_turn(
        self,
        conversation_id: int,
        user_message: str,
        assistant_response: str,
        knowledge_context: Optional[Dict] = None,
    ) -> None:
        """
        保存一轮法律咨询对话
        
        Args:
            conversation_id: 会话ID
            user_message: 用户问题
            assistant_response: 助手回答
            knowledge_context: 本次查询的知识库结果（可选，用于记录）
        """
        session = self.get_session(conversation_id)
        session.save_context(
            inputs={"input": user_message},
            outputs={"output": assistant_response},
        )
    
    async def get_chat_history(self, conversation_id: int) -> List[Dict[str, str]]:
        """
        获取指定会话的对话历史
        
        Returns:
            对话消息列表 [{"role": "human/ai", "content": "..."}]
        """
        session = self.get_session(conversation_id)
        variables = session.load_memory_variables({})
        return variables.get("chat_history", [])
    
    def clear_session(self, conversation_id: int) -> None:
        """清空指定会话的内存"""
        key = str(conversation_id)
        if key in self._sessions:
            self._sessions[key].clear()
            del self._sessions[key]
    
    def clear_all(self) -> None:
        """清空所有会话"""
        self._sessions.clear()


# =====================================================================
# 工厂函数 ====================

def create_memory(
    strategy: str = "token_budget",
    **kwargs
) -> Any:
    """
    创建 Memory 实例的工厂函数
    
    Args:
        strategy: 内存管理策略
            - "token_budget": 按Token预算动态压缩（推荐用于长对话）
            - "window": 固定窗口大小（简单场景）
            - "unlimited": 无限制（调试用）
        **kwargs: 传递给具体实现的参数
            
    Returns:
        Memory 实例
        
    示例:
        >>> memory = create_memory("token_budget", max_token_limit=2000)
        >>> history = memory.load_memory_variables({})
    """
    if not COMMUNITY_AVAILABLE:
        # 降级为自定义实现
        if strategy == "window":
            return SimpleChatMemory(max_messages=kwargs.get("k", 10))
        else:
            return SimpleChatMemory(max_tokens=kwargs.get("max_token_limit", 2000))
    
    if strategy == "token_budget":
        # 需要 LLM 来估算 token 数量
        llm = kwargs.get("llm")
        if not llm:
            raise ValueError("token_budget 策略需要传入 llm 参数")
        
        return ConversationTokenBufferMemory(
            llm=llm,
            max_token_limit=kwargs.get("max_token_limit", 2000),
            memory_key="chat_history",
            return_messages=True,
        )
    
    elif strategy == "window":
        return ConversationBufferWindowMemory(
            k=kwargs.get("k", 10),
            memory_key="chat_history",
            return_messages=True,
        )
    
    elif strategy == "unlimited":
        return ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True,
        )
    
    else:
        raise ValueError(f"未知的 memory 策略: {strategy}")


def create_consultation_memory() -> LawConsultationMemory:
    """
    创建法律咨询专用内存管理器
    
    Returns:
        LawConsultationMemory 实例
    """
    return LawConsultationMemory()


# =====================================================================
# 全局单例 ====================

# 法律咨询专用全局内存
_consultation_memory: Optional[LawConsultationMemory] = None


def get_consultation_memory() -> LawConsultationMemory:
    """获取或创建全局法律咨询内存"""
    global _consultation_memory
    if _consultation_memory is None:
        _consultation_memory = create_consultation_memory()
    return _consultation_memory


def reset_consultation_memory():
    """重置全局法律咨询内存（测试用）"""
    global _consultation_memory
    if _consultation_memory is not None:
        _consultation_memory.clear_all()
    _consultation_memory = None


# =====================================================================
# 向后兼容别名
# 注意: format_knowledge_for_prompt 和 format_history_for_prompt
# 已在文件顶部定义为 ResponseFormatter 的别名
# =====================================================================

"""
结构化输出解析器 - 替代 workflows.py 中所有手动 JSON 解析逻辑

设计目标:
1. 消除 _extract_json() + 4级容错策略的重复代码
2. 使用 LangChain 的 PydanticOutputParser 保证100%可靠解析
3. 每个 Parser 对应一个业务场景的输出格式定义

重构说明 (v2):
- 删除了手写的 LegacyJsonParser（改用 langchain_core.JsonOutputParser 内置能力）
- 删除了手写的 StrOutputParser（直接使用 langchain_core.output_parsers.StrOutputParser）
- 保留所有 Pydantic Model 和对应的 PydanticOutputParser 单例
"""

from typing import Dict, List, Any, Optional

from langchain_core.output_parsers import (
    JsonOutputParser,
    PydanticOutputParser,
    StrOutputParser as LangChainStrOutputParser,
)
from pydantic import BaseModel, Field


# =====================================================================
# 导出别名（保持向后兼容）
# =====================================================================

# 使用 LangChain 内置的 StrOutputParser
StrOutputParser = LangChainStrOutputParser


# =====================================================================
# Pydantic Models（用于 PydanticOutputParser，提供类型安全）
# =====================================================================

class IntentResult(BaseModel):
    """意图识别结果"""
    intent: str = Field(
        description="必须是以下8个值之一: document_generation, document_modification, contract_service, consultation, case_search, law_search, chitchat, unknown"
    )
    confidence: float = Field(
        description="判断置信度，0.0到1.0之间的数字"
    )
    reasoning: str = Field(
        description="中文判断理由"
    )
    document_type: str = Field(
        default="",
        description="文书类型(如起诉状/答辩状)，非文书类留空"
    )
    dispute_type: str = Field(
        default="",
        description="纠纷类型(如劳动纠纷/离婚纠纷)，无则留空"
    )
    extracted_info: Dict[str, Any] = Field(
        default_factory=dict,
        description="其他提取信息"
    )


class ParamExtractionResult(BaseModel):
    """参数提取结果"""
    extracted: Dict[str, str] = Field(
        description="提取到的参数键值对，未提取到的参数值为空字符串"
    )
    missing_required: List[str] = Field(
        description="缺失的必填参数名列表"
    )
    confidence: float = Field(
        description="提取置信度0.0-1.0"
    )
    response_text: str = Field(
        default="",
        description="LLM生成的完整自然语言追问响应（包含已收集信息和缺失参数提示）"
    )
    notes: str = Field(
        default="",
        description="简要说明提取情况"
    )


class ModificationResult(BaseModel):
    """文书修改指令"""
    modification_type: str = Field(
        description="修改类型: replace|add|delete|reformat"
    )
    location: str = Field(
        description="修改位置的描述"
    )
    location_hint: str = Field(
        description="用于定位原文的关键词"
    )
    original_text: str = Field(
        default="",
        description="被修改的原文本"
    )
    new_text: str = Field(
        description="修改后的新文本"
    )
    reason: str = Field(
        default="",
        description="修改原因说明"
    )


class ModifyClassifyResult(BaseModel):
    """修改请求分类结果"""
    modification_level: str = Field(
        description="L1_text_replace | L2_semantic_rewrite | L3_knowledge_enhanced"
    )
    legal_topics: List[str] = Field(
        default_factory=list,
        description="涉及的法律主题"
    )
    estimated_complexity: str = Field(
        description="low | medium | high"
    )
    requires_knowledge: bool = Field(
        description="是否需要知识库增强"
    )


class SearchPlanResult(BaseModel):
    """增强搜索 - 检索规划结果"""
    intent: str = Field(description="law_query | concept_qa | case_reference")
    article: str = Field(default="", description="目标法条名称")
    query: str = Field(description="检索关键词")
    filter: Dict[str, str] = Field(default_factory=dict, description="过滤条件")


class CaseExtractResult(BaseModel):
    """案件分析 - 要素抽取结果"""
    dispute_type: str = Field(description="纠纷类型")
    core_facts: str = Field(description="核心事实摘要")
    claims: List[str] = Field(default_factory=list, description="当事人诉求")
    key_issues: List[str] = Field(default_factory=list, description="争议焦点")


class RiskConfirmResult(BaseModel):
    """合同审查 - LLM风险确认结果"""
    is_confirmed: bool = Field(description="是否确认为真实风险")
    final_risk_level: str = Field(description="high | medium | low | none")
    risk_description: str = Field(description="确认后的风险描述")
    legal_basis: str = Field(default="", description="法律依据")
    suggestion: str = Field(description="修改建议")


class CaseAnalysisResult(BaseModel):
    """案件分析 - 单个案例深度分析"""
    case_id: str = Field(description="案例ID")
    similarity_reason: str = Field(description="相似度理由")
    key_holding: str = Field(description="法院核心观点")
    applicable_laws: List[str] = Field(default_factory=list, description="适用法条")
    lesson_for_user: str = Field(description="对用户的启示")


# =====================================================================
# 案件分析报告 - 可视化报告解析器（支持动态 sections + ECharts）
# =====================================================================

class ChartOption(BaseModel):
    """ECharts 图表配置（通用 JSON 对象）"""
    # 使用 dict 类型，允许任何 ECharts valid option 结构
    # 前端会直接 echarts.setOption() 使用
    pass  # 不需要预定义字段，LLM 输出什么就是什么


class TableColumn(BaseModel):
    """表格列定义"""
    key: str = Field(description="数据字段名")
    label: str = Field(description="列标题")


class TextSection(BaseModel):
    """文本章节"""
    type: str = Field(default="text", description="固定为 'text'")
    title: str = Field(description="章节标题")
    content: str = Field(description="HTML/Markdown 格式的正文内容")


class ChartSection(BaseModel):
    """图表章节（支持所有 ECharts 类型）"""
    type: str = Field(description="图表类型: pie/bar/line/radar/scatter/funnel/gauge/heatmap/boxplot 等")
    title: str = Field(description="图表标题")
    description: Optional[str] = Field(default=None, description="图表说明")
    chart_option: Dict[str, Any] = Field(description="完整的 ECharts option 配置")


class TableSection(BaseModel):
    """表格章节"""
    type: str = Field(default="table", description="固定为 'table'")
    title: str = Field(description="表格标题")
    columns: List[TableColumn] = Field(description="列定义列表")
    rows: List[Dict[str, Any]] = Field(description="数据行列表")


class VisualReportSection(BaseModel):
    """
    可视化报告章节（联合类型）
    
    支持三种 section 类型:
    - text: 文本段落 (TextSection)
    - chart: ECharts 图表 (ChartSection)，type 可是 pie/bar/line/radar 等
    - table: 表格 (TableSection)
    
    由于 Pydantic 的 discriminator 特性，这里用 Union + validator 实现
    """
    type: str = Field(description="section 类型: text/table/pie/bar/line/radar/scatter/funnel/gauge/heatmap/boxplot 等")
    title: Optional[str] = Field(default=None, description="章节标题")
    content: Optional[str] = Field(default=None, description="text 类型专用")
    description: Optional[str] = Field(default=None, description="chart 类型专用")
    chart_option: Optional[Dict[str, Any]] = Field(default=None, description="chart 类型专用")
    columns: Optional[List[TableColumn]] = Field(default=None, description="table 类型专用")
    rows: Optional[List[Dict[str, Any]]] = Field(default=None, description="table 类型专用")

    @property
    def is_text(self) -> bool:
        return self.type == "text" and self.content is not None

    @property
    def is_chart(self) -> bool:
        return self.chart_option is not None

    @property
    def is_table(self) -> bool:
        return self.type == "table" and self.columns is not None


class VisualReportData(BaseModel):
    """可视化报告完整数据结构"""
    title: str = Field(description="报告标题")
    generated_at: str = Field(description="生成时间")
    dispute_type: str = Field(description="纠纷类型")
    case_count: int = Field(description="类案总数")
    top3_similarity: List[float] = Field(default_factory=list, description="Top3 相似度列表")
    sections: List[VisualReportSection] = Field(default_factory=list, description="报告章节列表")


# =====================================================================
# 解析器实例（预创建，可直接在 LCEL Chain 中使用）
# =====================================================================

def create_intent_parser() -> PydanticOutputParser:
    """
    创建意图识别解析器
    
    使用 PydanticOutputParser 提供：
    - 自动格式化 instructions（注入到 prompt 中）
    - 类型安全的输出验证
    - 清晰的解析错误信息
    
    Returns:
        配置好的 PydanticOutputParser 实例
        
    使用示例:
        >>> parser = create_intent_parser()
        >>> format_instructions = parser.get_format_instructions()
        >>> result = parser.parse('{"intent": "consultation", ...}')
        >>> print(result.intent)  # "consultation" (类型安全)
    """
    return PydanticOutputParser(pydantic_object=IntentResult)


def create_param_extractor_parser() -> PydanticOutputParser:
    """创建参数提取解析器"""
    return PydanticOutputParser(pydantic_object=ParamExtractionResult)


def create_modification_parser() -> PydanticOutputParser:
    """创建修改指令解析器"""
    return PydanticOutputParser(pydantic_object=ModificationResult)


def create_modify_classify_parser() -> PydanticOutputParser:
    """创建修改分类解析器"""
    return PydanticOutputParser(pydantic_object=ModifyClassifyResult)


def create_search_plan_parser() -> PydanticOutputParser:
    """创建检索规划解析器"""
    return PydanticOutputParser(pydantic_object=SearchPlanResult)


def create_case_extract_parser() -> PydanticOutputParser:
    """创建案件要素抽取解析器"""
    return PydanticOutputParser(pydantic_object=CaseExtractResult)


def create_risk_confirm_parser() -> PydanticOutputParser:
    """创建风险确认解析器"""
    return PydanticOutputParser(pydantic_object=RiskConfirmResult)


def create_case_analysis_parser() -> PydanticOutputParser:
    """创建案例分析解析器"""
    return PydanticOutputParser(pydantic_object=CaseAnalysisResult)


def create_visual_report_parser() -> PydanticOutputParser:
    """创建可视化报告解析器（支持动态 sections + ECharts 配置）"""
    return PydanticOutputParser(pydantic_object=VisualReportData)


# =====================================================================
# 预创建的单例（供 chains/graphs 直接引用）
# =====================================================================

intent_parser: PydanticOutputParser = create_intent_parser()
param_extractor_parser: PydanticOutputParser = create_param_extractor_parser()
modification_parser: PydanticOutputParser = create_modification_parser()
modify_classify_parser: PydanticOutputParser = create_modify_classify_parser()

# 四大模块新增解析器
search_plan_parser: PydanticOutputParser = create_search_plan_parser()
case_extract_parser: PydanticOutputParser = create_case_extract_parser()
risk_confirm_parser: PydanticOutputParser = create_risk_confirm_parser()
case_analysis_parser: PydanticOutputParser = create_case_analysis_parser()
visual_report_parser: PydanticOutputParser = create_visual_report_parser()


# =====================================================================
# 兼容层：为旧代码提供的过渡接口（使用 JsonOutputParser 替代手写实现）
# =====================================================================

class LegacyJsonParser:
    """
    兼容旧代码的 JSON 解析器
    
    重构说明: 现在内部使用 langchain_core.JsonOutputParser，
    而非之前的手动 extract_json + 正则清理。
    
    在迁移期间可逐步替换旧的 _extract_json() 调用。
    迁移完成后应删除此类。
    """
    
    # 使用内置的 JsonOutputParser 作为底层引擎
    _json_parser = JsonOutputParser()
    
    @staticmethod
    def extract_json(text: str) -> str:
        """
        从文本中提取JSON字符串
        
        策略优先级:
        1. ```json ... ``` 代码块
        2. ``` ... ``` 通用代码块
        3. 第一个 { 到最后一个 } 的内容
        
        Args:
            text: 可能包含JSON的文本
            
        Returns:
            提取出的JSON字符串
        """
        text = text.strip()
        
        # 策略1: ```json 代码块
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            if end > start:
                return text[start:end].strip()
        
        # 策略2: ``` 通用代码块
        if "```" in text:
            start = text.find("```") + 3
            newline = text.find("\n", start)
            if newline > start:
                start = newline + 1
            end = text.find("```", start)
            if end > 0:
                return text[start:end].strip()
        
        # 策略3: 最外层花括号
        if "{" in text and "}" in text:
            start = text.find("{")
            end = text.rfind("}") + 1
            return text[start:end]
        
        return text
    
    @staticmethod
    def safe_parse(text: str, fallback: Any = None) -> Any:
        """
        安全解析JSON（带降级处理）
        
        Args:
            text: 输入文本
            fallback: 解析失败时的返回值
            
        Returns:
            解析后的对象或fallback
        """
        import json
        import re
        
        json_str = LegacyJsonParser.extract_json(text)
        
        try:
            # 处理可能存在的转义双引号 (LLM有时会输出转义字符)
            json_str = json_str.replace('\\"', '"')
            return json.loads(json_str)
        except json.JSONDecodeError:
            # 尝试修复常见问题
            try:
                cleaned = re.sub(r',\s*([}\]])', r'\1', json_str)
                return json.loads(cleaned)
            except json.JSONDecodeError:
                return fallback

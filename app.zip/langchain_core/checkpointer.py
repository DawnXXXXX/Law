"""
统一的 Checkpointer 管理模块

使用方式：
    from .checkpointer import get_checkpointer
    graph.compile(checkpointer=get_checkpointer())
"""

import os
from typing import Optional

def _get_default_db_path() -> str:
    """获取默认的 SQLite 数据库路径"""
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db_dir = os.path.join(base_dir, "data")
    os.makedirs(db_dir, exist_ok=True)
    return os.path.join(db_dir, "checkpoints.db")

_checkpointer = None
_db_path: Optional[str] = None

def init_checkpointer(db_path: Optional[str] = None):
    """初始化 Checkpointer（可选，在应用启动时调用）"""
    global _checkpointer, _db_path
    _db_path = db_path or _get_default_db_path()
    _checkpointer = None  # 重置，下次 get_checkpointer() 会创建新实例

def get_checkpointer():
    """获取全局共享的 Checkpointer 实例（单例模式）"""
    global _checkpointer, _db_path
    
    if _checkpointer is not None:
        return _checkpointer
    
    db_path = _db_path or _get_default_db_path()
    
    try:
        from langgraph.checkpoint.sqlite import SqliteSaver
        print(f"[Checkpointer] 初始化 SQLite Checkpointer: {db_path}")
        _checkpointer = SqliteSaver.from_conn_string(db_path)
        return _checkpointer
        
    except ImportError:
        print("[Checkpointer] langgraph.checkpoint.sqlite 不可用，降级为 MemorySaver")
        from langgraph.checkpoint.memory import MemorySaver
        _checkpointer = MemorySaver()
        return _checkpointer
        
    except Exception as e:
        print(f"[Checkpointer] SQLite 初始化失败: {e}，降级为 MemorySaver")
        from langgraph.checkpoint.memory import MemorySaver
        _checkpointer = MemorySaver()
        return _checkpointer

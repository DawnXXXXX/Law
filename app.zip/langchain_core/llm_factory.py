"""
LLM 工厂模块 - 统一管理多 LLM 源

优先级:
1. 本地 Ollama - 使用本地部署的模型
2. 腾讯混元 (Hunyuan) - 使用 OpenAI SDK，配置简单
3. DeepSeek - 备选方案
4. CodeBuddy Agent SDK - 兜底方案

使用方式:
    from langchain_core.llm_factory import get_primary_llm, get_intent_llm

    # 获取主 LLM（自动选择可用的最优方案）
    llm = get_primary_llm()

    # 获取意图识别专用 LLM
    intent_llm = get_intent_llm()
"""

import os
import threading
from typing import Optional, Any, Literal

from dotenv import load_dotenv
load_dotenv(override=True)


# ==================== LLM 优先级配置 ====================

class LLMConfig:
    """LLM 配置状态"""
    
    # 优先级列表（按优先级从高到低）
    # 注意：意图识别专用 ollama，其他功能主 LLM 优先 hunyuan
    PRIORITY = ["hunyuan", "ollama", "deepseek", "codebuddy"]
    
    # 当前启用的 LLM 类型
    _current_llm: Optional[str] = None
    
    @classmethod
    def get_current_llm_type(cls) -> str:
        """获取当前使用的 LLM 类型"""
        if cls._current_llm:
            return cls._current_llm
        
        # 自动检测可用 LLM（按优先级）
        if os.getenv("OLLAMA_BASE_URL"):
            cls._current_llm = "ollama"
        elif os.getenv("HUNYUAN_API_KEY"):
            cls._current_llm = "hunyuan"
        elif os.getenv("DEEPSEEK_API_KEY"):
            cls._current_llm = "deepseek"
        else:
            cls._current_llm = "codebuddy"
        
        return cls._current_llm
    
    @classmethod
    def set_primary_llm(cls, llm_type: Literal["ollama", "hunyuan", "deepseek", "codebuddy"]):
        """手动设置主 LLM 类型"""
        cls._current_llm = llm_type
        print(f"[LLMFactory] Primary LLM set to: {llm_type}")
    
    @classmethod
    def is_available(cls, llm_type: str) -> bool:
        """检查 LLM 类型是否可用"""
        if llm_type == "ollama":
            return bool(os.getenv("OLLAMA_BASE_URL"))
        elif llm_type == "hunyuan":
            return bool(os.getenv("HUNYUAN_API_KEY"))
        elif llm_type == "deepseek":
            return bool(os.getenv("DEEPSEEK_API_KEY"))
        elif llm_type == "codebuddy":
            try:
                from ...agent_sdk import SDK_AVAILABLE
                return SDK_AVAILABLE
            except ImportError:
                return False
        return False


# ==================== LLM 实例缓存 ====================

class _LLMCache:
    """LLM 实例缓存（线程安全）"""
    
    _instances: dict = {}
    _lock = threading.Lock()
    
    @classmethod
    def get(cls, key: str, factory_func) -> Any:
        """获取或创建 LLM 实例"""
        if key in cls._instances:
            return cls._instances[key]
        
        with cls._lock:
            if key not in cls._instances:
                cls._instances[key] = factory_func()
            return cls._instances[key]
    
    @classmethod
    def reset(cls):
        """重置缓存（测试用）"""
        with cls._lock:
            cls._instances.clear()


# ==================== 主 LLM 接口 ====================

def get_primary_llm() -> Any:
    """
    获取主 LLM 实例（根据配置自动选择最优方案）
    
    优先级: Ollama > 混元 > DeepSeek > CodeBuddy
    
    Returns:
        ChatOpenAI 或 BaseChatModel 实例
    """
    llm_type = LLMConfig.get_current_llm_type()
    
    if llm_type == "ollama":
        return get_ollama_llm()
    elif llm_type == "hunyuan":
        return get_hunyuan_llm()
    elif llm_type == "deepseek":
        return get_deepseek_llm()
    else:
        return get_codebuddy_llm()


def get_ollama_llm() -> Any:
    """获取本地 Ollama LLM"""
    from .ollama_llm import get_ollama_llm as _get
    return _LLMCache.get("ollama", _get)


def get_hunyuan_llm() -> Any:
    """获取腾讯混元 LLM"""
    from .hunyuan_llm import get_hunyuan_llm as _get
    return _LLMCache.get("hunyuan", _get)


def get_deepseek_llm() -> Any:
    """获取 DeepSeek LLM"""
    from .deepseek_llm import get_deepseek_llm as _get
    return _LLMCache.get("deepseek", _get)


def get_codebuddy_llm() -> Any:
    """获取 CodeBuddy Agent LLM（兜底方案）"""
    from .llm import LawChatLLM
    
    def _create():
        from ...agent_sdk import CodeBuddyAgent
        agent = CodeBuddyAgent()
        return LawChatLLM(agent_type="default").set_agent(agent)
    
    return _LLMCache.get("codebuddy", _create)


# ==================== 专用 LLM 接口 ====================

def get_intent_llm(temperature: float = 0.1) -> Any:
    """
    获取意图识别专用 LLM
    
    意图识别需要低温度、高准确性。
    
    Args:
        temperature: 温度参数（默认 0.1）
    """
    llm_type = LLMConfig.get_current_llm_type()
    
    if llm_type == "ollama":
        from .ollama_llm import create_ollama_llm
        return create_ollama_llm(temperature=temperature, max_tokens=1000)
    elif llm_type == "hunyuan":
        from .hunyuan_llm import create_hunyuan_llm
        return create_hunyuan_llm(temperature=temperature, max_tokens=1000)
    elif llm_type == "deepseek":
        from .deepseek_llm import create_deepseek_llm
        return create_deepseek_llm(temperature=temperature, max_tokens=1000)
    else:
        return get_codebuddy_llm()


def get_generation_llm(temperature: float = 0.7, max_tokens: int = 4000) -> Any:
    """
    获取文书生成专用 LLM
    
    文书生成需要较高温度以保证创意性。
    
    Args:
        temperature: 温度参数（默认 0.7）
        max_tokens: 最大 token 数（默认 4000）
    """
    llm_type = LLMConfig.get_current_llm_type()
    
    if llm_type == "ollama":
        from .ollama_llm import create_ollama_llm
        return create_ollama_llm(temperature=temperature, max_tokens=max_tokens)
    elif llm_type == "hunyuan":
        from .hunyuan_llm import create_hunyuan_llm
        return create_hunyuan_llm(temperature=temperature, max_tokens=max_tokens)
    elif llm_type == "deepseek":
        from .deepseek_llm import create_deepseek_llm
        return create_deepseek_llm(temperature=temperature, max_tokens=max_tokens)
    else:
        return get_codebuddy_llm()


def get_consultation_llm(temperature: float = 0.5) -> Any:
    """
    获取法律咨询专用 LLM
    
    Args:
        temperature: 温度参数（默认 0.5）
    """
    return get_primary_llm()  # 咨询可使用主 LLM


# ==================== 便捷函数 ====================

def use_ollama():
    """切换到本地 Ollama LLM"""
    LLMConfig.set_primary_llm("ollama")
    _LLMCache.reset()


def use_hunyuan():
    """切换到腾讯混元 LLM"""
    LLMConfig.set_primary_llm("hunyuan")
    _LLMCache.reset()


def use_deepseek():
    """切换到 DeepSeek LLM"""
    LLMConfig.set_primary_llm("deepseek")
    _LLMCache.reset()


def use_codebuddy():
    """切换到 CodeBuddy LLM"""
    LLMConfig.set_primary_llm("codebuddy")
    _LLMCache.reset()


def get_llm_info() -> dict:
    """获取当前 LLM 配置信息"""
    return {
        "primary_llm": LLMConfig.get_current_llm_type(),
        "available_llms": {
            "hunyuan": LLMConfig.is_available("hunyuan"),
            "deepseek": LLMConfig.is_available("deepseek"),
            "codebuddy": LLMConfig.is_available("codebuddy"),
        },
        "env_config": {
            "OLLAMA_BASE_URL": os.getenv("OLLAMA_BASE_URL", "not set"),
            "OLLAMA_MODEL": os.getenv("OLLAMA_MODEL", "not set"),
            "HUNYUAN_API_KEY": bool(os.getenv("HUNYUAN_API_KEY")),
            "HUNYUAN_MODEL": os.getenv("HUNYUAN_MODEL", "not set"),
            "DEEPSEEK_API_KEY": bool(os.getenv("DEEPSEEK_API_KEY")),
        },
    }


def create_llm_by_type(
    llm_type: Literal["ollama", "hunyuan", "deepseek", "codebuddy", "none"],
    temperature: float = 0.1,
    max_tokens: int = 2000,
) -> Optional[Any]:
    """
    根据类型创建 LLM 实例
    
    Args:
        llm_type: LLM 类型 (ollama, hunyuan, deepseek, codebuddy, none)
        temperature: 温度参数
        max_tokens: 最大 token 数
        
    Returns:
        LLM 实例，none 类型返回 None
    """
    if llm_type == "none" or llm_type == "":
        return None
    
    if llm_type == "ollama":
        from .ollama_llm import create_ollama_llm
        return create_ollama_llm(temperature=temperature, max_tokens=max_tokens)
    elif llm_type == "hunyuan":
        from .hunyuan_llm import create_hunyuan_llm
        return create_hunyuan_llm(temperature=temperature, max_tokens=max_tokens)
    elif llm_type == "deepseek":
        from .deepseek_llm import create_deepseek_llm
        return create_deepseek_llm(temperature=temperature, max_tokens=max_tokens)
    elif llm_type == "codebuddy":
        return get_codebuddy_llm()
    else:
        print(f"[create_llm_by_type] 未知 LLM 类型: {llm_type}，返回 None")
        return None

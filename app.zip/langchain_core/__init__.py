"""
法智通 LangChain 核心模块

将现有手写工作流引擎升级为基于 LangChain (LCEL + LangGraph) 的声明式架构。

模块结构:
- llm: LawChatLLM - CodeBuddy Agent SDK 的 LangChat 适配器
- prompts: 所有 ChatPromptTemplate 集中定义
- parsers: 结构化输出解析器 (替代手动JSON解析)
- tools: @tool 装饰的工具函数 (法规检索/案例检索/模板查询)
- memory: Memory 配置工厂 (对话历史管理)
- chains: LCEL Chain 组件 (意图识别/咨询/参数提取/修改/生成)
- graphs: LangGraph StateMachine (文书生成FSM/文书修改FSM/路由图)
"""

from .llm import LawChatLLM
from .deepseek_llm import get_deepseek_llm, create_deepseek_llm
from .hunyuan_llm import (
    get_hunyuan_llm,
    create_hunyuan_llm,
    create_hunyuan_pro_llm,
    create_hunyuan_standard_llm,
)
from .llm_factory import (
    get_primary_llm,
    get_intent_llm,
    get_generation_llm,
    get_consultation_llm,
    use_hunyuan,
    use_deepseek,
    use_codebuddy,
    get_llm_info,
    LLMConfig,
)
from .prompts import (
    INTENT_PROMPT,
    PARAM_EXTRACTION_PROMPT,
    MODIFICATION_PROMPT,
    DOCUMENT_GENERATION_PROMPT,
    CONSULTATION_PROMPT,
    KEYWORD_EXTRACT_PROMPT,
    MODIFY_CLASSIFY_PROMPT,
    MODIFY_REWRITE_PROMPT,
    MODIFY_ENHANCE_PROMPT,
)
from .parsers import (
    intent_parser,
    param_extractor_parser,
    modification_parser,
)
from .main_chain import run_main_chain, HybridChatService, chat

__all__ = [
    # LLM
    "LawChatLLM",
    # LLM Factory (Primary LLM Management)
    "get_primary_llm",
    "get_intent_llm",
    "get_generation_llm",
    "get_consultation_llm",
    "use_hunyuan",
    "use_deepseek",
    "use_codebuddy",
    "get_llm_info",
    "LLMConfig",
    # Prompts
    "INTENT_PROMPT",
    "PARAM_EXTRACTION_PROMPT",
    "MODIFICATION_PROMPT",
    "DOCUMENT_GENERATION_PROMPT",
    "CONSULTATION_PROMPT",
    # Parsers
    "intent_parser",
    "param_extractor_parser",
    "modification_parser",
    # Main Chain
    "run_main_chain",
    "HybridChatService",
    "chat",
]

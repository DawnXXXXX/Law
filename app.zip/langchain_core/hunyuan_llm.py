"""
腾讯混元 LLM 客户端 - 基于 langchain_openai.ChatOpenAI

使用 OpenAI SDK 兼容方式接入腾讯混元大模型 API。
支持混元-pro 和混元-standard 等模型。

使用说明:
1. 在 .env 中配置 HUNYUAN_API_KEY
2. 可选配置 HUNYUAN_BASE_URL 和 HUNYUAN_MODEL
3. 使用 get_hunyuan_llm() 获取单例实例

腾讯混元 API 参考:
- 官方文档: https://cloud.tencent.com/document/product/1729-97726
- API 地址: https://hunyuan.cloud.tencent.com
- SDK 支持 OpenAI 兼容格式
"""

import threading
from typing import Optional

from langchain_openai import ChatOpenAI


# ==================== 线程安全的单例管理 ====================

class _HunyuanLLMSingleton:
    """
    线程安全的腾讯混元 LLM 单例管理器
    
    使用双重检查锁定模式确保线程安全。
    """
    _instance: Optional[ChatOpenAI] = None
    _lock = threading.Lock()
    
    @classmethod
    def get(cls) -> ChatOpenAI:
        """获取或创建单例（线程安全）"""
        if cls._instance is None:
            with cls._lock:
                # 双重检查：防止多线程重复创建
                if cls._instance is None:
                    cls._instance = cls._create()
        return cls._instance
    
    @classmethod
    def reset(cls) -> None:
        """重置单例（测试用）"""
        with cls._lock:
            cls._instance = None
    
    @staticmethod
    def _create() -> ChatOpenAI:
        """创建新的 ChatOpenAI 实例"""
        from ..config import settings
        
        # 腾讯混元 API 地址（需要包含 /openai/v1 路径）
        base_url = getattr(settings, 'HUNYUAN_BASE_URL', "https://hunyuan.cloud.tencent.com/openai/v1")
        if "openai/v1" not in base_url:
            base_url = base_url.rstrip("/") + "/openai/v1"
        
        api_key = getattr(settings, 'HUNYUAN_API_KEY', None) or ""
        model = getattr(settings, 'HUNYUAN_MODEL', "hunyuan-pro")
        
        if not api_key:
            raise ValueError(
                "HUNYUAN_API_KEY 未配置，请在 .env 文件中添加:\n"
                "HUNYUAN_API_KEY=your_api_key_here"
            )
        
        return ChatOpenAI(
            api_key=api_key,
            base_url=base_url,
            model=model,
            temperature=0.7,
            max_tokens=4000,
            # 自动重试机制
            max_retries=3,
            timeout=120,
        )


# ==================== 公共接口 ====================

def get_hunyuan_llm() -> ChatOpenAI:
    """
    获取或创建腾讯混元 LLM 单例
    
    使用 OpenAI SDK 兼容方式调用腾讯混元大模型。
    
    Returns:
        配置好的 ChatOpenAI 实例（线程安全）
        
    Raises:
        ValueError: 当 HUNYUAN_API_KEY 未配置时
        
    使用示例:
        >>> llm = get_hunyuan_llm()
        >>> response = await llm.ainvoke("你好")
        >>> # 或在 LCEL Chain 中使用
        >>> chain = prompt | llm | parser
    """
    return _HunyuanLLMSingleton.get()


def create_hunyuan_llm(
    *,
    model: str = "hunyuan-pro",
    temperature: float = 0.7,
    max_tokens: int = 4000,
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
    **kwargs,
) -> ChatOpenAI:
    """
    创建自定义配置的腾讯混元 LLM 实例
    
    用于需要不同参数的场景。
    
    Args:
        model: 模型名称 (hunyuan-pro / hunyuan-standard)
        temperature: 温度参数 (0.0-1.0)，越高越有创意
        max_tokens: 最大生成 token 数
        base_url: API 地址（可选）
        api_key: API Key（可选）
        **kwargs: 传递给 ChatOpenAI 的其他参数
        
    Returns:
        新的 ChatOpenAI 实例（非单例）
        
    使用示例:
        >>> # 使用标准版模型
        >>> std_llm = create_hunyuan_llm(model="hunyuan-standard")
        >>> 
        >>> # 使用更高创意度
        >>> creative_llm = create_hunyuan_llm(temperature=0.9)
        >>> 
        >>> # 在 Chain 中使用
        >>> chain = GENERATION_PROMPT | creative_llm | StrOutputParser()
    """
    from ..config import settings
    
    api_key = api_key or getattr(settings, 'HUNYUAN_API_KEY', None) or ""
    base_url = base_url or getattr(settings, 'HUNYUAN_BASE_URL', "https://hunyuan.cloud.tencent.com/openai/v1")
    if "openai/v1" not in base_url:
        base_url = base_url.rstrip("/") + "/openai/v1"
    
    if not api_key:
        raise ValueError(
            "HUNYUAN_API_KEY 未配置，请在 .env 文件中添加:\n"
            "HUNYUAN_API_KEY=your_api_key_here"
        )
    
    return ChatOpenAI(
        api_key=api_key,
        base_url=base_url,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        timeout=120,
        max_retries=3,
        **kwargs,
    )


def create_hunyuan_pro_llm(**kwargs) -> ChatOpenAI:
    """创建混元-pro 模型实例（高配版）"""
    return create_hunyuan_llm(model="hunyuan-pro", temperature=0.7, **kwargs)


def create_hunyuan_standard_llm(**kwargs) -> ChatOpenAI:
    """创建混元-standard 模型实例（标准版）"""
    return create_hunyuan_llm(model="hunyuan-standard", temperature=0.5, **kwargs)

"""
DeepSeek LLM 客户端 - 基于 langchain_openai.ChatOpenAI

直接调用 DeepSeek API，绕过 CodeBuddy Agent 的意图识别。
用于参数提取等纯任务型场景。

重构说明:
- 使用 ChatOpenAI (langchain_openai) 替代手写的 BaseChatModel 子类
- 消除与 llm.py 中 LawChatLLM 的重复代码 (_generate/_agenerate/_convert_messages)
- 自动获得连接池、重试、流式输出等 LangChain 内置能力
- 配置统一从 config.py Settings 读取
"""

import threading
from typing import Optional

from langchain_openai import ChatOpenAI


# ==================== 线程安全的单例管理 ====================

class _DeepSeekLLMSingleton:
    """
    线程安全的 DeepSeek LLM 单例管理器
    
    解决原版全局变量 + 延迟初始化的线程安全问题。
    使用双重检查锁定模式确保线程安全。
    """
    _instance: Optional[ChatOpenAI] = None
    _lock = threading.Lock()
    
    @classmethod
    def get(cls) -> ChatOpenAI:
        """获取或创建单例（线程安全）"""
        if cls._instance is None:
            with cls._lock:
                # 双重检查：防止多线程重复创建
                if cls._instance is None:
                    cls._instance = cls._create()
        return cls._instance
    
    @classmethod
    def reset(cls) -> None:
        """重置单例（测试用）"""
        with cls._lock:
            cls._instance = None
    
    @staticmethod
    def _create() -> ChatOpenAI:
        """创建新的 ChatOpenAI 实例"""
        from ..config import settings
        
        api_key = getattr(settings, 'DEEPSEEK_API_KEY', None) or ""
        base_url = getattr(settings, 'DEEPSEEK_BASE_URL', "https://api.deepseek.com")
        model = getattr(settings, 'DEEPSEEK_MODEL', "deepseek-chat")
        
        return ChatOpenAI(
            api_key=api_key,
            base_url=base_url,
            model=model,
            temperature=0.1,
            max_tokens=2000,
            # 自动重试机制
            max_retries=2,
        )


# ==================== 公共接口 ====================

def get_deepseek_llm() -> ChatOpenAI:
    """
    获取或创建 DeepSeek LLM 单例
    
    使用 ChatOpenAI 连接 DeepSeek 兼容 API，
    无需手写 BaseChatModel 子类。
    
    Returns:
        配置好的 ChatOpenAI 实例（线程安全）
        
    使用示例:
        >>> llm = get_deepseek_llm()
        >>> response = await llm.ainvoke("你好")
        >>> # 或在 LCEL Chain 中使用
        >>> chain = prompt | llm | parser
    """
    return _DeepSeekLLMSingleton.get()


def create_deepseek_llm(
    *,
    temperature: float = 0.1,
    max_tokens: int = 2000,
    **kwargs,
) -> ChatOpenAI:
    """
    创建自定义配置的 DeepSeek LLM 实例
    
    用于需要不同参数的场景（如文书生成需要更高 temperature）。
    
    Args:
        temperature: 温度参数 (0.0-1.0)
        max_tokens: 最大生成 token 数
        **kwargs: 传递给 ChatOpenAI 的其他参数
        
    Returns:
        新的 ChatOpenAI 实例（非单例）
        
    使用示例:
        >>> creative_llm = create_deepseek_llm(temperature=0.7)
        >>> chain = GENERATION_PROMPT | creative_llm | StrOutputParser()
    """
    from ..config import settings
    
    api_key = getattr(settings, 'DEEPSEEK_API_KEY', None) or ""
    base_url = getattr(settings, 'DEEPSEEK_BASE_URL', "https://api.deepseek.com")
    model = getattr(settings, 'DEEPSEEK_MODEL', "deepseek-chat")
    
    return ChatOpenAI(
        api_key=api_key,
        base_url=base_url,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        **kwargs,
    )

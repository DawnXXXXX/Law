"""
参数提取 / 修改处理 / 文书生成 LCEL Chains

重构说明:
- 使用标准 LCEL 管道 (Prompt | LLM | Parser) 替代自定义类 + 手动 ainvoke()
- 消除内联模板字符串 + .replace() 的 workaround
- 使用 ChatPromptTemplate.from_template() 正确处理花括号转义
- 所有 Chain 都是真正的 Runnable，支持 | 操作符和 stream/ainvoke

替代 workflows.py 中 WorkflowAgentService 的3个方法:
1. extract_params() → create_param_extraction_chain()
2. process_modification() → create_modification_chain()
3. generate_document_content() → create_generation_chain()
"""

from typing import Any, Dict, Optional

from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnableLambda, RunnableParallel, RunnablePassthrough

from ..prompts import (
    PARAM_EXTRACTION_PROMPT,
    MODIFICATION_PROMPT,
    DOCUMENT_GENERATION_PROMPT,
)
from ..parsers import (
    param_extractor_parser,
    modification_parser,
)


# ==================== 参数提取链 ====================

def _serialize_param_input(input_dict: Dict[str, Any]) -> Dict[str, str]:
    """
    序列化参数提取的输入字典
    
    将 params_def、collected_params 从 dict 转换为 JSON 字符串，
    将 conversation_history 格式化为可读文本，
    避免 ChatPromptTemplate 尝试解析 JSON 内部的花括号。
    """
    import json
    
    params_def = input_dict.get("params_def", {})
    collected_params = input_dict.get("collected_params", {})
    conversation_history = input_dict.get("conversation_history", [])
    
    if isinstance(params_def, dict):
        params_def = json.dumps(params_def, ensure_ascii=False, indent=2)
    if isinstance(collected_params, dict):
        collected_params = json.dumps(collected_params, ensure_ascii=False, indent=2)
    
    # 格式化对话历史
    if isinstance(conversation_history, list):
        history_text = _format_conversation_history(conversation_history)
    else:
        history_text = str(conversation_history) if conversation_history else "（无历史记录）"
    
    return {
        **input_dict,
        "params_def": params_def,
        "collected_params": collected_params,
        "conversation_history": history_text,
        "format_instructions": param_extractor_parser.get_format_instructions(),
    }


def _format_conversation_history(history: list) -> str:
    """格式化对话历史为可读文本（精简版）"""
    if not history:
        return "（无历史记录）"
    
    lines = []
    for msg in history[-3:]:  # 只取最近3条，大幅减少 token
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        if role == "user":
            lines.append(f"用户: {content[:100]}")  # 截断到100字符
        elif role == "assistant":
            lines.append(f"助手: {content[:100]}")
    
    return "\n".join(lines)
    
    return "\n".join(lines)


def _parse_param_extraction_result(llm_output: Any) -> Dict[str, Any]:
    """解析参数提取的 LLM 输出"""
    content = llm_output.content if hasattr(llm_output, 'content') else str(llm_output)
    
    try:
        result = param_extractor_parser.parse(content)
        return {
            "extracted": dict(result.extracted) if result.extracted else {},
            "missing_required": list(result.missing_required),
            "confidence": float(result.confidence),
            "response_text": result.response_text if hasattr(result, 'response_text') and result.response_text else "",
            "notes": result.notes if hasattr(result, 'notes') else "",
        }
    except Exception as e:
        print(f"[param_extraction] 解析失败: {e}")
        # 尝试使用 JsonOutputParser 兜底
        from langchain_core.output_parsers import JsonOutputParser
        try:
            fallback = JsonOutputParser().parse(content)
            if isinstance(fallback, dict) and "extracted" in fallback:
                return {
                    "extracted": fallback.get("extracted", {}),
                    "missing_required": fallback.get("missing_required", []),
                    "confidence": fallback.get("confidence", 0.0),
                    "response_text": fallback.get("response_text", ""),
                    "notes": fallback.get("notes", f"解析失败(已降级): {e}"),
                }
        except Exception:
            pass
        return {"extracted": {}, "missing_required": [], "confidence": 0.0, "response_text": "", "notes": f"解析失败: {e}"}


def create_param_extraction_chain(llm: Any = None):
    """
    创建参数提取 LCEL 链 (标准 Runnable)

    使用 LCEL 声明式管道:
        输入 → _serialize → Prompt → LLM → _parse → 输出

    输入: {
        "user_input": "我叫张三，要告李四借了我5万",
        "template_name": "民事起诉状",
        "params_def": "{...}",
        "collected_params": "{}",
    }

    输出: {
        "extracted": {"原告姓名": "张三", ...},
        "missing_required": [],
        "confidence": 0.95,
        ...
    }

    Args:
        llm: LLM 实例（必须提供，否则抛出异常）

    Returns:
        可执行的 LCEL Chain (Runnable)

    使用示例:
        >>> chain = create_param_extraction_chain(llm)
        >>> result = await chain.ainvoke({
        ...     "user_input": "被告叫李四",
        ...     "template_name": "民事起诉状",
        ...     "params_def": '{"原告姓名": {...}}',
        ...     "collected_params": '{}',
        ... })
        >>> print(result["extracted"])
    """
    if llm is None:
        raise ValueError("create_param_extraction_chain() 需要传入 llm 参数")
    
    # 标准 LCEL 管道
    chain = (
        RunnableLambda(_serialize_param_input)       # 预处理：序列化字典
        | PARAM_EXTRACTION_PROMPT                     # ChatPromptTemplate (正确处理花括号)
        | llm                                          # LLM 调用
        | RunnableLambda(_parse_param_extraction_result)  # 后处理：Pydantic 解析
    )
    
    return chain


# ==================== 修改处理链 ====================

def _parse_modification_result(llm_output: Any) -> Dict[str, Any]:
    """解析文书修改的 LLM 输出"""
    content = llm_output.content if hasattr(llm_output, 'content') else str(llm_output)
    
    try:
        result = modification_parser.parse(content)
        return {
            "modification_type": result.modification_type,
            "location": result.location,
            "location_hint": result.location_hint,
            "original_text": result.original_text,
            "new_text": result.new_text,
            "reason": result.reason,
        }
    except Exception as e:
        print(f"[modification] 解析失败: {e}")
        from langchain_core.output_parsers import JsonOutputParser
        try:
            fallback = JsonOutputParser().parse(content)
            if isinstance(fallback, dict):
                return {
                    "modification_type": fallback.get("modification_type", "unknown"),
                    "location": fallback.get("location", ""),
                    "location_hint": fallback.get("location_hint", ""),
                    "original_text": fallback.get("original_text", ""),
                    "new_text": fallback.get("new_text", ""),
                    "reason": fallback.get("reason", f"解析失败(已降级): {e}"),
                }
        except Exception:
            pass
        return {"modification_type": "unknown", "reason": f"解析失败: {e}"}


def create_modification_chain(llm: Any = None):
    """
    创建文书修改 LCEL 链 (标准 Runnable)

    输入: {
        "user_input": "把违约金改成10%",
        "document_content": "...当前文书内容...",
    }

    输出: {
        "modification_type": "replace",
        "location": "违约金条款",
        ...
    }

    Args:
        llm: LLM 实例（必须提供）

    Returns:
        可执行的 LCEL Chain
    """
    if llm is None:
        raise ValueError("create_modification_chain() 需要传入 llm 参数")
    
    chain = (
        RunnableLambda(lambda x: {
            **x,
            "document_content": x.get("document_content", "")[:3000],
            "format_instructions": modification_parser.get_format_instructions(),
        })
        | MODIFICATION_PROMPT
        | llm
        | RunnableLambda(_parse_modification_result)
    )
    
    return chain


# ==================== 文书生成链 ====================

def _parse_generation_result(llm_output: Any) -> Dict[str, Any]:
    """解析文书生成的 LLM 输出"""
    content = llm_output.content if hasattr(llm_output, 'content') else str(llm_output)
    return {"content": content.strip()}


def create_generation_chain(llm: Any = None):
    """
    创建文书内容生成 LCEL 链 (标准 Runnable)

    输入: {
        "document_type": "民事起诉状",
        "params_json": '{"原告姓名":"张三", ...}',
    }

    输出: {
        "content": "## 民事起诉状\n\n**原告**: 张三...",
    }

    Args:
        llm: LLM 实例（必须提供）

    Returns:
        可执行的 LCEL Chain
    """
    if llm is None:
        raise ValueError("create_generation_chain() 需要传入 llm 参数")
    
    chain = (
        DOCUMENT_GENERATION_PROMPT
        | llm
        | RunnableLambda(_parse_generation_result)
    )
    
    return chain

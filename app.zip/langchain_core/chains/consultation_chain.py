"""
法律咨询 LCEL Chain（知识库增强） - 重构版

重构说明:
- 使用标准 LCEL 管道替代自定义类 + 手动 ainvoke()
- 使用 RunnableParallel 并行执行知识检索
- 使用 RunnableLambda 封装各步骤，保持管道式声明风格
- 保留与旧版完全相同的输入/输出接口（向后兼容）

架构 (LCEL 声明式):
    input
      → _extract_keywords (RunnableLambda)
        → RunnableParallel(
            laws=search_laws,
            cases=search_cases,
          )
        → _build_consult_input (RunnableLambda)
          → CONSULTATION_PROMPT | llm | _format_output (RunnableLambda)

替代 workflows.py 中的 consultation_workflow。
"""

from typing import Any, Dict, List, Optional

from langchain_core.output_parsers import StrOutputParser as LangChainStrOutputParser
from langchain_core.runnables import (
    RunnableLambda,
    RunnableParallel,
    RunnablePassthrough,
)

from ..prompts import (
    CONSULTATION_PROMPT,
    KEYWORD_EXTRACT_PROMPT,
)
from ..tools import parallel_knowledge_search
from ..services import (
    get_consultation_memory,
    KnowledgeRetrievalService,
)
# 直接从 response_formatter 导入，避免循环导入
from ..services.response_formatter import ResponseFormatter


# =====================================================================
# 步骤函数 (每个都是纯函数，可独立测试)
# =====================================================================

async def _extract_keywords(inputs: Dict[str, Any], llm: Any = None) -> str:
    """
    从用户问题中提取检索关键词
    
    Args:
        inputs: 包含 "message" 的字典
        llm: LLM 实例（可选）
        
    Returns:
        关键词字符串或降级后的原始消息
    """
    if not llm:
        return inputs.get("message", "")
    
    kw_prompt = KEYWORD_EXTRACT_PROMPT.format(input_text=inputs.get("message", ""))
    
    try:
        response = await llm.ainvoke(kw_prompt)
        return response.content.strip() if hasattr(response, 'content') else str(response).strip()
    except Exception as e:
        print(f"[consultation_chain] 关键词提取失败: {e}")
        return inputs.get("message", "")[:50]


async def _retrieve_knowledge(inputs: Dict[str, Any]) -> Dict[str, List[Dict]]:
    """
    根据关键词并行检索法规和案例
    
    内部使用 parallel_knowledge_search 实现并行调用。
    
    Args:
        inputs: 包含 "keywords" 的字典
        
    Returns:
        {"laws": [...], "cases": [...]}
    """
    keywords = inputs.get("keywords", "")
    
    if not keywords:
        return {"laws": [], "cases": []}
    
    result = await parallel_knowledge_search(keywords)
    return {
        "laws": result.get("laws", []),
        "cases": result.get("cases", []),
    }


async def _search_laws(keywords: str) -> List[Dict]:
    """并行检索法规（供 RunnableParallel 使用）"""
    if not keywords:
        return []
    result = await parallel_knowledge_search(keywords)
    return result.get("laws", [])


async def _search_cases(keywords: str) -> List[Dict]:
    """并行检索案例（供 RunnableParallel 使用）"""
    if not keywords:
        return []
    result = await parallel_knowledge_search(keywords)
    return result.get("cases", [])


async def _build_consult_input(inputs: Dict[str, Any]) -> Dict[str, Any]:
    """
    组装法律咨询的最终 Prompt 输入

    将知识库结果、对话历史、用户问题整合为
    CONSULTATION_PROMPT 所需的变量字典。

    Args:
        inputs: 包含 laws/cases/message/conversation_id 的字典

    Returns:
        格式化后的 Prompt 变量字典
    """
    laws = inputs.get("laws", [])
    cases = inputs.get("cases", [])
    message = inputs.get("message", "")
    conversation_id = inputs.get("conversation_id", 0)

    # 格式化知识库内容
    knowledge_text = KnowledgeRetrievalService().format_for_prompt(laws, cases)

    # 获取对话历史
    mem = get_consultation_memory()
    history_msgs = await mem.get_chat_history(conversation_id)
    chat_history_text = ResponseFormatter.format_history_for_prompt(history_msgs)

    # 构建元数据（用于最终输出的统计信息）
    # 安全处理 keywords：可能是 str 或 dict
    _keywords = inputs.get("keywords", "")
    if isinstance(_keywords, (list, dict)):
        keywords_list = list(_keywords) if isinstance(_keywords, (list, dict)) else []
    elif isinstance(_keywords, str):
        keywords_list = _keywords.split() if _keywords else []
    else:
        keywords_list = []

    metadata = {
        "laws_count": len([l for l in laws if not l.get("error")]),
        "cases_count": len([c for c in cases if not c.get("error")]),
        "keywords": keywords_list,
    }

    return {
        **inputs,
        "knowledge_context": knowledge_text,
        "chat_history": chat_history_text,
        "user_question": f"{knowledge_text}\n\n{chat_history_text}\n\n{message}",
        "_metadata": metadata,
    }


def _format_output(llm_output: Any, **kwargs) -> Dict[str, Any]:
    """
    格式化最终输出（标准化为与旧版一致的格式）
    
    Args:
        llm_output: LLM 返回的 AIMessage 或字符串
        kwargs: 中间传递的元数据
        
    Returns:
        标准化的输出字典
    """
    content = ""
    if hasattr(llm_output, 'content'):
        content = llm_output.content
    elif isinstance(llm_output, str):
        content = llm_output
    else:
        content = str(llm_output)
    
    metadata = kwargs.get("_metadata", {})
    
    return {
        "content": content.strip(),
        "widget": None,
        "workflow_output": {
            "knowledge_retrieved": True,
            "laws_count": metadata.get("laws_count", 0),
            "cases_count": metadata.get("cases_count", 0),
            "keywords": metadata.get("keywords", []),
        },
    }


async def _save_to_memory(inputs: Dict[str, Any]) -> None:
    """异步保存对话到 Memory（不阻塞主流程）"""
    try:
        mem = get_consultation_memory()
        await mem.save_consultation_turn(
            conversation_id=inputs.get("conversation_id", 0),
            user_message=inputs.get("message", ""),
            assistant_response=inputs.get("_llm_content", ""),
            knowledge_context={
                "laws": inputs.get("laws", []),
                "cases": inputs.get("cases", []),
            },
        )
    except Exception as e:
        print(f"[consultation_chain] 保存Memory失败(不影响结果): {e}")


# =====================================================================
# Chain 工厂函数 ====================
# =====================================================================

def create_consultation_chain(llm: Any = None):
    """
    创建法律咨询 LCEL Chain (标准 Runnable)
    
    重构说明:
    - 不再返回自定义 ConsultationChainImpl 类
    - 返回真正的 LCEL Runnable Chain
    - 支持所有 Runnable 操作: invoke/ainvoke/stream/batch
    
    输入: {
        "message": "公司没签劳动合同能要双倍工资吗",
        "conversation_id": 123,
    }
    
    输出: {
        "content": "根据《劳动合同法》第82条...",
        "intent": "consultation",
        "confidence": 1.0,
        "workflow_output": {...},
    }
    
    Args:
        llm: LawChatLLM 实例（可选）
        
    Returns:
        可执行的 LCEL Chain (Runnable)
        
    使用示例:
        >>> chain = create_consultation_chain(law_chat_llm)
        >>> result = await chain.ainvoke({
        ...     "message": "公司没签劳动合同能要双倍工资吗",
        ...     "conversation_id": 123,
        ... })
        >>> print(result["content"])
    """
    if llm is None:
        # 无法自动获取 LLM，用户需要显式传入
        print(f"[consultation_chain] 警告: 未提供 LLM，部分功能可能受限")
    
    # 简化版 chain：
    # 输入: {"message": ..., "conversation_id": ..., "keywords": ...}
    # Step 1: 并行检索法规和案例
    retrieval_chain = (
        RunnableParallel(
            keywords=RunnablePassthrough(),  # 传递 keywords
            laws=_search_laws,              # 检索法规
            cases=_search_cases,            # 检索案例
        )
        | _build_consult_input            # 组装完整输入
        # Step 2: LLM 生成回答
        | (
            RunnableLambda(lambda x: CONSULTATION_PROMPT.format(**x))
            | llm
        )
        # Step 3: 格式化输出
        | _format_output
    )
    
    # 最终 chain：直接传递输入（keywords 应在外部提取后传入）
    chain = retrieval_chain
    
    # 包装：添加意图标识和 Memory 保存的副作用
    async def wrapped_invoke(input_dict: Dict[str, Any], config=None) -> Dict[str, Any]:
        """包装函数：添加 intent 标识和 Memory 持久化"""
        # 执行主链
        result = await chain.ainvoke(input_dict, config=config)
        
        # 添加标准字段
        result["intent"] = "consultation"
        result["confidence"] = 1.0
        
        # 异步保存到 Memory（不阻塞）
        if input_dict.get("conversation_id"):
            try:
                mem = get_consultation_memory()
                await mem.save_consultation_turn(
                    conversation_id=input_dict["conversation_id"],
                    user_message=input_dict.get("message", ""),
                    assistant_response=result.get("content", ""),
                )
            except Exception as e:
                print(f"[consultation_chain] 保存Memory失败(不影响结果): {e}")
        
        return result
    
    # 创建一个简单的 Runnable 包装器
    class ConsultationChainWrapper:
        """LCEL Chain 包装器，保持与旧版相同的接口"""
        
        def __init__(self, _llm):
            self._llm = _llm
            self._inner_chain = chain
        
        async def ainvoke(self, input: Dict[str, Any], config=None) -> Dict[str, Any]:
            """异步调用"""
            return await wrapped_invoke(input, config=config)
        
        async def invoke(self, input: Dict[str, Any], config=None) -> Dict[str, Any]:
            """同步调用"""
            return await self.ainvoke(input, config)
    
    return ConsultationChainWrapper(llm)

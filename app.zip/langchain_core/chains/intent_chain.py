"""
意图识别 LCEL Chain

替代 main_workflow.py 中的 IntentRecognizer 类，
使用 LangChain 的 Chain 管道实现声明式的意图识别流程。

架构:
    user_input + history → PromptTemplate → LawChatLLM → PydanticOutputParser → IntentResult
"""

from typing import Any, Dict, List, Optional

from langchain_core.runnables import (
    Runnable,
    RunnableLambda,
    RunnablePassthrough,
)
from langchain_core.output_parsers import PydanticOutputParser

from ..prompts import INTENT_PROMPT
from ..parsers import IntentResult, intent_parser, LegacyJsonParser


def create_intent_chain(llm: Any = None) -> Runnable:
    """
    创建意图识别 LCEL 链
    
    Args:
        llm: LawChatLLM 实例（可选，后续可动态设置）
        
    Returns:
        可执行的 Runnable Chain
        
    使用示例:
        >>> chain = create_intent_chain(law_chat_llm)
        >>> result = await chain.ainvoke({
        ...     "user_input": "帮我写一个离婚起诉状",
        ...     "history": "",
        ... })
        >>> print(result.intent)      # "document_generation"
        >>> print(result.confidence)  # 0.95
        >>> print(result.document_type) # "起诉状"
    """
    
    def _build_input(dct: Dict[str, Any]) -> Dict[str, Any]:
        """构建 prompt 输入，注入格式化指令"""
        return {
            "user_input": dct.get("user_input", ""),
            "history": dct.get("history", ""),
            "format_instructions": intent_parser.get_format_instructions(),
        }
    
    def _parse_output(llm_response: str) -> IntentResult:
        """
        解析 LLM 输出为结构化结果
        
        使用 PydanticOutputParser 进行类型安全解析。
        如果解析失败，降级为 LegacyJsonParser。
        """
        try:
            return intent_parser.parse(llm_response)
        except Exception as e:
            print(f"[intent_chain] Pydantic解析失败，尝试兼容模式: {e}")
            fallback = LegacyJsonParser.safe_parse(llm_response)
            
            if fallback and isinstance(fallback, dict):
                # 将字典转为 IntentResult
                return IntentResult(
                    intent=fallback.get("intent", "unknown"),
                    confidence=float(fallback.get("confidence", 0.5)),
                    reasoning=fallback.get("reasoning", ""),
                    document_type=fallback.get("document_type", ""),
                    dispute_type=fallback.get("dispute_type", ""),
                    extracted_info=fallback.get("extracted_info", {}),
                )
            
            # 最终回退
            return IntentResult(
                intent="unknown",
                confidence=0.0,
                reasoning=f"解析失败: {str(e)}",
            )
    
    def _normalize_intent(result: IntentResult) -> dict:
        """将结果标准化为字典格式（与旧接口兼容）"""
        
        # 标准化 intent 值
        valid_intents = {
            "document_generation", "document_modification", "contract_service",
            "consultation", "case_search", "law_search", "chitchat", "unknown",
        }
        
        raw_intent = result.intent if result.intent else "unknown"
        if raw_intent not in valid_intents:
            # 尝试模糊匹配（保留原有逻辑）
            intent_map = {
                "文书生成": "document_generation", "起草": "document_generation",
                "文书修改": "document_modification", "修改": "document_modification",
                "合同服务": "contract_service", "合同": "contract_service",
                "法律咨询": "consultation", "咨询": "consultation",
                "案例检索": "case_search", "案例": "case_search",
                "法规检索": "law_search", "法规": "law_search",
                "闲聊": "chitchat",
            }
            raw_intent = intent_map.get(raw_intent, "unknown")
        
        # 检测意图变更
        previous = result.extracted_info or {}
        intent_changed = True
        
        return {
            "intent": raw_intent,
            "confidence": result.confidence,
            "reasoning": result.reasoning,
            "document_type": result.document_type or "",
            "dispute_type": result.dispute_type or "",
            "extracted_info": result.extracted_info or {},
            "intent_changed": intent_changed,
            "_raw_result": result,  # 保存原始对象供调试
        }
    
    # 构建 LCEL 管道
    # 输入: {"user_input": "...", "history": "..."}
    # 输出: {intent, confidence, reasoning, ...}
    
    chain = (
        RunnableLambda(_build_input)       # Step 1: 组装输入
        | INTENT_PROMPT                     # Step 2: 注入Prompt模板 (自动填充{user_input}{history}{format_instructions})
        | llm                               # Step 3: 调用LLM
        | RunnableLambda(lambda x: x.content if hasattr(x, 'content') else str(x))  # Step 3.5: 提取文本
        | RunnableLambda(_parse_output)     # Step 4: 结构化解析
        | RunnableLambda(_normalize_intent) # Step 5: 标准化输出
    )
    
    return chain


# ==================== 兼容层：供旧代码调用 ====================

class IntentChainAdapter:
    """
    意图识别链的适配器
    
    提供与原 IntentRecognizer.recognize() 相同的接口签名，
    内部使用新的 LCEL Chain 实现。用于渐进式迁移期间保持接口一致。
    """
    
    def __init__(self, agent=None):
        self._chain = None
        self._agent = agent
    
    async def recognize(
        self,
        query: str,
        history: Optional[List[Dict[str, str]]] = None,
        previous_intent: str = ""
    ) -> Dict[str, Any]:
        """
        执行意图识别（兼容旧接口）
        
        Args:
            query: 用户查询
            history: 对话历史 [{"role":"user/assistant","content":"..."}]
            previous_intent: 之前的意图
            
        Returns:
            意图识别字典
        """
        # 优先使用已初始化的全局单例，避免创建无 agent 实例的空壳 LLM
        if self._chain is None:
            try:
                from ..llm import get_intent_llm, initialize_all_llms
                llm = get_intent_llm()
                if not llm or not llm._agent_instance:
                    from ..agent_sdk import CodeBuddyAgent, SDK_AVAILABLE
                    if SDK_AVAILABLE:
                        agent = CodeBuddyAgent()
                        initialize_all_llms(agent)
                        llm = get_intent_llm()
            except Exception as e:
                print(f"[IntentChainAdapter] LLM 初始化失败: {e}")
                import traceback
                traceback.print_exc()
                llm = None

            if llm and self._agent:
                llm.set_agent(self._agent)
            self._chain = create_intent_chain(llm)
        
        # 格式化历史记录（精简）
        history_text = ""
        if history:
            lines = []
            for msg in history[-3:]:  # 最近3条
                role = "用户" if msg.get("role") == "user" else "助手"
                content = msg.get('content', '')[:100]  # 截断100字符
                lines.append(f"{role}：{content}")
            history_text = "\n".join(lines)
        
        if previous_intent:
            history_text += f"\n## 之前的意图\n{previous_intent}"
        
        # 调用链
        result = await self._chain.ainvoke({
            "user_input": query,
            "history": history_text,
        })
        
        # 返回字典格式（与旧的 _parse_response 返回值一致）
        return {
            "intent": result["intent"],
            "confidence": result["confidence"],
            "reasoning": result["reasoning"],
            "document_type": result["document_type"],
            "dispute_type": result["dispute_type"],
            "extracted_info": result["extracted_info"],
            "intent_changed": result["intent_changed"],
        }

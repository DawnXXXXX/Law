"""
LangChain 主链入口 (Phase 3)

提供与原有 SmartChatService.chat() 接口兼容的统一入口，
内部调用 LangChain/LangGraph 实现的 router_chain。

使用方式:
    from app.langchain_core.main_chain import run_main_chain
    
    result = await run_main_chain(
        message="帮我写起诉状",
        conversation_id=123,
        project_id=456,
        history=[],
        llm=agent,
        db=db,
    )
    # result 格式与 SmartChatService.chat() 完全一致
"""

from __future__ import annotations

import os
import asyncio
from typing import Dict, Any, Optional, List, Literal

# 功能开关：默认启用 LangChain 版本
USE_LANGCHAIN = os.environ.get("USE_LANGCHAIN", "true").lower() == "true"


async def run_main_chain(
    message: str,
    *,
    conversation_id: int = 0,
    project_id: Optional[int] = None,
    history: Optional[List[Dict[str, str]]] = None,
    llm: Any = None,
    db: Any = None,
    attached_files: Optional[List[Dict[str, Any]]] = None,
    workflow_state: Optional[Dict[str, Any]] = None,
    collected_params: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    LangChain 版本的主链入口
    
    与 SmartChatService.chat() 接口完全兼容，
    内部调用 router_graph.run_router()。
    
    Args:
        message: 用户消息
        conversation_id: 会话ID
        project_id: 项目ID
        history: 对话历史
        llm: LawChatLLM 实例（CodeBuddy Agent 包装）
        db: 数据库会话
        attached_files: 附件列表
        workflow_state: 现有工作流状态（用于多轮对话）
        collected_params: 收集的表单参数
        
    Returns:
        {
            "content": str,           # 回复内容
            "intent": str,             # 意图类型
            "confidence": float,       # 置信度
            "workflow_state": dict,    # 工作流状态
            "widget": dict,            # 组件数据
            "workflow_output": dict,   # 业务输出
        }
    """
    from .graphs.router_graph import run_router
    
    # 提取工作流状态中的必要信息
    if workflow_state and isinstance(workflow_state, dict):
        existing_params = workflow_state.get("collected_params", {})
        document_type = workflow_state.get("document_type", "")
    else:
        existing_params = {}
        document_type = ""
    
    # 合并 collected_params（表单提交的参数优先级更高）
    merged_params = {**existing_params}
    if collected_params:
        merged_params.update(collected_params)
    
    try:
        # 调用 LangChain 路由链
        result = await run_router(
            message=message,
            conversation_id=conversation_id,
            project_id=project_id,
            history=history or [],
            llm=llm,
            db=db,
            attached_files=attached_files or [],
            collected_params=merged_params,
            workflow_state=workflow_state,  # 传递前端传来的 workflow_state
        )
        
        # 合并工作流状态
        if workflow_state and isinstance(workflow_state, dict):
            existing_state = workflow_state.get("workflow_state", {})
            result["workflow_state"] = {
                **existing_state,
                **result.get("workflow_state", {}),
            }
        
        return result
        
    except Exception as e:
        import traceback
        print(f"[main_chain] 错误: {e}")
        traceback.print_exc()
        
        # 降级返回错误信息
        return {
            "content": f"处理请求时遇到问题：{str(e)}",
            "intent": "error",
            "confidence": 0.0,
            "workflow_state": {
                "session_id": f"sess_{conversation_id}",
                "current_workflow": "error",
                "workflow_state": {},
                "collected_params": collected_params,
                "document_type": document_type,
            },
            "widget": None,
            "workflow_output": {"error": str(e)},
        }


# =============================================================================
# 渐进式切换支持
# =============================================================================

class HybridChatService:
    """
    混合模式的对话服务
    
    支持在原有实现和新实现之间切换，
    通过 USE_LANGCHAIN 环境变量控制。
    
    使用示例:
        # 在 .env 中设置 USE_LANGCHAIN=true 使用新实现
        # USE_LANGCHAIN=false 使用原有实现
    """
    
    def __init__(self):
        self.use_langchain = USE_LANGCHAIN
        
        if self.use_langchain:
            print("[HybridChatService] 使用 LangChain 版本")
            self._init_langchain()
        else:
            print("[HybridChatService] 使用原有实现")
            from ..smart_chat import SmartChatService
            self._legacy_service = SmartChatService()
    
    def _init_langchain(self):
        """初始化 LangChain 组件"""
        from ..agent_sdk import CodeBuddyAgent, SDK_AVAILABLE
        from .llm import initialize_all_llms
        
        # 初始化 CodeBuddyAgent（无需 config 参数）
        self.agent: Optional[CodeBuddyAgent] = None
        if SDK_AVAILABLE:
            try:
                self.agent = CodeBuddyAgent()
                print(f"[HybridChatService] CodeBuddyAgent 初始化成功")
            except Exception as e:
                print(f"[HybridChatService] CodeBuddyAgent 初始化失败: {e}")
                import traceback
                traceback.print_exc()
                raise  # 不再降级，直接抛出错误让开发者看到
        else:
            raise RuntimeError("[HybridChatService] CodeBuddy Agent SDK 不可用，请检查安装")
        
        # 将 Agent 注入到所有 LLM 单例
        try:
            initialize_all_llms(self.agent)
            print("[HybridChatService] 所有 LLM 单例初始化完成")
        except Exception as e:
            print(f"[HybridChatService] LLM 初始化失败: {e}")
            import traceback
            traceback.print_exc()
            raise
        
        # 构建路由器
        from .graphs.router_graph import build_main_router_graph
        self.router = build_main_router_graph(llm=None, db=None)
        
        # LLM 单例会通过 get_intent_llm() 等函数获取，无需单独存储
        self._llm = None
    
    async def chat(
        self,
        message: str,
        conversation_id: int,
        project_id: Optional[int] = None,
        history: Optional[List[Dict[str, str]]] = None,
        workflow_state: Optional[Dict[str, Any]] = None,
        db=None,
        attached_files: Optional[List[Dict[str, Any]]] = None,
        collected_params: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """统一的对话接口"""
        
        if self.use_langchain:
            return await run_main_chain(
                message=message,
                conversation_id=conversation_id,
                project_id=project_id,
                history=history,
                llm=self._llm,
                db=db,
                attached_files=attached_files,
                workflow_state=workflow_state,
                collected_params=collected_params,
            )
        else:
            return await self._legacy_service.chat(
                message=message,
                conversation_id=conversation_id,
                project_id=project_id,
                history=history,
                workflow_state=workflow_state,
                db=db,
                attached_files=attached_files,
            )
    
    async def close(self):
        """关闭服务"""
        if not self.use_langchain and hasattr(self, "_legacy_service"):
            await self._legacy_service.close()


# =============================================================================
# 便捷函数
# =============================================================================

async def chat(
    message: str,
    *,
    conversation_id: int = 0,
    project_id: Optional[int] = None,
    history: Optional[List[Dict[str, str]]] = None,
    llm: Any = None,
    db: Any = None,
    **kwargs,
) -> Dict[str, Any]:
    """
    便捷的对话函数
    
    使用示例:
        result = await chat(
            message="帮我写起诉状",
            conversation_id=123,
        )
    """
    return await run_main_chain(
        message=message,
        conversation_id=conversation_id,
        project_id=project_id,
        history=history,
        llm=llm,
        db=db,
        **kwargs,
    )

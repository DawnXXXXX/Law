"""
本地 Ollama LLM 客户端 - 基于 langchain_openai.ChatOpenAI

使用方式:
    from langchain_core.ollama_llm import get_ollama_llm, create_ollama_llm
    
    # 获取单例
    llm = get_ollama_llm()
    
    # 创建新实例
    llm = create_ollama_llm(
        base_url="http://localhost:11434/v1",
        model="qwen3.5:9b",
        temperature=0.7,
    )
"""

from typing import Optional, Any
from langchain_openai import ChatOpenAI


# 单例实例
_ollama_instance: Optional[ChatOpenAI] = None


def get_ollama_llm() -> ChatOpenAI:
    """
    获取 Ollama LLM 单例实例
    
    使用环境变量配置:
    - OLLAMA_BASE_URL: Ollama 服务地址（默认 http://localhost:11434/v1）
    - OLLAMA_MODEL: 模型名称（默认 qwen3.5:9b）
    - OLLAMA_TEMPERATURE: 温度参数（默认 0.7）
    """
    global _ollama_instance
    
    if _ollama_instance is None:
        import os
        base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
        model = os.getenv("OLLAMA_MODEL", "qwen3.5:9b")
        temperature = float(os.getenv("OLLAMA_TEMPERATURE", "0.7"))
        
        _ollama_instance = create_ollama_llm(
            base_url=base_url,
            model=model,
            temperature=temperature,
        )
    
    return _ollama_instance


def create_ollama_llm(
    base_url: str = "http://localhost:11434/v1",
    model: str = "qwen3.5:9b",
    temperature: float = 0.7,
    max_tokens: int = 4000,
    **kwargs
) -> ChatOpenAI:
    """
    创建 Ollama LLM 实例
    
    Args:
        base_url: Ollama API 地址
        model: 模型名称
        temperature: 温度参数
        max_tokens: 最大 token 数
        **kwargs: 传递给 ChatOpenAI 的其他参数
        
    Returns:
        ChatOpenAI 实例
    """
    print(f"[Ollama LLM] 创建实例: base_url={base_url}, model={model}, temperature={temperature}")
    
    return ChatOpenAI(
        base_url=base_url,
        api_key="not-needed",  # Ollama 不需要 API Key
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        **kwargs
    )

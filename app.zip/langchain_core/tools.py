"""
LangChain Tool 定义 - 封装外部API调用为可复用的 @tool 函数

设计原则:
1. 每个外部API调用封装为一个独立的 @tool 装饰函数
2. Tool 具有清晰的 docstring（LLM通过docstring理解何时调用）
3. 支持被 LangChain Agent 自动调用
4. 也可以在 LCEL Chain 中作为 Runnable 使用

可用的工具:
- search_laws: 检索法律法规 (得理开放平台 API)
- search_cases: 检索司法案例 (得理开放平台 API)
- get_template_info: 查询文书模板信息 (本地数据库)
"""

import json
from typing import Dict, List, Any, Optional
import httpx

from langchain_core.tools import tool


# ==================== 配置常量 ====================
# 从 config.py Settings 读取，支持环境变量覆盖

from ..config import settings

LAW_API_BASE = getattr(settings, 'LAW_API_BASE_URL', "https://openapi.delilegal.com")
LAW_API_APPID = getattr(settings, 'LAW_API_APPID', "")
LAW_API_SECRET = getattr(settings, 'LAW_API_SECRET', "")


# ==================== 知识检索 Tools ====================

@tool
async def search_laws(keywords: str, page_size: int = 5) -> List[Dict[str, Any]]:
    """
    检索法律法规。
    
    Args:
        keywords: 法律检索关键词，可以是单个词或多个词用空格分隔。
                  推荐使用法律专业术语，如"劳动合同法 第82条"、"诉讼时效"、"违约责任"等。
        page_size: 返回结果数量上限，默认5条
    
    Returns:
        匹配的法规列表，每项包含:
        - lawId: 法规ID
        - lawName: 法律名称
        - lawType: 法规类型
        - effectiveStatus: 效力状态(现行有效/已废止/部分失效)
        - lawText: 法条具体内容
        - publishDate: 发布日期
    
    示例用法:
        - search_laws("劳动合同法 未签合同 双倍工资")
        - search_laws("民法典 诉讼时效")
    
    注意事项:
        - 关键词越精确，匹配结果越相关
        - 如果没有找到结果，尝试使用更通用的关键词
    """
    keyword_list = [k.strip() for k in keywords.split() if k.strip()]
    
    if not keyword_list:
        return [{"error": "请提供有效的检索关键词"}]
    
    request_data = {
        "pageNo": 1,
        "pageSize": min(page_size, 10),
        "sortField": "correlation",
        "sortOrder": "desc",
        "condition": {
            "keywords": keyword_list,
            "fieldName": "semantic"
        }
    }
    
    headers = {
        "Content-Type": "application/json",
        "appid": LAW_API_APPID,
        "secret": LAW_API_SECRET,
    }
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{LAW_API_BASE}/api/qa/v3/search/queryListLaw",
                json=request_data,
                headers=headers,
            )
            response.raise_for_status()
            result = response.json()
            
            if result.get("success"):
                laws = result.get("body", {}).get("data", [])
                
                # 标准化输出格式
                return [
                    {
                        "id": law.get("lawId", ""),
                        "title": law.get("lawName", "未知法规"),
                        "law_type": law.get("lawType", ""),
                        "effective_status": law.get("effectiveStatus", ""),
                        "content": law.get("lawText", ""),
                        "publish_date": law.get("publishDate", ""),
                    }
                    for law in laws[:page_size]
                ]
            else:
                return [{"error": f"API返回失败: {result.get('message', '未知错误')}"}]
                
    except httpx.TimeoutException:
        return [{"error": "法规检索超时(30s)，请稍后重试"}]
    except Exception as e:
        return [{"error": f"法规检索异常: {str(e)}"}]


@tool
async def search_cases(keywords: str, page_size: int = 5) -> List[Dict[str, Any]]:
    """
    检索司法案例/裁判文书。
    
    Args:
        keywords: 案例检索关键词。推荐格式：
                  - "纠纷类型 + 关键事实"，如"劳动纠纷 未签合同"
                  - "案由 + 争议焦点"，如"借款合同 违约金过高"
                  - 单一主题词也可，如"离婚纠纷"、"工伤认定"
        page_size: 返回结果数量上限，默认5条
    
    Returns:
        匹配的案例列表，每项包含:
        - caseId: 案例ID
        - caseName: 案件名称
        - court: 审理法院
        - caseNo: 案号
        - caseType: 案件类型(民事/刑事/行政)
        - judgmentDate: 判决日期
        - brief: 案件摘要
        - fullText: 全文(可选)
        
    示例用法:
        - search_cases("劳动争议 未签劳动合同 双倍工资")
        - search_cases("房屋租赁 合同解除 违约金")
        
    注意事项:
        - 案例检索与法规检索的关键词策略不同：
          * 案例：侧重于"纠纷类型+关键事实"
          * 法规：侧重于"法律名称+条款主题"
        - 如需查找特定法院的案例，可在关键词中加入法院名称
    """
    keyword_list = [k.strip() for k in keywords.split() if k.strip()]
    
    if not keyword_list:
        return [{"error": "请提供有效的检索关键词"}]
    
    request_data = {
        "pageNo": 1,
        "pageSize": min(page_size, 10),
        "sortField": "correlation",
        "sortOrder": "desc",
        "condition": {
            "keywordArr": keyword_list
        }
    }
    
    headers = {
        "Content-Type": "application/json",
        "appid": LAW_API_APPID,
        "secret": LAW_API_SECRET,
    }
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{LAW_API_BASE}/api/qa/v3/search/queryListCase",
                json=request_data,
                headers=headers,
            )
            response.raise_for_status()
            result = response.json()
            
            if result.get("success"):
                cases = result.get("body", {}).get("data", [])
                
                # 标准化输出格式
                return [
                    {
                        "id": case.get("id", ""),
                        "title": case.get("title", "未知案例"),
                        "court": case.get("court", ""),
                        "case_number": case.get("caseNumber", ""),
                        "case_type": case.get("caseType", ""),
                        "judgment_date": case.get("judgementDate", ""),
                        "summary": case.get("brief", ""),
                        "content": case.get("content", ""),
                    }
                    for case in cases[:page_size]
                ]
            else:
                return [{"error": f"API返回失败: {result.get('message', '未知错误')}"}]
                
    except httpx.TimeoutException:
        return [{"error": "案例检索超时(30s)，请稍后重试"}]
    except Exception as e:
        return [{"error": f"案例检索异常: {str(e)}"}]


# ==================== 模板查询 Tool ====================

@tool
async def get_template_info(document_type: str) -> Dict[str, Any]:
    """
    查询文书模板信息和参数定义。
    
    Args:
        document_type: 文书类型名称或ID。支持以下输入方式：
                     - 精确名称: "民事起诉状"、"答辩状"、"申请书"
                     - 模糊匹配: "起诉状"、"劳动仲裁申请书"
                     - 数字ID: "123"(如果知道模板ID)
    
    Returns:
        模板信息字典，包含:
        - id: 模板ID
        - name: 模板完整名称
        - description: 模板描述
        - category: 所属分类
        - params: 参数定义字典 {参数名: {label, required, type, description}}
        
    错误情况:
        - 找不到匹配模板时返回 {"error": "未找到匹配的模板"}
        - 数据库不可用时返回 {"error": "数据库连接异常"}
        
    使用示例:
        - get_template_info("起诉状") → 返回起诉状模板及所需参数(原告、被告、诉求等)
        - get_template_info("答辩状") → 返回答辩状模板
        - get_template_info("劳动合同") → 返回劳动合同相关模板
    """
    # 延迟导入避免循环依赖
    from ..workflows import TemplateManager
    
    template_mgr = TemplateManager(db=None)
    
    try:
        template = await template_mgr.get_template(document_type)
        
        if not template:
            # 尝试模糊搜索
            templates = await template_mgr.get_all_templates()
            matches = [
                t for t in templates 
                if document_type in t.get("name", "") or document_type.lower() in str(t).lower()
            ]
            
            if matches:
                template = matches[0]
            else:
                return {"error": f'未找到匹配"{document_type}"的模板'}
        
        params_def = await template_mgr.get_template_params(template["name"])
        
        return {
            "id": template.get("id"),
            "name": template.get("name"),
            "description": template.get("description", ""),
            "category": template.get("category", "其他"),
            "params": params_def,
        }
        
    except Exception as e:
        return {"error": f"模板查询异常: {str(e)}"}


# ==================== 组合工具: 并行知识检索 ====================

async def parallel_knowledge_search(keywords: str) -> Dict[str, List[Dict[str, Any]]]:
    """
    并行执行法规和案例检索
    
    这是一个组合工具（非@tool），用于 consultation_chain 内部，
    同时调用 search_laws 和 search_cases 以减少延迟。
    
    Args:
        keywords: 检索关键词
        
    Returns:
        {
            "laws": [...],   // 法规列表
            "cases": [...]   // 案例列表
        }
    """
    import asyncio
    
    laws_task = search_laws.ainvoke(keywords)
    cases_task = search_cases.ainvoke(keywords)
    
    laws, cases = await asyncio.gather(laws_task, cases_task, return_exceptions=True)
    
    result = {}
    
    if isinstance(laws, list):
        result["laws"] = laws
    else:
        result["laws"] = []
        print(f"[parallel_knowledge_search] 法规检索失败: {laws}")
    
    if isinstance(cases, list):
        result["cases"] = cases
    else:
        result["cases"] = []
        print(f"[parallel_knowledge_search] 案例检索失败: {cases}")
    
    return result


# ==================== 工具注册表 ====================

# 所有可用工具的列表（可用于 Agent 初始化）
ALL_TOOLS = [
    search_laws,
    search_cases,
    get_template_info,
]

# 按功能分类的工具字典
TOOL_REGISTRY = {
    "knowledge": [search_laws, search_cases],
    "template": [get_template_info],
    "all": ALL_TOOLS,
}

# 兼容性别名（供其他模块使用 _tool 后缀引用）
search_laws_tool = search_laws
search_cases_tool = search_cases
get_template_info_tool = get_template_info


# ==================== 分页检索（供工作流批量使用） ====================


async def search_cases_paged(
    keywords: str, page_no: int = 1, page_size: int = 10, max_pages: int = 5
) -> List[Dict[str, Any]]:
    """
    分页案例检索 — 用于案件分析报告等需要大量候选案例的场景。

    逐页调用 API 并聚合结果，直到获取足够数据或达到最大页数限制。
    """
    keyword_list = [k.strip() for k in keywords.split() if k.strip()]
    if not keyword_list:
        return []

    all_cases: List[Dict[str, Any]] = []
    target_count = page_size * min(max_pages, 5)

    for page in range(1, max_pages + 1):
        if len(all_cases) >= target_count:
            break

        request_data = {
            "pageNo": page,
            "pageSize": page_size,
            "sortField": "correlation",
            "sortOrder": "desc",
            "condition": {"keywordArr": [keywords.strip()]},
        }
        headers = {
            "Content-Type": "application/json",
            "appid": LAW_API_APPID,
            "secret": LAW_API_SECRET,
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{LAW_API_BASE}/api/qa/v3/search/queryListCase",
                    json=request_data,
                    headers=headers,
                )
                response.raise_for_status()
                result = response.json()

                if result.get("success"):
                    cases = result.get("body", {}).get("data", [])
                    # 调试：打印第一条案例的字段名
                    if cases and page == 1:
                        print(f"[search_cases_paged] API返回案例字段: {list(cases[0].keys())}")
                    # 调试：打印每页检索到的案例标题
                    for idx, c in enumerate(cases):
                        print(f"[search_cases_paged] 页{page}案例{idx+1}: title='{c.get('title','')[:60]}...'")
                    all_cases.extend(
                        {
                            # API 实际返回字段名（根据 Law.openapi.json 示例）
                            "id": c.get("id", ""),
                            "title": c.get("title", ""),  # API 直接返回 title，不是 caseName
                            "court": c.get("court", ""),
                            "case_number": c.get("caseNumber", ""),  # 不是 caseNo
                            "case_type": c.get("caseType", ""),
                            "judgment_date": c.get("judgementDate", ""),  # 注意是双 t，不是 judgmentDate
                            "summary": c.get("brief", ""),  # brief 可能为空
                            "content": c.get("content", ""),  # API 直接返回 content，不是 caseFullText
                        }
                        for c in cases
                    )
                    print(f"[search_cases_paged] 第{page}页获取到 {len(cases)} 条案例")
                    # 当前页不足 page_size 条说明已到末尾
                    if len(cases) < page_size:
                        break
                else:
                    # 打印 API 返回的完整信息用于调试
                    print(f"[search_cases_paged] API 返回失败: {result}")
                    break
        except Exception as e:
            print(f"[search_cases_paged] 第{page}页检索失败: {e}")
            break

    return all_cases[:target_count]


async def search_laws_paged(
    keywords: str, page_no: int = 1, page_size: int = 10, max_pages: int = 3
) -> List[Dict[str, Any]]:
    """分页法规检索 — 与 search_cases_paged 对称"""
    keyword_list = [k.strip() for k in keywords.split() if k.strip()]
    if not keyword_list:
        return []

    all_laws: List[Dict[str, Any]] = []

    for page in range(1, max_pages + 1):
        request_data = {
            "pageNo": page,
            "pageSize": min(page_size, 10),
            "sortField": "correlation",
            "sortOrder": "desc",
            "condition": {"keywords": keyword_list, "fieldName": "semantic"},
        }
        headers = {
            "Content-Type": "application/json",
            "appid": LAW_API_APPID,
            "secret": LAW_API_SECRET,
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{LAW_API_BASE}/api/qa/v3/search/queryListLaw",
                    json=request_data,
                    headers=headers,
                )
                response.raise_for_status()
                result = response.json()

                if result.get("success"):
                    laws = result.get("body", {}).get("data", [])
                    all_laws.extend(
                        {
                            "id": l.get("lawId", ""),
                            "title": l.get("lawName", ""),
                            "law_type": l.get("lawType", ""),
                            "effective_status": l.get("effectiveStatus", ""),
                            "content": l.get("lawText", ""),
                            "publish_date": l.get("publishDate", ""),
                        }
                        for l in laws
                    )
                    if len(laws) < page_size:
                        break
                else:
                    break
        except Exception as e:
            print(f"[search_laws_paged] 第{page}页检索失败: {e}")
            break

    return all_laws

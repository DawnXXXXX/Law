"""
合同风险审查子工作流 (ContractReviewGraph)

四节点状态机：
    文件解析条款拆分(非LLM) → 规则引擎预筛(非LLM) → LLM风险确认(LLM) → 报告生成(非LLM)

用户上传合同文件 → 输出结构化 Markdown 风险审查报告
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Sequence, Optional

try:
    from langgraph.graph import StateGraph, END
    LANGGRAPH_AVAILABLE = True
except ImportError:
    StateGraph = None
    END = None
    LANGGRAPH_AVAILABLE = False

from ...config import settings


# =====================================================================
# State 定义
# =====================================================================

class ContractReviewState(Dict):
    """合同审查工作流状态"""
    file_path: str = ""
    clauses: List[Dict[str, Any]] = []          # 解析后的条款列表
    rule_hits: List[Dict[str, Any]] = []         # 规则引擎命中结果
    llm_confirmed_risks: List[Dict[str, Any]] = []  # LLM确认后的风险
    report_markdown: str = ""                    # 最终审查报告
    report_data: Dict[str, Any] = {}             # 可视化报告数据（sections 结构）
    _llm: Any = None


# =====================================================================
# 条款拆分器
# =====================================================================


def parse_contract_clauses(file_path: str) -> List[Dict[str, Any]]:
    """
    合同文件解析 + 条款拆分

    支持: .docx / .txt
    返回: [{"index": 0, "title": "第一条 xxx", "content": "..."}, ...]
    """
    path = Path(file_path)
    suffix = path.suffix.lower()

    if suffix == ".docx":
        return _parse_docx(path)
    elif suffix == ".txt":
        return _parse_txt(path)
    elif suffix == ".pdf":
        return _parse_pdf_simple(path)
    else:
        raise ValueError(f"不支持的文件格式: {suffix}")


def _parse_docx(path: Path) -> List[Dict[str, Any]]:
    """解析 DOCX 文件并按段落/条款示意拆分
    
    使用 docx_processor.read_docx_paragraphs，与文书修改保持一致
    """
    from ...utils.docx_processor import read_docx_paragraphs

    # 使用统一的文档读取工具
    doc_data = read_docx_paragraphs(str(path))
    paragraphs = doc_data.get("paragraphs", [])

    clauses: List[Dict[str, Any]] = []
    current_content: List[str] = []
    current_title = "前言"

    for para in paragraphs:
        text = para.get("text", "").strip()
        if not text:
            continue

        # 检测条款标题模式: "第X条" / "第X章" / 数字编号
        is_title = any([
            text.startswith("第") and ("条" in text[:6] or "章" in text[:6]),
            text.startswith(("一、", "二、", "三、", "四、", "五、",
                           "六、", "七、", "八、", "九、", "十、")),
            text.startswith(("1.", "2.", "3.", "4.", "5.",
                           "6.", "7.", "8.", "9.")),
        ])

        if is_title and current_content:
            clauses.append({
                "index": len(clauses),
                "title": current_title,
                "content": "\n".join(current_content),
            })
            current_content = []
            current_title = text

        current_content.append(text)

    # 最后一个条款
    if current_content:
        clauses.append({
            "index": len(clauses),
            "title": current_title,
            "content": "\n".join(current_content),
        })

    return clauses if clauses else [
        {"index": 0, "title": "全文", "content": "\n".join(p.get("text", "").strip() for p in paragraphs if p.get("text", "").strip())}
    ]


def _parse_txt(path: Path) -> List[Dict[str, Any]]:
    """解析 TXT 文件"""
    text = path.read_text(encoding="utf-8")
    lines = [l.strip() for l in text.split("\n") if l.strip()]

    clauses: List[Dict[str, Any]] = []
    current_lines: List[str] = []
    current_title = "合同正文"

    for line in lines:
        is_title = any([
            line.startswith("第") and ("条" in line[:6] or "章" in line[:6]),
            line.startswith(("一、", "二、", "三、")) or line[0].isdigit() and "." in line[:3],
        ])
        if is_title and current_lines:
            clauses.append({"index": len(clauses), "title": current_title, "content": "\n".join(current_lines)})
            current_lines = []
            current_title = line
        current_lines.append(line)

    if current_lines:
        clauses.append({"index": len(clauses), "title": current_title, "content": "\n".join(current_lines)})
    return clauses or [{"index": 0, "title": "全文", "content": text}]


def _parse_pdf_simple(path: Path) -> List[Dict[str, Any]]:
    """简单 PDF 文本提取"""
    try:
        import PyPDF2
        reader = PyPDF2.PdfReader(str(path))
        text = "".join(p.extract_text() or "" for p in reader.pages)
        return [{"index": 0, "title": "全文", "content": text}]
    except Exception:
        return [{"index": 0, "title": "全文", "content": f"无法解析PDF: {path.name}"}]


# =====================================================================
# 节点函数
# =====================================================================


async def node_parse_file(state: ContractReviewState) -> Dict[str, Any]:
    """节点1: 文件解析与条款拆分"""
    file_path = state.get("file_path", "")
    if not file_path:
        raise ValueError("缺少 file_path")

    clauses = parse_contract_clauses(file_path)
    print(f"[ContractReview] 解析完成: {len(clauses)}个条款")
    return {**state, "clauses": clauses}


async def node_rule_scan(state: ContractReviewState) -> Dict[str, Any]:
    """节点2: 规则引擎预筛"""
    from ..services.contract_rule_engine import ContractRuleEngine

    engine = ContractRuleEngine()
    scan_result = engine.scan_clauses(state.get("clauses", []), text_field="content")

    hits = [
        {
            "rule_id": r.rule_id,
            "risk_type": r.risk_type,
            "risk_level": r.risk_level,
            "clause_index": r.clause_index,
            "matched_text": r.matched_text,
            "description": r.description,
            "suggestion": r.suggestion,
            "need_llm_confirm": r.need_llm_confirm,
            "llm_prompt_extra": r.llm_prompt_extra,
        }
        for r in scan_result.suspected_risks
    ]

    print(f"[ContractReview] 规则扫描完成: {len(hits)}项疑似风险 (高{scan_result.high_risk_count}/中{scan_result.medium_risk_count}/低{scan_result.low_risk_count})")
    return {**state, "rule_hits": hits}


async def node_llm_confirm(state: ContractReviewState) -> Dict[str, Any]:
    """节点3: LLM 风险确认 - 仅对 need_llm_confirm=true 的项调用 LLM"""
    from ..prompts import CONTRACT_RISK_CONFIRM_PROMPT
    from ..parsers import risk_confirm_parser as parser

    llm = state.get("_llm")
    hits = state.get("rule_hits", [])
    clauses = state.get("clauses", [])

    confirmed: List[Dict[str, Any]] = []
    chain = CONTRACT_RISK_CONFIRM_PROMPT | llm | parser

    for hit in hits:
        if not hit.get("need_llm_confirm"):
            # 无需LLM确认的项直接采用规则引擎结论
            confirmed.append({
                **hit,
                "is_confirmed": True,
                "final_risk_level": hit["risk_level"],
                "risk_description": hit["description"],
                "suggestion": hit["suggestion"],
            })
            continue

        clause_idx = hit.get("clause_index", 0)
        clause_text = (
            clauses[clause_idx].get("content", "")
            if clause_idx < len(clauses)
            else hit.get("matched_text", "")
        )

        try:
            result = await chain.ainvoke({
                "clause_text": clause_text,
                "rule_id": hit.get("rule_id", ""),
                "risk_type": hit.get("risk_type", ""),
                "risk_level": hit.get("risk_level", ""),
                "matched_text": hit.get("matched_text", ""),
                "llm_prompt_extra": hit.get("llm_prompt_extra", ""),
                "format_instructions": parser.get_format_instructions(),
            })
            confirmed.append({
                **hit,
                "is_confirmed": result.is_confirmed,
                "final_risk_level": result.final_risk_level,
                "risk_description": result.risk_description,
                "legal_basis": result.legal_basis,
                "suggestion": result.suggestion,
            })
        except Exception as e:
            print(f"[ContractReview] LLM确认失败({hit.get('rule_id')}): {e}")
            confirmed.append({**hit, "is_confirmed": True, "final_risk_level": hit.get("risk_level", "medium")})

    # 按 risk_level 排序: high > medium > low > none
    level_order = {"high": 0, "medium": 1, "low": 2, "none": 3}
    confirmed.sort(key=lambda x: level_order.get(x.get("final_risk_level", ""), 4))

    print(f"[ContractReview] LLM确认完成: {len(confirmed)}项风险")
    return {**state, "llm_confirmed_risks": confirmed}


def _build_risk_item_html(r: Dict[str, Any]) -> str:
    """构建单个风险项的 HTML"""
    risk_level = r.get('final_risk_level', 'low')
    risk_type = r.get('risk_type', '')
    clause_idx = r.get('clause_index', 0)
    risk_desc = r.get('risk_description', '-')
    suggestion = r.get('suggestion', '-')
    legal_basis = r.get('legal_basis', '')
    
    legal_html = f"<p><strong>法律依据:</strong> {legal_basis}</p>" if legal_basis else ''
    
    return (
        f"<div class='risk-item risk-{risk_level}'>"
        f"<div class='risk-header'>"
        f"<span class='risk-badge'>{risk_level.upper()}</span>"
        f"<span class='risk-type'>{risk_type}</span>"
        f"</div>"
        f"<div class='risk-body'>"
        f"<p><strong>所在条款:</strong> 第{clause_idx + 1}条</p>"
        f"<p><strong>风险描述:</strong> {risk_desc}</p>"
        f"<p><strong>修改建议:</strong> {suggestion}</p>"
        f"{legal_html}"
        f"</div>"
        f"</div>"
    )


async def node_report_gen(state: ContractReviewState) -> Dict[str, Any]:
    """节点4: 报告生成 - Markdown + 可视化风险审查报告"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    risks = state.get("llm_confirmed_risks", [])
    clauses = state.get("clauses", [])

    high = [r for r in risks if r.get("final_risk_level") == "high"]
    med = [r for r in risks if r.get("final_risk_level") == "medium"]
    low = [r for r in risks if r.get("final_risk_level") == "low"]

    def _format_risk(r: Dict) -> str:
        icon = {"high": "🔴", "medium": "🟡", "low": "🟢", "none": "⚪"}
        clause_idx = r.get("clause_index", 0)
        clause_title = clauses[clause_idx].get("title", "") if clause_idx < len(clauses) else "未知"
        return f"""### {icon.get(r.get('final_risk_level'), '⚪')} {r.get('risk_type', '')} ({r.get('rule_id', '')})
- **所在条款**: 第{clause_idx + 1}条「{clause_title}」
- **风险描述**: {r.get('risk_description', '-')}
- **修改建议**: {r.get('suggestion', '-')}
{' - **法律依据**: ' + r.get('legal_basis', '') if r.get('legal_basis') else ''}"""

    risk_sections = "\n\n".join(_format_risk(r) for r in risks if r.get("is_confirmed"))

    report = f"""# 合同风险审查报告

> 生成时间: {now}
> 系统: 法智通 AI 法律助手

---

## 一、审查概况

| 指标 | 数值 |
|------|------|
| 总条款数 | {len(clauses)} |
| 发现风险 | {len(risks)} 项 |
| 🔴 高风险 | {len(high)} 项 |
| 🟡 中风险 | {len(med)} 项 |
| 🟢 低风险 | {len(low)} 项 |

---

## 二、风险详情

{risk_sections if risk_sections else "✅ 未发现明显风险"}

---

## 三、免责声明

本报告由 AI 自动生成，仅供参考，不构成正式的法律意见。具体问题请咨询专业律师。
"""

    # ========== 计算风险评分 ==========
    risk_score = min(len(high) * 30 + len(med) * 15 + len(low) * 5, 100)
    if risk_score <= 40:
        risk_level_text = "低风险"
        risk_level_color = "#22c55e"
    elif risk_score <= 70:
        risk_level_text = "中风险"
        risk_level_color = "#f59e0b"
    else:
        risk_level_text = "高风险"
        risk_level_color = "#ef4444"

    # ========== 打印仪表盘数据日志 ==========
    logger = logging.getLogger("contract_review")
    logger.info("=" * 50)
    logger.info("[合同风险审查 - 仪表盘数据]")
    logger.info(f"  文件名: {state.get('file_path', '').split('/')[-1] or '合同文件'}")
    logger.info(f"  总条款数: {len(clauses)}")
    logger.info(f"  发现风险: {len(risks)} 项")
    logger.info(f"  高风险: {len(high)} 项 (权重30分/项)")
    logger.info(f"  中风险: {len(med)} 项 (权重15分/项)")
    logger.info(f"  低风险: {len(low)} 项 (权重5分/项)")
    logger.info(f"  风险评分: {risk_score} 分")
    logger.info(f"  风险等级: {risk_level_text}")
    logger.info(f"  评分公式: min({len(high)}*30 + {len(med)}*15 + {len(low)}*5, 100) = {risk_score}")
    logger.info("=" * 50)

    # ========== 生成可视化报告数据 ==========
    # 统计引用的法律依据条数
    legal_basis_count = len([r for r in risks if r.get("legal_basis")])

    report_data = {
        "title": "合同风险审查报告",
        "report_type": "contract_review",
        "generated_at": now,
        "file_name": Path(state.get("file_path", "")).name or "合同文件",
        "summary": {
            "total_clauses": len(clauses),
            "total_risks": len(risks),
            "high_risk": len(high),
            "medium_risk": len(med),
            "low_risk": len(low),
            "risk_score": risk_score,
            "risk_level": risk_level_text,
            "legal_basis_count": legal_basis_count,
        },
        "sections": [
            # 风险概览（仪表盘 + 柱状图左右并排）
            {
                "type": "gauge",
                "title": "合同风险概览",
                "chart_option": {
                    "tooltip": {"trigger": "axis", "axisPointer": {"type": "shadow"}},
                    "grid": [{"left": "55%", "right": "4%", "top": "12%", "bottom": "8%", "containLabel": True}],
                    "xAxis": {
                        "type": "category",
                        "data": ["高风险", "中风险", "低风险", "无风险"],
                        "axisLabel": {"fontSize": 13},
                        "gridIndex": 0,
                    },
                    "yAxis": {
                        "type": "value",
                        "name": "条款数",
                        "minInterval": 1,
                        "gridIndex": 0,
                    },
                    "series": [
                        {
                            "type": "gauge",
                            "center": ["22%", "55%"],
                            "radius": "90%",
                            "startAngle": 200,
                            "endAngle": -20,
                            "min": 0,
                            "max": 100,
                            "progress": {
                                "show": True,
                                "width": 16,
                                "itemStyle": {"color": risk_level_color}
                            },
                            "axisLine": {
                                "lineStyle": {
                                    "width": 16,
                                    "color": [[0.4, "#22c55e"], [0.7, "#f59e0b"], [1, "#ef4444"]]
                                }
                            },
                            "axisTick": {"show": False},
                            "splitLine": {"show": False},
                            "axisLabel": {"show": False},
                            "pointer": {"show": False},
                            "anchor": {"show": True, "showAbove": True, "size": 14, "itemStyle": {"borderWidth": 3, "borderColor": risk_level_color}},
                            "title": {"show": True, "offsetCenter": [0, "70%"], "fontSize": 13, "color": "#666"},
                            "detail": {
                                "valueAnimation": True,
                                "fontSize": 32,
                                "fontWeight": "bold",
                                "offsetCenter": [0, "40%"],
                                "formatter": "{value}",
                                "color": risk_level_color
                            },
                            "data": [{"value": risk_score, "name": f"{risk_level_text}"}]
                        },
                        {
                            "type": "bar",
                            "barWidth": "50%",
                            "xAxisIndex": 0,
                            "yAxisIndex": 0,
                            "data": [
                                {"value": len(high), "itemStyle": {"color": "#ef4444", "borderRadius": [4, 4, 0, 0]}},
                                {"value": len(med), "itemStyle": {"color": "#f59e0b", "borderRadius": [4, 4, 0, 0]}},
                                {"value": len(low), "itemStyle": {"color": "#22c55e", "borderRadius": [4, 4, 0, 0]}},
                                {"value": max(0, len(clauses) - len(risks)), "itemStyle": {"color": "#94a3b8", "borderRadius": [4, 4, 0, 0]}},
                            ],
                            "label": {"show": True, "position": "top", "fontSize": 14, "fontWeight": "bold"}
                        }
                    ]
                }
            },
            # 风险详情列表
            {
                "type": "text",
                "title": "风险详情",
                "content": "<div class='risk-list'>" + "".join(
                    _build_risk_item_html(r)
                    for r in risks if r.get("is_confirmed")
                ) + ("<p class='no-risk'>✅ 未发现明显风险</p>" if not risks else "") + "</div>"
            },
            # 合同条款概览
            {
                "type": "text",
                "title": "合同条款概览",
                "content": "<div class='clause-overview'>" + "".join(
                    f"<div class='clause-item'>"
                    f"<h4>第{idx + 1}条: {c.get('title', '条款')[:30]}...</h4>"
                    f"<p>{c.get('content', '')[:100]}...</p>"
                    f"</div>"
                    for idx, c in enumerate(clauses[:5])
                ) + (f"<p class='more'>...还有 {len(clauses) - 5} 条条款</p>" if len(clauses) > 5 else "") + "</div>"
            } if clauses else {"type": "text", "title": "合同条款概览", "content": "<p>无条款数据</p>"},
        ]
    }

    # 保存报告和可视化数据
    reports_dir = Path(settings.UPLOAD_DIR) / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 保存 Markdown 报告
    md_path = reports_dir / f"contract_review_{timestamp}.md"
    md_path.write_text(report, encoding="utf-8")
    
    # 保存可视化报告 JSON
    json_path = reports_dir / f"contract_review_{timestamp}.json"
    json_path.write_text(json.dumps(report_data, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[ContractReview] 报告已保存: {md_path}, 可视化数据已保存: {json_path}")
    return {**state, "report_markdown": report, "report_data": report_data}


# =====================================================================
# 图构建
# =====================================================================


def build_contract_review_graph(llm: Optional[Any] = None) -> Any:
    """构建合同审查工作流图"""
    if not LANGGRAPH_AVAILABLE:
        raise ImportError("LangGraph 未安装")

    graph = StateGraph(ContractReviewState)

    graph.add_node("parse_file", node_parse_file)
    graph.add_node("rule_scan", node_rule_scan)
    graph.add_node("llm_confirm", node_llm_confirm)
    graph.add_node("report_gen", node_report_gen)

    graph.set_entry_point("parse_file")
    graph.add_edge("parse_file", "rule_scan")
    graph.add_edge("rule_scan", "llm_confirm")
    graph.add_edge("llm_confirm", "report_gen")
    graph.add_edge("report_gen", END)

    return graph.compile()




async def run_contract_review(
    file_path: str = "",
    *,
    file_content: str = "",
    file_name: str = "合同.txt",
    llm: Optional[Any] = None,
) -> Dict[str, Any]:
    """一次性执行完整合同审查流程

    Args:
        file_path: 文件路径（优先使用）
        file_content: 文件内容（当没有文件路径时使用）
        file_name: 文件名（用于确定文件类型）
        llm: LLM 实例
    """
    import tempfile
    import os

    temp_path = ""  # 初始化临时文件路径

    # 如果没有文件路径但有内容，创建临时文件
    if not file_path and file_content:
        # 根据文件名后缀确定文件类型
        suffix = Path(file_name).suffix.lower() if file_name else ".txt"
        if not suffix or suffix not in [".docx", ".txt", ".pdf"]:
            suffix = ".txt"

        # 创建临时文件
        fd, temp_path = tempfile.mkstemp(suffix=suffix, prefix="contract_review_")
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(file_content)
            file_path = temp_path
        except Exception as e:
            os.close(fd)
            raise ValueError(f"无法创建临时文件: {e}")

    if not file_path:
        raise ValueError("缺少 file_path 或 file_content")

    graph = build_contract_review_graph(llm)

    state = await graph.ainvoke({
        "file_path": file_path,
        "_llm": llm,
    })

    # 清理临时文件
    if temp_path and os.path.exists(temp_path):
        try:
            os.unlink(temp_path)
        except Exception:
            pass

    return {
        "report_markdown": state.get("report_markdown", ""),
        "report_data": state.get("report_data", {}),
        "clauses": state.get("clauses", []),
        "risks": state.get("llm_confirmed_risks", []),
    }

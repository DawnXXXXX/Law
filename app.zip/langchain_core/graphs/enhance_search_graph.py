"""
增强搜索子工作流 (EnhanceSearchGraph)

五节点状态机：检索规划(LLM) → 检索执行(非LLM) → 语义重排序(可选,非LLM) → 答案生成(LLM) → 报表生成(非LLM)

状态转换图:
    user_input
        │
        ▼
    ┌─────────────────────┐
    │ 节点1: 检索规划     │  (LLM: intent+query+filter)
    └────────┬────────────┘
             │
             ▼
    ┌─────────────────────┐
    │ 节点2: 检索执行     │  (非LLM: API调用)
    └────────┬────────────┘
             │
             ▼
    ┌─────────────────────┐
    │ 节点3: 语义重排序   │  (可选: SimilarCaseRetrieval)
    └────────┬────────────┘
             │
             ▼
    ┌─────────────────────┐
    │ 节点4: 答案生成     │  (LLM: 自然语言回答)
    └────────┬────────────┘
             │
             ▼
    ┌─────────────────────┐
    │ 节点5: 报表生成     │  (非LLM: 结构化报表组装)
    └─────────────────────┘
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from typing import Annotated, Any, Dict, List, Optional

try:
    from langgraph.graph import StateGraph, END
    LANGGRAPH_AVAILABLE = True
except ImportError:
    StateGraph = None
    END = None
    LANGGRAPH_AVAILABLE = False


# =====================================================================
# State 定义
# =====================================================================

class EnhanceSearchState(Dict):
    """增强搜索工作流状态"""
    user_input: str = ""
    plan: Dict[str, Any] = {}          # 检索规划结果 {intent, article, query, filter}
    raw_results: Dict[str, List] = {}   # 原始检索结果 {"laws": [...], "cases": [...]}
    reranked_cases: List[Dict] = []     # 重排序后的案例
    final_answer: str = ""              # 最终自然语言回答
    report_data: Dict[str, Any] = {}    # 可视化报表数据（sections 结构）
    _llm: Any = None


# =====================================================================
# 判决结果提取工具
# =====================================================================

_VERDICT_PATTERNS = [
    (r"宣告无罪", "无罪"), (r"无罪", "无罪"),
    (r"驳回.*(?:诉讼|起诉|上诉|请求)", "不支持"), (r"不予支持", "不支持"),
    (r"驳回上诉，维持原判", "不支持"),
    (r"判处(?:拘役|有期徒刑|管制|死刑|罚金)", "支持"), (r"以.*罪.*判处", "支持"),
    (r"支持.*(?:诉讼|全部)", "支持"), (r"准予.*(?:离婚|诉讼|赔偿)", "支持"),
    (r"准许.*(?:离婚|原告|请求)", "支持"), (r"判令.*(?:赔偿|停止|返还)", "支持"),
    (r"判决.*(?:赔偿|支持)", "支持"),
    (r"部分支持", "部分支持"), (r"部分驳回", "部分支持"), (r"各承担", "部分支持"),
    (r"调解", "调解"), (r"达成协议", "调解"),
    (r"撤诉", "撤诉"), (r"撤回起诉", "撤诉"), (r"按撤诉处理", "撤诉"),
]


def _extract_verdict(text: str) -> str:
    """从判决文本中快速提取判决结果类型"""
    for pattern, label in _VERDICT_PATTERNS:
        if re.search(pattern, text):
            return label
    return "其他"


def _escape_html(text: str) -> str:
    """转义 HTML 特殊字符并处理换行"""
    if not text:
        return ""
    return (str(text)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("\r\n", "<br>")
            .replace("\n", "<br>")
            .replace("\r", "<br>"))


# =====================================================================
# 节点函数
# =====================================================================


async def node_search_plan(state: EnhanceSearchState) -> Dict[str, Any]:
    """节点1: LLM 检索规划 - 意图识别 + 关键词提取 + 过滤条件构造"""
    from ..prompts import SEARCH_PLAN_PROMPT
    from ..parsers import search_plan_parser as parser

    llm = state.get("_llm")
    chain = SEARCH_PLAN_PROMPT | llm | parser

    result = await chain.ainvoke({
        "user_input": state.get("user_input", ""),
        "format_instructions": parser.get_format_instructions(),
    })

    print(f"[EnhanceSearch] 规划完成: intent={result.intent}, query={result.query}")
    return {
        **state,
        "plan": {
            "intent": result.intent,
            "article": result.article,
            "query": result.query,
            "filter": dict(result.filter),
        },
    }


async def node_search_execute(state: EnhanceSearchState) -> Dict[str, Any]:
    """节点2: 检索执行 - 根据规划调用法规/案例API"""
    from ..tools import search_laws, search_cases

    plan = state.get("plan", {})
    query = plan.get("query", state.get("user_input", ""))
    intent = plan.get("intent", "concept_qa")

    laws_result: List[Dict] = []
    cases_result: List[Dict] = []

    import asyncio
    tasks = []
    if intent != "case_reference":
        tasks.append(search_laws.ainvoke(query))
    if intent != "law_query":
        tasks.append(search_cases.ainvoke(query))

    if tasks:
        results = await asyncio.gather(*tasks, return_exceptions=True)
        idx = 0
        if intent != "case_reference" and idx < len(results):
            laws_result = results[idx] if isinstance(results[idx], list) else []
            idx += 1
        if intent != "law_query" and idx < len(results):
            cases_result = results[idx] if isinstance(results[idx], list) else []

    # 过滤掉错误项
    laws_clean = [l for l in laws_result if not l.get("error")]
    cases_clean = [c for c in cases_result if not c.get("error")]

    print(f"[EnhanceSearch] 检索完成: 法规{len(laws_clean)}条, 案例{len(cases_clean)}条")
    return {**state, "raw_results": {"laws": laws_clean, "cases": cases_clean}}


async def node_semantic_rerank(state: EnhanceSearchState) -> Dict[str, Any]:
    """节点3: 语义重排序 - 对案例进行语义相似度排序（仅当有案例时）"""
    from ..services.similar_case_service import SimilarCaseRetrievalService

    raw = state.get("raw_results", {})
    cases = list(raw.get("cases", []))
    user_input = state.get("user_input", "")

    if not cases or not user_input:
        return state

    service = SimilarCaseRetrievalService()
    reranked = service.retrieve_similar_cases(user_input, cases, top_k=len(cases))

    print(f"[EnhanceSearch] 语义重排序完成，Top3相似度: {[round(c.get('similarity_score', 0), 3) for c in reranked[:3]]}")
    return {**state, "reranked_cases": reranked}


async def node_answer_generate(state: EnhanceSearchState) -> Dict[str, Any]:
    """节点4: 答案生成 - 基于检索结果生成自然语言回答"""
    from ..prompts import ENHANCE_ANSWER_PROMPT

    llm = state.get("_llm")

    raw = state.get("raw_results", {})
    reranked = state.get("reranked_cases", [])

    laws = raw.get("laws", [])
    # 优先使用重排后的案例，否则用原始顺序
    cases_to_use = reranked if reranked else raw.get("cases", [])

    # 格式化上下文（控制Token量）
    laws_text = "\n".join(
        f"- 《{l.get('title','')}》({l.get('law_type','')}): {l.get('content','')[:200]}"
        for l in laws[:5]
    )
    cases_text = "\n".join(
        f"- [{c.get('title','')}](相似度:{c.get('similarity_score','N/A')}) "
        f"{c.get('court','')} | {c.get('summary','')[:150]}"
        for c in cases_to_use[:5]
    )

    chain = ENHANCE_ANSWER_PROMPT | llm
    answer = await chain.ainvoke({
        "user_input": state.get("user_input", ""),
        "laws_context": laws_text or "未检索到相关法规",
        "cases_context": cases_text or "未检索到相关案例",
    })

    content = answer.content if hasattr(answer, 'content') else str(answer)
    print(f"[EnhanceSearch] 答案生成完成，长度={len(content)}字符")
    return {**state, "final_answer": content}


async def node_report_generate(state: EnhanceSearchState) -> Dict[str, Any]:
    """节点5: 结构化报表生成 - 将检索结果组装为可视化报表数据（非LLM）"""
    plan = state.get("plan", {})
    raw = state.get("raw_results", {})
    reranked = state.get("reranked_cases", [])
    final_answer = state.get("final_answer", "")

    laws = raw.get("laws", [])
    cases = reranked or raw.get("cases", [])

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    intent_text = {
        "case_reference": "案例检索",
        "law_query": "法规查询",
        "concept_qa": "综合检索",
    }.get(plan.get("intent", ""), "综合检索")

    sections = []

    # 1. 检索概览
    summary_html = (
        f"<div class='search-summary'>"
        f"<p><strong>检索类型:</strong> {intent_text}</p>"
        f"<p><strong>检索关键词:</strong> {_escape_html(plan.get('query', ''))}</p>"
        f"<p><strong>检索结果:</strong> 法规 {len(laws)} 条，案例 {len(cases)} 条</p>"
        f"</div>"
    )
    sections.append({"type": "text", "title": "检索概览", "content": summary_html})

    # 2. 案例判决分布图（饼图）+ 案例列表
    if cases:
        distribution: Dict[str, int] = {}
        for case in cases:
            text = (case.get("content") or case.get("summary") or "")
            verdict = _extract_verdict(text)
            distribution[verdict] = distribution.get(verdict, 0) + 1

        total_cases = sum(distribution.values())

        # 饼图配色
        color_map = {
            "支持": "#22c55e", "部分支持": "#f59e0b", "不支持": "#ef4444",
            "无罪": "#3b82f6", "调解": "#8b5cf6", "撤诉": "#94a3b8", "其他": "#cbd5e1",
        }

        pie_data = [
            {"value": v, "name": k, "itemStyle": {"color": color_map.get(k, "#cbd5e1")}}
            for k, v in sorted(distribution.items(), key=lambda x: x[1], reverse=True)
        ]

        sections.append({
            "type": "pie",
            "title": f"判决结果分布（共 {total_cases} 个案例）",
            "chart_option": {
                "tooltip": {"trigger": "item", "formatter": "{b}: {c}起 ({d}%)"},
                "legend": {"top": "5%", "left": "center", "textStyle": {"fontSize": 13}},
                "series": [{
                    "type": "pie",
                    "radius": ["35%", "65%"],
                    "center": ["50%", "55%"],
                    "avoidLabelOverlap": True,
                    "itemStyle": {"borderRadius": 6, "borderColor": "#fff", "borderWidth": 2},
                    "label": {"show": True, "fontSize": 12, "formatter": "{b}\n{c}起 ({d}%)"},
                    "emphasis": {"label": {"show": True, "fontSize": 14, "fontWeight": "bold"}},
                    "data": pie_data,
                }],
            },
        })

        # Top 案例 HTML
        case_items = []
        for i, c in enumerate(cases[:5]):
            title = _escape_html(c.get("title", "未知案例"))
            court = _escape_html(c.get("court", "N/A"))
            case_number = _escape_html(c.get("case_number", "N/A"))
            similarity = c.get("similarity_score", 0)
            sim_str = f"{similarity:.3f}" if isinstance(similarity, (int, float)) else "N/A"
            summary_text = _escape_html((c.get("summary") or "")[:200])
            case_items.append(
                f"<div class='case-item'>"
                f"<h4>案例{i+1}: {title}</h4>"
                f"<p><strong>案号:</strong> {case_number} | "
                f"<strong>法院:</strong> {court} | "
                f"<strong>相似度:</strong> {sim_str}</p>"
                f"<p>{summary_text}</p>"
                f"</div>"
            )
        sections.append({
            "type": "text",
            "title": "检索案例",
            "content": "<div class='case-list'>" + "".join(case_items) + "</div>",
        })

    # 3. 相关法规列表
    if laws:
        law_items = []
        for l in laws[:5]:
            law_title = _escape_html(l.get("title", "未知法规"))
            law_content = _escape_html((l.get("content") or "")[:300])
            law_type = _escape_html(l.get("law_type", ""))
            law_items.append(
                f"<div class='law-item'>"
                f"<h4>《{law_title}》{f'（{law_type}）' if law_type else ''}</h4>"
                f"<p>{law_content}</p>"
                f"</div>"
            )
        sections.append({
            "type": "text",
            "title": "相关法规",
            "content": "<div class='law-list'>" + "".join(law_items) + "</div>",
        })

    # 4. AI 分析摘要
    if final_answer:
        sections.append({
            "type": "text",
            "title": "AI 分析摘要",
            "content": "<div class='ai-summary'>" + _escape_html(final_answer) + "</div>",
        })

    report_data = {
        "title": f"{intent_text}报告",
        "report_type": "enhance_search",
        "generated_at": now,
        "plan": plan,
        "case_count": len(cases),
        "dispute_type": plan.get("query", ""),
        "summary": {
            "total_laws": len(laws),
            "total_cases": len(cases),
            "verdict_distribution": distribution if cases else {},
        },
        "sections": sections,
    }

    print(f"[EnhanceSearch] 结构化报表生成完成: {len(sections)} 个章节")
    return {**state, "report_data": report_data}


# =====================================================================
# 图构建
# =====================================================================


def build_enhance_search_graph(llm: Optional[Any] = None) -> Any:
    """
    构建增强搜索工作流图

    Args:
        llm: LLM 实例（用于检索规划和答案生成）

    Returns:
        编译后的 CompiledGraph
    """
    if not LANGGRAPH_AVAILABLE:
        raise ImportError("LangGraph 未安装")

    graph = StateGraph(EnhanceSearchState)

    graph.add_node("search_plan", node_search_plan)
    graph.add_node("search_execute", node_search_execute)
    graph.add_node("semantic_rerank", node_semantic_rerank)
    graph.add_node("answer_generate", node_answer_generate)
    graph.add_node("report_generate", node_report_generate)

    graph.set_entry_point("search_plan")
    graph.add_edge("search_plan", "search_execute")
    graph.add_edge("search_execute", "semantic_rerank")
    graph.add_edge("semantic_rerank", "answer_generate")
    graph.add_edge("answer_generate", "report_generate")
    graph.add_edge("report_generate", END)

    return graph.compile()


# =====================================================================
# 便捷入口
# =====================================================================


async def run_enhance_search(
    message: str,
    *,
    llm: Optional[Any] = None,
) -> Dict[str, Any]:
    """
    一次性执行完整增强搜索流程

    Returns:
        {"final_answer": str, "plan": dict, "raw_results": dict, ...}
    """
    graph = build_enhance_search_graph(llm)

    state = await graph.ainvoke({
        "user_input": message,
        "_llm": llm,
    })

    return {
        "final_answer": state.get("final_answer", ""),
        "plan": state.get("plan", {}),
        "raw_results": state.get("raw_results", {}),
        "reranked_cases": state.get("reranked_cases", []),
        "report_data": state.get("report_data", {}),
    }

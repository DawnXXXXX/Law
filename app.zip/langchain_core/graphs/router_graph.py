"""
顶层路由 StateGraph (LangGraph)

替代 MainWorkflow.execute() 的意图分发逻辑，
使用 LangGraph + RunnableBranch 实现声明式的路由分发。

这是整个系统的入口点，将用户消息路由到对应的工作流/链。

架构:
    user_input → IntentChain → intent_result
                              ↓
                    RunnableBranch (路由)
                        ├→ document_gen_graph  (文书生成)
                        ├→ document_mod_graph   (文书修改)
                        ├→ consultation_chain    (法律咨询)
                        ├→ search_laws tool     (法规检索)
                        ├→ search_cases tool     (案例检索)
                        ├→ contract_chain       (合同服务)
                        └→ chitchat_chain       (闲聊)

使用示例:
    >>> router = build_main_router_graph(llm, db)
    >>> result = await router.ainvoke({
    ...     "user_message": "帮我写起诉状",
    ...     "conversation_id": 123,
    ... }, config={"configurable": {"thread_id": "conv_001"}})
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional

try:
    from langgraph.graph import StateGraph, END
    from langgraph.checkpoint.memory import MemorySaver
    LANGGRAPH_AVAILABLE = True
except ImportError:
    StateGraph = None
    END = None
    MemorySaver = None
    LANGGRAPH_AVAILABLE = False


class RouterState(Dict):
    """
    路由器的统一状态
    
    兼容原有 WorkflowContext 的所有字段，
    同时增加 LangChain/LangGraph 需要的字段。
    
    设计为 Dict 子类（而非 TypedDict）以支持动态属性访问。
    """
    
    # 输入字段
    user_message: str = ""
    conversation_id: int = 0
    project_id: Optional[int] = None
    history: list = []              # 对话历史 [{"role":"...","content":"..."}]
    attached_files: list = []
    
    # 意图识别结果
    intent: str = "unknown"
    intent_confidence: float = 0.0
    intent_reasoning: str = ""
    
    # 业务上下文
    document_type: str = ""
    dispute_type: str = ""
    collected_params: dict = {}
    
    # 工作流状态（用于多轮对话的状态持久化）
    workflow_state: dict = {}      # 子工作流的内部状态
    
    # 输出结果
    response: str = ""
    widget: Optional[dict] = None
    workflow_output: Optional[dict] = None
    
    # 内部字段
    _llm: Any = None
    _db: Any = None


# =====================================================================
# 路由节点函数 ====================

async def route_to_workflow(state: RouterState, db: Any = None) -> dict:
    """
    核心路由节点：根据意图将请求分发到对应的工作流/链
    
    Args:
        state: 路由器状态
        db: 数据库会话（作为单独参数传递，避免序列化问题）
    
    这是整个系统最关键的编排函数。
    """
    intent = state.get("intent", "unknown")
    message = state.get("user_message", "")
    conversation_id = state.get("conversation_id", 0)
    
    print(f"[router] intent={intent}, message={message[:60]}")
    
    llm = state.get("_llm")
    print(f"[router] 从 state 获取 LLM: {llm is not None}, type={type(llm).__name__ if llm else 'None'}")
    
    try:
        if intent == "document_generation":
            return await _handle_document_generation(state, llm, db)
        
        elif intent == "document_modification":
            return await _handle_document_modification(state, llm, db)
        
        elif intent == "consultation":
            return await _handle_consultation(state, llm)
        
        elif intent == "case_search":
            return await _handle_enhance_search(state, llm)

        elif intent == "law_search":
            return await _handle_enhance_search(state, llm)

        elif intent == "case_analysis":
            return await _handle_case_analysis(state, llm)

        elif intent == "contract_review":
            return await _handle_contract_review(state, llm)

        elif intent == "contract_service":
            # contract_service 保留为菜单入口，实际审查走 contract_review
            return await _handle_contract(state, llm)
        
        elif intent == "chitchat":
            return await _handle_chitchat(message, state.get("conversation_id"), state.get("history", []))
        
        else:
            # unknown → 默认走咨询
            print(f"[router] 未知意图 '{intent}'，默认走咨询流程")
            return await _handle_consultation(state, llm)
            
    except Exception as e:
        print(f"[router] 处理异常: {e}")
        import traceback
        traceback.print_exc()
        
        return {
            **state,
            "response": f"处理您的请求时遇到问题：{str(e)}",
        }


async def _handle_document_generation(state: RouterState, llm: Any, db: Any) -> dict:
    """路由到文书生成状态机"""
    from .document_gen_graph import build_document_gen_graph, MAX_LOOP_COUNT
    
    print(f"\n[router:_handle_doc_gen] ===== 进入文书生成处理 =====")
    print(f"[router:_handle_doc_gen] user_message={state.get('user_message', '')[:50]}")
    print(f"[router:_handle_doc_gen] existing_wf_state keys={list((state.get('workflow_state', {}) or {}).keys())}")
    
    # 检查是否已达到循环限制
    existing_wf_state = state.get("workflow_state", {}) or {}
    current_loop = existing_wf_state.get("loop_count", 0)
    loop_limit_reached = existing_wf_state.get("loop_limit_reached", False)
    
    if loop_limit_reached or current_loop >= MAX_LOOP_COUNT:
        print(f"[router:_handle_doc_gen] ⚠️ 循环限制检查: loop_count={current_loop}, limit={MAX_LOOP_COUNT}, reached={loop_limit_reached}")
        from .document_gen_graph import LOOP_LIMIT_ERROR
        return {
            **state,
            "response": LOOP_LIMIT_ERROR,
            "workflow_state": {
                **existing_wf_state,
                "phase": "error",
                "loop_limit_reached": True,
            },
        }
    
    if not LANGGRAPH_AVAILABLE:
        # 降级到旧实现
        from ..workflows import document_generation_workflow
        from ..main_workflow import WorkflowContext
        
        ctx = WorkflowContext(
            session_id=f"sess_{state.get('conversation_id', 0)}",
            conversation_id=state.get("conversation_id", 0),
            project_id=state.get("project_id"),
            document_type=state.get("document_type", ""),
            dispute_type=state.get("dispute_type", ""),
            collected_params=dict(state.get("collected_params", {})),
            current_workflow="document_generation",
            workflow_state=state.get("workflow_state", {}),
            attached_files=state.get("attached_files", []),
        )
        
        ctx = await document_generation_workflow(
            message=state.get("user_message", ""),
            context=ctx,
            history=state.get("history", []),
            agent=llm,
            db=db,
        )
        
        return {
            **state,
            "response": ctx.response,
            "widget": ctx.widget,
            "workflow_state": ctx.workflow_state,
            "workflow_output": ctx.workflow_output,
        }
    
    # 使用 LangGraph 实现（db 已通过 build_document_gen_graph 直接传入）
    from .document_gen_graph import build_document_gen_graph
    
    print(f"[router:_handle_doc_gen] 接收到的 llm: {llm is not None}, type={type(llm).__name__ if llm else 'None'}")
    
    graph = build_document_gen_graph(llm, db)
    print(f"[router:_handle_doc_gen] graph 创建完成, llm in graph=None")
    
    print(f"[router:_handle_doc_gen] 传入的 collected_params={dict(state.get('collected_params', {}))}")
    print(f"[router:_handle_doc_gen] 传入的 template_id={existing_wf_state.get('template_id')}")
    print(f"[router:_handle_doc_gen] 传入的 template_name={existing_wf_state.get('template_name')}")
    print(f"[router:_handle_doc_gen] 传入的 template_params keys={list((existing_wf_state.get('template_params') or {}).keys())}")
    print(f"[router:_handle_doc_gen] 传入的 loop_count={current_loop}/{MAX_LOOP_COUNT}")
    
    # 合并 collected_params 中的模板信息
    # 前端通过 collected_params 传递模板信息
    passed_collected_params = dict(state.get("collected_params", {})) or {}
    existing_collected_params = dict(existing_wf_state.get("collected_params", {})) or {}
    merged_params = {**passed_collected_params, **existing_collected_params}
    
    # 优先从 merged_params 获取模板信息
    template_id_from_collected = merged_params.get("template_id") or existing_wf_state.get("template_id")
    template_name_from_collected = merged_params.get("template_name") or existing_wf_state.get("template_name")
    
    print(f"[router:_handle_doc_gen] 从 collected_params 提取 template_id={template_id_from_collected}")
    print(f"[router:_handle_doc_gen] 从 collected_params 提取 template_name={template_name_from_collected}")
    
    # 【关键修复】根据当前状态动态选择入口节点，避免重复进入 select_template
    # 如果已有模板信息，跳过 select_template 直接进入 collect_params
    current_phase = existing_wf_state.get("phase", "")
    has_template = bool(template_id_from_collected and template_name_from_collected)
    
    # 确定入口节点
    if current_phase in ("completed", "error"):
        if current_phase == "completed":
            # 工作流已完成，重置状态以允许新流程开始
            print(f"[router:_handle_doc_gen] 工作流已完成，重置状态以开始新流程")
            # 重置工作流状态，开始新的文书生成流程
            entry_node = "select_template"
        else:  # current_phase == "error"
            # 工作流出错，不再处理，让意图识别走其他分支
            print(f"[router:_handle_doc_gen] 工作流出错(phase={current_phase})，跳过文书生成")
            return None
    else:
        # 原有的逻辑保持不变
        if has_template and current_phase in ("collecting", "collect_params", "confirm"):
            # 已有模板且在参数收集/确认阶段，直接进入 collect_params
            entry_node = "collect_params"
            print(f"[router:_handle_doc_gen] ✓ 已有模板，选择入口节点: {entry_node}")
        elif current_phase == "generate" or current_phase == "generating":
            # 生成阶段
            entry_node = "generate"
            print(f"[router:_handle_doc_gen] ✓ 生成阶段，选择入口节点: {entry_node}")
        else:
            # 默认从 select_template 开始
            entry_node = "select_template"
            print(f"[router:_handle_doc_gen] ○ 无模板/新会话，选择入口节点: {entry_node}")

    gen_state = await graph.ainvoke(
        {
            "user_message": state.get("user_message", ""),
            "conversation_id": state.get("conversation_id", 0),
            "project_id": state.get("project_id"),  # 传递项目ID
            "document_type": state.get("document_type", "") or existing_wf_state.get("document_type", ""),
            "dispute_type": state.get("dispute_type", ""),
            "template_id": template_id_from_collected,
            "template_name": template_name_from_collected or state.get("document_type", ""),
            "template_params": existing_wf_state.get("template_params", {}),
            "collected_params": merged_params,  # 使用合并后的参数
            "phase": current_phase or "select_template",  # 传递当前阶段
            "loop_count": current_loop,  # 传递循环计数
            "_llm": llm,  # 传递 LLM 实例用于轻量级意图分类
        },
        config={
            "configurable": {
                "thread_id": f"docgen_{state.get('conversation_id', 0)}",
                "node": entry_node,  # 动态指定入口节点
            }
        },
    )
    
    print(f"[router:_handle_doc_gen] gen_state keys={list(gen_state.keys())}")
    print(f"[router:_handle_doc_gen] gen_state.phase={gen_state.get('phase')}")
    print(f"[router:_handle_doc_gen] gen_state.response={gen_state.get('response', '')[:100] if gen_state.get('response') else 'None'}")
    print(f"[router:_handle_doc_gen] gen_state.collected_params={gen_state.get('collected_params', {})}")
    print(f"[router:_handle_doc_gen] gen_state.loop_count={gen_state.get('loop_count', 0)}")
    print(f"[router:_handle_doc_gen] ===== 文书生成处理完成 =====\n")
    
    return {
        **state,
        "response": gen_state.get("response", ""),
        "widget": gen_state.get("widget"),
        "collected_params": gen_state.get("collected_params", {}),
        "workflow_state": gen_state,
        "workflow_output": {
            "generated_content": gen_state.get("generated_content"),
            "file_path": gen_state.get("file_path"),
            "phase": gen_state.get("phase"),
            "loop_count": gen_state.get("loop_count", current_loop),
            "loop_limit_reached": gen_state.get("loop_limit_reached", False),
        },
    }


async def _handle_document_modification(state: RouterState, llm: Any, db: Any) -> dict:
    """路由到文书修改状态机"""
    from .document_mod_graph import build_modify_agent_graph
    
    if not LANGGRAPH_AVAILABLE:
        # 降级到旧实现
        from ..workflows import document_modification_workflow
        from ..main_workflow import WorkflowContext
        
        ctx = WorkflowContext(
            session_id=f"sess_{state.get('conversation_id', 0)}",
            conversation_id=state.get("conversation_id", 0),
            current_workflow="document_modification",
            workflow_state=state.get("workflow_state", {}),
            attached_files=state.get("attached_files", []),
        )
        
        ctx = await document_modification_workflow(
            message=state.get("user_message", ""),
            context=ctx,
            history=state.get("history", []),
            agent=llm,
            db=db,
        )
        
        return {**state, "response": ctx.response, "widget": ctx.widget}
    
    # 使用 LangGraph ModifyAgent
    graph = build_modify_agent_graph(llm)
    
    wf_state = state.get("workflow_state", {})
    
    mod_state = await graph.ainvoke(
        {
            "document_id": wf_state.get("document_path", "doc_inline"),
            "original_content": wf_state.get("original_content", wf_state.get("document_content", "")) or state.get("user_message", ""),
            "current_content": wf_state.get("current_content", wf_state.get("document_content", "")) or state.get("user_message", ""),
            "user_modification_request": state.get("user_message", ""),
            "version_history": [],
            "current_version": 0,
        },
        config={"configurable": {"thread_id": f"mod_{state.get('conversation_id', 0)}"}},
    )
    
    return {
        **state,
        "response": mod_state.get("response", ""),
        "widget": mod_state.get("widget"),
        "workflow_state": {
            **wf_state,
            "current_content": mod_state.get("current_content", ""),
            "version_history": mod_state.get("version_history", []),
            "current_version": mod_state.get("current_version", 0),
        },
    }


async def _handle_consultation(state: RouterState, llm: Any) -> dict:
    """路由到法律咨询 LCEL Chain"""
    from ..chains.consultation_chain import create_consultation_chain, _extract_keywords
    
    chain = create_consultation_chain(llm)
    
    # 先提取关键词
    keywords = await _extract_keywords(
        {"message": state.get("user_message", "")}, 
        llm
    )
    
    # 调用 chain（传入提取的关键词）
    result = await chain.ainvoke({
        "message": state.get("user_message", ""),
        "conversation_id": state.get("conversation_id", 0),
        "keywords": keywords,
    })
    
    return {
        **state,
        "response": result.get("content", ""),
        "intent": "consultation",
        "confidence": 1.0,
        "workflow_output": result.get("workflow_output"),
    }


async def _handle_case_search(state: RouterState, llm: Any) -> dict:
    """路由到案例检索 Tool（使用 SearchService）"""
    from ..services import SearchService

    message = state.get("user_message", "")

    # 使用 SearchService 统一检索
    search_service = SearchService(llm or state.get("_llm"))
    result = await search_service.search_cases(message)

    if result.has_error:
        return {**state, "response": "未找到相关案例。请尝试更换关键词。"}

    return {
        **state,
        "response": result.formatted,
        "workflow_output": {"cases": result.items},
    }


async def _handle_law_search(state: RouterState, llm: Any) -> dict:
    """路由到法规检索 Tool（使用 SearchService）"""
    from ..services import SearchService

    message = state.get("user_message", "")

    # 使用 SearchService 统一检索
    search_service = SearchService(llm or state.get("_llm"))
    result = await search_service.search_laws(message)

    if result.has_error:
        return {**state, "response": "未找到相关法规。请尝试更换关键词。"}

    return {
        **state,
        "response": result.formatted,
        "workflow_output": {"laws": result.items},
    }


async def _handle_contract(state: RouterState, llm: Any) -> dict:
    """路由到合同服务（菜单入口）"""
    return {
        **state,
        "response": """📜 **合同服务**

**审查合同** - 分析合同条款，识别风险

请上传合同文件或粘贴合同文本，我来帮您审查。""",
        "widget": {
            "type": "card",
            "title": "合同服务",
            "actions": [
                {"type": "button", "label": "审查合同", "action": "review_contract"},
            ],
        },
    }


async def _handle_enhance_search(state: RouterState, llm: Any) -> dict:
    """路由到增强搜索工作流（替代原有简单检索）"""
    from .enhance_search_graph import run_enhance_search

    message = state.get("user_message", "")
    print(f"[router] 进入增强搜索流程")

    result = await run_enhance_search(message, llm=llm)

    # 检查是否有可视化报告数据
    report_data = result.get("report_data", {})
    has_visual_report = bool(report_data and report_data.get("sections"))

    return {
        **state,
        "response": result.get("final_answer", "未获取到搜索结果"),
        "workflow_output": {
            "plan": result.get("plan", {}),
            "raw_results": result.get("raw_results", {}),
            "reranked_cases": result.get("reranked_cases", []),
            "report_data": report_data,
            "has_visual_report": has_visual_report,
        },
        "widget": {
            "type": "report",
            "title": "查看检索报告",
            "report_data": report_data,
        } if has_visual_report else None,
    }


async def _handle_case_analysis(state: RouterState, llm: Any) -> dict:
    """路由到案件分析报告工作流"""
    from .case_analysis_graph import run_case_analysis

    message = state.get("user_message", "")
    print(f"[router] 进入案件分析报告流程")

    result = await run_case_analysis(message, llm=llm)

    # 检查是否有可视化报告数据
    report_data = result.get("report_data", {})
    has_visual_report = bool(report_data and report_data.get("sections"))

    # 构建响应文本（优先使用 report_markdown，为空时从 report_data 构建）
    report_markdown = result.get("report_markdown", "")
    if not report_markdown and report_data:
        report_markdown = f"**{report_data.get('title', '案件分析报告')}**\n\n"
        report_markdown += f"📅 生成时间: {report_data.get('generated_at', '未知')}\n"
        report_markdown += f"📋 纠纷类型: {report_data.get('dispute_type', '未知')}\n"
        report_markdown += f"📊 类案总数: {report_data.get('case_count', 0)} 个\n\n"
        if report_data.get("sections"):
            report_markdown += f"报告共 {len(report_data['sections'])} 个章节，已生成可视化报表。"

    return {
        **state,
        "response": report_markdown or "案件分析报告生成失败",
        "workflow_output": {
            "extracted_elements": result.get("extracted_elements", {}),
            "verdict_distribution": result.get("verdict_distribution", {}),
            "top3_cases": result.get("top3_cases", []),
            "laws_summary": result.get("laws_summary", []),
            "pdf_url": result.get("pdf_url", ""),
            "report_data": report_data,
            "has_visual_report": has_visual_report,
        },
        "widget": {
            "type": "report",
            "title": "查看分析报告",
            "report_data": report_data,
        } if has_visual_report else None,
    }


async def _handle_contract_review(state: RouterState, llm: Any) -> dict:
    """路由到合同风险审查工作流"""
    from .contract_review_graph import run_contract_review

    attached_files = state.get("attached_files", [])

    if not attached_files:
        return {**state, "response": "请上传需要审查的合同文件（支持 .docx / .txt 格式）"}

    # 支持多种字段名：file_path（直接路径）或 file_name + content（文件内容）
    first_file = attached_files[0] if isinstance(attached_files[0], dict) else {}
    file_path = first_file.get("file_path", "")
    file_name = first_file.get("file_name", "")
    file_content = first_file.get("content", "")

    if not file_path and not file_content:
        return {**state, "response": "无法获取上传的文件内容，请重新上传。"}

    print(f"[router] 进入合同审查流程: {file_path or file_name}")

    result = await run_contract_review(
        file_path=file_path if file_path else "",
        file_content=file_content,
        file_name=file_name,
        llm=llm
    )

    # 检查是否有可视化报告数据
    report_data = result.get("report_data", {})
    has_visual_report = bool(report_data and report_data.get("sections"))

    # 构建简短响应文本
    summary = report_data.get("summary", {}) if report_data else {}
    report_text = result.get("report_markdown", "合同审查报告生成失败")
    
    # 如果有可视化数据，在响应中加上摘要
    if summary:
        report_text = f"""📋 **合同审查完成**

| 指标 | 数值 |
|------|------|
| 总条款数 | {summary.get('total_clauses', 0)} |
| 🔴 高风险 | {summary.get('high_risk', 0)} 项 |
| 🟡 中风险 | {summary.get('medium_risk', 0)} 项 |
| 🟢 低风险 | {summary.get('low_risk', 0)} 项 |

可视化报告已生成，请点击下方卡片查看详情。"""

    return {
        **state,
        "response": report_text,
        "workflow_output": {
            "clauses": result.get("clauses", []),
            "risks": result.get("risks", []),
            "report_data": report_data,
            "has_visual_report": has_visual_report,
        },
        "widget": {
            "type": "report",
            "title": "查看审查报告",
            "report_data": report_data,
        } if has_visual_report else None,
    }


async def _handle_chitchat(
    message: str,
    conversation_id: Optional[int] = None,
    history: list = None
) -> dict:
    """处理闲聊"""
    from ..memory import get_memory
    
    lower_msg = message.lower()
    history = history or []
    
    # 使用 LangChain Memory 补充获取更多历史（如果提供 conversation_id）
    if conversation_id is not None:
        memory_service = get_memory()
        memory_history = await memory_service.get_chat_history(conversation_id)
        # 合并历史（Memory 中的历史更完整）
        if memory_history:
            history = memory_history
    
    # 检测是否询问历史
    if any(kw in lower_msg for kw in ["记得", "聊过", "之前", "历史", "说过", "谈过"]):
        if history:
            # 总结对话历史
            summary_parts = []
            for msg in history[-6:]:  # 最近3轮对话
                role = "我" if msg.get("role") == "ai" else "您"
                content = msg.get("content", "")[:100]
                if content:
                    summary_parts.append(f"{role}说：{content}")
            
            if summary_parts:
                response = f"我记得我们的对话内容：\n\n" + "\n\n".join(summary_parts) + "\n\n请问您想继续聊什么？"
            else:
                response = "我记得我们的对话，不过内容比较简短。请问您想聊什么？"
        else:
            response = "抱歉，我目前还没有保存对话历史。我是法律AI助手，主要帮助您处理法律相关的问题，比如生成法律文书、解答法律疑问等。请问有什么我可以帮您的？"
        return {"response": response, "intent": "chitchat"}
    
    # 问候语处理
    if any(kw in lower_msg for kw in ["你好", "hi", "hello", "嗨"]):
        response = """👋 你好！

我是法律AI助手，除了法律咨询，我也乐意和您简单聊聊天。

有什么我可以帮您的吗？
- 📝 帮您生成法律文书
- 📜 审查或起草合同
- ⚖️ 了解诉讼流程
- 💬 解答法律问题"""
    else:
        response = "好的，让我们继续。\n\n请问您需要什么帮助？"
    
    return {"response": response, "intent": "chitchat"}


# =====================================================================
# 图构建函数 ====================

def build_main_router_graph(llm: Any = None, db: Any = None):
    """
    构建顶层路由状态机图
    
    Args:
        llm: LawChatLLM 实例
        db: 数据库会话
        
    Returns:
        编译后的 CompiledGraph
        
    使用示例:
        >>> router = build_main_router_graph(law_llm, db_session)
        >>> 
        >>> # 单次调用
        >>> result = await router.ainvoke({
        ...     "user_message": "帮我写起诉状",
        ...     "conversation_id": 123,
        ...     "_llm": law_llm,
        ...     "_db": db_session,
        ... })
        >>> print(result["content"])
    """
    if not LANGGRAPH_AVAILABLE:
        raise ImportError("LangGraph 未安装")
    
    graph = StateGraph(RouterState)
    
    # 注册节点
    graph.add_node("route", route_to_workflow)
    
    # 设置入口
    graph.set_entry_point("route")
    
    # 路由到结束
    graph.add_edge("route", END)
    
    # 不使用 checkpointer（避免 AsyncSession 等不可序列化对象的序列化问题）
    return graph.compile()


# =====================================================================
# 便捷入口函数 ====================

async def run_router(
    message: str,
    *,
    conversation_id: int = 0,
    project_id: Optional[int] = None,
    history: Optional[list] = None,
    llm: Any = None,
    db: Any = None,
    attached_files: Optional[list] = None,
    collected_params: Optional[Dict[str, str]] = None,
    workflow_state: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    一次性执行完整的路由流程（封装入口）
    
    这是 SmartChatService.chat() 的推荐替换方案。
    自动完成: 意图识别 → 路由 → 执行 → 返回结果
    
    Args:
        message: 用户消息
        conversation_id: 会话ID
        project_id: 项目ID
        history: 对话历史
        llm: LawChatLLM 实例
        db: 数据库会话
        attached_files: 附件列表
        collected_params: 收集的表单参数
        workflow_state: 前端传来的工作流状态（包含 template_id, template_name 等）
        
    Returns:
        标准化结果字典，兼容原有 SmartChatService.chat() 格式：
        {
            "content": "...",
            "intent": "...",
            "confidence": 0.xx,
            "workflow_state": {...},
            "widget": {...},
            "workflow_output": {...},
        }
    """
    from ..services import IntentClassifier

    if not llm:
        # 优先使用已初始化的全局单例，避免创建无 agent 实例的空壳 LLM
        try:
            from ..llm import get_intent_llm, initialize_all_llms
            llm = get_intent_llm()
            # 检查 LLM 是否真正初始化（有 agent 实例）
            if not llm or not llm._agent_instance:
                # 全局单例也未初始化，尝试从 agent_sdk 创建并注入
                from ..agent_sdk import CodeBuddyAgent, SDK_AVAILABLE
                if SDK_AVAILABLE:
                    agent = CodeBuddyAgent()
                    initialize_all_llms(agent)
                    llm = get_intent_llm()
        except Exception as e:
            print(f"[run_router] LLM 初始化失败: {e}")
            import traceback
            traceback.print_exc()
            llm = None

    # Step 1: 意图识别（使用 IntentClassifier 服务）
    # 意图识别用本地 ollama（轻量、快速）
    from ...config import settings
    from ..llm_factory import create_llm_by_type
    
    # 意图识别 LLM（强制使用本地 ollama）
    intent_llm_type = "ollama" if os.getenv("OLLAMA_BASE_URL") else "hunyuan"
    classifier_use_llm = getattr(settings, 'INTENT_CLASSIFIER_USE_LLM', True)
    
    print(f"[run_router] 意图分类 LLM 类型: {intent_llm_type}")
    
    if classifier_use_llm:
        intent_llm = create_llm_by_type(intent_llm_type, temperature=0.1, max_tokens=200)
        print(f"[run_router] 意图分类使用 LLM: {intent_llm_type}, llm={intent_llm is not None}")
    else:
        intent_llm = None
        print(f"[run_router] 意图分类不使用 LLM")
    
    intent_classifier = IntentClassifier(intent_llm)

    history_text = ""
    if history:
        lines = []
        for msg in history[-5:]:
            role = "用户" if msg.get("role") == "user" else "助手"
            content = msg.get("content", "")[:200]
            lines.append(f"{role}：{content}")
        history_text = "\n".join(lines)

    print(f"\n{'='*60}")
    print(f"[run_router] ========== 开始处理请求 ==========")
    print(f"[run_router] 用户消息: {message[:100]}")
    print(f"[run_router] conversation_id: {conversation_id}")
    print(f"[run_router] 历史记录数: {len(history) if history else 0}")
    print(f"[run_router] 调用 IntentClassifier.classify()...")
    
    intent_result = await intent_classifier.classify(
        query=message,
        history=history,
        previous_intent="",
    )
    
    print(f"[run_router] 意图识别结果: intent={intent_result.get('intent')}, confidence={intent_result.get('confidence'):.2f}")
    print(f"[run_router] 提取的文档类型: {intent_result.get('document_type', 'N/A')}")
    print(f"[run_router] 提取的参数: {list(intent_result.get('extracted_info', {}).keys())}")
    print(f"[run_router] 外部传入的 collected_params: {collected_params}")
    print(f"[run_router] 前端传入的 workflow_state keys: {list((workflow_state or {}).keys())}")
    
    # 合并工作流状态（前端传来的状态优先）
    existing_wf = workflow_state or {}
    
    # 合并参数：意图识别提取的参数 + 表单提交的参数 + workflow_state 中的参数
    extracted_params = intent_result.get("extracted_info", {})
    
    # 从 workflow_state 中提取模板相关参数
    wf_template_id = existing_wf.get("template_id")
    wf_template_name = existing_wf.get("template_name")
    wf_template_params = existing_wf.get("template_params", {})
    wf_collected_params = existing_wf.get("collected_params", {})
    
    # 合并所有参数源（后面的覆盖前面的）
    merged_params = {
        **extracted_params,           # 意图识别提取的参数
        **wf_collected_params,        # workflow_state 中的已收集参数
        **(collected_params or {}),   # 前端传来的参数（最高优先级）
    }
    
    # ========== 会话隔离检查 ==========
    # 判断是否为新会话/初始状态
    # 注意：LangChain END 常量序列化后可能是 "__end__" 或 "END"
    wf_phase = existing_wf.get("phase", "")
    
    # 真正的结束状态列表（不包括空字符串！）
    # 空字符串表示"新会话/无状态"，不应清空数据
    REAL_END_PHASES = ("END", "__end__")
    is_new_session = (wf_phase == "") or (wf_phase in REAL_END_PHASES)
    
    # 判断 workflow_state 是否有效
    # 如果有 phase 且不是结束状态，说明有正在进行的工作流
    wf_has_meaningful_state = bool(
        wf_phase and wf_phase not in REAL_END_PHASES
    )
    
    # 进一步检查：即使 phase 是初始状态，如果已有 template_id 说明之前已选择过模板
    # 此时不应该清空（用户可能正在点击确认按钮）
    has_existing_template = bool(wf_template_id or existing_wf.get("template_id"))
    
    # 只有真正的结束状态才清空数据
    # 注意：phase="" 不清空（可能是新会话，应该保留前端传入的数据）
    is_ended_flow = wf_phase in REAL_END_PHASES
    
    print(f"[run_router] 会话状态检查: phase={wf_phase}, is_new_session={is_new_session}, has_meaningful_state={wf_has_meaningful_state}, has_existing_template={has_existing_template}, is_ended_flow={is_ended_flow}")
    
    # 如果是无效的 workflow_state，清空相关数据
    # 注意：只有在旧流程真正结束时（is_ended_flow=True）才清空
    # 新会话（phase=""）应该保留前端传入的数据，不主动清空
    should_clear_state = is_ended_flow
    
    if should_clear_state:
        print(f"[run_router] ⚠️ 检测到初始状态/结束状态 workflow_state，清空会话数据重新开始")
        existing_wf = {}
        wf_template_id = None
        wf_template_name = None
        wf_template_params = {}
        wf_collected_params = {}
        merged_params = {}  # 也清空合并后的参数
        collected_params = {}  # 清空前端传来的参数
    # ==========================================
    
    # ========== Widget 选择结果优先处理 ==========
    # 只有在有效会话状态下，才处理 Widget 选择的 template_id
    param_template_id = (collected_params or {}).get("template_id")
    if wf_has_meaningful_state and (wf_template_id or param_template_id):
        print(f"[run_router] 检测到 template_id，强制使用 document_generation 意图")
        print(f"[run_router]   wf_template_id={wf_template_id}, param_template_id={param_template_id}")
        intent_result = {
            "intent": "document_generation",
            "confidence": 1.0,
            "reasoning": "前端已传递 template_id，用户完成了 Widget 选择",
        }
        # 确保 template_id 在 merged_params 中
        if param_template_id:
            merged_params["template_id"] = param_template_id
        elif wf_template_id and "template_id" not in merged_params:
            merged_params["template_id"] = wf_template_id
    # ==========================================
    
    # ========== 循环次数限制检查 ==========
    # 如果之前已达到循环限制，直接返回错误而不调用 LLM
    if existing_wf.get("loop_limit_reached", False):
        print(f"[run_router] ⚠️ 前端传入 workflow_state 已标记 loop_limit_reached，直接返回限制消息")
        from .document_gen_graph import LOOP_LIMIT_ERROR
        return {
            "content": LOOP_LIMIT_ERROR,
            "intent": "loop_limit",
            "confidence": 0.0,
            "workflow_state": {
                **existing_wf,
                "loop_limit_reached": True,
                "phase": "error",
            },
            "widget": None,
            "workflow_output": {"error": "loop_limit_reached"},
        }
    
    current_loop = existing_wf.get("loop_count", 0)
    from .document_gen_graph import MAX_LOOP_COUNT
    if current_loop >= MAX_LOOP_COUNT:
        print(f"[run_router] ⚠️ loop_count={current_loop} >= MAX_LOOP_COUNT={MAX_LOOP_COUNT}，拒绝处理")
        from .document_gen_graph import LOOP_LIMIT_ERROR
        return {
            "content": LOOP_LIMIT_ERROR,
            "intent": "loop_limit",
            "confidence": 0.0,
            "workflow_state": {
                **existing_wf,
                "loop_limit_reached": True,
                "phase": "error",
            },
            "widget": None,
            "workflow_output": {"error": "loop_limit_reached"},
        }
    # ======================================
    
    # Step 2: 路由并执行
    # 业务逻辑（文书生成/修改/咨询等）使用混元 LLM
    business_llm = create_llm_by_type("hunyuan", temperature=0.7, max_tokens=4000)
    
    router_state: RouterState = RouterState(
        user_message=message,
        conversation_id=conversation_id,
        project_id=project_id,
        history=history or [],
        attached_files=attached_files or [],
        intent=intent_result.get("intent", "unknown"),
        intent_confidence=intent_result.get("confidence", 0.5),
        intent_reasoning=intent_result.get("reasoning", ""),
        document_type=intent_result.get("document_type", "") or existing_wf.get("document_type", ""),
        dispute_type=intent_result.get("dispute_type", ""),
        collected_params=merged_params,
        workflow_state=existing_wf,  # 传递前端传来的工作流状态
    )
    # ⚠️ 重要：RouterState 继承自 Dict，字段赋值不会生效，必须用 dict 方式设置
    # 业务逻辑使用混元，意图识别使用本地 ollama
    router_state["_llm"] = business_llm
    print(f"[run_router] 业务逻辑 LLM: hunyuan, llm={business_llm is not None}")
    
    # ========== 意图自动切换 ==========
    # 如果有附件文件且意图是 contract_service，自动切换到 contract_review
    current_intent = router_state.get("intent", "unknown")
    has_files = bool(attached_files)
    if current_intent == "contract_service" and has_files:
        print(f"[run_router] 检测到附件文件，自动切换意图: contract_service → contract_review")
        router_state["intent"] = "contract_review"
    # =================================
    
    # 将 db 作为额外参数传递（不在状态中）
    result = await route_to_workflow(router_state, db=db)
    
    print(f"[run_router] 工作流返回: phase={result.get('workflow_state', {}).get('phase', 'N/A')}")
    print(f"[run_router] 响应长度: {len(result.get('response', ''))} 字符")
    print(f"[run_router] Widget类型: {result.get('widget', {}).get('type', 'N/A') if result.get('widget') else 'None'}")
    
    # 调试：检查 widget categories
    w = result.get('widget')
    if w and w.get('type') == 'template_selector':
        cats = w.get('categories', [])
        print(f"[run_router] Widget categories 数量: {len(cats)}")
        for cat in cats:
            tpls = cat.get('templates', [])
            print(f"[run_router]   分类 '{cat.get('name')}': {len(tpls)} 个模板")
            for tpl in tpls[:3]:
                print(f"[run_router]     - {tpl.get('name')} (id={tpl.get('id')})")
    
    print(f"[run_router] ========== 请求处理完成 ==========")
    print(f"{'='*60}\n")
    
    # 获取工作流状态（可能是嵌套的，需要扁平化）
    wf_state = result.get("workflow_state", {})
    
    # 标准化输出格式（与 SmartChatService.chat() 一致）
    return {
        "content": result.get("response", ""),
        "intent": result.get("intent", "unknown"),
        "confidence": result.get("intent_confidence", result.get("intent_confidence", 0.0)),
        "workflow_state": {
            "session_id": f"sess_{conversation_id}",
            "current_workflow": result.get("intent", "unknown"),
            "document_type": result.get("document_type", ""),
            "collected_params": result.get("collected_params", {}),
            # 将 document_gen_graph 的状态展平
            "template_id": wf_state.get("template_id"),
            "template_name": wf_state.get("template_name"),
            "template_params": wf_state.get("template_params", {}),
            "phase": wf_state.get("phase"),
            "missing_required": wf_state.get("missing_required", []),
        },
        "widget": result.get("widget"),
        "workflow_output": result.get("workflow_output"),
    }

"""
文书生成 StateGraph (LangGraph)

替代 workflows.py 中 document_generation_workflow() 的隐式 phase 状态机，
使用 LangGraph StateGraph 实现显式的、可观测的、可调试的状态驱动流程。

【重要修复 v2】- 添加循环次数限制
- 每个会话最多执行 20 次 LLM 调用
- 防止无限循环导致 token 消耗过多

状态转换图:
                    ┌─────────────────┐
              ┌─────│   SELECT_TEMPLATE │◄──────────┐
              │     └────────┬────────┘            │
              │              │                     │
              │    [已指定document_type?]           │
              │       Yes  / No                   │
              │        ↓ / ↓                       │
              │  ┌──────────────┐                  │
              │  │ COLLECT_PARAMS│                 │
              │  └──────┬───────┘                  │
              │         │                           │
              │   [参数齐全?]                        │
              │   Yes / No                          │
              │    ↓ / ↓                            │
              │ ┌────────────┐                      │
              │ │   CONFIRM   │◄──(修改)────────────┘
              │ └──────┬─────┘
              │        │
              │  [确认?]
              │ Yes/No/修改
              │ ↓ / ↩️ / ↓
              │ ┌──────────┐
              └─│ GENERATE │
                └────┬─────┘
                     │
                     ↓
                ┌─────────┐
                │ COMPLETED│
                └─────────┘

使用示例:
    >>> graph = build_document_gen_graph(llm, db)
    >>> 
    >>> # 第1轮: 选择模板
    >>> state1 = await graph.ainvoke(
    ...     {"user_message": "帮我写起诉状"},
    ...     config={"configurable": {"thread_id": "sess_001"}}
    ... )
    >>> # state1["phase"] == "select_template", 显示模板列表
    >>> 
    >>> # 第2轮: 用户选择模板后进入参数收集
    >>> state2 = await graph.ainvoke(
    ...     {"user_message": "用民事起诉状模板，原告张三，被告李四"},
    ...     config={"configurable": {"thread_id": "sess_001"}}
    ... )
    >>> # state2["phase"] == "collect_params" 或 "confirm"
    >>> 
    >>> # 第3轮: 确认生成
    >>> state3 = await graph.ainvoke(
    ...     {"user_message": "确认生成"},
    ...     config={"configurable": {"thread_id": "sess_001"}}
    ... )
    >>> # state3["phase"] == "completed"
    >>> # state3["generated_content"] 包含完整文书
"""

from __future__ import annotations

from typing import Annotated, Any, Dict, List, Optional, TypedDict
import operator

try:
    from langgraph.graph import StateGraph, END
    from langgraph.checkpoint.memory import MemorySaver
    LANGGRAPH_AVAILABLE = True
except ImportError:
    # 降级：提供模拟实现
    StateGraph = None
    END = None
    MemorySaver = None
    LANGGRAPH_AVAILABLE = False


# =====================================================================
# 全局配置 - 循环次数限制
# =====================================================================

# 每个会话最多执行 20 次 LLM 调用（防止无限循环）
MAX_LOOP_COUNT = 20

# 超过限制后的错误消息
LOOP_LIMIT_ERROR = """已达到最大对话次数限制。

当前会话已执行过多轮对话，为避免消耗过多资源，请：
1. 重新开始一个新会话
2. 或直接告诉我您的最终需求

抱歉给您带来不便，感谢理解！"""


# =====================================================================
# 子流程轻量级意图分类
# =====================================================================

class SubflowIntent:
    """子流程意图枚举
    
    所有节点共享的统一意图分类入口：classify_subflow_intent()
    
    基础意图（所有节点通用）：
    - CANCEL         → 清空状态 → END
    - CHANGE_TEMPLATE → 清空状态 → select_template
    - ASK_QUESTION   → help 节点（问答模式，回复用户问题后停留在 help 节点）
    - DEFAULT        → 继续当前节点原有逻辑
    
    节点特有扩展意图：
    - confirm 节点补充：MODIFY → collect_params（回退，带已有参数）
    """
    CANCEL = "cancel"                # 取消，清空状态
    CHANGE_TEMPLATE = "change_template"  # 切换模板
    ASK_QUESTION = "ask_question"   # 回答问题，停留在当前节点（转发到 help）
    DEFAULT = "default"             # 默认，继续原有逻辑
    MODIFY = "modify"               # 修改参数（confirm 节点特有）


async def classify_subflow_intent(
    user_message: str,
    llm: Any = None,
    context: str = "default",
    state: Any = None,
) -> str:
    """
    基于上下文工程的意图分类器

    通过丰富的业务上下文和场景描述，让 LLM 精准判断用户真实意图。

    分类结果:
    - cancel: 用户明确要取消操作
    - change_template: 用户明确要更换模板
    - ask_question: 用户在提问，非参数输入
    - modify: 用户想修改已确认的参数（仅 confirm 阶段）
    - default: 继续当前节点的原有逻辑（填参数等）
    """

    # ========== 前置校验：LLM 必须存在 ==========
    if llm is None:
        raise ValueError("classify_subflow_intent: llm 参数不能为空")

    import re as re_module

    # ====== 上下文工程：从 state 提取关键信息 ======
    current_phase = state.get("phase", "未知") if state else "未知"
    has_template = bool(state.get("template_id")) if state else False
    template_name = state.get("template_name", "无") if state else "无"
    collected_keys = list(state.get("collected_params", {}).keys()) if state else []
    
    print(f"[classify_subflow_intent] 调试: state={type(state).__name__}, phase={current_phase}, has_template={has_template}")
    print(f"[classify_subflow_intent] 调试: state keys={list(state.keys()) if state else []}")

    # 可用意图列表及描述
    intents_info = {
        "default": "继续当前阶段的原有逻辑（填写参数、确认信息等）",
        "change_template": "用户明确要求更换或重新选择文书模板",
        "cancel": "用户明确要求取消本次文书生成",
        "ask_question": "用户在咨询法律问题或使用方法",
        "confirm": "用户明确确认要生成文书（点击确认按钮、说'确认生成'、'好的生成'、'开始生成'等）",
    }
    if context == "confirm":
        intents_info["modify"] = "用户要求修改已确认的某个参数"

    available_intents = list(intents_info.keys())

    # ====== 提示词工程：结构化 Prompt ======
    prompt = f"""# 角色
你是法律文书生成系统的「意图分类器」。

# 业务背景
系统正在帮助用户通过对话交互式地生成一份法律文书（如起诉状、合同等）。
完整流程：选择模板 → 收集必要参数 → 确认并生成文档

# 当前会话状态
- 所在阶段：{current_phase}
- 已选模板：{'是 - ' + template_name if has_template else '否'}
- 已收集参数：{collected_keys if collected_keys else '无'}

# 用户最新输入
{user_message}

# 意图定义与判断标准

## default（默认/继续操作）
适用场景：
- 用户在提供或补充信息（如姓名、金额、地址等参数）
- 用户在正常对话回应系统的提问
- 用户的表述不明确或不属于以下任何特殊意图
→ 这是最常见的意图，当不确定时优先返回此项

## change_template（更换模板）
适用场景：
- 用户明确表达对当前模板不满意
- 用户说"换一个"、"重新选"、"不要这个"
- ⚠️ 重要：如果已有模板且用户只是在正常对话/填参数，**不应**判定为此项

## cancel（取消）
适用场景：
- 用户明确表示要中止/放弃本次生成

## ask_question（提问咨询）
适用场景：
- 用户在询问法律相关问题
- 用户在问如何使用系统功能
- 输入明显是疑问句且与当前流程无关

{f'''## modify（修改参数）
适用场景：
- 当前在「确认阶段」，用户想改某个已填写的参数
- 用户指出某项信息有误需要修正''' if context == "confirm" else ""}

# 判断示例

| 场景 | 用户输入 | 当前状态 | 正确意图 |
|------|----------|----------|----------|
| 填写原告信息 | "原告张三" | 已有模板 | default |
| 明确要换模板 | "换个合同模板吧" | 已有模板 | change_template |
| 正常填参数 | "被告李四，住址北京" | 已有模板 | default |
| 法律咨询 | "诉讼时效是多久？" | 任意阶段 | ask_question |
| 确认阶段想改 | "电话号码填错了" | confirm阶段 | modify |
| 确认生成 | "确认生成" | confirm阶段 | confirm |
| 确认生成 | "好的，开始生成" | confirm阶段 | confirm |
| 确认生成 | "好的" | confirm阶段（参数已齐全） | confirm |

# 输出要求
严格按 JSON 格式输出：
{{"intent": "选择的意图"}}
"""

    # ========== 调用 LLM ==========
    response = await llm.ainvoke(prompt)
    content = response.content if hasattr(response, 'content') else str(response)

    match = re_module.search(r'"intent"\s*:\s*"([^"]+)"', content)
    if match and match.group(1) in available_intents:
        intent_result = match.group(1)
        print(f"[classify_subflow_intent] → {intent_result} (阶段={current_phase}, 有模板={has_template})")
        return intent_result

    return SubflowIntent.DEFAULT


# =====================================================================
# 服务实例存储（替代 ContextVar）
# 服务通过 build_document_gen_graph 构造函数注入，存储在模块级别
# =====================================================================

_template_service: Any = None
_doc_gen_service: Any = None


# =====================================================================
# State 定义（类型安全的 TypedDict）
# =====================================================================

class DocumentGenState(TypedDict):
    """
    文书生成的完整状态定义
    
    所有节点通过此字典传递状态，
    使用 Annotated + operator.merge 支持增量更新。
    """
    
    # === 输入 ===
    user_message: str                              # 当前用户消息
    conversation_id: int                           # 会话ID
    project_id: Optional[int] = None              # 项目ID
    
    # === 模板信息 ===
    template_id: Optional[int]                     # 选中的模板ID
    template_name: Optional[str]                  # 模板名称
    template_params: Dict[str, Any]               # 参数定义 {name: {label, required, type}}
    template_categories: Optional[List[Dict]]      # 模板分类列表（用于选择界面）
    
    # === 参数收集 ===
    collected_params: Dict[str, str]              # 已收集的参数值
    missing_required: List[str]                   # 缺失的必填参数名
    
    # === 上下文传递 ===
    document_type: str                             # 从意图识别提取的文书类型
    dispute_type: str                              # 从意图识别提取的纠纷类型
    
    # === 生成结果 ===
    generated_content: Optional[str]              # LLM生成的文书内容
    file_path: Optional[str]                       # 保存的文件路径
    generation_metadata: Dict[str, Any]           # 生成元数据
    
    # === 循环控制【重要】 ===
    loop_count: int                               # 已执行的 LLM 调用次数
    loop_limit_reached: bool                      # 是否已达到循环限制
    
    # === 内部字段 ===
    _llm: Any                                     # LLM 实例（用于意图分类，不序列化）
    
    # === 输出 ===
    response: str                                  # 给用户的响应文本
    widget: Optional[Dict[str, Any]]               # 前端Widget配置
    phase: str                                     # 当前阶段名称（用于调试和前端状态同步）
    error: Optional[str]                          # 错误信息


# =====================================================================
# 节点函数（每个节点是一个纯函数：State → Partial[State]）
# =====================================================================

async def select_template_node(state: DocumentGenState) -> Dict[str, Any]:
    """
    节点1: 选择模板（使用 TemplateService）

    处理逻辑:
    - 如果已有 template_id → 直接进入参数收集
    - 如果用户已指定文书类型 → 自动匹配模板 → 进入参数收集
    - 否则 → 加载所有模板按分类展示 → 等待用户选择
    
    【重要】此节点会调用 LLM（通过 TemplateService），需要检查循环限制
    """
    print(f"\n[doc_gen:select_template] ===== 进入模板选择节点 =====")
    print(f"[doc_gen:select_template] user_message={state.get('user_message', '')[:80]}")
    print(f"[doc_gen:select_template] document_type={state.get('document_type', 'N/A')}")
    print(f"[doc_gen:select_template] template_name={state.get('template_name', 'N/A')}")
    print(f"[doc_gen:select_template] template_id={state.get('template_id', 'N/A')}")
    print(f"[doc_gen:select_template] loop_count={state.get('loop_count', 0)}/{MAX_LOOP_COUNT}")

    # ========== 循环次数检查 ==========
    current_loop = state.get("loop_count", 0)
    if current_loop >= MAX_LOOP_COUNT:
        print(f"[doc_gen:select_template] ⚠️ 达到最大循环次数限制！")
        return {
            "phase": "error",
            "loop_limit_reached": True,
            "response": LOOP_LIMIT_ERROR,
            "error": f"loop_limit_reached: {MAX_LOOP_COUNT}",
        }
    # =================================

    result: Dict[str, Any] = {
        "phase": "select_template",
        "loop_count": current_loop,
    }

    document_type = state.get("document_type", "")
    message = state.get("user_message", "")
    llm = state.get("_llm")

    # ========== 统一意图分类 ==========
    subflow_intent = await classify_subflow_intent(message, llm, context="select_template", state=state)

    # cancel - 清空状态，结束
    if subflow_intent == SubflowIntent.CANCEL:
        print(f"[doc_gen:select_template] 意图: cancel - 结束")
        return {
            **result,
            "phase": END,
            "response": "好的，已取消本次文书生成。如有需要，随时告诉我！",
        }

    # 场景0: 已有 template_id → 直接进入参数收集
    existing_template_id = state.get("template_id")
    existing_template_name = state.get("template_name")
    existing_template_params = state.get("template_params", {})
    
    if existing_template_id and existing_template_name:
        print(f"[doc_gen:select_template] 场景0: 已有模板信息，直接进入参数收集")
        print(f"[doc_gen:select_template] template_id={existing_template_id}, template_name={existing_template_name}")
        
        # 【修复】如果 template_params 为空，从数据库加载
        if not existing_template_params and _template_service:
            print(f"[doc_gen:select_template] template_params 为空，从数据库加载...")
            try:
                template = await _template_service.get_template_by_id(existing_template_id)
                if template:
                    existing_template_params = (
                        template.get("params_def", {})
                        or template.get("params_definition", {})
                    )
                    if not existing_template_params:
                        pd_val = template.get("placeholder_dict")
                        if pd_val:
                            existing_template_params = _convert_params_def(pd_val) if isinstance(pd_val, dict) else {}
                    print(f"[doc_gen:select_template] 已加载 template_params: {list(existing_template_params.keys()) if existing_template_params else '空'}")
            except Exception as e:
                print(f"[doc_gen:select_template] 加载 template_params 失败: {e}")
        
        print(f"[doc_gen:select_template] ===== 节点执行完成 =====\n")
        return {
            **result,
            "template_id": existing_template_id,
            "template_name": existing_template_name,
            "template_params": existing_template_params,
            "phase": "collect_params",
        }

    # 场景A: 已指定文书类型 → 尝试自动匹配模板
    if document_type and _template_service:
        print(f"[doc_gen:select_template] 场景A: 已指定文书类型 '{document_type}'，尝试匹配模板...")
        try:
            match_result = await _template_service.match_template(
                document_type=document_type,
                message=message,
            )

            if match_result.matched:
                print(f"[doc_gen:select_template] 模板匹配成功: {match_result.template_name}")
                print(f"[doc_gen:select_template] 进入阶段: collect_params")
                print(f"[doc_gen:select_template] ===== 节点执行完成 =====\n")
                return {
                    **result,
                    "template_id": match_result.template_id,
                    "template_name": match_result.template_name,
                    "template_params": match_result.params_def,
                    "response": match_result.response_text,
                    "widget": match_result.widget,
                    "phase": "collect_params",
                }
            else:
                print(f"[doc_gen:select_template] 模板匹配失败，进入场景B")
        except Exception as e:
            print(f"[doc_gen:select_template] 模板匹配异常: {e}")

    # 场景B: 未指定或未匹配 → 展示模板选择列表
    print(f"[doc_gen:select_template] 场景B: 展示模板选择列表")
    if _template_service:
        try:
            categories = await _template_service.list_categories()

            if not categories:
                return {
                    **result,
                    "response": """📝 **文书生成**

暂无可用的文书模板。

请先在【模板管理】中上传文书模板后再试。

或者告诉我您想要的文书类型，我会尽量帮您起草。""",
                    "template_categories": [],
                }

            category_list = [
                {"name": cat.name, "templates": cat.templates}
                for cat in categories
            ]

            total = sum(len(cat.templates) for cat in categories)

            return {
                **result,
                "response": f"请问您要生成什么类型的文书？共找到 **{total}** 个模板。",
                "widget": {
                    "type": "template_selector",
                    "title": "选择文书模板",
                    "categories": category_list,
                },
                "template_categories": category_list,
            }

        except Exception as e:
            return {
                **result,
                "response": f"加载模板失败: {str(e)}",
                "error": str(e),
            }

    # 无 TemplateService 时的降级
    return {
        **result,
        "response": "模板服务暂不可用，请稍后再试。",
        "error": "TemplateService not initialized",
    }


# =====================================================================
# help 节点（问答模式）
# =====================================================================

async def help_node(state: DocumentGenState) -> Dict[str, Any]:
    """
    help 节点：问答模式，处理用户的问题

    行为：
    - 用户输入被分类为 ASK_QUESTION 时，进入此节点
    - 回复用户问题
    - 停留在 help 节点，等待用户继续输入
    - 用户继续输入后，再次进行意图分类

    状态字段：
    - _help_return_phase: 从哪个节点来的（回复后返回）
    - _help_question: 用户之前问的问题
    """
    print(f"\n[doc_gen:help] ===== 进入帮助节点（问答模式） =====")
    
    user_message = state.get("user_message", "")
    return_phase = state.get("_help_return_phase", "collect_params")
    llm = state.get("_llm")
    
    print(f"[doc_gen:help] user_message={user_message[:80]}")
    print(f"[doc_gen:help] return_phase={return_phase}")
    
    # ========== 循环次数检查 ==========
    current_loop = state.get("loop_count", 0)
    if current_loop >= MAX_LOOP_COUNT:
        print(f"[doc_gen:help] ⚠️ 达到最大循环次数限制！")
        return {
            "phase": "error",
            "loop_limit_reached": True,
            "response": LOOP_LIMIT_ERROR,
            "error": f"loop_limit_reached: {MAX_LOOP_COUNT}",
        }
    
    # 递增循环计数
    new_loop_count = current_loop + 1
    
    # ========== 统一意图分类 ==========
    # 传递 state 以便 LLM 正确判断意图
    subflow_intent = await classify_subflow_intent(user_message, llm, state=state)
    
    # 通用意图处理
    if subflow_intent == SubflowIntent.CANCEL:
        print(f"[doc_gen:help] 意图: cancel - 结束")
        return {
            "phase": END,
            "response": "好的，已取消本次文书生成。如有需要，随时告诉我！",
            "loop_count": new_loop_count,
        }
    
    if subflow_intent == SubflowIntent.CHANGE_TEMPLATE:
        print(f"[doc_gen:help] 意图: change_template - 跳转模板选择")
        return {
            "phase": "select_template",
            "collected_params": {},
            "missing_required": [],
            "template_id": None,
            "template_name": None,
            "template_params": {},
            "response": "好的，我们重新选择文书模板。请问您想生成什么类型的文书？",
            "loop_count": new_loop_count,
        }
    
    if subflow_intent == SubflowIntent.DEFAULT:
        # DEFAULT 意图：返回原节点继续执行
        print(f"[doc_gen:help] 意图: default - 返回 {return_phase} 继续执行")
        return {
            "phase": return_phase,
            "_continue_from_help": True,  # 标记从 help 返回
            "loop_count": new_loop_count,  # 保持循环计数
        }
    
    # ASK_QUESTION 或其他：停留在 help 节点回复问题
    print(f"[doc_gen:help] 意图: {subflow_intent} - 回复用户问题，停留在 help")
    
    # 使用 LLM 回复用户问题
    if llm is not None and _doc_gen_service:
        try:
            template_name = state.get("template_name", "") or state.get("document_type", "")
            params_def = state.get("template_params", {})
            collected = state.get("collected_params", {})
            
            prompt = f"""用户在法律文书生成助手，模板：{template_name}

用户问题: "{user_message}"

已收集参数: {list(collected.keys())}

请简洁回复。如果问题关于：
- 如何填写：提供清晰指导
- 参数含义：解释法律含义
- 流程：简要说明

回复："""
            
            response = await llm.ainvoke(prompt)
            reply = response.content if hasattr(response, 'content') else str(response)
            
            return {
                "phase": "help",
                "response": reply + "\n\n💡 请继续告诉我您要填写的信息，或说「继续」返回上一阶段。",
                "loop_count": new_loop_count,
            }
            
        except Exception as e:
            print(f"[doc_gen:help] LLM 回复失败: {e}")
    
    # 降级回复
    return {
        "phase": "help",
        "response": f"您的问题是：{user_message}\n\n抱歉，我暂时无法回答这个问题。请继续填写文书信息，或说「继续」返回上一阶段。",
        "loop_count": new_loop_count,
    }


# =====================================================================
# 参数收集节点
# =====================================================================

async def collect_params_node(state: DocumentGenState) -> Dict[str, Any]:
    """
    节点2: 收集参数（使用 DocumentGenerationService）

    处理逻辑:
    1. 先进行轻量级意图分类
    2. 根据意图执行不同操作
    3. 调用 LLM 提取用户输入中的参数值
    4. 合并到已收集参数
    5. 检查是否还有缺失的必填参数
    6. 缺失则追问，齐全则进入确认
    
    【重要】此节点会调用 LLM，需要检查并递增循环次数
    """
    print(f"\n[doc_gen:collect_params] ===== 进入参数收集节点 =====")
    print(f"[doc_gen:collect_params] user_message={state.get('user_message', '')[:80]}")
    print(f"[doc_gen:collect_params] template_name={state.get('template_name', '')}")
    print(f"[doc_gen:collect_params] document_type={state.get('document_type', '')}")
    print(f"[doc_gen:collect_params] 已收集参数: {list(state.get('collected_params', {}).keys())}")
    print(f"[doc_gen:collect_params] loop_count={state.get('loop_count', 0)}/{MAX_LOOP_COUNT}")

    # ========== 循环次数检查 + 递增 ==========
    current_loop = state.get("loop_count", 0)
    if current_loop >= MAX_LOOP_COUNT:
        print(f"[doc_gen:collect_params] ⚠️ 达到最大循环次数限制！")
        return {
            "phase": "error",
            "loop_limit_reached": True,
            "response": LOOP_LIMIT_ERROR,
            "error": f"loop_limit_reached: {MAX_LOOP_COUNT}",
        }

    # ========== 轻量级意图分类 ==========
    user_message = state.get("user_message", "")
    llm = state.get("_llm")  # 从 state 获取 LLM
    
    # 传递 state 以便 LLM 正确判断意图
    subflow_intent = await classify_subflow_intent(user_message, llm, state=state)
    
    # 获取当前模板状态（从多个来源）
    collected = state.get("collected_params", {})
    current_template_id = state.get("template_id") or collected.get("template_id")
    current_template_name = state.get("template_name") or collected.get("template_name")
    
    print(f"[doc_gen:collect_params] 模板状态检查:")
    print(f"[doc_gen:collect_params]   state.template_id={state.get('template_id')}")
    print(f"[doc_gen:collect_params]   collected.template_id={collected.get('template_id')}")
    print(f"[doc_gen:collect_params]   current_template_id={current_template_id}")
    
    # 根据意图处理
    if subflow_intent == SubflowIntent.CANCEL:
        print(f"[doc_gen:collect_params] 意图: cancel - 清空状态，结束")
        return {
            "phase": END,
            "collected_params": {},
            "missing_required": [],
            "template_id": None,
            "template_name": None,
            "template_params": {},
            "response": "好的，已取消本次文书生成。如有需要，随时告诉我！",
        }
    
    if subflow_intent == SubflowIntent.CHANGE_TEMPLATE:
        # 重要：如果已经有 template_id，说明这是 Widget 选择结果，不应该清空状态
        # 只更新 template_name（如果消息中包含新的模板名）
        print(f"[doc_gen:collect_params] 意图: change_template - 检查是否需要更换模板")
        
        # 检查消息中是否明确要更换模板（排除 Widget 选择的情况）
        message_lower = user_message.lower()
        is_widget_selection = "选择模板" in user_message or "template" in message_lower
        
        if current_template_id and not is_widget_selection:
            # 有模板ID且不是 Widget 选择：检查是否真的想换模板
            print(f"[doc_gen:collect_params] 当前已有 template_id={current_template_id}，忽略 change_template 意图")
            # 继续执行原有逻辑，不清空状态
        elif current_template_id and is_widget_selection:
            # Widget 选择已完成：更新模板信息
            print(f"[doc_gen:collect_params] Widget 选择完成，更新模板信息")
            # 从 collected_params 获取新的模板信息
            new_template_id = state.get("collected_params", {}).get("template_id")
            new_template_name = state.get("collected_params", {}).get("template_name")
            
            if new_template_id and new_template_id != current_template_id:
                print(f"[doc_gen:collect_params] 模板已更换: {current_template_id} -> {new_template_id}")
                return {
                    "phase": "select_template",  # 返回选择节点加载新模板
                    "template_id": None,  # 清空让选择节点重新匹配
                    "template_name": None,
                    "template_params": {},
                    "collected_params": {},
                    "missing_required": [],
                    "response": "好的，正在为您加载新模板...",
                }
            else:
                # 模板未变，继续参数收集
                print(f"[doc_gen:collect_params] 模板未更换，继续参数收集")
        else:
            # 没有 template_id：允许更换模板
            print(f"[doc_gen:collect_params] 切换到模板选择")
            return {
                "phase": "select_template",
                "collected_params": {},
                "missing_required": [],
                "template_id": None,
                "template_name": None,
                "template_params": {},
                "response": "好的，我们重新选择文书模板。请问您想生成什么类型的文书？",
            }
    
    if subflow_intent == SubflowIntent.ASK_QUESTION:
        # ask_question 意图：转发到 help 节点（问答模式）
        print(f"[doc_gen:collect_params] 意图: ask_question - 转发到 help 节点")
        return {
            "phase": "help",
            "_help_return_phase": "collect_params",  # 返回时继续参数收集
            "response": "好的，请问您有什么问题？",  # 临时响应，会被 help 节点覆盖
            "loop_count": current_loop,  # 保持循环计数不变
        }
    
    # confirm 意图：用户确认生成，进入确认节点
    if subflow_intent == "confirm":
        print(f"[doc_gen:collect_params] 意图: confirm - 进入确认节点")
        return {
            "phase": "confirm",
            "response": "好的，正在为您生成文书...",  # 会被 confirm_node 覆盖
            "loop_count": current_loop,  # 保持循环计数不变
        }
    
    # 默认：继续执行原有参数提取逻辑
    print(f"[doc_gen:collect_params] 意图: default - 继续原有逻辑")
    # ========================================
    
    # 递增循环计数（因为此节点会调用 LLM）
    new_loop_count = current_loop + 1
    print(f"[doc_gen:collect_params] 递增 loop_count: {current_loop} → {new_loop_count}")

    result: Dict[str, Any] = {
        "phase": "collect_params",
        "loop_count": new_loop_count,
    }

    # 获取模板信息（从多个来源）
    template_id = current_template_id or state.get("template_id")
    template_name = state.get("template_name", "") or state.get("document_type", "")
    params_def = state.get("template_params", {})
    
    # 如果 params_def 为空但有 template_id，从服务加载
    if not params_def and template_id and _template_service:
        print(f"[doc_gen:collect_params] params_def 为空，尝试从 template_id={template_id} 加载")
        try:
            # 通过 template_id 获取模板详情
            template = await _template_service.get_template_by_id(template_id)
            if template:
                # 【修复】统一参数定义来源，优先级：params_def > params_definition > placeholder_dict
                params_def = (
                    template.get("params_def", {}) 
                    or template.get("params_definition", {})
                )
                # 如果前两者为空，尝试从 placeholder_dict 获取
                if not params_def:
                    pd_val = template.get("placeholder_dict")
                    if pd_val:
                        if isinstance(pd_val, dict):
                            # 【修复】使用 TemplateManager._convert_to_params_def 转换格式
                            # 支持标准格式 {"key": {...}} 和示例值格式 {"key": "示例值"}
                            params_def = _convert_params_def(pd_val)
                        elif isinstance(pd_val, str) and pd_val.strip():
                            import json
                            try:
                                pd_dict = json.loads(pd_val)
                                params_def = _convert_params_def(pd_dict)
                            except json.JSONDecodeError:
                                print(f"[doc_gen:collect_params] placeholder_dict 解析失败")
                print(f"[doc_gen:collect_params] 已加载 params_def: {list(params_def.keys()) if params_def else '空'}")
        except Exception as e:
            print(f"[doc_gen:collect_params] 加载 params_def 失败: {e}")
    
    collected = dict(state.get("collected_params", {}))
    message = state.get("user_message", "")

    if not _doc_gen_service:
        print(f"[doc_gen:collect_params] 错误: _doc_gen_service 未初始化")
        return {
            **result,
            "collected_params": collected,
            "response": "文书生成服务暂不可用，请稍后再试。",
            "error": "DocumentGenerationService not initialized",
        }

    try:
        collect_result = await _doc_gen_service.collect_params(
            user_message=message,
            template_name=template_name,
            params_def=params_def,
            collected_params=collected,
        )

        print(f"[doc_gen:collect_params] 参数提取完成:")
        print(f"  - 新收集参数: {list(collect_result.collected_params.keys())}")
        print(f"  - 缺失必填: {collect_result.missing_required}")
        print(f"  - 返回阶段: {collect_result.phase}")
        print(f"[doc_gen:collect_params] ===== 节点执行完成 =====\n")

        # 关键修复：根据缺失参数决定下一阶段，而不是依赖 collect_result.phase
        # collect_result.phase 可能不准确（如 LLM 返回 "collect_params" 但参数已齐全）
        next_phase = "collect_params"
        if not collect_result.missing_required:
            # 参数已齐全，进入确认阶段
            next_phase = "confirm"
            print(f"[doc_gen:collect_params] >>> 参数齐全，进入 confirm 阶段")

        return {
            **result,
            "collected_params": collect_result.collected_params,
            "missing_required": collect_result.missing_required,
            "response": collect_result.response_text,
            "widget": collect_result.widget,
            "phase": next_phase,  # 使用计算后的 phase，而不是 LLM 返回的
            "loop_count": new_loop_count,  # 携带循环计数
        }

    except Exception as e:
        import traceback
        print(f"[doc_gen:collect_params] 参数提取失败: {e}")
        print(f"[doc_gen:collect_params] 堆栈: {traceback.format_exc()}")
        return {
            **result,
            "collected_params": collected,
            "response": f"参数处理遇到问题，请重新输入信息。错误: {str(e)}",
            "loop_count": new_loop_count,  # 即使失败也携带循环计数
        }


async def confirm_node(state: DocumentGenState) -> Dict[str, Any]:
    """
    节点3: 确认生成
    
    确认节点职责：
    1. 展示完整的参数确认界面（调用字典格式化）
    2. 接收用户输入 + 统一意图分类
    3. 根据意图转发：
       - CANCEL → END
       - CHANGE_TEMPLATE → select_template
       - MODIFY → collect_params（回退，带已有参数）
       - ASK_QUESTION → 简短确认，直接生成
       - DEFAULT → 交给 LLM 判断 confirm/modify
    """
    message = state.get("user_message", "")
    collected_params = state.get("collected_params", {})
    
    print(f"\n[doc_gen:confirm] ===== 进入确认节点 =====")
    print(f"[doc_gen:confirm] user_message={message[:80] if message else '(empty)'}")
    current_loop = state.get("loop_count", 0)
    print(f"[doc_gen:confirm] loop_count={current_loop}/{MAX_LOOP_COUNT}")
    
    # ========== 优先处理 Widget 操作 ==========
    # 如果用户是通过点击按钮操作的（message 为空），从 collected_params 获取 widget_action
    widget_action = collected_params.get("widget_action", "")
    if widget_action:
        print(f"[doc_gen:confirm] 检测到 Widget 操作: {widget_action}")
        
        if widget_action in ("confirm", "confirm_generate", "生成", "确认"):
            print(f"[doc_gen:confirm] Widget 操作: 确认生成")
            return {
                "phase": "generating",
                "_confirmed": True,
                "response": "好的，开始生成文书...",
                "loop_count": current_loop,
            }
        
        if widget_action in ("cancel", "cancel_generate", "取消"):
            print(f"[doc_gen:confirm] Widget 操作: 取消生成")
            return {
                "phase": END,
                "collected_params": {},
                "missing_required": [],
                "template_id": None,
                "template_name": None,
                "template_params": {},
                "response": "好的，已取消本次文书生成。如有需要，随时告诉我！",
                "loop_count": current_loop,
            }
        
        if widget_action in ("modify", "change_params", "修改"):
            print(f"[doc_gen:confirm] Widget 操作: 修改参数")
            return {
                "phase": "collect_params",
                "collected_params": collected_params,  # 保留已有参数
                "missing_required": [],  # 清空缺失，收集节点会重新计算
                "response": "好的，请告诉我需要修改的内容。",
                "loop_count": current_loop,
            }
    # ==========================================
    
    # ========== 循环次数检查 ==========
    current_loop = state.get("loop_count", 0)
    if current_loop >= MAX_LOOP_COUNT:
        print(f"[doc_gen:confirm] 达到最大循环次数限制！")
        return {
            "phase": "error",
            "loop_limit_reached": True,
            "response": LOOP_LIMIT_ERROR,
            "error": f"loop_limit_reached: {MAX_LOOP_COUNT}",
        }
    
    # 获取上下文信息
    collected_params = state.get("collected_params", {})
    params_def = state.get("template_params", {})
    template_name = state.get("template_name", "")
    llm = state.get("_llm")
    
    # ========== 统一意图分类（传入 context="confirm" 以启用 MODIFY 意图）==========
    # 传递 state 以便 LLM 正确判断意图
    subflow_intent = await classify_subflow_intent(message, llm, context="confirm", state=state)
    
    # ========== 基础意图处理 ==========
    
    # cancel - 清空状态，结束
    if subflow_intent == SubflowIntent.CANCEL:
        print(f"[doc_gen:confirm] 意图: cancel")
        return {
            "phase": END,
            "collected_params": {},
            "missing_required": [],
            "response": "好的，已取消本次文书生成。如有需要，随时告诉我！",
        }
    
    # change_template - 跳转模板选择
    if subflow_intent == SubflowIntent.CHANGE_TEMPLATE:
        print(f"[doc_gen:confirm] 意图: change_template")
        return {
            "phase": "select_template",
            "collected_params": {},
            "missing_required": [],
            "template_id": None,
            "template_name": None,
            "template_params": {},
            "response": "好的，我们重新选择文书模板。请问您想生成什么类型的文书？",
        }
    
    # ========== confirm 节点特有意图 ==========
    
    # MODIFY - 回退到参数收集（带已有参数）
    if subflow_intent == SubflowIntent.MODIFY:
        print(f"[doc_gen:confirm] 意图: modify - 回退到参数收集")
        
        updated_params = await _handle_modify_request(
            message=message,
            collected_params=collected_params,
            params_def=params_def,
        )
        
        return {
            "phase": "collect_params",
            "collected_params": updated_params,
            "missing_required": [],  # 清空缺失，收集节点会重新计算
            "response": "好的，请告诉我需要修改的内容。",
        }
    
    # ASK_QUESTION - 简短确认，直接生成
    if subflow_intent == SubflowIntent.ASK_QUESTION:
        print(f"[doc_gen:confirm] 意图: ask_question - 简短确认，直接生成")
        
        # 递增循环计数
        new_loop_count = current_loop + 1
        
        return {
            "phase": "generating",
            "_confirmed": True,
            "response": "好的，开始生成文书...",
            "loop_count": new_loop_count,
        }
    
    # ========== DEFAULT 意图 - 交给 LLM 判断 ==========
    print(f"[doc_gen:confirm] 意图: default - LLM 判断 confirm/modify")
    
    # 递增循环计数（LLM 调用）
    new_loop_count = current_loop + 1
    
    prompt = f"""用户回复: "{message}"

当前状态:
- 模板: {template_name}
- 已收集参数: {list(collected_params.keys())}

请分析用户意图，输出 JSON:
{{"intent": "confirm|modify", "reason": "原因说明"}}

意图说明:
- confirm: 用户明确表示要生成/确认（如"生成"、"好的"、"确认"、"开始"）
- modify: 用户要修改参数或补充信息

注意:
- 只有用户明确说要生成/确认时才是 confirm
- 其他情况都是 modify
"""
    
    try:
        if _doc_gen_service and _doc_gen_service._llm:
            response = await _doc_gen_service._llm.ainvoke(prompt)
            content = response.content if hasattr(response, 'content') else str(response)
            
            print(f"[doc_gen:confirm] LLM 判断: {content[:200]}")
            
            import json, re
            json_match = re.search(r'\{"intent":\s*"([^"]+)"', content)
            if json_match:
                intent = json_match.group(1)
                
                if intent == "confirm":
                    return {
                        "phase": "generating",
                        "_confirmed": True,
                        "response": "好的，开始生成文书...",
                        "loop_count": new_loop_count,
                    }
                
                # modify - 回退到参数收集
                updated_params = await _handle_modify_request(
                    message=message,
                    collected_params=collected_params,
                    params_def=params_def,
                )
                confirm_text = _build_confirm_text(template_name, updated_params, params_def)
                return {
                    "phase": "confirm",
                    "collected_params": updated_params,
                    "response": confirm_text + "\n\n💡 请回复：**确认生成** / **取消** / 或告诉我需要修改的内容",
                    "loop_count": new_loop_count,
                }
                
    except Exception as e:
        print(f"[doc_gen:confirm] LLM 调用失败: {e}")
    
    # LLM 调用失败：停留在 confirm 阶段
    confirm_text = _build_confirm_text(template_name, collected_params, params_def)
    return {
        "phase": "confirm",
        "response": confirm_text + "\n\n💡 请回复：**确认生成** / **取消** / 或告诉我需要修改的内容",
        "loop_count": new_loop_count,
    }


async def _handle_modify_request(
    message: str,
    collected_params: Dict[str, str],
    params_def: Dict[str, Any],
) -> Dict[str, str]:
    """
    处理参数修改请求，包括批量修改（如"都填为XXX"）
    
    Args:
        message: 用户消息
        collected_params: 当前已收集的参数
        params_def: 参数定义
    
    Returns:
        更新后的参数字典
    """
    if not _doc_gen_service:
        return collected_params
    
    try:
        # 使用 DocumentGenerationService 的参数提取逻辑
        collect_result = await _doc_gen_service.collect_params(
            user_message=message,
            template_name="",
            params_def=params_def,
            collected_params=collected_params,
        )
        
        print(f"[doc_gen:_handle_modify_request] 更新后参数: {list(collect_result.collected_params.keys())}")
        return collect_result.collected_params
    except Exception as e:
        print(f"[doc_gen:_handle_modify_request] 参数更新失败: {e}")
        return collected_params


async def generate_node(state: DocumentGenState) -> Dict[str, Any]:
    """
    节点4: 执行文书生成（使用 DocumentGenerationService）

    处理逻辑:
    - 调用文书生成服务
    - 保存结果到项目目录
    - 返回成功响应 + Widget
    """
    print(f"[doc_gen:generate] 开始生成文书...")

    template_name = state.get("template_name", "") or state.get("document_type", "未知模板")
    params = state.get("collected_params", {})
    conversation_id = state.get("conversation_id")

    result: Dict[str, Any] = {"phase": "generating"}

    if not _doc_gen_service:
        return {
            **result,
            "phase": "error",
            "error": "DocumentGenerationService not initialized",
            "response": "文书生成服务暂不可用，请稍后再试。",
        }

    # 构建项目目录路径（直接从 state 获取 project_id）
    output_dir = None
    project_id = state.get("project_id")
    if project_id:
        from ...config import settings
        import os
        output_dir = os.path.join(settings.UPLOAD_DIR, f"project_{project_id}")
        print(f"[doc_gen:generate] 项目目录: {output_dir}")

    try:
        gen_result = await _doc_gen_service.generate(
            template_name=template_name,
            collected_params=params,
            output_dir=output_dir,
            template_id=state.get("template_id"),
            project_id=state.get("project_id"),
        )

        return {
            **result,
            "generated_content": gen_result.content,
            "file_path": gen_result.file_path,
            "generation_metadata": {
                "template_name": template_name,
                "params_used": params,
                "filename": gen_result.filename,
            },
            "phase": "completed",
            "response": gen_result.response_text,
            "widget": gen_result.widget,
        }

    except Exception as e:
        print(f"[doc_gen:generate] 生成失败: {e}")
        import traceback
        traceback.print_exc()

        return {
            **result,
            "phase": "error",
            "error": str(e),
            "response": f"文书生成失败：{str(e)}",
        }


# =====================================================================
# 条件边函数
# =====================================================================

def route_after_select_template(state: DocumentGenState) -> str:
    """
    选择模板后的路由判断
    
    Returns:
        "collect_params" - 已有模板，进入参数收集
        END - 需要等待用户选择模板
    """
    print(f"[route_after_select_template] template_id={state.get('template_id')}, phase={state.get('phase')}")
    
    if state.get("template_id"):
        print(f"[route_after_select_template] 已选模板，进入参数收集")
        return "collect_params"
    
    # 没有 template_id 时，返回 END 等待用户选择
    print(f"[route_after_select_template] 需要等待用户选择模板")
    return END


def route_after_collect_params(state: DocumentGenState) -> str:
    """
    参数收集后的路由判断
    
    Returns:
        END - 等待用户输入（参数不齐全，需要用户回复）
        "confirm" - 参数齐全且用户未确认，显示确认界面
        "collect_params" - 用户确认生成，进入确认节点
        "help" - ASK_QUESTION 意图，进入问答模式
    """
    missing = state.get("missing_required", [])
    phase = state.get("phase", "")
    response = state.get("response", "")
    
    print(f"[route_after_collect_params] missing={missing}, phase={phase}, has_response={bool(response)}")
    
    # help 节点返回：继续返回原节点
    if phase == "help" or state.get("_continue_from_help"):
        return_state = state.get("_help_return_phase", "collect_params")
        print(f"[route_after_collect_params] 从 help 返回，继续执行: {return_state}")
        return return_state
    
    # 用户已确认（phase="confirm"），进入 confirm_node 处理生成
    if phase == "confirm":
        print(f"[route_after_collect_params] 用户已确认，进入 confirm_node 处理")
        return "confirm"
    
    # 如果有缺失参数，应该等待用户输入（返回 END）
    # LangGraph 会在返回 END 后停止本次执行，等待下次 API 调用
    if missing and len(missing) > 0:
        print(f"[route_after_collect_params] 仍有缺失参数，等待用户输入")
        return END  # 等待用户输入
    
    # 参数齐全且未确认（phase="collect_params"），显示确认界面
    # 返回 END 让前端显示确认界面，用户确认后才会进入 confirm_node 处理
    print(f"[route_after_collect_params] 参数已齐全，显示确认界面，等待用户确认")
    return END


def route_after_confirm(state: DocumentGenState) -> str:
    """
    确认节点的路由判断
    
    Returns:
        "generate" - 用户确认生成
        "select_template" - 用户取消
        "collect_params" - 用户想修改参数
        END - 显示确认界面，等待用户下一步操作
    """
    phase = state.get("phase")
    print(f"[route_after_confirm] phase={phase}")
    
    if phase == "generating":
        return "generate"
    if phase == "select_template":
        return "select_template"
    if phase == "collect_params":
        return "collect_params"
    
    # phase == "confirm" 或其他情况：显示确认界面，等待用户输入
    print(f"[route_after_confirm] 显示确认界面，等待用户操作（用户可回复：确认生成/取消/修改参数）")
    return END


def route_after_help(state: DocumentGenState) -> str:
    """
    help 节点的路由判断
    
    Returns:
        "help" - 停留在 help 节点（继续回复用户问题）
        "select_template" - 用户想换模板
        "collect_params" - 用户想继续填写参数
        END - 等待用户输入
    """
    phase = state.get("phase", "")
    
    print(f"[route_after_help] phase={phase}")
    
    if phase == "select_template":
        return "select_template"
    if phase == "collect_params":
        return "collect_params"
    
    # phase == "help" 或其他情况：停留在 help 节点继续回复问题
    print(f"[route_after_help] 停留在 help 节点，等待用户继续输入")
    return "help"


# =====================================================================
# 图构建函数 ====================

def build_document_gen_graph(
    llm: Any = None,
    db: Any = None,
):
    """
    构建文书生成状态机图

    内部初始化 TemplateService 和 DocumentGenerationService，
    并存储在模块级别供节点函数访问（替代 ContextVar）。

    Args:
        llm: LawChatLLM 实例
        db: 数据库会话（用于模板查询）

    Returns:
        编译后的 CompiledGraph 实例

    使用示例:
        >>> graph = build_document_gen_graph(law_llm, db_session)
        >>> state = await graph.ainvoke(
        ...     {"user_message": "帮我写起诉状", "conversation_id": 123},
        ...     config={"configurable": {"thread_id": "conv_001"}}
        ... )
    """
    global _template_service, _doc_gen_service

    if not LANGGRAPH_AVAILABLE:
        raise ImportError(
            "LangGraph 未安装。请运行: pip install langgraph\n"
            "或者降级使用 workflows.py 中的旧实现。"
        )

    # 初始化服务（替代 ContextVar）
    from ..services import TemplateService, DocumentGenerationService
    from ...config import settings
    import os

    _template_service = TemplateService(db)
    # 文书保存到 settings.UPLOAD_DIR/generated 目录
    output_dir = os.path.join(settings.UPLOAD_DIR, "generated")
    _doc_gen_service = DocumentGenerationService(llm, template_service=_template_service, output_dir=output_dir)

    # 创建图
    graph = StateGraph(DocumentGenState)

    # 注册节点
    graph.add_node("select_template", select_template_node)
    graph.add_node("collect_params", collect_params_node)
    graph.add_node("help", help_node)
    graph.add_node("confirm", confirm_node)
    graph.add_node("generate", generate_node)

    # 设置入口
    graph.set_entry_point("select_template")

    # 定义条件边
    graph.add_conditional_edges(
        "select_template",
        route_after_select_template,
        {
            "collect_params": "collect_params",
            END: END,  # 等待用户选择模板
        },
    )

    graph.add_conditional_edges(
        "collect_params",
        route_after_collect_params,
        {
            "collect_params": "collect_params",  # 追问
            "confirm": "confirm",
            "help": "help",  # 问答模式
            END: END,  # 等待用户输入
        },
    )

    # help 节点路由：根据意图返回不同节点
    graph.add_conditional_edges(
        "help",
        route_after_help,
        {
            "help": "help",           # 停留在 help（继续问答）
            "select_template": "select_template",
            "collect_params": "collect_params",
            END: END,               # 等待用户输入
        },
    )

    graph.add_conditional_edges(
        "confirm",
        route_after_confirm,
        {
            "generate": "generate",
            "select_template": "select_template",
            "collect_params": "collect_params",
            END: END,  # 等待用户确认/取消/修改
        },
    )

    graph.add_edge("generate", END)

    from ..checkpointer import get_checkpointer
    return graph.compile(checkpointer=get_checkpointer())


def get_graph_mermaid() -> str:
    """
    获取文书生成图的 Mermaid 代码表示
    
    Returns:
        Mermaid 格式的图代码字符串
    """
    # 动态获取当前图的 Mermaid 表示（如果 LangGraph 可用）
    if LANGGRAPH_AVAILABLE:
        graph = build_document_gen_graph()
        try:
            return graph.get_graph().draw_mermaid()
        except Exception as e:
            print(f"[get_graph_mermaid] 获取图失败: {e}")
    
    # 返回静态 Mermaid 代码（作为后备）
    return "无"



# =====================================================================
# 辅助函数 ====================

def _convert_params_def(placeholder_dict: Dict) -> Dict[str, Dict]:
    """
    将占位符字典转换为标准参数定义格式
    
    支持三种格式：
    1. 标准格式: {"key": {"label": "...", "required": true, ...}}
    2. 示例值格式: {"key": "示例值"} → 自动转换为标准格式
    3. 新Schema格式 (v2.0): {"_version": "2.0", "fields": {...}, "conditional_blocks": [...], ...}
       → 从 fields 中提取参数定义，附加条件逻辑
    
    示例值格式中，Unicode符号（如 ☑ □ √ 等）会保留在description中
    """
    # ========== 检测并处理新Schema格式 (v2.0) ==========
    if placeholder_dict.get("_version") == "2.0" or "fields" in placeholder_dict:
        print(f"[_convert_params_def] 检测到新Schema格式 (v2.0)，从 fields 中提取参数定义")
        fields = placeholder_dict.get("fields", {})
        params = {}
        for key, value in fields.items():
            if isinstance(value, dict):
                params[key] = value
            else:
                params[key] = {
                    "label": key,
                    "required": False,
                    "type": "text",
                    "description": str(value) if value is not None else ""
                }
        # 附加条件逻辑元数据
        if "conditional_blocks" in placeholder_dict:
            params["__conditional_blocks__"] = placeholder_dict["conditional_blocks"]
        if "checkbox_formatting" in placeholder_dict:
            params["__checkbox_formatting__"] = placeholder_dict["checkbox_formatting"]
        return params
    
    # ========== 旧格式处理 ==========
    params = {}
    for key, value in placeholder_dict.items():
        if isinstance(value, dict):
            params[key] = value
        else:
            # 示例值格式：自动转换为参数定义
            str_value = str(value) if value is not None else ""
            # 判断是否包含选择框格式的Unicode符号
            has_checkbox = any(s in str_value for s in ["☑", "□", "√", "■", "×", "○", "●"])
            
            params[key] = {
                "label": key,
                "required": not has_checkbox and bool(str_value.strip()),  # 有选择框的可选，其他必填
                "type": "checkbox" if has_checkbox else "text",
                "description": str_value  # 保留原始值，包括 Unicode 符号
            }
    
    return params


def _format_param_list(params_def: Dict[str, Any]) -> str:
    """格式化参数列表为文本"""
    required = [(k, v) for k, v in params_def.items() if v.get("required")]
    optional = [(k, v) for k, v in params_def.items() if not v.get("required")]
    
    lines = []
    for i, (key, info) in enumerate(required, 1):
        lines.append(f"{i}. **{info.get('label', key)}** （必填）")
    
    if optional:
        lines.append("\n可选信息：")
        for key, info in optional:
            lines.append(f"- {info.get('label', key)}")
    
    return "\n".join(lines)


def _build_missing_prompt(
    template_name: str,
    params_def: Dict[str, Any],
    missing: List[str],
    collected: Dict[str, str],
) -> str:
    """构建缺失参数追问提示"""
    prompt = f"好的，我已收集到以下信息：\n"
    
    for key, value in collected.items():
        if value:
            label = params_def.get(key, {}).get("label", key)
            prompt += f"✅ {label}：{value}\n"
    
    prompt += "\n还缺少以下**必填信息**，请补充：\n"
    for key in missing:
        label = params_def.get(key, {}).get("label", key)
        prompt += f"• {label}\n"
    
    return prompt


def _build_params_widget(
    params_def: Dict[str, Any],
    collected: Dict[str, str],
) -> Dict[str, Any]:
    """构建参数表单Widget"""
    fields = []
    for key, info in params_def.items():
        fields.append({
            "name": key,
            "label": info.get("label", key),
            "type": info.get("type", "text"),
            "required": info.get("required", False),
            "value": collected.get(key, ""),
            "placeholder": f"请输入{info.get('label', key)}",
        })
    
    return {
        "type": "form",
        "title": "填写信息",
        "fields": fields,
    }


def _build_confirm_text(
    template_name: Optional[str], 
    params: Dict[str, str],
    params_def: Optional[Dict[str, Any]] = None,
) -> str:
    """
    构建确认文本
    
    适配新Schema格式 (v2.0)：
    - 支持 single_choice 类型显示选项
    - 支持 conditional_blocks 条件逻辑
    - 支持 checkbox_formatting 复选框格式
    """
    name = template_name or "未知模板"
    text = f"✅ 所有信息已收集完毕！\n\n📋 **{name}**\n"
    
    # 获取条件逻辑元数据
    conditional_blocks = None
    checkbox_formatting = None
    if params_def:
        conditional_blocks = params_def.get("__conditional_blocks__")
        checkbox_formatting = params_def.get("__checkbox_formatting__")
        # 从显示中过滤掉元数据键
        _display_params = {k: v for k, v in params.items() if not k.startswith("__")}
    else:
        _display_params = params
    
    # 构建字段显示列表（应用条件逻辑）
    hidden_fields = set()
    if conditional_blocks:
        for block in conditional_blocks:
            block_type = block.get("type")
            trigger = block.get("trigger")
            trigger_value = params.get(trigger)
            
            if block_type == "show_or_hide":
                show_when = block.get("show_when", [])
                if trigger_value not in show_when:
                    # 触发条件不满足，隐藏关联字段
                    affected = block.get("affected_fields", [])
                    hidden_fields.update(affected)
                    
            elif block_type == "clear_detail":
                clear_when = block.get("clear_when", [])
                detail_field = block.get("detail_field")
                if trigger_value in clear_when:
                    # 触发条件满足，清空详情字段值
                    if detail_field in params:
                        _display_params[detail_field] = ""
    
    # 获取复选框符号
    checked = checkbox_formatting.get("checked_symbol", "☑") if checkbox_formatting else "☑"
    unchecked = checkbox_formatting.get("unchecked_symbol", "□") if checkbox_formatting else "□"
    
    # 构建显示文本
    for key, value in _display_params.items():
        if key.startswith("__"):
            continue
        if key in hidden_fields:
            continue
        
        # 获取字段定义
        field_def = {}
        if params_def and key in params_def and not key.startswith("__"):
            field_def = params_def[key]
        
        # 获取显示标签
        label = field_def.get("label", key)
        
        # 处理不同类型的显示
        field_type = field_def.get("type", "text")
        if field_type == "single_choice":
            options = field_def.get("options", [])
            # 显示为选项列表，选中的用 ☑ 标记
            option_lines = []
            for opt in options:
                symbol = checked if value == opt else unchecked
                option_lines.append(f"  {symbol} {opt}")
            text += f"• {label}：\n" + "\n".join(option_lines) + "\n"
        elif field_type == "checkbox":
            # 复选框类型，显示符号和描述
            desc = field_def.get("description", value)
            symbol = checked if value and value != "false" else unchecked
            text += f"• {label}：{symbol} {desc}\n"
        elif value:
            # 普通文本字段
            text += f"• {label}：{value}\n"
    
    text += "\n是否确认生成文书？"
    return text

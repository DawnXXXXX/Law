"""
案件分析报告子工作流 (CaseAnalysisGraph)

四节点状态机：
    要素抽取(LLM) → 多路检索与统计(非LLM) → 深度案例分析(LLM) → 报告生成存储(非LLM)

输入用户案情描述 → 输出结构化 Markdown 案件分析报告 + PDF 存档
"""

from __future__ import annotations

import json
import os
import asyncio
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any, Dict, List, Optional

try:
    from langgraph.graph import StateGraph, END
    LANGGRAPH_AVAILABLE = True
except ImportError:
    StateGraph = None
    END = None
    LANGGRAPH_AVAILABLE = False

from ...config import settings


# =====================================================================
# 判决结果正则规则库
# =====================================================================

VERDICT_PATTERNS = [
    # 无罪/不支持
    (r"宣告无罪", "无罪"),
    (r"无罪", "无罪"),
    (r"驳回.*(?:诉讼|起诉|上诉|请求)", "不支持"),
    (r"不予支持", "不支持"),
    (r"驳回上诉，维持原判", "不支持"),
    # 有罪/支持（刑事案件）
    (r"判处(?:拘役|有期徒刑|管制|死刑|罚金)", "支持"),
    (r"以.*罪.*判处", "支持"),
    (r"数罪并罚", "支持"),
    # 支持（民事案件）
    (r"支持.*(?:诉讼|全部)", "支持"),
    (r"准予.*(?:离婚|诉讼|赔偿)", "支持"),
    (r"准许.*(?:离婚|原告|请求)", "支持"),
    (r"判令.*(?:赔偿|停止|返还)", "支持"),
    (r"判决.*(?:赔偿|支持)", "支持"),
    # 部分支持
    (r"部分支持", "部分支持"),
    (r"部分驳回", "部分支持"),
    (r"各承担", "部分支持"),
    # 调解
    (r"调解", "调解"),
    (r"达成协议", "调解"),
    # 撤诉
    (r"撤诉", "撤诉"),
    (r"撤回起诉", "撤诉"),
    (r"按撤诉处理", "撤诉"),
]


def extract_verdict(text: str) -> str:
    """从判决文本中快速提取判决结果类型"""
    for pattern, label in VERDICT_PATTERNS:
        import re
        if re.search(pattern, text):
            return label
    return "其他"


# =====================================================================
# State 定义
# =====================================================================

class CaseAnalysisState(Dict):
    """案件分析报告工作流状态"""
    user_input: str = ""
    extracted_elements: Dict[str, Any] = {}
    verdict_distribution: Dict[str, int] = {}
    top3_cases: List[Dict] = []
    case_analysis: List[Dict] = []
    laws_summary: List[str] = []
    retrieved_laws: List[Dict] = []  # 通过API检索到的法律法规
    report_markdown: str = ""
    report_data: Dict[str, Any] = {}  # 可视化报告数据（sections 结构）
    pdf_url: str = ""
    _llm: Any = None


# =====================================================================
# 节点函数
# =====================================================================


async def node_extract_elements(state: CaseAnalysisState) -> Dict[str, Any]:
    """节点1: 要素抽取 - 从案情描述中提取结构化要素"""
    from ..prompts import CASE_EXTRACT_PROMPT
    from ..parsers import case_extract_parser as parser

    user_input = state.get("user_input", "").strip()
    
    # 如果输入为空或太短，使用默认空值
    if len(user_input) < 10:
        print(f"[CaseAnalysis] ⚠️ 案情描述过短，无法提取要素")
        return {
            **state,
            "extracted_elements": {
                "dispute_type": user_input or "未指定",
                "core_facts": user_input,
                "claims": [],
                "key_issues": [],
            }
        }

    llm = state.get("_llm")
    chain = CASE_EXTRACT_PROMPT | llm | parser

    try:
        result = await chain.ainvoke({
            "case_description": user_input,
            "format_instructions": parser.get_format_instructions(),
        })

        elements = {
            "dispute_type": result.dispute_type or "未指定",
            "core_facts": result.core_facts or user_input,
            "claims": list(result.claims) if result.claims else [],
            "key_issues": list(result.key_issues) if result.key_issues else [],
        }
    except Exception as e:
        print(f"[CaseAnalysis] ⚠️ 要素抽取失败: {e}，使用原始输入作为核心事实")
        elements = {
            "dispute_type": "未指定",
            "core_facts": user_input,
            "claims": [],
            "key_issues": [],
        }

    print(f"[CaseAnalysis] 要素抽取完成: 类型={elements['dispute_type']}")
    return {**state, "extracted_elements": elements}


async def node_multi_retrieve(state: CaseAnalysisState) -> Dict[str, Any]:
    """节点2: 多路检索与统计 - 根据纠纷类型批量获取案例 + 法律法规 + 判决分布统计"""
    from ..tools import search_cases_paged, search_laws_paged
    from ..services.similar_case_service import SimilarCaseRetrievalService
    import asyncio

    elements = state.get("extracted_elements", {})
    dispute_type = elements.get("dispute_type", "")
    user_case = state.get("user_input", "")
    core_facts = elements.get("core_facts", user_case)

    # 构建检索关键词（如果纠纷类型为空或太短，使用用户输入）
    if dispute_type and len(dispute_type) > 2:
        keywords = dispute_type
        issues = elements.get("key_issues", [])
        if issues:
            keywords += " " + " ".join(issues[:3])
    else:
        # 纠纷类型为空时，使用用户输入作为关键词
        keywords = user_case[:100]  # 限制关键词长度
        print(f"[CaseAnalysis] ⚠️ 纠纷类型为空，使用用户输入作为关键词: {keywords[:50]}...")

    print(f"[CaseAnalysis] 开始并行检索案例与法律法规，关键词: {keywords}")
    
    # 并行检索案例和法律法规
    async def _get_cases():
        try:
            return await search_cases_paged(keywords, page_size=10, max_pages=5)
        except Exception as e:
            print(f"[CaseAnalysis] ⚠️ 案例检索异常: {e}")
            return []

    async def _get_laws():
        try:
            return await search_laws_paged(keywords, page_size=10, max_pages=2)
        except Exception as e:
            print(f"[CaseAnalysis] ⚠️ 法规检索异常: {e}")
            return []

    cases, laws = await asyncio.gather(_get_cases(), _get_laws())

    if not cases:
        print("[CaseAnalysis] 未检索到案例")
        return {**state, "top3_cases": [], "verdict_distribution": {}, "retrieved_laws": laws}

    # 判决结果分布统计
    distribution: Dict[str, int] = {}
    for case in cases:
        text = case.get("content") or case.get("full_text") or case.get("summary") or ""
        verdict = extract_verdict(text)
        distribution[verdict] = distribution.get(verdict, 0) + 1

    # 类案语义精选 Top 3
    service = SimilarCaseRetrievalService()
    top3 = service.retrieve_similar_cases(core_facts, cases, top_k=3)

    print(f"[CaseAnalysis] 检索完成: 案例{len(cases)}条, 法律法规{len(laws)}条, Top3精选, 分布={distribution}")
    return {
        **state,
        "top3_cases": top3,
        "verdict_distribution": distribution,
        "retrieved_laws": laws,
    }


async def node_deep_analysis(state: CaseAnalysisState) -> Dict[str, Any]:
    """节点3: 深度案例分析 - 对Top3案例逐一分析并汇总法条 + 生成可视化报告"""
    from ..prompts import CASE_ANALYSIS_PROMPT, CASE_VISUAL_REPORT_PROMPT
    from ..parsers import create_visual_report_parser

    llm = state.get("_llm")
    top3 = state.get("top3_cases", [])
    user_case = state.get("user_input", "")
    elements = state.get("extracted_elements", {})
    dist = state.get("verdict_distribution", {})
    retrieved_laws = state.get("retrieved_laws", [])
    analysis = state.get("case_analysis", [])

    if not top3:
        return {**state, "case_analysis": [], "laws_summary": [], "report_data": {}}

    # 格式化Top3案例上下文（使用 content 字段并输出完整原文）
    cases_text = "\n\n---\n\n".join(
        f"""### 案例{i+1}: {c.get('title','未知')}
- 案号: {c.get('caseNumber','N/A')}
- 法院: {c.get('court','N/A')}
- 相似度: {c.get('similarity_score','N/A')}
- 判决日期: {c.get('judgementDate','N/A')}
- 全文:
{c.get('content', c.get('full_text','') or c.get('summary','') or '')}"""
        for i, c in enumerate(top3)
    )

    # 原有深度分析
    chain = CASE_ANALYSIS_PROMPT | llm
    response = await chain.ainvoke({
        "user_case": user_case,
        "top_cases": cases_text,
    })

    content = response.content if hasattr(response, 'content') else str(response)

    try:
        data = json.loads(content)
        analysis_list = data if isinstance(data, list) else data.get("analysis", [])
    except (json.JSONDecodeError, AttributeError):
        analysis_list = [{"error": "LLM输出解析失败"}]

    print(f"[CaseAnalysis] 深度分析完成: {len(analysis_list)}条, API检索法规{len(retrieved_laws)}条")

    # ===== 生成可视化报告 sections =====
    # 构建判决分布文本
    total_cases = sum(dist.values())
    dist_rows = "\n".join(
        f"- {k}: {v}起 ({v/total_cases*100:.1f}%)" if total_cases > 0 else f"- {k}: 0起 (0%)"
        for k, v in sorted(dist.items(), key=lambda x: x[1], reverse=True)
    ) if dist else "暂无判决分布数据"
    
    verdict_distribution_text = f"类案总数: {total_cases}个\n判决结果分布:\n{dist_rows}"

    # Top3 案例摘要（给LLM分析用，简短）
    top_cases_summary = "\n".join(
        f"{i+1}. {c.get('title','未知')} | {c.get('court','未知')} | 相似度: {c.get('similarity_score','N/A'):.3f}"
        for i, c in enumerate(top3)
    )

    # 分析要点
    analysis_points = "\n".join(
        f"- {a.get('key_holding', '暂无')}" for a in analysis if not a.get("error")
    ) or "暂无分析数据"

    # 法律依据（来自API检索结果，包含法律名称、法条内容、效力状态）
    if retrieved_laws:
        laws_summary_text = "\n".join(
            f"- 【{law.get('title', law.get('lawName', '未知法规'))}】"
            f"（{law.get('effectiveStatus', law.get('effective_status', '未知状态'))}）\n"
            f"  {law.get('lawText', law.get('content', ''))}"
            for law in retrieved_laws if not law.get("error")
        )
    else:
        # 兜底：使用深度分析中LLM提取的法条
        laws_summary_text = "\n".join(f"- {l}" for l in analysis_list if isinstance(l, str)) if analysis_list else "暂无法律依据"

    # 调用 LLM 生成可视化报告（带超时控制）
    visual_parser = create_visual_report_parser()
    visual_chain = CASE_VISUAL_REPORT_PROMPT | llm | visual_parser

    print(f"[CaseAnalysis] 开始生成可视化报告...")
    try:
        report_data = await asyncio.wait_for(
            visual_chain.ainvoke({
                "dispute_type": elements.get('dispute_type', '未知'),
                "core_facts": elements.get('core_facts', ''),
                "claims": elements.get('claims', []),
                "key_issues": elements.get('key_issues', []),
                "verdict_distribution_text": verdict_distribution_text,
                "top_cases_summary": top_cases_summary,
                "analysis_points": analysis_points,
                "laws_summary": laws_summary_text,
                "generated_time": datetime.now().strftime("%Y-%m-%d %H:%M"),
            }),
            timeout=120.0  # 120秒超时
        )
        
        # 转换为 dict
        report_data_dict = report_data.model_dump() if hasattr(report_data, 'model_dump') else report_data
        
        # 确保 sections 中的 chart_option 是 dict（可能被 Pydantic 转换）
        for section in report_data_dict.get("sections", []):
            if "chart_option" in section and hasattr(section["chart_option"], "__dict__"):
                section["chart_option"] = section["chart_option"].__dict__ if hasattr(section["chart_option"], "__dict__") else {}
        
        # 添加 Top3 案例全文部分（不通过LLM，直接从数据提取）
        def escape_html(text):
            """转义 HTML 特殊字符并处理换行"""
            if not text:
                return ""
            return (str(text)
                    .replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace('"', "&quot;")
                    .replace("\r\n", "<br>")
                    .replace("\n", "<br>")
                    .replace("\r", "<br>"))
        
        top3_full_text_section = {
            "type": "text",
            "title": "Top3 案例全文",
            "content": "<div class='top3-full-text'>" + "".join(
                f"<div class='case-item'>"
                f"<h4>案例{i+1}: {escape_html(c.get('title', '未知'))}</h4>"
                f"<p><strong>案号:</strong> {escape_html(c.get('caseNumber', 'N/A'))} | "
                f"<strong>法院:</strong> {escape_html(c.get('court', '未知'))} | "
                f"<strong>判决日期:</strong> {escape_html(c.get('judgementDate', 'N/A'))} | "
                f"<strong>相似度:</strong> {c.get('similarity_score', 0):.3f}</p>"
                f"<div class='case-content'>{escape_html(c.get('content', c.get('full_text', '') or ''))}</div>"
                f"</div>"
                for i, c in enumerate(top3)
            ) + "</div>"
        }
        report_data_dict["sections"].append(top3_full_text_section)
        
        print(f"[CaseAnalysis] 可视化报告生成完成: {len(report_data_dict.get('sections', []))} 个章节")
    except asyncio.TimeoutError:
        print(f"[CaseAnalysis] ⚠️ 可视化报告生成超时(120s)，使用降级报告")
        report_data_dict = {
            "title": "法律案件分析报告",
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "dispute_type": elements.get('dispute_type', '未知'),
            "case_count": total_cases,
            "top3_similarity": [c.get('similarity_score', 0) for c in top3[:3]],
            "sections": [
                {
                    "type": "text",
                    "title": "报告生成提示",
                    "content": f"<p>可视化报告生成超时（LLM响应时间过长），已降级为基础报告。</p><p>请查看下方 Markdown 报告获取完整内容。</p>"
                }
            ]
        }
    except Exception as e:
        import traceback
        print(f"[CaseAnalysis] ⚠️ 可视化报告生成失败: {e}")
        traceback.print_exc()
        report_data_dict = {
            "title": "法律案件分析报告",
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "dispute_type": elements.get('dispute_type', '未知'),
            "case_count": total_cases,
            "top3_similarity": [c.get('similarity_score', 0) for c in top3[:3]],
            "sections": [
                {
                    "type": "text",
                    "title": "报告生成提示",
                    "content": f"<p>可视化报告生成遇到问题: {str(e)}</p><p>请查看下方 Markdown 报告获取完整内容。</p>"
                }
            ]
        }

    return {
        **state,
        "case_analysis": analysis_list,
        "laws_summary": [l.get("title", l.get("lawName", "")) for l in retrieved_laws] if retrieved_laws else [],
        "report_data": report_data_dict,
    }


async def node_report_generation(state: CaseAnalysisState) -> Dict[str, Any]:
    """节点4: 报告生成与存储 - 保存可视化报告 JSON"""
    report_data = state.get("report_data", {})  # 可视化报告数据

    json_url = ""
    if report_data and report_data.get("sections"):
        reports_dir = Path(settings.UPLOAD_DIR) / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        json_path = reports_dir / f"case_analysis_{timestamp}.json"
        json_path.write_text(
            json.dumps(report_data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        json_url = f"/uploads/reports/case_analysis_{timestamp}.json"
        print(f"[CaseAnalysis] 报告JSON已保存: {json_path}")

    print(f"[CaseAnalysis] 报告生成完成")
    return {**state, "report_markdown": "", "report_data": report_data, "pdf_url": json_url}


# =====================================================================
# 图构建
# =====================================================================


def build_case_analysis_graph(llm: Optional[Any] = None) -> Any:
    """构建案件分析报告工作流图"""
    if not LANGGRAPH_AVAILABLE:
        raise ImportError("LangGraph 未安装")

    graph = StateGraph(CaseAnalysisState)

    graph.add_node("extract_elements", node_extract_elements)
    graph.add_node("multi_retrieve", node_multi_retrieve)
    graph.add_node("deep_analysis", node_deep_analysis)
    graph.add_node("report_generation", node_report_generation)

    graph.set_entry_point("extract_elements")
    graph.add_edge("extract_elements", "multi_retrieve")
    graph.add_edge("multi_retrieve", "deep_analysis")
    graph.add_edge("deep_analysis", "report_generation")
    graph.add_edge("report_generation", END)

    return graph.compile()


async def run_case_analysis(
    case_description: str,
    *,
    llm: Optional[Any] = None,
) -> Dict[str, Any]:
    """一次性执行完整案件分析流程"""
    graph = build_case_analysis_graph(llm)

    state = await graph.ainvoke({
        "user_input": case_description,
        "_llm": llm,
    })

    return {
        "report_markdown": state.get("report_markdown", ""),
        "report_data": state.get("report_data", {}),  # 可视化报告数据（sections 结构）
        "pdf_url": state.get("pdf_url", ""),
        "extracted_elements": state.get("extracted_elements", {}),
        "verdict_distribution": state.get("verdict_distribution", {}),
        "top3_cases": state.get("top3_cases", []),
        "laws_summary": state.get("laws_summary", []),
    }

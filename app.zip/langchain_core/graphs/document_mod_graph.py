"""
ModifyAgent 文书修改 StateGraph (LangGraph)

这是系统中最复杂的组件，支持：
- L1: 简单文本替换
- L2: 语义改写（LLM辅助）
- L3: 知识增强修改（引用法规/案例）
- 多轮迭代 + 版本管理 + 差异预览 + 回滚

状态转换图:
    ┌─────────────┐
    │  ANALYZE    │ ← 用户输入修改需求
    │  _REQUEST   │
    └──────┬──────┘
           │ [分类: L1/L2/L3?]
     ┌─────┼──────────┐
     ↓     ↓          ↓
  [L1直接] [L2改写]  [L3知识增强]
     ↓     ↓          ↓
     └─────┼──────────┘
           │
    ┌──────▼────────┐
    │   EXECUTE     │ 执行修改
    │  _MODIFICATION│
    └──────┬────────┘
           │
    ┌──────▼────────┐
    │    CONFIRM    │ 展示diff预览
    └──────┬────────┘
           │ [确认/回滚/继续改]
      Yes / Rollback / Continue
      ↓       ↓          ↓
    [END]  [ROLLBACK]  [ANALYZE_REQUEST]

使用示例:
    >>> graph = build_modify_agent_graph(llm)
    >>> 
    >>> # 第1轮: 首次修改
    >>> state1 = await graph.ainvoke({
    ...     "original_content": "...原始文书...",
    ...     "current_content": "...原始文书...",
    ...     "user_modification_request": "把违约金改成10%",
    ... }, config={"configurable": {"thread_id": "sess_001"}})
    >>> 
    >>> # 第2轮: 确认或继续修改
    >>> state2 = await graph.ainvoke({
    ...     **state1,
    ...     "user_modification_request": "确认",
    ... }, config={"configurable": {"thread_id": "sess_001"}})
"""

from __future__ import annotations

from typing import Annotated, Any, Dict, List, Optional, TypedDict
import operator
import re
from datetime import datetime

try:
    from langgraph.graph import StateGraph, END
    from langgraph.checkpoint.memory import MemorySaver
    LANGGRAPH_AVAILABLE = True
except ImportError:
    StateGraph = None
    END = None
    MemorySaver = None
    LANGGRAPH_AVAILABLE = False


# =====================================================================
# 服务实例存储
# 服务通过 build_modify_agent_graph 构造函数注入
# =====================================================================

_mod_service: Any = None


# =====================================================================
# State 定义 ====================

class ModifySessionState(TypedDict):
    """
    修改会话状态 - 支持多轮迭代和版本管理
    
    核心设计:
    - version_history 使用 operator.append 实现不可变追加
    - 每次修改自动创建新版本
    - 支持回滚到任意历史版本
    """
    
    # === 文档基础信息 ===
    document_id: str                               # 文档标识
    original_content: str                          # 原始内容(第一版，不变)
    current_content: str                           # 当前版本内容
    
    # === 当前修改请求 ===
    user_modification_request: str                 # 用户原始请求文本
    
    # === AI解析结果 ===
    parsed_modification: Dict[str, Any]            # 结构化修改指令
    modification_level: str                        # L1/L2/L3
    
    # === 版本管理 ===
    version_history: Annotated[List[Dict], operator.add]  # [{version, content, diff, request, timestamp}]
    current_version: int                          # 当前版本号
    
    # === 知识库上下文（L3时使用）===
    knowledge_context: Dict[str, List[Dict]]      # {laws: [...], cases: [...]}
    
    # === 输出 ===
    response: str                                  # 给用户的响应
    preview_diff: str                             # 差异预览文本
    widget: Optional[Dict[str, Any]]             # Widget配置
    phase: str                                     # 当前阶段
    error: Optional[str]


# =====================================================================
# 节点函数 ====================

async def analyze_request_node(state: ModifySessionState) -> Dict[str, Any]:
    """
    节点1: 分析用户修改请求 - 分类修改级别(L1/L2/L3)

    使用 DocumentModificationService 进行分类。
    """
    request = state.get("user_modification_request", "")
    content = state.get("current_content", "")[:3000]

    print(f"[modify:analyze] request={request[:80]}")

    result = {
        "phase": "analyze",
        "user_modification_request": request,
    }

    if _mod_service is None:
        # 降级为简单规则判断
        level = DocumentModificationService._classify_by_rules(request)
        return {
            **result,
            "parsed_modification": {
                "modification_level": level,
                "legal_topics": [],
                "estimated_complexity": "low",
                "requires_knowledge": False,
                "raw_user_request": request,
            },
            "modification_level": level,
        }

    try:
        classification = await _mod_service.classify_modification(request, content)

        return {
            **result,
            "parsed_modification": {
                "modification_level": classification.modification_level,
                "legal_topics": classification.legal_topics,
                "estimated_complexity": classification.estimated_complexity,
                "requires_knowledge": classification.requires_knowledge,
                "raw_user_request": request,
            },
            "modification_level": classification.modification_level,
        }

    except Exception as e:
        print(f"[modify:analyze] 分类失败: {e}")
        level = DocumentModificationService._classify_by_rules(request)
        return {
            **result,
            "parsed_modification": {
                "modification_level": level,
                "legal_topics": [],
                "estimated_complexity": "low",
                "requires_knowledge": False,
                "raw_user_request": request,
            },
            "modification_level": level,
        }


async def knowledge_enhance_node(state: ModifySessionState) -> Dict[str, Any]:
    """
    节点2 (可选): 知识增强检索
    
    仅当 modification_level == "L3" 时执行，
    并行检索相关法规和案例供后续改写使用。
    """
    from ..tools import parallel_knowledge_search
    
    parsed = state.get("parsed_modification", {})
    topics = parsed.get("legal_topics", [])
    
    if not topics:
        # 从用户请求中提取可能的法律主题
        request = state.get("user_modification_request", "")
        topics = DocumentModificationService._extract_legal_topics(request)
    
    if not topics:
        return {"knowledge_context": {"laws": [], "cases": []}, "phase": "knowledge_enhance"}
    
    keywords = " ".join(topics[:3])  # 取前3个主题作为关键词
    
    knowledge = await parallel_knowledge_search(keywords)
    
    print(f"[modify:knowledge] 检索到 {len(knowledge.get('laws', []))} 条法规, {len(knowledge.get('cases', []))} 个案例")
    
    return {
        "knowledge_context": knowledge,
        "phase": "knowledge_enhance",
    }


async def execute_modification_node(state: ModifySessionState) -> Dict[str, Any]:
    """
    节点3: 执行修改 - 根据级别选择策略
    
    L1: 正则替换
    L2: LLM 语义改写
    L3: LLM + 知识库增强改写
    """
    from ..services import DocumentModificationService

    level = state.get("modification_level", "L1")
    original = state.get("current_content", "")
    request = state.get("user_modification_request", "")
    knowledge = state.get("knowledge_context", {})

    print(f"[modify:execute] level={level}")

    if _mod_service is None:
        # 无服务时的降级
        if level == "L1_text_replace":
            new_content = DocumentModificationService._exec_l1(original, request)
        else:
            new_content = original
        diff = DocumentModificationService.compute_diff(original, new_content)
    else:
        try:
            exec_result = await _mod_service.execute(level, original, request, knowledge)
            new_content = exec_result.content
            diff = exec_result.diff
        except Exception as e:
            print(f"[modify:execute] 执行失败: {e}")
            new_content = original
            diff = "(执行失败，内容未变)"

    # 计算差异
    diff = diff
    
    # 更新版本
    current_ver = state.get("current_version", 0) + 1
    version_entry = {
        "version": current_ver,
        "content": new_content,
        "diff": diff,
        "request": request,
        "level": level,
        "timestamp": datetime.now().isoformat(),
    }
    
    preview_text = f"""📝 **修改已完成 (v{current_ver})**

**修改类型**: {level}
**修改请求**: {request}

### 变更预览
{diff}

请确认是否应用此修改？"""
    
    return {
        "current_content": new_content,
        "current_version": current_ver,
        "preview_diff": diff,
        "response": preview_text,
        "widget": {
            "type": "confirm",
            "title": f"确认修改 (v{current_ver})",
            "message": f"{len(diff)} 处变更",
            "actions": [
                {"type": "button", "label": "确认修改", "action": "apply_modification", "primary": True},
                {"type": "button", "label": "回滚", "action": "rollback"},
                {"type": "button", "label": "继续修改", "action": "continue_modify"},
            ],
        },
        "version_history": [version_entry],  # 通过 operator.append 追加
        "phase": "confirm",
    }


async def rollback_node(state: ModifySessionState) -> Dict[str, Any]:
    """
    节点4: 回滚操作
    
    将文档恢复到指定历史版本。
    """
    request = state.get("user_modification_request", "")
    history = state.get("version_history", [])
    current_ver = state.get("current_version", 0)
    
    # 提取目标版本号
    target_ver = DocumentModificationService.extract_target_version(request, current_ver)
    
    if target_ver is None or target_ver < 1 or target_ver > current_ver:
        return {
            "response": f"⚠️ 无法回滚：无效的版本号。当前版本 v{current_ver}，可回滚范围 v1 ~ v{current_ver-1}",
            "phase": "confirm",
        }
    
    # 找到目标版本的内容
    target_content = None
    for entry in reversed(history):
        if entry.get("version") == target_ver:
            target_content = entry.get("content", state.get("original_content", ""))
            break
    
    if not target_content and target_ver == 1:
        target_content = state.get("original_content", "")
    
    if target_content is None:
        return {
            "response": f"⚠️ 找不到版本 v{target_ver} 的记录",
            "phase": "confirm",
        }
    
    diff = compute_diff(state.get("current_content", ""), target_content)
    
    new_ver = current_ver + 1
    version_entry = {
        "version": new_ver,
        "content": target_content,
        "diff": diff,
        "request": f"[ROLLBACK to v{target_ver}]",
        "level": "rollback",
        "timestamp": datetime.now().isoformat(),
    }
    
    return {
        "current_content": target_content,
        "current_version": new_ver,
        "preview_diff": diff,
        "response": f"↩️ 已回滚到 **v{target_ver}**\n\n{diff}" if len(diff) < 500 else f"↩️ 已回滚到 **v{target_ver}**（共 {diff.count(chr(10))} 行变更）",
        "version_history": [version_entry],
        "phase": "confirm",
    }


async def confirm_node(state: ModifySessionState) -> Dict[str, Any]:
    """
    节点5: 确认处理
    
    解析用户对修改结果的反馈。
    """
    message = state.get("user_modification_request", "").lower().strip()
    
    # 确认关键词
    confirm_kw = ["确认", "是的", "执行", "好", "ok", "apply", "确认修改"]
    if any(kw in message for kw in confirm_kw):
        return {
            "phase": "completed",
            "response": f"✅ 修改已确认！当前版本 v{state.get('current_version', '?')}。\n\n您可以继续修改其他内容，或者返回生成新文书。",
            "widget": {
                "type": "card",
                "title": "修改完成",
                "actions": [
                    {"type": "button", "label": "查看文书", "action": "open_document"},
                    {"type": "button", "label": "继续修改", "action": "continue_modify"},
                    {"type": "button", "label": "生成新文书", "action": "new_document"},
                ],
            },
        }
    
    # 回滚关键词
    rollback_kw = ["回滚", "撤销", "rollback", "恢复", "还原"]
    if any(kw in message for kw in rollback_kw):
        return {"phase": "rollback"}
    
    # 继续修改（默认）
    continue_kw = ["继续", "再改", "还有", "另外", "继续改", "还要"]
    if any(kw in message for kw in continue_kw) or len(message) > 3:
        return {"phase": "analyze"}  # 回到分析节点开始新一轮修改
    
    # 默认等待明确指示
    return {
        "phase": "confirm",
        "response": "请问是「确认」此修改、「回滚」到之前版本、还是「继续修改」其他内容？",
    }


# =====================================================================
# 条件边函数 ====================

def route_after_analyze(state: ModifySessionState) -> str:
    """分析后的路由"""
    level = state.get("modification_level", "L1")
    if level == "L3_knowledge_enhanced":
        return "knowledge_enhance"
    return "execute_modification"

def route_after_confirm(state: ModifySessionState) -> str:
    """确认后的路由"""
    phase = state.get("phase")
    routes = {
        "completed": END.name if END else "END",
        "rollback": "rollback",
        "analyze": "analyze_request",
    }
    return routes.get(phase, "confirm")


# =====================================================================
# 图构建函数 ====================

def build_modify_agent_graph(llm: Any = None):
    """
    构建 ModifyAgent 状态机图

    内部初始化 DocumentModificationService。

    Args:
        llm: LawChatLLM 实例

    Returns:
        编译后的 CompiledGraph

    使用示例（完整闭环）:
        >>> mod_graph = build_modify_agent_graph(law_llm)
        >>>
        >>> # Phase 1: 生成后进入修改模式（假设已有生成结果）
        >>> initial_state = {
        ...     "document_id": "doc_001",
        ...     "original_content": generated_doc_content,
        ...     "current_content": generated_doc_content,
        ...     "user_modification_request": "",
        ...     "version_history": [],
        ...     "current_version": 0,
        ... }
        >>>
        >>> # Round 1: 用户要求修改
        >>> s1 = await mod_graph.ainvoke(
        ...     {**initial_state, "user_modification_request": "把违约金改成10%"},
        ...     config={"configurable": {"thread_id": "mod_001"}}
        ... )
        >>>
        >>> # s1["current_version"] == 1, s1["preview_diff"] 显示变更
        >>>
        >>> # Round 2: 确认修改
        >>> s2 = await mod_graph.ainvoke(
        ...     {**s1, "user_modification_request": "确认"},
        ...     config={"configurable": {"thread_id": "mod_001"}}
        ... )
        >>>
        >>> # Round 3: 继续迭代修改
        >>> s3 = await mod_graph.ainvoke(
        ...     {**s2, "user_modification_request": "再加上双倍工资条款"},
        ...     config={"configurable": {"thread_id": "mod_001"}}
        ... )
        >>>
        >>> # s3["current_version"] == 3
        >>> # s3["version_history"] 包含 v1/v2/v3 的完整记录
        >>> # 随时可回滚: {**s3, "user_modification_request": "回滚到v1"}
    """
    global _mod_service

    if not LANGGRAPH_AVAILABLE:
        raise ImportError("LangGraph 未安装。请运行: pip install langgraph")

    # 初始化 DocumentModificationService
    from ..services import DocumentModificationService
    _mod_service = DocumentModificationService(llm)

    graph = StateGraph(ModifySessionState)

    # 注册所有节点
    graph.add_node("analyze_request", analyze_request_node)
    graph.add_node("knowledge_enhance", knowledge_enhance_node)
    graph.add_node("execute_modification", execute_modification_node)
    graph.add_node("confirm", confirm_node)
    graph.add_node("rollback", rollback_node)

    # 设置入口
    graph.set_entry_point("analyze_request")

    # 条件边
    graph.add_conditional_edges(
        "analyze_request",
        route_after_analyze,
        {
            "knowledge_enhance": "knowledge_enhance",
            "execute_modification": "execute_modification",
        },
    )

    graph.add_edge("knowledge_enhance", "execute_modification")
    graph.add_edge("execute_modification", "confirm")

    graph.add_conditional_edges(
        "confirm",
        route_after_confirm,
        {
            "__end__": END,  # completed
            "rollback": "rollback",
            "analyze_request": "analyze_request",
            "confirm": "confirm",  # 等待
        },
    )

    graph.add_edge("rollback", "confirm")  # 回滚后回到确认界面

    from ..checkpointer import get_checkpointer
    return graph.compile(checkpointer=get_checkpointer())


# =====================================================================
# 内部实现函数 ====================

def _classify_by_rules(request: str) -> str:
    """基于规则快速分类（LLM不可用时的降级方案）"""
    l1_patterns = ["改成", "改为", "替换成", "换成", "把.*改", "将.*改为"]
    l3_patterns = ["法条", "法律依据", "根据.*法", "引用", "案例", "参照"]
    
    for pattern in l3_patterns:
        if re.search(pattern, request):
            return "L3_knowledge_enhanced"
    
    for pattern in l1_patterns:
        if re.search(pattern, request):
            return "L1_text_replace"
    
    return "L2_semantic_rewrite"


def _extract_legal_topics(request: str) -> List[str]:
    """从请求中提取可能的法律主题词"""
    legal_terms = [
        "劳动合同", "民法典", "合同法", "公司法", "婚姻法", "劳动法",
        "违约金", "赔偿", "侵权", "债务", "股权", "知识产权",
        "诉讼时效", "管辖权", "证据", "仲裁", "执行",
    ]
    
    found = []
    for term in legal_terms:
        if term in request:
            found.append(term)
    
    return found[:3]




def compute_diff(old_text: str, new_text: str) -> str:
    """
    计算两段文本的差异（简化版）
    
    返回人类可读的差异描述。
    对于生产环境，建议使用 difflib.SequenceMatcher 或 external diff 库。
    """
    import difflib
    
    if old_text == new_text:
        return "(无变更)"
    
    # 使用 unified_diff 格式
    old_lines = old_text.splitlines(keepends=True)
    new_lines = new_text.splitlines(keepends=True)
    
    diff_lines = list(difflib.unified_diff(old_lines, new_lines, lineterm="", n=3))
    
    if len(diff_lines) > 50:
        # 差异过大时截取
        return (
            f"... 共 {len(diff_lines)} 行变更 ...\n"
            + "".join(diff_lines[:20])
            + f"\n... (省略中间部分) ...\n"
            + "".join(diff_lines[-20:])
        )
    
    return "".join(diff_lines) if diff_lines else "(内容已更新)"


def _extract_target_version(request: str, current_ver: int) -> Optional[int]:
    """从用户消息中提取目标回滚版本号"""
    # 匹配 "回滚到v1" / "恢复v2" / "回到第3版" 等
    patterns = [
        r'[Vv]?(\d+)',
        r'第\s*(\d+)\s*版',
        r'version\s*(\d+)',
        r'回滚?\s*到?.*?(\d+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, request)
        if match:
            ver = int(match.group(1))
            if 1 <= ver <= current_ver:
                return ver
    
    return None

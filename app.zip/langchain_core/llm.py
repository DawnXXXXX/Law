"""
LawChatLLM - CodeBuddy Agent SDK 的 LangChain LLM 适配器

将现有的 CodeBuddyAgent 封装为符合 langchain_core.language_models.BaseChatModel
接口的标准LLM，使其可用于所有LangChain组件(Chain/Graph/Agent/Memory)。
"""

import asyncio
from typing import Any, Dict, List, Optional, Union

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    ChatMessage,
    HumanMessage,
    SystemMessage,
)
from langchain_core.callbacks.manager import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import Field, PrivateAttr


class LawChatLLM(BaseChatModel):
    """
    CodeBuddy Agent SDK 的 LangChain 标准适配器
    
    将 codebuddy_agent_sdk 的 query() 函数包装为 BaseChatModel 接口，
    使其可无缝接入:
    - LCEL Chain (| 管道操作符)
    - LangGraph StateGraph (状态机节点)
    - ConversationMemory (自动历史管理)
    - RunnableBranch (路由分发)
    
    Attributes:
        agent: CodeBuddyAgent 实例 (来自 app.agent_sdk)
        agent_type: Agent 类型，对应 agent_config.yaml 中的配置key
            - "default": 意图识别引擎 (通用)
            - "legal_advisor": 法律咨询专家 (纯文本问答+知识库)
            - "contract_analyzer": 合同分析专家
    """
    
    # ===== Pydantic 字段（支持序列化和验证）=====
    
    # 内部存储 CodeBuddyAgent 实例（不参与schema，使用 PrivateAttr 避免 deepcopy 问题）
    _agent_instance: Any = PrivateAttr(default=None)
    agent_type: str = Field(default="default", description="Agent类型")
    
    # 可选: 直接传入配置字典创建内部agent（替代外部注入）
    config: Optional[Dict[str, Any]] = Field(default=None, description="Agent配置")
    
    def __init__(self, **kwargs):
        """初始化 LawChatLLM"""
        super().__init__(**kwargs)
        
        # 延迟导入避免循环依赖
        if self._agent_instance is None and self.config:
            from ..agent_sdk import CodeBuddyAgent
            self._agent_instance = CodeBuddyAgent(self.config)
    
    @property
    def _llm_type(self) -> str:
        """返回 LLM 类型标识"""
        return "codebuddy-law-chat"
    
    def set_agent(self, agent: Any) -> "LawChatLLM":
        """
        注入 CodeBuddyAgent 实例
        
        Args:
            agent: 已初始化的 CodeBuddyAgent 实例
            
        Returns:
            self (链式调用)
        """
        object.__setattr__(self, "_agent_instance", agent)
        return self
    
    def _get_system_prompt(self) -> str:
        """获取当前 agent_type 对应的系统提示词"""
        if not self._agent_instance:
            return "你是一个法律AI助手。"
        
        return self._agent_instance._get_system_prompt(self.agent_type)
    
    def _convert_messages(self, messages: List[BaseMessage]) -> str:
        """
        将 LangChain Message 列表转换为 CodeBuddy 可用的字符串格式
        
        处理逻辑:
        - SystemMessage → 作为系统上下文前缀
        - HumanMessage → 用户输入
        - AIMessage → 助手回复（用于多轮对话历史）
        - ChatMessage → 根据 role 分发
        
        Args:
            messages: LangChain 标准消息列表
            
        Returns:
            格式化后的字符串
        """
        parts = []
        
        for msg in messages:
            if isinstance(msg, SystemMessage):
                parts.append(f"[系统指令]\n{msg.content}")
            elif isinstance(msg, HumanMessage):
                parts.append(f"[用户]\n{msg.content}")
            elif isinstance(msg, AIMessage):
                parts.append(f"[助手]\n{msg.content}")
            elif isinstance(msg, ChatMessage):
                role_label = {"user": "用户", "assistant": "助手"}.get(msg.role, msg.role)
                parts.append(f"[{role_label}]\n{msg.content}")
            else:
                parts.append(str(msg.content))
        
        return "\n\n".join(parts)
    
    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """
        同步生成响应（LangChain 调用入口）
        
        这是 BaseChatModel 的核心方法，所有 Chain/Graph 都通过此方法调用LLM。
        
        Args:
            messages: 输入消息列表（通常包含 system + history + user）
            stop: 停止词列表（CodeBuddy暂不支持）
            run_manager: 回调管理器（用于日志/追踪）
            **kwargs: 额外参数（如 temperature, max_tokens 等）
            
        Returns:
            ChatResult 包含 ChatGeneration 列表
        """
        if not self._agent_instance:
            return ChatResult(
                generations=[ChatGeneration(
                    message=AIMessage(content="LawChatLLM 未初始化：请调用 set_agent() 注入 CodeBuddyAgent 实例")
                )]
            )
        
        if run_manager:
            run_manager.on_llm_start(
                serialized={"name": self._llm_type},
                prompt=str([m.content for m in messages]),
                **kwargs,
            )
        
        try:
            # 将 LangChain messages 转换为 CodeBuddy 格式
            full_message = self._convert_messages(messages)
            system_prompt = self._get_system_prompt()
            
            # 在线程池中执行同步的 _run_query_sync 方法
            # 使用 asyncio.new_event_loop() 创建独立的事件循环避免冲突
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                response_content = loop.run_in_executor(
                    None,
                    lambda: self._agent_instance._run_query_sync(full_message, system_prompt)
                )
                # 获取结果
                response_content = loop.run_until_complete(response_content)
            finally:
                loop.close()
            
            result = ChatResult(
                generations=[ChatGeneration(message=AIMessage(content=response_content))]
            )
            
            if run_manager:
                run_manager.on_llm_end(result)
                
            return result
            
        except Exception as e:
            error_msg = f"LawChatLLM 调用失败: {str(e)}"
            
            if run_manager:
                run_manager.on_llm_error(error_msg)
            
            return ChatResult(
                generations=[ChatGeneration(
                    message=AIMessage(content=error_msg)
                )]
            )
    
    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """
        异步生成响应（LangGraph/异步Chain使用）
        
        与 _generate() 相同的逻辑，但以 async 方式运行，
        适合在 async def 的 Graph Node 或 Chain 中使用。
        """
        if not self._agent_instance:
            return ChatResult(
                generations=[ChatGeneration(
                    message=AIMessage(content="LawChatLLM 未初始化：请调用 set_agent() 注入 CodeBuddyAgent 实例")
                )]
            )
        
        try:
            # 将 LangChain messages 转换为 CodeBuddy 格式
            full_message = self._convert_messages(messages)
            system_prompt = self._get_system_prompt()
            
            # 在线程池中执行同步的 _run_query_sync 方法
            loop = asyncio.get_event_loop()
            response_content = await loop.run_in_executor(
                None,
                lambda: self._agent_instance._run_query_sync(full_message, system_prompt)
            )
            
            return ChatResult(
                generations=[ChatGeneration(message=AIMessage(content=response_content))]
            )
            
        except Exception as e:
            error_msg = f"LawChatLLM 调用失败: {str(e)}"
            
            return ChatResult(
                generations=[ChatGeneration(
                    message=AIMessage(content=error_msg)
                )]
            )
    
    @property
    def _identifying_params(self) -> Dict[str, Any]:
        """标识参数（用于缓存键）"""
        return {
            "agent_type": self.agent_type,
            "model_name": self._llm_type,
        }
    
    def dict(self, **kwargs) -> Dict:
        """序列化为字典"""
        d = super().dict(**kwargs)
        d["_llm_type"] = self._llm_type
        return d


# ==================== 工厂函数 ====================

def create_law_chat_llm(agent: Any = None, agent_type: str = "default") -> LawChatLLM:
    """
    创建 LawChatLLM 实例的工厂函数
    
    Args:
        agent: CodeBuddyAgent 实例（可选，后续可通过 set_agent() 设置）
        agent_type: Agent 类型名称
        
    Returns:
        配置好的 LawChatLLM 实例
        
    使用示例:
        >>> from app.agent_sdk import CodeBuddyAgent
        >>> agent = CodeBuddyAgent(config)
        >>> llm = create_law_chat_llm(agent, "default")
        >>> 
        >>> # 直接用于 LCEL Chain
        >>> chain = prompt | llm | parser
        >>> result = chain.invoke({"input": "..."})
    """
    llm = LawChatLLM(agent_type=agent_type)
    
    if agent:
        llm.set_agent(agent)
    
    return llm


# ==================== 预配置的 LLM 单例（线程安全）====================

import threading

# 使用锁保证单例创建的线程安全
_llm_lock = threading.Lock()

# 意图识别专用 LLM（使用 default 配置）
_intent_llm: Optional[LawChatLLM] = None

# 法律咨询专用 LLM（使用 legal_advisor 配置）
_consultation_llm: Optional[LawChatLLM] = None

# 文书生成专用 LLM（使用 default 配置 + 更高temperature允许创造性）
_generation_llm: Optional[LawChatLLM] = None


def _get_or_create(var_name: str, factory_func) -> LawChatLLM:
    """
    线程安全的单例获取/创建
    
    Args:
        var_name: 全局变量名（用于日志）
        factory_func: 无参工厂函数
        
    Returns:
        已存在或新创建的 LawChatLLM 实例
    """
    # 获取对应的全局变量
    import sys
    frame = sys._getframe(1)
    globals_dict = frame.f_globals
    instance = globals_dict.get(var_name)
    
    if instance is None:
        with _llm_lock:
            # 双重检查
            instance = globals_dict.get(var_name)
            if instance is None:
                instance = factory_func()
                globals_dict[var_name] = instance
    
    return instance


def get_intent_llm() -> LawChatLLM:
    """获取或创建意图识别专用 LLM"""
    global _intent_llm
    if _intent_llm is None:
        with _llm_lock:
            if _intent_llm is None:
                _intent_llm = create_law_chat_llm(agent_type="default")
    return _intent_llm


def get_consultation_llm() -> LawChatLLM:
    """获取或创建法律咨询专用 LLM"""
    global _consultation_llm
    if _consultation_llm is None:
        with _llm_lock:
            if _consultation_llm is None:
                _consultation_llm = create_law_chat_llm(agent_type="legal_advisor")
    return _consultation_llm


def get_generation_llm() -> LawChatLLM:
    """获取或创建文书生成专用 LLM"""
    global _generation_llm
    if _generation_llm is None:
        with _llm_lock:
            if _generation_llm is None:
                _generation_llm = create_law_chat_llm(agent_type="default")
    return _generation_llm


def initialize_all_llms(agent: Any) -> None:
    """
    一次性初始化所有 LLM 单例（应用启动时调用）
    
    Args:
        agent: 已认证的 CodeBuddyAgent 实例
    """
    global _intent_llm, _consultation_llm, _generation_llm
    
    _intent_llm = create_law_chat_llm(agent, "default")
    _consultation_llm = create_law_chat_llm(agent, "legal_advisor")
    _generation_llm = create_law_chat_llm(agent, "default")

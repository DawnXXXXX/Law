"""
文件 API 路由
简化的文件管理：文件树直接反映物理存储结构
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional, List
import os
import uuid
from datetime import datetime
import shutil

from ..database import get_db
from ..models import Project, File as FileModel
from ..schemas import (
    FileResponse, FileContentResponse,
    SummaryCreate, SummaryUpdate, SummaryResponse
)
from ..config import settings
from ..utils.file_processor import extract_text_from_file, extract_html_from_docx

router = APIRouter(prefix="/api/projects", tags=["文件管理"])


def get_project_dir(project_id: int) -> str:
    """获取项目的物理存储目录"""
    return os.path.join(settings.UPLOAD_DIR, f"project_{project_id}")


def ensure_project_dir(project_id: int) -> str:
    """确保项目目录存在"""
    project_dir = get_project_dir(project_id)
    os.makedirs(project_dir, exist_ok=True)
    return project_dir


def scan_directory_tree(base_path: str, relative_path: str = "") -> List[dict]:
    """递归扫描目录，返回树形结构"""
    items = []
    current_path = os.path.join(base_path, relative_path) if relative_path else base_path
    
    if not os.path.exists(current_path):
        return items
    
    # 排序：文件夹在前，文件在后
    entries = sorted(os.listdir(current_path), key=lambda x: (
        0 if os.path.isdir(os.path.join(current_path, x)) else 1,
        x.lower()
    ))
    
    for name in entries:
        full_path = os.path.join(current_path, name)
        rel_path = os.path.join(relative_path, name) if relative_path else name
        
        if os.path.isdir(full_path):
            # 文件夹
            items.append({
                "id": f"folder-{rel_path.replace(os.sep, '/')}",
                "type": "directory",
                "name": name,
                "path": rel_path,
                "children": scan_directory_tree(base_path, rel_path)
            })
        else:
            # 文件
            size = os.path.getsize(full_path)
            ext = os.path.splitext(name)[1].lower().lstrip('.')
            items.append({
                "id": f"file-{rel_path.replace(os.sep, '/')}",
                "type": "file",
                "name": name,
                "path": rel_path,
                "file_type": ext,
                "size": size
            })
    
    return items


# ========== 文件树接口 ==========

@router.get("/{project_id}/file-tree")
async def get_file_tree(
    project_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取项目文件树（直接读取物理存储）"""
    # 检查项目是否存在
    project_query = select(Project).where(Project.id == project_id)
    project_result = await db.execute(project_query)
    if not project_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="项目不存在")
    
    # 确保项目目录存在
    ensure_project_dir(project_id)
    
    # 扫描目录结构
    project_dir = get_project_dir(project_id)
    tree = scan_directory_tree(project_dir)
    
    return {"code": 0, "data": tree}


# ========== 文件夹接口 ==========

@router.post("/{project_id}/folders")
async def create_folder(
    project_id: int,
    path: str = Query(..., description="文件夹路径（相对路径）"),
    db: AsyncSession = Depends(get_db)
):
    """创建文件夹（物理目录）"""
    # 检查项目是否存在
    project_query = select(Project).where(Project.id == project_id)
    project_result = await db.execute(project_query)
    if not project_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="项目不存在")
    
    # 检查是否已存在
    project_dir = ensure_project_dir(project_id)
    full_path = os.path.join(project_dir, path)
    
    if os.path.exists(full_path):
        raise HTTPException(status_code=400, detail="文件夹已存在")
    
    # 检查父目录是否存在
    parent_path = os.path.dirname(full_path)
    if not os.path.exists(parent_path):
        raise HTTPException(status_code=400, detail="父文件夹不存在")
    
    # 创建文件夹
    os.makedirs(full_path, exist_ok=True)
    
    return {"code": 0, "message": "文件夹创建成功", "path": path}


@router.delete("/{project_id}/folders")
async def delete_folder(
    project_id: int,
    path: str = Query(..., description="文件夹路径（相对路径）"),
    db: AsyncSession = Depends(get_db)
):
    """删除文件夹（物理目录）"""
    project_dir = ensure_project_dir(project_id)
    full_path = os.path.join(project_dir, path)
    
    # 安全检查：不能删除项目根目录
    real_project_dir = os.path.realpath(project_dir)
    real_full_path = os.path.realpath(full_path)
    if not real_full_path.startswith(real_project_dir):
        raise HTTPException(status_code=400, detail="路径非法")
    
    if not os.path.exists(full_path) or not os.path.isdir(full_path):
        raise HTTPException(status_code=404, detail="文件夹不存在")
    
    # 删除文件夹
    shutil.rmtree(full_path)
    
    return {"code": 0, "message": "文件夹已删除"}


# ========== 文件接口 ==========

@router.post("/{project_id}/upload", status_code=201)
async def upload_file(
    project_id: int,
    files: List[UploadFile] = File(...),
    folder_path: Optional[str] = Query(None, description="目标文件夹路径（相对路径）"),
    db: AsyncSession = Depends(get_db)
):
    """统一上传接口：文件和文件夹都通过此接口上传"""
    # 检查项目是否存在
    project_query = select(Project).where(Project.id == project_id)
    project_result = await db.execute(project_query)
    db_project = project_result.scalar_one_or_none()
    if not db_project:
        raise HTTPException(status_code=404, detail="项目不存在")
    
    project_dir = ensure_project_dir(project_id)
    
    # 确定目标目录
    if folder_path:
        target_dir = os.path.join(project_dir, folder_path)
        # 检查目标目录是否存在
        if not os.path.exists(target_dir):
            raise HTTPException(status_code=400, detail="目标文件夹不存在")
    else:
        target_dir = project_dir
    
    uploaded_files = []
    errors = []
    
    for file in files:
        if not file.filename:
            continue
        
        # 检查重名
        target_path = os.path.join(target_dir, file.filename)
        if os.path.exists(target_path):
            errors.append(f"{file.filename} 已存在")
            continue
        
        # 确保使用绝对路径
        file_path = os.path.abspath(target_path)
        
        # 保存文件
        contents = await file.read()
        with open(file_path, 'wb') as f:
            f.write(contents)
        
        # 提取文本内容（异步存储到数据库，只为索引用）
        file_ext = os.path.splitext(file.filename)[1].lower().lstrip('.')
        content_text = extract_text_from_file(file_path, file_ext)
        
        # 创建数据库记录（可选，用于全文搜索）
        db_file = FileModel(
            project_id=project_id,
            folder_id=None,  # 不再使用folder_id
            name=file.filename,
            file_type=file_ext,
            file_path=file_path,
            content=content_text,
            size=len(contents)
        )
        db.add(db_file)
        
        uploaded_files.append({
            "name": file.filename,
            "size": len(contents),
            "path": os.path.relpath(file_path, project_dir)
        })
    
    # 更新项目更新时间
    db_project.updated_at = datetime.utcnow()
    await db.commit()
    
    return {
        "code": 0,
        "data": {
            "uploaded_count": len(uploaded_files),
            "files": uploaded_files,
            "errors": errors if errors else None
        }
    }


@router.get("/{project_id}/files/{path:path}/content")
async def get_file_content(
    project_id: int,
    path: str,
    format: Optional[str] = Query(None, description="返回格式: text 或 html"),
    db: AsyncSession = Depends(get_db)
):
    """获取文件内容"""
    project_dir = ensure_project_dir(project_id)
    
    # 规范化路径
    normalized_path = path.replace('/', os.sep).replace('\\', os.sep)
    full_path = os.path.normpath(os.path.join(project_dir, normalized_path))
    
    # 安全检查
    real_project_dir = os.path.realpath(project_dir)
    real_file_path = os.path.realpath(full_path)
    if not real_file_path.startswith(real_project_dir + os.sep) and real_file_path != real_project_dir:
        raise HTTPException(status_code=400, detail="路径非法")
    
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="文件不存在")
    
    if os.path.isdir(full_path):
        raise HTTPException(status_code=400, detail="不支持读取文件夹")
    
    # 根据文件类型和格式返回
    ext = os.path.splitext(normalized_path)[1].lower().lstrip('.')
    
    # docx 文件支持 HTML 格式（使用 OnlyOffice 转换）
    if ext == 'docx' and format == 'html':
        html_content = extract_html_from_docx(full_path, use_onlyoffice=True)
        return FileContentResponse(
            content=html_content,
            file_name=os.path.basename(normalized_path)
        )
    
    if ext in ['txt', 'md', 'json', 'xml', 'html', 'css', 'js', 'ts']:
        # 文本文件直接读取
        with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
            text_content = f.read()
        return FileContentResponse(
            content=text_content,
            file_name=os.path.basename(normalized_path)
        )
    elif ext == 'docx':
        # Word 文档提取文本（纯文本）
        text_content = extract_text_from_file(full_path, ext)
        return FileContentResponse(
            content=text_content,
            file_name=os.path.basename(normalized_path)
        )
    elif ext == 'pdf':
        # PDF 文档提取文本
        text_content = extract_text_from_file(full_path, ext)
        return FileContentResponse(
            content=text_content,
            file_name=os.path.basename(normalized_path)
        )
    else:
        # 其他二进制文件返回为空
        return FileContentResponse(
            content="",
            file_name=os.path.basename(normalized_path)
        )


@router.put("/{project_id}/files/{path:path}/rename")
async def rename_file(
    project_id: int,
    path: str,
    new_name: str,
    db: AsyncSession = Depends(get_db)
):
    """重命名文件"""
    project_dir = ensure_project_dir(project_id)
    
    # 规范化路径
    normalized_path = path.replace('/', os.sep).replace('\\', os.sep)
    full_path = os.path.normpath(os.path.join(project_dir, normalized_path))
    
    # 安全检查
    real_project_dir = os.path.realpath(project_dir)
    real_full_path = os.path.realpath(full_path)
    if not real_full_path.startswith(real_project_dir + os.sep) and real_full_path != real_project_dir:
        raise HTTPException(status_code=400, detail="路径非法")
    
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="文件不存在")
    
    # 检查新名称是否已存在
    new_path = os.path.join(os.path.dirname(full_path), new_name)
    if os.path.exists(new_path):
        raise HTTPException(status_code=400, detail="目标文件名已存在")
    
    # 重命名
    os.rename(full_path, new_path)
    
    # 更新数据库记录
    old_name = os.path.basename(normalized_path)
    query = select(FileModel).where(
        FileModel.project_id == project_id,
        FileModel.name == old_name
    )
    result = await db.execute(query)
    db_file = result.scalar_one_or_none()
    if db_file:
        db_file.name = new_name
        db_file.file_path = new_path
        db_file.updated_at = datetime.utcnow()
        await db.commit()
    
    return {"code": 0, "message": "重命名成功"}


@router.delete("/{project_id}/files/{path:path}")
async def delete_file(
    project_id: int,
    path: str,
    db: AsyncSession = Depends(get_db)
):
    """删除文件"""
    project_dir = ensure_project_dir(project_id)
    
    # 规范化路径：将 URL 编码的 / 转换为系统路径分隔符
    normalized_path = path.replace('/', os.sep).replace('\\', os.sep)
    full_path = os.path.normpath(os.path.join(project_dir, normalized_path))
    
    # 安全检查：确保路径在项目目录内
    real_project_dir = os.path.realpath(project_dir)
    real_full_path = os.path.realpath(full_path)
    if not real_full_path.startswith(real_project_dir + os.sep) and real_full_path != real_project_dir:
        raise HTTPException(status_code=400, detail="路径非法")
    
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="文件不存在")
    
    if os.path.isdir(full_path):
        raise HTTPException(status_code=400, detail="请使用文件夹删除接口")
    
    # 删除物理文件
    os.remove(full_path)
    
    # 删除数据库记录
    file_name = os.path.basename(normalized_path)
    query = select(FileModel).where(
        FileModel.project_id == project_id,
        FileModel.name == file_name
    )
    result = await db.execute(query)
    db_file = result.scalar_one_or_none()
    if db_file:
        await db.delete(db_file)
        await db.commit()
    
    return {"code": 0, "message": "文件已删除"}


@router.post("/{project_id}/files/{path:path}/move")
async def move_file(
    project_id: int,
    path: str,
    target_folder: Optional[str] = Query(None, description="目标文件夹路径"),
    db: AsyncSession = Depends(get_db)
):
    """移动文件到指定文件夹"""
    project_dir = ensure_project_dir(project_id)
    
    # 规范化路径
    normalized_path = path.replace('/', os.sep).replace('\\', os.sep)
    full_path = os.path.normpath(os.path.join(project_dir, normalized_path))
    
    # 安全检查
    real_project_dir = os.path.realpath(project_dir)
    real_full_path = os.path.realpath(full_path)
    if not real_full_path.startswith(real_project_dir + os.sep) and real_full_path != real_project_dir:
        raise HTTPException(status_code=400, detail="路径非法")
    
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="文件不存在")
    
    # 确定目标路径
    if target_folder:
        normalized_target = target_folder.replace('/', os.sep).replace('\\', os.sep)
        target_dir = os.path.normpath(os.path.join(project_dir, normalized_target))
        if not os.path.exists(target_dir):
            raise HTTPException(status_code=400, detail="目标文件夹不存在")
    else:
        target_dir = project_dir
    
    # 目标完整路径
    new_path = os.path.join(target_dir, os.path.basename(normalized_path))
    
    # 检查目标是否已存在
    if os.path.exists(new_path):
        raise HTTPException(status_code=400, detail="目标位置已存在同名文件")
    
    # 移动文件
    shutil.move(full_path, new_path)
    
    # 更新数据库记录
    file_name = os.path.basename(normalized_path)
    query = select(FileModel).where(
        FileModel.project_id == project_id,
        FileModel.name == file_name
    )
    result = await db.execute(query)
    db_file = result.scalar_one_or_none()
    if db_file:
        db_file.file_path = new_path
        db_file.folder_id = None  # 不再使用folder_id
        db_file.updated_at = datetime.utcnow()
        await db.commit()
    
    return {"code": 0, "message": "文件已移动"}


@router.get("/{project_id}/files/{path:path}/download")
async def download_file(
    project_id: int,
    path: str,
    db: AsyncSession = Depends(get_db)
):
    """下载文件"""
    project_dir = ensure_project_dir(project_id)
    
    # 规范化路径
    normalized_path = path.replace('/', os.sep).replace('\\', os.sep)
    full_path = os.path.normpath(os.path.join(project_dir, normalized_path))
    
    # 安全检查
    real_project_dir = os.path.realpath(project_dir)
    real_full_path = os.path.realpath(full_path)
    if not real_full_path.startswith(real_project_dir + os.sep) and real_full_path != real_project_dir:
        raise HTTPException(status_code=400, detail="路径非法")
    
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="文件不存在")
    
    if os.path.isdir(full_path):
        raise HTTPException(status_code=400, detail="不支持下载文件夹")
    
    # 获取文件名
    file_name = os.path.basename(full_path)
    
    # 根据文件类型设置媒体类型
    ext = os.path.splitext(file_name)[1].lower().lstrip('.')
    media_types = {
        'pdf': 'application/pdf',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'doc': 'application/msword',
        'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'xls': 'application/vnd.ms-excel',
        'txt': 'text/plain',
        'html': 'text/html',
        'css': 'text/css',
        'js': 'application/javascript',
        'json': 'application/json',
        'xml': 'application/xml',
        'png': 'image/png',
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'gif': 'image/gif',
        'zip': 'application/zip',
    }
    media_type = media_types.get(ext, 'application/octet-stream')
    
    return FileResponse(
        path=full_path,
        filename=file_name,
        media_type=media_type
    )


# ========== 兼容性接口（保留旧接口别名）==========

@router.get("/{project_id}/files")
async def get_project_files(
    project_id: int,
    folder_path: Optional[str] = Query(None, description="文件夹路径"),
    db: AsyncSession = Depends(get_db)
):
    """获取项目文件列表（兼容性接口）"""
    project_dir = ensure_project_dir(project_id)
    
    if folder_path:
        target_dir = os.path.join(project_dir, folder_path)
        if not os.path.exists(target_dir):
            return []
        entries = os.listdir(target_dir)
    else:
        entries = os.listdir(project_dir)
    
    files = []
    for name in entries:
        full_path = os.path.join(target_dir if folder_path else project_dir, name)
        if os.path.isfile(full_path):
            files.append({
                "id": name,
                "name": name,
                "file_type": os.path.splitext(name)[1].lower().lstrip('.'),
                "size": os.path.getsize(full_path)
            })
    
    return files


# ========== 摘要相关接口 ==========

@router.get("/{project_id}/files/{file_id}/summaries", response_model=list)
async def get_file_summaries(
    project_id: int,
    file_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取文件的所有摘要历史"""
    query = select(FileModel).where(
        FileModel.id == file_id,
        FileModel.project_id == project_id
    )
    result = await db.execute(query)
    db_file = result.scalar_one_or_none()
    if not db_file:
        raise HTTPException(status_code=404, detail="文件不存在")
    
    # 获取所有摘要
    from ..models import FileSummary
    summary_query = select(FileSummary).where(
        FileSummary.file_id == file_id
    ).order_by(FileSummary.version.desc())
    summary_result = await db.execute(summary_query)
    summaries = summary_result.scalars().all()
    
    return [SummaryResponse.model_validate(s) for s in summaries]


@router.post("/{project_id}/files/{file_id}/summaries", response_model=SummaryResponse, status_code=201)
async def create_summary(
    project_id: int,
    file_id: int,
    summary_data: SummaryCreate,
    db: AsyncSession = Depends(get_db)
):
    """为文件创建/更新摘要"""
    query = select(FileModel).where(
        FileModel.id == file_id,
        FileModel.project_id == project_id
    )
    result = await db.execute(query)
    db_file = result.scalar_one_or_none()
    if not db_file:
        raise HTTPException(status_code=404, detail="文件不存在")
    
    # 获取最新版本号
    from ..models import FileSummary
    version_query = select(FileSummary).where(
        FileSummary.file_id == file_id
    ).order_by(FileSummary.version.desc()).limit(1)
    version_result = await db.execute(version_query)
    latest = version_result.scalar_one_or_none()
    new_version = (latest.version + 1) if latest else 1
    
    # 创建新摘要
    db_summary = FileSummary(
        file_id=file_id,
        content=summary_data.content,
        version=new_version,
        created_by=summary_data.created_by
    )
    db.add(db_summary)
    
    # 更新文件的 summary 字段
    db_file.summary = summary_data.content
    
    await db.commit()
    await db.refresh(db_summary)
    
    return SummaryResponse.model_validate(db_summary)

"""
知识库 API 路由
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, desc
from typing import Optional

from ..database import get_db
from ..models import KnowledgeCategory, KnowledgeDocument
from ..schemas import (
    CategoryCreate, CategoryResponse,
    DocumentCreate, DocumentResponse,
    KnowledgeSearchRequest, LawCollectionRequest
)

router = APIRouter(prefix="/api/knowledge", tags=["知识库"])


# ============ 分类管理 ============

@router.get("/categories", response_model=list)
async def get_categories(
    db: AsyncSession = Depends(get_db)
):
    """获取知识库分类"""
    query = select(KnowledgeCategory).order_by(KnowledgeCategory.id)
    result = await db.execute(query)
    categories = result.scalars().all()
    return [CategoryResponse.model_validate(c) for c in categories]


@router.post("/categories", response_model=CategoryResponse, status_code=201)
async def create_category(
    category: CategoryCreate,
    db: AsyncSession = Depends(get_db)
):
    """创建分类"""
    # 验证父分类存在
    if category.parent_id:
        parent_query = select(KnowledgeCategory).where(KnowledgeCategory.id == category.parent_id)
        parent_result = await db.execute(parent_query)
        if not parent_result.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="父分类不存在")
    
    db_category = KnowledgeCategory(
        name=category.name,
        parent_id=category.parent_id
    )
    db.add(db_category)
    await db.commit()
    await db.refresh(db_category)
    
    return CategoryResponse.model_validate(db_category)


@router.delete("/categories/{category_id}")
async def delete_category(
    category_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除分类"""
    query = select(KnowledgeCategory).where(KnowledgeCategory.id == category_id)
    result = await db.execute(query)
    category = result.scalar_one_or_none()
    
    if not category:
        raise HTTPException(status_code=404, detail="分类不存在")
    
    await db.delete(category)
    await db.commit()
    
    return {"code": 0, "message": "分类已删除"}


# ============ 文档管理 ============

@router.get("/documents", response_model=list)
async def get_documents(
    category_id: Optional[int] = None,
    doc_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """获取文档列表"""
    query = select(KnowledgeDocument)
    
    if category_id:
        query = query.where(KnowledgeDocument.category_id == category_id)
    if doc_type:
        query = query.where(KnowledgeDocument.doc_type == doc_type)
    
    query = query.order_by(desc(KnowledgeDocument.created_at))
    result = await db.execute(query)
    documents = result.scalars().all()
    
    return [DocumentResponse.model_validate(d) for d in documents]


@router.post("/documents", response_model=dict, status_code=201)
async def create_document(
    document: DocumentCreate,
    db: AsyncSession = Depends(get_db)
):
    """创建/收藏文档"""
    # 验证分类存在
    if document.category_id:
        category_query = select(KnowledgeCategory).where(KnowledgeCategory.id == document.category_id)
        category_result = await db.execute(category_query)
        if not category_result.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="分类不存在")
    
    db_document = KnowledgeDocument(
        category_id=document.category_id,
        title=document.title,
        doc_type=document.doc_type,
        content=document.content,
        file_path=document.file_path,
        law_id=document.law_id,
        notes=document.notes
    )
    db.add(db_document)
    await db.commit()
    await db.refresh(db_document)
    
    return {
        "code": 0,
        "data": {
            "document_id": db_document.id
        }
    }


@router.post("/laws", response_model=dict, status_code=201)
async def collect_law(
    request: LawCollectionRequest,
    db: AsyncSession = Depends(get_db)
):
    """收藏法条（快捷方式）"""
    db_document = KnowledgeDocument(
        title=request.title,
        doc_type="law",
        content=request.content,
        law_id=request.law_id,
        notes=request.notes
    )
    db.add(db_document)
    await db.commit()
    await db.refresh(db_document)
    
    return {
        "code": 0,
        "data": {
            "collection_id": db_document.id
        }
    }


@router.get("/documents/{document_id}", response_model=dict)
async def get_document(
    document_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取文档详情"""
    query = select(KnowledgeDocument).where(KnowledgeDocument.id == document_id)
    result = await db.execute(query)
    document = result.scalar_one_or_none()
    
    if not document:
        raise HTTPException(status_code=404, detail="文档不存在")
    
    return {
        "code": 0,
        "data": {
            "document_id": document.id,
            "title": document.title,
            "doc_type": document.doc_type,
            "content": document.content,
            "notes": document.notes,
            "created_at": document.created_at
        }
    }


@router.delete("/documents/{document_id}")
async def delete_document(
    document_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除文档"""
    query = select(KnowledgeDocument).where(KnowledgeDocument.id == document_id)
    result = await db.execute(query)
    document = result.scalar_one_or_none()
    
    if not document:
        raise HTTPException(status_code=404, detail="文档不存在")
    
    await db.delete(document)
    await db.commit()
    
    return {"code": 0, "message": "文档已删除"}


@router.get("/search", response_model=dict)
async def search_knowledge(
    keyword: str = Query(..., min_length=1),
    doc_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """搜索知识库"""
    query = select(KnowledgeDocument).where(
        or_(
            KnowledgeDocument.title.contains(keyword),
            KnowledgeDocument.content.contains(keyword)
        )
    )
    
    if doc_type:
        query = query.where(KnowledgeDocument.doc_type == doc_type)
    
    query = query.order_by(desc(KnowledgeDocument.created_at)).limit(20)
    result = await db.execute(query)
    documents = result.scalars().all()
    
    return {
        "code": 0,
        "data": [
            {
                "document_id": d.id,
                "title": d.title,
                "doc_type": d.doc_type,
                "summary": d.content[:200] if d.content else None,
                "notes": d.notes
            }
            for d in documents
        ]
    }

"""
AI 聊天 API 路由
基于大模型的智能对话系统
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import Optional, List
import os
import json

from ..database import get_db
from ..models import Conversation, Message, Project, File
from ..schemas import (
    ConversationCreate, ConversationResponse,
    MessageResponse, ChatRequest, ChatResponse
)
from ..smart_chat import get_chat_service, SmartChatService
from ..config import settings

router = APIRouter(prefix="/api", tags=["AI对话"])


@router.get("/chat/sessions", response_model=list)
async def get_chat_sessions(
    project_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db)
):
    """获取对话会话列表"""
    query = select(Conversation)
    if project_id:
        query = query.where(Conversation.project_id == project_id)

    query = query.order_by(desc(Conversation.updated_at))
    result = await db.execute(query)
    sessions = result.scalars().all()

    return [ConversationResponse.model_validate(s) for s in sessions]


@router.post("/chat/sessions", status_code=201)
async def create_chat_session(
    conversation: ConversationCreate,
    db: AsyncSession = Depends(get_db)
):
    """创建对话会话"""
    if conversation.project_id:
        project_query = select(Project).where(Project.id == conversation.project_id)
        project_result = await db.execute(project_query)
        if not project_result.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="项目不存在")

    db_conversation = Conversation(
        project_id=conversation.project_id,
        title=conversation.title or f"新对话"
    )
    db.add(db_conversation)
    await db.commit()
    await db.refresh(db_conversation)

    return {
        "code": 0,
        "data": {
            "conversation_id": db_conversation.id
        }
    }


@router.get("/chat/sessions/{session_id}", response_model=ConversationResponse)
async def get_chat_session(
    session_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取对话会话"""
    query = select(Conversation).where(Conversation.id == session_id)
    result = await db.execute(query)
    session = result.scalar_one_or_none()

    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")

    return ConversationResponse.model_validate(session)


@router.get("/chat/sessions/{session_id}/messages")
async def get_chat_messages(
    session_id: int,
    limit: int = Query(20, ge=1, le=100),
    before: Optional[int] = None,
    db: AsyncSession = Depends(get_db)
):
    """获取对话历史"""
    session_query = select(Conversation).where(Conversation.id == session_id)
    session_result = await db.execute(session_query)
    if not session_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="会话不存在")

    query = select(Message).where(Message.conversation_id == session_id)
    if before:
        query = query.where(Message.id < before)

    query = query.order_by(desc(Message.id)).limit(limit)
    result = await db.execute(query)
    messages = result.scalars().all()

    # 转换消息，解析 workflow_state JSON
    def to_message_response(m):
        data = {
            "id": m.id,
            "conversation_id": m.conversation_id,
            "role": m.role,
            "content": m.content,
            "created_at": m.created_at,
            "workflow_state": json.loads(m.workflow_state) if m.workflow_state else None
        }
        return MessageResponse.model_validate(data)

    return {
        "code": 0,
        "data": {
            "messages": [to_message_response(m) for m in reversed(messages)]
        }
    }


@router.delete("/chat/sessions/{session_id}")
async def delete_chat_session(
    session_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除对话会话"""
    query = select(Conversation).where(Conversation.id == session_id)
    result = await db.execute(query)
    session = result.scalar_one_or_none()

    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")

    await db.delete(session)
    await db.commit()

    return {"code": 0, "message": "会话已删除"}


@router.post("/chat/send")
async def send_message(
    chat_request: ChatRequest,
    db: AsyncSession = Depends(get_db)
):
    """发送消息 - 使用智能对话服务"""
    # 调试日志：打印收到的请求数据
    print(f"[chat:send_message] 收到请求: project_id={chat_request.project_id}, conversation_id={chat_request.conversation_id}, message={chat_request.message[:50] if chat_request.message else 'empty'}, attached_file_ids={chat_request.attached_file_ids}, workflow_state_keys={list((chat_request.workflow_state or {}).keys())}")

    # 获取或创建会话（确保ID为整数类型）
    conversation_id = int(chat_request.conversation_id) if chat_request.conversation_id else None
    project_id = int(chat_request.project_id) if chat_request.project_id else None

    if conversation_id:
        session_query = select(Conversation).where(Conversation.id == conversation_id)
        session_result = await db.execute(session_query)
        conversation = session_result.scalar_one_or_none()
        if not conversation:
            raise HTTPException(status_code=404, detail="会话不存在")
    else:
        conversation = Conversation(
            project_id=chat_request.project_id,
            title=chat_request.message[:50] + "..." if len(chat_request.message) > 50 else chat_request.message
        )
        db.add(conversation)
        await db.commit()
        await db.refresh(conversation)
        conversation_id = conversation.id

    # 保存用户消息
    user_message = Message(
        conversation_id=conversation_id,
        role="user",
        content=chat_request.message
    )
    db.add(user_message)
    await db.commit()
    await db.refresh(user_message)

    # 获取对话历史（用于上下文）
    history_query = select(Message).where(
        Message.conversation_id == conversation_id
    ).order_by(Message.id.asc()).limit(20)
    history_result = await db.execute(history_query)
    history_messages = history_result.scalars().all()
    history = [{"role": m.role, "content": m.content} for m in history_messages]

    # 获取附件文件内容
    attached_files = []
    print(f"[chat] attached_file_ids: {chat_request.attached_file_ids}, type: {type(chat_request.attached_file_ids)}")
    if chat_request.attached_file_ids:
        file_ids_or_names = chat_request.attached_file_ids
        project_id = chat_request.project_id
        print(f"[chat] 处理附件: file_ids_or_names={file_ids_or_names}, project_id={project_id}")

        # 判断是ID列表还是文件名列表
        if file_ids_or_names and isinstance(file_ids_or_names[0], int):
            # 整数ID列表：从数据库查询
            file_query = select(File).where(File.id.in_(file_ids_or_names))
            file_result = await db.execute(file_query)
            files = file_result.scalars().all()
            for f in files:
                # 拼接文件物理路径（相对路径，适配部署）
                file_path = os.path.join(settings.UPLOAD_DIR, f"project_{f.project_id}", f.name)
                attached_files.append({
                    "file_id": f.id,
                    "file_name": f.name,
                    "content": f.content or "",
                    "file_path": file_path
                })
        else:
            # 文件名字符串列表：根据项目ID和文件名查找
            for file_name in file_ids_or_names:
                # 去掉 "file-" 前缀（前端添加的标识）
                clean_name = file_name
                if file_name.startswith("file-"):
                    clean_name = file_name[5:]  # 去掉 "file-" 前缀
                print(f"[chat] 查找文件: name={clean_name}, project_id={project_id}")
                # 尝试从数据库查找同名文件
                query = select(File)
                if project_id:
                    # 确保 project_id 是整数类型
                    pid = int(project_id) if isinstance(project_id, str) else project_id
                    query = query.where(File.project_id == pid)
                query = query.where(File.name == clean_name)
                result = await db.execute(query)
                file_obj = result.scalar_one_or_none()

                if file_obj:
                    print(f"[chat] 从数据库找到文件: id={file_obj.id}, content长度={len(file_obj.content or '')}")
                    # 拼接文件物理路径（相对路径，适配部署）
                    file_path = os.path.join(settings.UPLOAD_DIR, f"project_{file_obj.project_id}", file_obj.name)
                    attached_files.append({
                        "file_id": file_obj.id,
                        "file_name": file_obj.name,
                        "content": file_obj.content or "",
                        "file_path": file_path
                    })
                else:
                    print(f"[chat] 数据库中未找到文件: {file_name}")

    # ============================================
    # 获取上一次的工作流状态（优先使用前端传入的，否则从数据库恢复）
    # ============================================
    workflow_state = chat_request.workflow_state
    if not workflow_state and conversation_id:
        # 从数据库恢复最后一次的 workflow_state
        last_msg_query = select(Message).where(
            Message.conversation_id == conversation_id,
            Message.role == "assistant"
        ).order_by(desc(Message.id)).limit(1)
        last_msg_result = await db.execute(last_msg_query)
        last_msg = last_msg_result.scalar_one_or_none()
        if last_msg and last_msg.workflow_state:
            try:
                workflow_state = json.loads(last_msg.workflow_state)
                print(f"[chat] 从数据库恢复 workflow_state: phase={workflow_state.get('phase', 'N/A')}")
            except:
                pass

    # ============================================
    # 使用智能对话服务处理
    # ============================================
    chat_service = get_chat_service()
    
    try:
        result = await chat_service.chat(
            message=chat_request.message,
            conversation_id=conversation_id,
            project_id=chat_request.project_id,
            history=history,
            attached_files=attached_files,
            workflow_state=workflow_state,
            collected_params=chat_request.collected_params,
            db=db  # 传递数据库会话
        )
        
        response_content = result.get("content", "")
        response_widget = result.get("widget")  # 获取 Widget 配置
        response_workflow_state = result.get("workflow_state")
        
    except Exception as e:
        # 降级响应
        response_content = f"抱歉，处理您的请求时遇到问题：{str(e)}"
        response_widget = None
        response_workflow_state = None

    # 保存 AI 响应（包含 workflow_state）
    assistant_message = Message(
        conversation_id=conversation_id,
        role="assistant",
        content=response_content,
        workflow_state=json.dumps(response_workflow_state) if response_workflow_state else None
    )
    db.add(assistant_message)
    await db.commit()
    await db.refresh(assistant_message)

    return {
        "code": 0,
        "data": {
            "message_id": assistant_message.id,
            "conversation_id": conversation_id,
            "role": "assistant",
            "content": response_content,
            "widget": response_widget,
            "workflow_state": response_workflow_state
        }
    }


async def generate_stream_response(
    chat_request: ChatRequest,
    db: AsyncSession
):
    """生成流式响应"""
    # 获取或创建会话
    conversation_id = chat_request.conversation_id
    if conversation_id:
        session_query = select(Conversation).where(Conversation.id == conversation_id)
        session_result = await db.execute(session_query)
        conversation = session_result.scalar_one_or_none()
        if not conversation:
            raise HTTPException(status_code=404, detail="会话不存在")
    else:
        conversation = Conversation(
            project_id=chat_request.project_id,
            title=chat_request.message[:50] + "..." if len(chat_request.message) > 50 else chat_request.message
        )
        db.add(conversation)
        await db.commit()
        await db.refresh(conversation)
        conversation_id = conversation.id

    # 保存用户消息
    user_message = Message(
        conversation_id=conversation_id,
        role="user",
        content=chat_request.message
    )
    db.add(user_message)
    await db.commit()

    # 获取对话历史
    history_query = select(Message).where(
        Message.conversation_id == conversation_id
    ).order_by(Message.id.asc()).limit(20)
    history_result = await db.execute(history_query)
    history_messages = history_result.scalars().all()
    history = [{"role": m.role, "content": m.content} for m in history_messages]

    # 获取附件
    attached_files = []
    if chat_request.attached_file_ids:
        file_query = select(File).where(File.id.in_(chat_request.attached_file_ids))
        file_result = await db.execute(file_query)
        files = file_result.scalars().all()
        for f in files:
            attached_files.append({
                "file_id": f.id,
                "file_name": f.name,
                "content": f.content or ""
            })

    # 使用智能对话服务
    chat_service = get_chat_service()

    try:
        result = await chat_service.chat(
            message=chat_request.message,
            conversation_id=conversation_id,
            project_id=chat_request.project_id,
            history=history,
            attached_files=attached_files
        )

        full_response = result.get("content", "")

        # 流式返回
        for char in full_response:
            yield f"data: {json.dumps({'delta': char})}\n\n"
            import asyncio
            await asyncio.sleep(0.01)

        yield f"data: {json.dumps({'done': True})}\n\n"

    except Exception as e:
        error_msg = f"抱歉，处理您的请求时遇到问题。"
        for char in error_msg:
            yield f"data: {json.dumps({'delta': char})}\n\n"
            import asyncio
            await asyncio.sleep(0.01)

    yield "data: [DONE]\n\n"


@router.post("/chat/stream")
async def stream_message(
    chat_request: ChatRequest,
    db: AsyncSession = Depends(get_db)
):
    """发送消息（SSE流式响应）"""
    return StreamingResponse(
        generate_stream_response(chat_request, db),
        media_type="text/event-stream"
    )


# ==================== 智能对话测试接口 ====================

@router.post("/chat/smart/test")
async def test_smart_chat(
    user_query: str = Query(..., description="测试查询内容"),
    project_id: Optional[int] = Query(None, description="项目ID")
):
    """
    测试智能对话 - 直接测试大模型对话能力
    """
    chat_service = get_chat_service()

    result = await chat_service.chat(
        message=user_query,
        conversation_id=0,
        project_id=project_id,
        history=[]
    )

    return {
        "code": 0,
        "data": {
            "query": user_query,
            "response": result.get("content", ""),
            "needs_tool": result.get("needs_tool", False),
            "tool_name": result.get("tool_name")
        }
    }

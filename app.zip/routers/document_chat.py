"""
文书生成对话 API 路由
专门处理文书生成对话流程：大模型意图识别 + 模板选择 + 参数收集
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import Optional, List, Dict, Any
import uuid
import json

from ..database import get_db
from ..models import Conversation, Message, Project, File
from ..schemas import ChatRequest
from ..document_chat_service import (
    get_document_chat_service,
    DialogContext,
    WorkflowPhase
)
from ..services.ai_service import AIService

router = APIRouter(prefix="/api/document-chat", tags=["文书生成对话"])


# 会话存储（生产环境应使用 Redis）
_session_store: Dict[str, Dict[str, Any]] = {}


def get_session_id(conversation_id: int, project_id: Optional[int] = None) -> str:
    """生成会话ID"""
    return f"doc_chat_{conversation_id}_{project_id or 0}"


def get_or_create_context(
    session_id: str,
    conversation_id: int,
    project_id: Optional[int] = None
) -> DialogContext:
    """获取或创建对话上下文"""
    if session_id in _session_store:
        data = _session_store[session_id]
        return DialogContext.from_dict(data)
    
    return DialogContext(
        session_id=session_id,
        conversation_id=conversation_id,
        project_id=project_id
    )


def save_context(context: DialogContext):
    """保存对话上下文"""
    _session_store[context.session_id] = context.to_dict()


@router.get("/templates")
async def get_template_list():
    """
    获取文书模板列表
    返回按类型分组的模板
    """
    from ..document_chat_service import DocumentChatService
    
    return {
        "code": 0,
        "data": {
            "categories": DocumentChatService.TEMPLATE_CATEGORIES
        }
    }


@router.get("/templates/{template_id}/params")
async def get_template_params(template_id: str):
    """
    获取模板参数定义
    
    Args:
        template_id: 模板ID（如 divorce_lawsuit, labor_arbitration 等）
    """
    from ..document_chat_service import DocumentChatService
    
    service = DocumentChatService()
    params = service._get_template_params(template_id)
    template_name = service._get_template_name(template_id)
    
    # 转换为前端友好格式
    formatted_params = []
    for key, info in params.items():
        formatted_params.append({
            "key": key,
            "label": info.get("label", key),
            "type": info.get("type", "text"),
            "required": info.get("required", False),
            "description": info.get("description", ""),
            "options": info.get("options", [])
        })
    
    return {
        "code": 0,
        "data": {
            "template_id": template_id,
            "template_name": template_name,
            "params": formatted_params,
            "required_count": len([p for p in formatted_params if p["required"]]),
            "optional_count": len([p for p in formatted_params if not p["required"]])
        }
    }


@router.post("/chat")
async def document_chat(
    chat_request: ChatRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    文书生成对话 - 处理用户消息
    
    流程：
    1. 意图识别（大模型）
    2. 模板选择（Widget）
    3. 参数收集（大模型提取）
    4. 文书生成
    """
    conversation_id = chat_request.conversation_id or 0
    session_id = get_session_id(conversation_id, chat_request.project_id)
    
    # 获取对话上下文
    context = get_or_create_context(
        session_id,
        conversation_id,
        chat_request.project_id
    )
    
    # 获取对话历史
    history = []
    if conversation_id:
        history_query = select(Message).where(
            Message.conversation_id == conversation_id
        ).order_by(Message.id.desc()).limit(10)
        history_result = await db.execute(history_query)
        history_messages = history_result.scalars().all()
        history = [{"role": m.role, "content": m.content} for m in reversed(history_messages)]
    
    # 初始化服务
    ai_service = AIService()
    doc_service = get_document_chat_service(ai_service)
    
    # 处理消息
    try:
        result = await doc_service.process_message(
            message=chat_request.message,
            context=context,
            conversation_history=history
        )
        
        response_content = result.get("content", "")
        widget = result.get("widget")
        intent = result.get("intent", {})
        
    except Exception as e:
        response_content = f"处理请求时遇到问题：{str(e)}"
        widget = None
        intent = {}
    
    # 保存上下文
    save_context(context)
    
    return {
        "code": 0,
        "data": {
            "content": response_content,
            "widget": widget,
            "intent": intent,
            "workflow_state": {
                "phase": context.workflow_phase,
                "step": context.step,
                "doc_type": context.document_params.doc_type,
                "template_name": context.document_params.template_name,
                "collected_count": len(context.document_params.collected_fields),
                "pending_count": len(context.document_params.pending_fields),
                "document_path": context.generated_document_path
            }
        }
    }


@router.get("/context")
async def get_context(
    conversation_id: int = Query(..., description="会话ID"),
    project_id: Optional[int] = Query(None, description="项目ID")
):
    """
    获取当前对话上下文
    """
    session_id = get_session_id(conversation_id, project_id)
    
    if session_id not in _session_store:
        return {
            "code": 0,
            "data": {
                "exists": False,
                "context": None
            }
        }
    
    context_data = _session_store[session_id]
    
    return {
        "code": 0,
        "data": {
            "exists": True,
            "context": context_data
        }
    }


@router.post("/context/reset")
async def reset_context(
    conversation_id: int = Query(..., description="会话ID"),
    project_id: Optional[int] = Query(None, description="项目ID")
):
    """
    重置对话上下文
    """
    session_id = get_session_id(conversation_id, project_id)
    
    if session_id in _session_store:
        del _session_store[session_id]
    
    return {
        "code": 0,
        "message": "上下文已重置"
    }


@router.post("/generate")
async def generate_document(
    conversation_id: int = Query(..., description="会话ID"),
    project_id: int = Query(..., description="项目ID"),
    db: AsyncSession = Depends(get_db)
):
    """
    生成文书
    当所有参数收集完毕后调用此接口生成文书
    """
    session_id = get_session_id(conversation_id, project_id)
    
    if session_id not in _session_store:
        raise HTTPException(status_code=400, detail="对话上下文不存在，请重新开始对话")
    
    context_data = _session_store[session_id]
    context = DialogContext.from_dict(context_data)
    
    # 检查参数是否完整
    if not context.document_params.collected_fields:
        raise HTTPException(status_code=400, detail="未收集到任何参数")
    
    # 调用文书生成
    from ..workflow_tools import generate_document_from_template
    
    try:
        result = await generate_document_from_template(
            document_type=context.document_params.template_name,
            dispute_type=context.document_params.doc_type,
            params=context.document_params.collected_fields
        )
        
        # 更新上下文
        context.generated_document_path = result.get("file_path", "")
        context.workflow_phase = WorkflowPhase.COMPLETED.value
        save_context(context)
        
        return {
            "code": 0,
            "data": {
                "success": True,
                "file_path": result.get("file_path"),
                "file_name": result.get("file_name"),
                "message": "文书生成成功"
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"生成失败：{str(e)}")


# ==================== 意图识别测试接口 ====================

@router.post("/intent/recognize")
async def recognize_intent(
    user_query: str = Query(..., description="用户查询"),
    conversation_history: Optional[str] = Query(None, description="对话历史（JSON数组）")
):
    """
    测试意图识别
    直接调用大模型识别用户意图
    """
    from ..document_chat_service import IntentRecognizer
    
    history = []
    if conversation_history:
        try:
            history = json.loads(conversation_history)
        except:
            pass
    
    ai_service = AIService()
    recognizer = IntentRecognizer(ai_service)
    
    result = await recognizer.recognize_intent(user_query, history)
    
    return {
        "code": 0,
        "data": {
            "query": user_query,
            "result": result
        }
    }


@router.post("/intent/detect-change")
async def detect_intent_change(
    user_query: str = Query(..., description="用户最新回复"),
    current_intent: str = Query(..., description="当前意图（JSON）"),
    current_doc_type: str = Query("", description="当前文书类型"),
    conversation_history: Optional[str] = Query(None, description="对话历史（JSON数组）")
):
    """
    测试意图变更检测
    判断用户是否切换了意图
    """
    from ..document_chat_service import IntentRecognizer, IntentInfo
    
    history = []
    if conversation_history:
        try:
            history = json.loads(conversation_history)
        except:
            pass
    
    intent_data = json.loads(current_intent)
    current = IntentInfo(
        primary=intent_data.get("primary", ""),
        secondary=intent_data.get("secondary", ""),
        specific=intent_data.get("specific", ""),
        confidence=intent_data.get("confidence", 0.0)
    )
    
    ai_service = AIService()
    recognizer = IntentRecognizer(ai_service)
    
    result = await recognizer.detect_intent_change(
        user_query, current, current_doc_type, history
    )
    
    return {
        "code": 0,
        "data": {
            "query": user_query,
            "result": result
        }
    }


@router.post("/params/extract")
async def extract_params(
    user_reply: str = Query(..., description="用户回复"),
    doc_type: str = Query(..., description="文书类型"),
    template_params: str = Query(..., description="模板参数定义（JSON）"),
    collected_params: str = Query("{}", description="已收集参数（JSON）")
):
    """
    测试参数提取
    从用户回复中提取文书参数
    """
    from ..document_chat_service import IntentRecognizer
    
    params = json.loads(template_params)
    collected = json.loads(collected_params)
    
    ai_service = AIService()
    recognizer = IntentRecognizer(ai_service)
    
    result = await recognizer.extract_params(
        user_reply, doc_type, params, collected
    )
    
    return {
        "code": 0,
        "data": {
            "reply": user_reply,
            "doc_type": doc_type,
            "result": result
        }
    }

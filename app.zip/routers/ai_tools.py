"""
AI 工具 API 路由
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional, List

from ..database import get_db
from ..models import Project, File, AiTool
from ..schemas import AiToolResponse, AiToolListResponse
from ..services.ai_service import AIService

router = APIRouter(prefix="/api/ai", tags=["AI工具"])


# 默认 AI 工具配置
DEFAULT_AI_TOOLS = [
    {"name": "file_read", "display_name": "读取文件", "description": "读取项目中的文件内容", "category": "file"},
    {"name": "file_write", "display_name": "写入文件", "description": "创建或修改项目中的文件", "category": "file"},
    {"name": "file_delete", "display_name": "删除文件", "description": "删除项目中的文件", "category": "file"},
    {"name": "folder_create", "display_name": "创建文件夹", "description": "在项目中创建新文件夹", "category": "file"},
    {"name": "folder_delete", "display_name": "删除文件夹", "description": "删除项目中的文件夹", "category": "file"},
    {"name": "knowledge_search", "display_name": "知识库检索", "description": "在知识库中搜索相关法律资料", "category": "knowledge"},
    {"name": "knowledge_write", "display_name": "知识库写入", "description": "向知识库添加新文档", "category": "knowledge"},
    {"name": "law_search", "display_name": "法律条文检索", "description": "检索相关法律法规条文", "category": "search"},
    {"name": "case_search", "display_name": "案例检索", "description": "检索相关司法案例", "category": "search"},
    {"name": "contract_analyze", "display_name": "合同分析", "description": "分析合同内容和条款", "category": "ai"},
    {"name": "contract_risk_review", "display_name": "合同风险审查", "description": "审查合同潜在风险", "category": "ai"},
    {"name": "draft_document", "display_name": "起草法律文书", "description": "AI起草法律文书", "category": "ai"},
    {"name": "chat", "display_name": "对话咨询", "description": "与用户进行法律问答", "category": "ai"},
]


@router.get("/tools", response_model=AiToolListResponse)
async def get_ai_tools(db: AsyncSession = Depends(get_db)):
    """获取所有AI工具配置"""
    query = select(AiTool).order_by(AiTool.category, AiTool.id)
    result = await db.execute(query)
    tools = result.scalars().all()

    # 如果没有工具，初始化默认工具
    if not tools:
        for tool_data in DEFAULT_AI_TOOLS:
            db_tool = AiTool(**tool_data, enabled=1)
            db.add(db_tool)
        await db.commit()
        result = await db.execute(query)
        tools = result.scalars().all()

    return AiToolListResponse(
        tools=[AiToolResponse.model_validate(t) for t in tools],
        total=len(tools)
    )


@router.get("/tools/enabled")
async def get_enabled_tools(db: AsyncSession = Depends(get_db)):
    """获取已启用的AI工具列表（供AI调用）"""
    query = select(AiTool).where(AiTool.enabled == 1)
    result = await db.execute(query)
    tools = result.scalars().all()

    return {
        "code": 0,
        "tools": [
            {
                "name": t.name,
                "display_name": t.display_name,
                "description": t.description,
                "category": t.category
            }
            for t in tools
        ]
    }


@router.put("/tools/{tool_id}")
async def update_tool(tool_id: int, enabled: int, db: AsyncSession = Depends(get_db)):
    """更新AI工具启用状态"""
    query = select(AiTool).where(AiTool.id == tool_id)
    result = await db.execute(query)
    tool = result.scalar_one_or_none()

    if not tool:
        raise HTTPException(status_code=404, detail="工具不存在")

    tool.enabled = enabled
    await db.commit()

    return {"code": 0, "message": "更新成功"}


@router.post("/tools/init")
async def init_default_tools(db: AsyncSession = Depends(get_db)):
    """初始化默认AI工具（管理员操作）"""
    # 清空现有工具
    await db.execute(select(AiTool))
    existing = await db.execute(select(AiTool))
    existing_tools = existing.scalars().all()

    for tool in existing_tools:
        await db.delete(tool)

    # 添加默认工具
    for tool_data in DEFAULT_AI_TOOLS:
        db_tool = AiTool(**tool_data, enabled=1)
        db.add(db_tool)

    await db.commit()

    return {"code": 0, "message": "初始化成功"}


class ContractAnalysisRequest(BaseModel):
    """合同分析请求"""
    file_id: Optional[int] = None
    content: Optional[str] = None


class ContractRiskReviewRequest(BaseModel):
    """合同风险审查请求"""
    file_id: Optional[int] = None
    content: Optional[str] = None
    contract_type: Optional[str] = None


class DraftDocumentRequest(BaseModel):
    """起草文档请求"""
    project_id: int
    document_type: str  # lawsuit, defense, proxy, etc.
    description: str
    context: Optional[str] = None


@router.post("/analyze-contract", response_model=dict)
async def analyze_contract(
    request: ContractAnalysisRequest,
    db: AsyncSession = Depends(get_db)
):
    """合同语义分析"""
    content = request.content
    
    # 如果提供了文件ID，获取文件内容
    if request.file_id:
        file_query = select(File).where(File.id == request.file_id)
        file_result = await db.execute(file_query)
        file = file_result.scalar_one_or_none()
        if not file:
            raise HTTPException(status_code=404, detail="文件不存在")
        content = file.content
    
    if not content:
        raise HTTPException(status_code=400, detail="请提供合同内容或文件ID")
    
    ai_service = AIService()
    result = await ai_service.analyze_contract(content)
    
    return {
        "code": 0,
        "data": result
    }


@router.post("/risk-review", response_model=dict)
async def risk_review(
    request: ContractRiskReviewRequest,
    db: AsyncSession = Depends(get_db)
):
    """合同风险审查"""
    content = request.content
    
    # 如果提供了文件ID，获取文件内容
    if request.file_id:
        file_query = select(File).where(File.id == request.file_id)
        file_result = await db.execute(file_query)
        file = file_result.scalar_one_or_none()
        if not file:
            raise HTTPException(status_code=404, detail="文件不存在")
        content = file.content
    
    if not content:
        raise HTTPException(status_code=400, detail="请提供合同内容或文件ID")
    
    ai_service = AIService()
    result = await ai_service.contract_risk_review(content, request.contract_type)
    
    return {
        "code": 0,
        "data": result
    }


@router.post("/draft-document", response_model=dict)
async def draft_document(
    request: DraftDocumentRequest,
    db: AsyncSession = Depends(get_db)
):
    """AI起草文档"""
    # 验证项目存在
    project_query = select(Project).where(Project.id == request.project_id)
    project_result = await db.execute(project_query)
    project = project_result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    
    ai_service = AIService()
    result = await ai_service.draft_document(
        document_type=request.document_type,
        description=request.description,
        context=request.context
    )
    
    return {
        "code": 0,
        "data": {
            "content": result,
            "document_type": request.document_type
        }
    }

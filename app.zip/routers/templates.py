"""
文书模板 API 路由
模板管理：上传、查询、使用模板
每个模板由3个文件组成：空白模板、带占位符模板、占位符字典JSON
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query, Form
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import os
import json
import shutil
from datetime import datetime

from ..database import get_db
from ..models import Template
from ..config import settings

router = APIRouter(prefix="/api/templates", tags=["模板管理"])


# ============ 存储配置 ============

TEMPLATE_DIR = os.path.join(settings.UPLOAD_DIR, "templates")


def ensure_template_dir():
    """确保模板目录存在"""
    os.makedirs(TEMPLATE_DIR, exist_ok=True)


# ============ 请求/响应模型 ============

class TemplateCreate(BaseModel):
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    author: Optional[str] = None
    tags: Optional[str] = None
    version: str = "1.0"


class TemplateUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    author: Optional[str] = None
    tags: Optional[str] = None
    version: Optional[str] = None
    is_active: Optional[int] = None


class TemplateResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    category: Optional[str]
    blank_template_path: Optional[str]
    placeholder_template_path: Optional[str]
    dictionary_path: Optional[str]
    placeholder_dict: Optional[Dict[str, Any]]
    author: Optional[str]
    tags: Optional[str]
    version: str
    is_active: int
    created_at: datetime
    updated_at: datetime


class PlaceholderParams(BaseModel):
    """模板填充参数"""
    params: Dict[str, str]  # {占位符名称: 实际值}


# ============ 文件命名规范 ============

def validate_template_files(files: List[UploadFile]) -> Dict[str, UploadFile]:
    """
    验证并分组模板文件
    根据文件类型（MIME）自动识别：
    - application/vnd.openxmlformats-officedocument.wordprocessingml.document -> docx
    - application/json -> dictionary
    
    返回: {"blank": xxx, "placeholder": xxx, "dictionary": xxx}
    """
    result = {"blank": None, "placeholder": None, "dictionary": None}
    
    for f in files:
        if not f.filename:
            continue
        
        content_type = f.content_type or ""
        fname_lower = f.filename.lower()
        
        # 根据 MIME 类型识别
        if "wordprocessingml" in content_type or content_type in ["application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]:
            # Word 文档：第一个是空白模板，第二个是占位符模板
            if result["blank"] is None:
                result["blank"] = f
            elif result["placeholder"] is None:
                result["placeholder"] = f
        
        elif content_type == "application/json" or fname_lower.endswith(".json"):
            result["dictionary"] = f
        
        # 也根据文件名关键词识别（备选）
        elif result["dictionary"] is None and ("dict" in fname_lower or "dictionary" in fname_lower or "字典" in fname_lower or "参数" in fname_lower):
            result["dictionary"] = f
    
    return result


# ============ 模板接口 ============

@router.post("", status_code=201)
async def create_template(
    files: List[UploadFile] = File(...),
    name: str = Form(..., description="模板名称"),
    description: Optional[str] = Form(None, description="模板描述"),
    category: Optional[str] = Form(None, description="分类"),
    author: Optional[str] = Form(None, description="作者"),
    tags: Optional[str] = Form(None, description="标签，逗号分隔"),
    version: str = Form("1.0", description="版本号"),
    db: AsyncSession = Depends(get_db)
):
    """
    上传文书模板（3个文件）
    
    支持任意文件名的上传，后端会自动按规范重命名：
    - 空白模板 -> xxx_blank.docx
    - 占位符模板 -> xxx_placeholder.docx  
    - 参数字典 -> xxx_dict.json
    
    占位符格式：{{ placeholder_name }} 或 {{ placeholder_name:"默认值" }}
    """
    ensure_template_dir()
    
    # 验证文件（根据文件类型检测，不限制名称）
    file_map = validate_template_files(files)
    
    missing_files = []
    if not file_map["blank"]:
        missing_files.append("空白模板 (.docx)")
    if not file_map["placeholder"]:
        missing_files.append("占位符模板 (.docx)")
    if not file_map["dictionary"]:
        missing_files.append("参数字典 (.json)")
    
    if missing_files:
        raise HTTPException(
            status_code=400,
            detail={
                "message": f"缺少必需文件: {', '.join(missing_files)}",
                "hint": "请上传3个文件：空白模板(.docx)、占位符模板(.docx)、参数字典(.json)",
                "missing_files": missing_files
            }
        )
    
    # 创建模板目录
    import uuid
    template_id = uuid.uuid4().hex[:8]
    template_dir = os.path.join(TEMPLATE_DIR, f"{name}_{template_id}")
    os.makedirs(template_dir, exist_ok=True)
    
    saved_files = {}
    placeholder_dict = {}
    
    # 保存各文件（自动重命名）
    try:
        # 1. 保存空白模板（自动重命名为 name_blank.docx）
        blank_content = await file_map["blank"].read()
        blank_filename = f"{name}_blank.docx"
        blank_path = os.path.join(template_dir, blank_filename)
        with open(blank_path, 'wb') as f:
            f.write(blank_content)
        saved_files["blank"] = blank_path
        
        # 2. 保存占位符模板（自动重命名为 name_placeholder.docx）
        placeholder_content = await file_map["placeholder"].read()
        placeholder_filename = f"{name}_placeholder.docx"
        placeholder_path = os.path.join(template_dir, placeholder_filename)
        with open(placeholder_path, 'wb') as f:
            f.write(placeholder_content)
        saved_files["placeholder"] = placeholder_path
        
        # 3. 解析并保存参数字典（自动重命名为 name_dict.json）
        dict_content = await file_map["dictionary"].read()
        try:
            placeholder_dict = json.loads(dict_content.decode('utf-8'))
            if not isinstance(placeholder_dict, dict):
                raise ValueError("字典必须是JSON对象")
        except json.JSONDecodeError as e:
            raise HTTPException(status_code=400, detail=f"参数字典JSON格式错误: {e}")
        
        dict_filename = f"{name}_dict.json"
        dict_path = os.path.join(template_dir, dict_filename)
        with open(dict_path, 'w', encoding='utf-8') as f:
            json.dump(placeholder_dict, f, ensure_ascii=False, indent=2)
        saved_files["dictionary"] = dict_path
        
        # 4. 创建数据库记录
        db_template = Template(
            name=name,
            description=description,
            category=category,
            blank_template_path=saved_files["blank"],
            placeholder_template_path=saved_files["placeholder"],
            dictionary_path=saved_files["dictionary"],
            placeholder_dict=json.dumps(placeholder_dict, ensure_ascii=False),
            author=author,
            tags=tags,
            version=version,
            is_active=1
        )
        db.add(db_template)
        await db.commit()
        await db.refresh(db_template)
        
        # 返回统一格式
        return {
            "code": 0,
            "message": "模板上传成功",
            "data": TemplateResponse(
                id=db_template.id,
                name=db_template.name,
                description=db_template.description,
                category=db_template.category,
                blank_template_path=db_template.blank_template_path,
                placeholder_template_path=db_template.placeholder_template_path,
                dictionary_path=db_template.dictionary_path,
                placeholder_dict=placeholder_dict,
                author=db_template.author,
                tags=db_template.tags,
                version=db_template.version,
                is_active=db_template.is_active,
                created_at=db_template.created_at,
                updated_at=db_template.updated_at
            )
        }
        
    except HTTPException:
        raise
    except Exception as e:
        # 清理已创建的文件
        for path in saved_files.values():
            if os.path.exists(path):
                os.remove(path)
        if os.path.exists(template_dir):
            shutil.rmtree(template_dir)
        raise HTTPException(status_code=500, detail=f"创建模板失败: {str(e)}")


@router.get("")
async def list_templates(
    category: Optional[str] = Query(None, description="按分类筛选"),
    is_active: Optional[int] = Query(None, description="是否启用"),
    db: AsyncSession = Depends(get_db)
):
    """获取模板列表"""
    query = select(Template)
    
    if category:
        query = query.where(Template.category == category)
    if is_active is not None:
        query = query.where(Template.is_active == is_active)
    
    query = query.order_by(Template.created_at.desc())
    result = await db.execute(query)
    templates = result.scalars().all()
    
    return {
        "code": 0,
        "data": [
            TemplateResponse(
                id=t.id,
                name=t.name,
                description=t.description,
                category=t.category,
                blank_template_path=t.blank_template_path,
                placeholder_template_path=t.placeholder_template_path,
                dictionary_path=t.dictionary_path,
                placeholder_dict=json.loads(t.placeholder_dict) if t.placeholder_dict else {},
                author=t.author,
                tags=t.tags,
                version=t.version,
                is_active=t.is_active,
                created_at=t.created_at,
                updated_at=t.updated_at
            )
            for t in templates
        ]
    }


@router.get("/search/")
async def search_templates(
    keyword: str = Query(..., description="搜索关键词"),
    db: AsyncSession = Depends(get_db)
):
    """
    搜索模板 - 支持模糊匹配
    """
    from ..services.template_service import TemplateService
    
    service = TemplateService(db)
    templates = await service.search_templates(keyword)
    
    return {
        "code": 0,
        "data": templates,
        "total": len(templates)
    }


@router.get("/find/")
async def find_template(
    keyword: str = Query(None, description="搜索关键词（名称模糊匹配）"),
    template_id: int = Query(None, description="模板ID（精确匹配）"),
    db: AsyncSession = Depends(get_db)
):
    """
    查找模板 - 按ID或关键词查找
    
    优先使用 template_id 精确匹配，失败后使用 keyword 模糊搜索
    """
    from ..services.template_service import TemplateService
    
    service = TemplateService(db)
    
    # 优先按ID查找
    if template_id:
        template = await service.get_template_by_id(template_id)
        if template:
            return {"code": 0, "data": template, "match_type": "id"}
    
    # 按关键词模糊搜索
    if keyword:
        templates = await service.search_templates(keyword)
        if templates:
            # 返回第一个匹配结果
            return {"code": 0, "data": templates[0], "match_type": "keyword", "all_matches": templates}
    
    raise HTTPException(status_code=404, detail="未找到匹配的模板")


@router.get("/{template_id}")
async def get_template(
    template_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取模板详情"""
    query = select(Template).where(Template.id == template_id)
    result = await db.execute(query)
    template = result.scalar_one_or_none()
    
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    return {
        "code": 0,
        "data": TemplateResponse(
            id=template.id,
            name=template.name,
            description=template.description,
            category=template.category,
            blank_template_path=template.blank_template_path,
            placeholder_template_path=template.placeholder_template_path,
            dictionary_path=template.dictionary_path,
            placeholder_dict=json.loads(template.placeholder_dict) if template.placeholder_dict else {},
            author=template.author,
            tags=template.tags,
            version=template.version,
            is_active=template.is_active,
            created_at=template.created_at,
            updated_at=template.updated_at
        )
    }


@router.put("/{template_id}")
async def update_template(
    template_id: int,
    update_data: TemplateUpdate,
    db: AsyncSession = Depends(get_db)
):
    """更新模板信息"""
    query = select(Template).where(Template.id == template_id)
    result = await db.execute(query)
    template = result.scalar_one_or_none()
    
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    # 更新字段
    update_dict = update_data.model_dump(exclude_unset=True)
    for key, value in update_dict.items():
        setattr(template, key, value)
    
    await db.commit()
    await db.refresh(template)
    
    return {
        "code": 0,
        "data": TemplateResponse(
            id=template.id,
            name=template.name,
            description=template.description,
            category=template.category,
            blank_template_path=template.blank_template_path,
            placeholder_template_path=template.placeholder_template_path,
            dictionary_path=template.dictionary_path,
            placeholder_dict=json.loads(template.placeholder_dict) if template.placeholder_dict else {},
            author=template.author,
            tags=template.tags,
            version=template.version,
            is_active=template.is_active,
            created_at=template.created_at,
            updated_at=template.updated_at
        )
    }


@router.delete("/{template_id}")
async def delete_template(
    template_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除模板（同时删除文件）"""
    query = select(Template).where(Template.id == template_id)
    result = await db.execute(query)
    template = result.scalar_one_or_none()
    
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    # 删除物理文件
    template_dir = os.path.dirname(template.blank_template_path) if template.blank_template_path else None
    if template_dir and os.path.exists(template_dir):
        shutil.rmtree(template_dir)
    
    # 删除数据库记录
    await db.delete(template)
    await db.commit()
    
    return {"code": 0, "message": "模板已删除"}


@router.get("/{template_id}/preview")
async def preview_template(
    template_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    获取模板预览（返回空白模板内容）
    用于在选择模板时展示给用户查看
    """
    query = select(Template).where(Template.id == template_id)
    result = await db.execute(query)
    template = result.scalar_one_or_none()
    
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    if not template.blank_template_path or not os.path.exists(template.blank_template_path):
        raise HTTPException(status_code=404, detail="空白模板文件不存在")
    
    # 读取空白模板
    from ..utils.file_processor import extract_text_from_file
    content = extract_text_from_file(template.blank_template_path, "docx")
    
    return {
        "code": 0,
        "data": {
            "id": template.id,
            "name": template.name,
            "description": template.description,
            "content": content,
            "placeholder_dict": json.loads(template.placeholder_dict) if template.placeholder_dict else {}
        }
    }


@router.post("/{template_id}/fill")
async def fill_template(
    template_id: int,
    params: PlaceholderParams,
    project_id: int = Query(..., description="目标项目ID"),
    output_filename: Optional[str] = Query(None, description="输出文件名"),
    db: AsyncSession = Depends(get_db)
):
    """
    填充模板：复制占位符模板到项目目录，替换占位符
    
    工作流程：
    1. 验证所有必填参数都已提供
    2. 复制占位符模板到项目目录
    3. 读取模板内容
    4. 替换所有占位符
    5. 保存到项目目录
    """
    from ..models import Project
    
    # 1. 获取模板
    query = select(Template).where(Template.id == template_id)
    result = await db.execute(query)
    template = result.scalar_one_or_none()
    
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    if not template.placeholder_template_path or not os.path.exists(template.placeholder_template_path):
        raise HTTPException(status_code=404, detail="占位符模板文件不存在")
    
    # 2. 获取模板参数定义
    placeholder_def = json.loads(template.placeholder_dict) if template.placeholder_dict else {}
    
    # 3. 验证参数
    missing_params = []
    for param_key in placeholder_def.keys():
        if param_key not in params.params:
            missing_params.append({
                "key": param_key,
                "description": placeholder_def[param_key]
            })
    
    if missing_params:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "缺少必填参数",
                "missing_params": missing_params
            }
        )
    
    # 4. 检查项目
    project_query = select(Project).where(Project.id == project_id)
    project_result = await db.execute(project_query)
    project = project_result.scalar_one_or_none()
    
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    
    # 5. 复制模板到项目目录
    project_dir = os.path.join(settings.UPLOAD_DIR, f"project_{project_id}")
    os.makedirs(project_dir, exist_ok=True)
    
    if output_filename:
        if not output_filename.endswith('.docx'):
            output_filename += '.docx'
    else:
        output_filename = f"{template.name}_填充.docx"
    
    output_path = os.path.join(project_dir, output_filename)
    
    # 复制文件
    shutil.copy2(template.placeholder_template_path, output_path)
    
    # 6. 替换占位符
    from ..utils.docx_processor import apply_docx_modifications, read_docx_paragraphs
    
    # 读取文档获取当前内容
    doc_content = read_docx_paragraphs(output_path)
    
    # 构建替换修改列表
    modifications = []
    for param_key, param_value in params.params.items():
        # 占位符格式
        placeholder_spaced = f"{{{{ {param_key} }}}}"  # {{ key }} 有空格
        placeholder_no_space = f"{{{{ {param_key}}}}}"  # {{key}} 无空格
        placeholder_alt = f"{{{{{param_key}}}}}"  # {{{key}}} 三重大括号
        
        # 1. 处理段落中的占位符
        for para in doc_content.get("paragraphs", []):
            para_text = para.get("text", "")
            
            if placeholder_spaced in para_text:
                modifications.append({
                    "type": "modify",
                    "index": para.get("index"),
                    "text": placeholder_spaced,
                    "new_text": param_value
                })
            elif placeholder_no_space in para_text:
                modifications.append({
                    "type": "modify",
                    "index": para.get("index"),
                    "text": placeholder_no_space,
                    "new_text": param_value
                })
            elif placeholder_alt in para_text:
                modifications.append({
                    "type": "modify",
                    "index": para.get("index"),
                    "text": placeholder_alt,
                    "new_text": param_value
                })
        
        # 2. 处理表格单元格中的占位符
        for table_idx, table_info in enumerate(doc_content.get("tables", [])):
            for row_idx, row in enumerate(table_info.get("cells", [])):
                for col_idx, cell_text in enumerate(row):
                    if not cell_text:
                        continue
                    
                    cell_index = f"t{table_idx}_r{row_idx}_c{col_idx}"
                    
                    if placeholder_spaced in cell_text:
                        modifications.append({
                            "type": "cell_modify",
                            "index": cell_index,
                            "text": placeholder_spaced,
                            "new_text": param_value
                        })
                    elif placeholder_no_space in cell_text:
                        modifications.append({
                            "type": "cell_modify",
                            "index": cell_index,
                            "text": placeholder_no_space,
                            "new_text": param_value
                        })
                    elif placeholder_alt in cell_text:
                        modifications.append({
                            "type": "cell_modify",
                            "index": cell_index,
                            "text": placeholder_alt,
                            "new_text": param_value
                        })
    
    # 执行替换
    if modifications:
        result = apply_docx_modifications(output_path, modifications)
        if not result.get("success"):
            # 尝试简单文本替换
            with open(output_path, 'rb') as f:
                content_bytes = f.read()
            
            content_str = content_bytes.decode('utf-8', errors='ignore')
            for param_key, param_value in params.params.items():
                placeholder_spaced = f"{{{{ {param_key} }}}}"
                placeholder_no_space = f"{{{{ {param_key}}}}}"
                placeholder_alt = f"{{{{{param_key}}}}}"
                content_str = content_str.replace(placeholder_spaced, param_value)
                content_str = content_str.replace(placeholder_no_space, param_value)
                content_str = content_str.replace(placeholder_alt, param_value)
            
            with open(output_path, 'wb') as f:
                f.write(content_str.encode('utf-8'))
    
    return {
        "code": 0,
        "data": {
            "message": "模板填充成功",
            "output_path": output_path,
            "output_filename": output_filename,
            "applied_params": list(params.params.keys()),
            "template_name": template.name
        }
    }


@router.post("/{template_id}/validate-params")
async def validate_template_params(
    template_id: int,
    params: PlaceholderParams,
    db: AsyncSession = Depends(get_db)
):
    """
    验证填充参数是否完整
    返回缺失的参数列表
    """
    query = select(Template).where(Template.id == template_id)
    result = await db.execute(query)
    template = result.scalar_one_or_none()
    
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    placeholder_def = json.loads(template.placeholder_dict) if template.placeholder_dict else {}
    
    # 检查缺失参数
    missing_params = []
    for param_key, description in placeholder_def.items():
        if param_key not in params.params or not params.params[param_key]:
            missing_params.append({
                "key": param_key,
                "description": description,
                "value": params.params.get(param_key, "")
            })
    
    return {
        "code": 0,
        "data": {
            "is_complete": len(missing_params) == 0,
            "total_params": len(placeholder_def),
            "provided_params": len(params.params),
            "missing_params": missing_params,
            "all_params": placeholder_def
        }
    }


@router.get("/{template_id}/params")
async def get_template_params(
    template_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取模板参数定义"""
    query = select(Template).where(Template.id == template_id)
    result = await db.execute(query)
    template = result.scalar_one_or_none()
    
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    placeholder_def = json.loads(template.placeholder_dict) if template.placeholder_dict else {}
    
    return {
        "code": 0,
        "data": {
            "template_id": template.id,
            "template_name": template.name,
            "params": placeholder_def
        }
    }

"""
API 路由包
"""
from .projects import router as projects_router
from .files import router as files_router
from .chat import router as chat_router
from .knowledge import router as knowledge_router
from .ai_tools import router as ai_tools_router
from .agent import router as agent_router
from .plugins import router as plugins_router
from .templates import router as templates_router

__all__ = [
    "projects_router",
    "files_router",
    "chat_router",
    "knowledge_router",
    "ai_tools_router",
    "agent_router",
    "plugins_router",
    "templates_router"
]

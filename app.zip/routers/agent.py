"""
Agent API 路由
将 CodeBuddy Agent SDK 封装为 RESTful API
"""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import Optional, List
import asyncio
import json

from ..agent_sdk import CodeBuddyAgent, FileReference

router = APIRouter(prefix="/api/agent", tags=["Agent API"])


# ==================== 请求/响应模型 ====================

class ChatRequest(BaseModel):
    """对话请求"""
    message: str = Field(..., description="用户消息")
    session_id: Optional[str] = Field(None, description="会话ID，不传则创建新会话")
    agent_type: Optional[str] = Field("default", description="Agent类型")
    file_refs: Optional[List[dict]] = Field(None, description="文件引用列表")


class AgentResponse(BaseModel):
    """Agent 响应"""
    code: int = 0
    message: str = "success"
    data: dict


# ==================== 依赖项 ====================

def get_agent_instance() -> CodeBuddyAgent:
    """获取 Agent 实例"""
    return CodeBuddyAgent()


# ==================== 对话接口 ====================

@router.post("/chat", response_model=AgentResponse)
async def chat(
    request: ChatRequest,
    agent: CodeBuddyAgent = Depends(get_agent_instance)
):
    """
    发送消息给 Agent（非流式）
    """
    try:
        # 转换文件引用
        file_refs = None
        if request.file_refs:
            file_refs = [
                FileReference(
                    file_path=fr.get("file_path", ""),
                    start_line=fr.get("start_line", 0),
                    end_line=fr.get("end_line", 0),
                    content=fr.get("content", ""),
                    summary=fr.get("summary")
                )
                for fr in request.file_refs
            ]
        
        # 调用 Agent
        response = await agent.chat(
            message=request.message,
            session_id=request.session_id,
            agent_type=request.agent_type,
            file_refs=file_refs
        )
        
        return AgentResponse(
            code=0,
            message="success",
            data={
                "content": response.content,
                "session_id": request.session_id,
                "file_changes": response.file_changes,
                "citations": response.citations
            }
        )
        
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/chat/stream")
async def stream_chat(
    request: ChatRequest,
    agent: CodeBuddyAgent = Depends(get_agent_instance)
):
    """
    发送消息给 Agent（流式 SSE）
    """
    async def generate():
        try:
            # 转换文件引用
            file_refs = None
            if request.file_refs:
                file_refs = [
                    FileReference(
                        file_path=fr.get("file_path", ""),
                        start_line=fr.get("start_line", 0),
                        end_line=fr.get("end_line", 0),
                        content=fr.get("content", ""),
                        summary=fr.get("summary")
                    )
                    for fr in request.file_refs
                ]
            
            # 流式调用
            full_response = ""
            async for chunk in agent.stream_chat(
                message=request.message,
                session_id=request.session_id,
                agent_type=request.agent_type,
                file_refs=file_refs
            ):
                full_response += chunk
                yield f"data: {{\"delta\": {json.dumps(chunk)}}}\n\n"
            
            yield f"data: {{\"done\": true, \"content\": {json.dumps(full_response)}}}\n\n"
            
        except Exception as e:
            yield f"data: {{\"error\": {json.dumps(str(e))}}}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream"
    )

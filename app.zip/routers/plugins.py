"""
法律API插件路由 - 封装法律AI助手平台API
"""
from fastapi import APIRouter, HTTPException, Header, Depends
from pydantic import BaseModel
from typing import Optional, List
import httpx
import json
import os
import urllib.parse

from ..config import settings
from ..database import get_db, AsyncSessionLocal
from ..utils.docx_processor import read_docx_paragraphs, apply_docx_modifications, restore_from_backup, get_backup_info
from ..utils.file_processor import extract_html_from_docx

# 创建异步上下文管理器用于获取数据库会话
class AsyncSessionContext:
    """异步上下文管理器，用于替代 get_async_session"""
    async def __aenter__(self):
        self.session = AsyncSessionLocal()
        return self.session
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.session.close()

def get_async_session():
    """获取异步数据库会话的上下文管理器"""
    return AsyncSessionContext()

router = APIRouter(prefix="/api/plugins", tags=["法律插件"])

# 法律API基础URL
LAW_API_BASE = "https://openapi.delilegal.com"
LAW_API_APPID = "QthdBErlyaYvyXul"
LAW_API_SECRET = "EC5D455E6BD348CE8E18BE05926D2EBE"


# ============ 请求模型 ============

class LawSearchCondition(BaseModel):
    keywords: List[str]
    fieldName: str = "semantic"


class LawSearchRequest(BaseModel):
    pageNo: int = 1
    pageSize: int = 5
    sortField: str = "correlation"
    sortOrder: str = "desc"
    condition: LawSearchCondition


class CaseSearchCondition(BaseModel):
    keywordArr: List[str]


class CaseSearchRequest(BaseModel):
    pageNo: int = 1
    pageSize: int = 5
    sortField: str = "correlation"
    sortOrder: str = "desc"
    condition: CaseSearchCondition


class MessageContent(BaseModel):
    type: str = "text"
    text: str


class ChatMessage(BaseModel):
    role: str
    content: List[MessageContent]


class ChatRequest(BaseModel):
    assistant_id: str = "2040365056239076416"
    user_id: str = "anonymous"
    stream: bool = False
    messages: List[ChatMessage]


# ============ Word文档接口请求模型 ============

class DocxReadRequest(BaseModel):
    file_path: str  # 文件绝对路径
    include_tables: bool = True  # 是否包含表格信息


class ModificationItem(BaseModel):
    type: str  # modify, add, delete, cell_modify, cell_delete
    # 段落修改参数
    index: Optional[int] = None  # 段落索引（优先使用，精确匹配）
    text: Optional[str] = None  # 原文本（用于定位或校验）
    new_text: Optional[str] = None  # 新文本（用于modify类型）
    insert_index: Optional[int] = None  # 插入位置（用于add类型）
    insert_text: Optional[str] = None  # 插入的文本（用于add类型）
    # 表格单元格修改参数（可使用 index="t2_r0_c1" 格式，或单独指定）
    cell_index: Optional[str] = None  # 单元格索引，格式如 "t2_r0_c1" (table, row, col)
    table_index: Optional[int] = None  # 表格索引（从0开始）
    row: Optional[int] = None  # 行索引（从0开始）
    col: Optional[int] = None  # 列索引（从0开始）


class DocxApplyRequest(BaseModel):
    file_path: str  # 文件绝对路径
    modifications: List[ModificationItem]
    create_backup: bool = True  # 是否创建备份


class DocxRestoreRequest(BaseModel):
    file_path: str  # 文件绝对路径
    keep_backup: bool = True  # 恢复后是否保留备份文件


# ============ Word文档接口 ============

@router.post("/docx/read")
async def read_docx(request: DocxReadRequest):
    """
    读取Word文档，返回段落列表（优先使用 OnlyOffice 转换为 HTML）
    
    请求参数:
    - file_path: 文件绝对路径
    - include_tables: 是否包含表格信息（默认True）
    
    返回:
    - file_name: 文件名
    - file_path: 文件路径
    - paragraphs: 段落列表
    - tables: 表格列表
    - paragraph_count: 段落数量
    - table_count: 表格数量
    - html_content: OnlyOffice 转换的 HTML 内容
    - converter: 使用的转换器类型 "onlyoffice" 或 "python-docx"
    """
    try:
        # 安全检查：确保路径存在且是docx文件
        if not os.path.exists(request.file_path):
            raise HTTPException(status_code=404, detail=f"文件不存在: {request.file_path}")
        
        if not request.file_path.lower().endswith('.docx'):
            raise HTTPException(status_code=400, detail="只支持 .docx 文件")
        
        # 使用 OnlyOffice 转换为 HTML（支持回退到 python-docx）
        html_content = extract_html_from_docx(request.file_path, use_onlyoffice=True)
        converter = "onlyoffice" if html_content and "OnlyOffice 转换失败" not in html_content and "需要安装" not in html_content else "python-docx"
        
        # 如果 OnlyOffice 失败，使用 python-docx 读取
        if converter == "python-docx" or not html_content:
            result = read_docx_paragraphs(request.file_path)
            result["html_content"] = html_content
            result["converter"] = converter
            return {
                "code": 0,
                "data": result
            }
        
        # OnlyOffice 成功，返回 HTML 内容
        return {
            "code": 0,
            "data": {
                "file_name": os.path.basename(request.file_path),
                "file_path": request.file_path,
                "html_content": html_content,
                "converter": "onlyoffice"
            }
        }
        
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"读取文档失败: {str(e)}")


@router.post("/docx/apply")
async def apply_docx_changes(request: DocxApplyRequest):
    """
    执行Word文档修改
    
    请求参数:
    - file_path: 文件绝对路径
    - modifications: 修改列表
        - type: modify/add/delete
        - index: 段落索引（可选）
        - text: 原文本（用于定位）
        - new_text: 新文本（modify类型）
        - insert_index: 插入位置（add类型）
        - insert_text: 插入文本（add类型）
    - create_backup: 是否创建备份（默认True）
    
    返回:
    - success: 是否全部成功
    - message: 消息
    - applied_count: 已应用数量
    - failed_count: 失败数量
    - failed_modifications: 失败的修改列表
    - backup_path: 备份文件路径
    """
    try:
        # 安全检查
        if not os.path.exists(request.file_path):
            raise HTTPException(status_code=404, detail=f"文件不存在: {request.file_path}")
        
        if not request.file_path.lower().endswith('.docx'):
            raise HTTPException(status_code=400, detail="只支持 .docx 文件")
        
        # 转换修改列表
        mods = [m.model_dump() for m in request.modifications]
        
        # 应用修改
        result = apply_docx_modifications(request.file_path, mods)
        
        return {
            "code": 0,
            "data": result
        }
        
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"修改文档失败: {str(e)}")


@router.post("/docx/restore")
async def restore_docx(request: DocxRestoreRequest):
    """
    撤销修改，从备份恢复文档
    
    请求参数:
    - file_path: 文件绝对路径
    - keep_backup: 恢复后是否保留备份文件（默认True）
    
    返回:
    - success: 是否成功
    - message: 消息
    - restored_path: 恢复后的文件路径
    - backup_removed: 备份是否被删除
    """
    try:
        # 安全检查
        if not os.path.exists(request.file_path):
            raise HTTPException(status_code=404, detail=f"文件不存在: {request.file_path}")
        
        if not request.file_path.lower().endswith('.docx'):
            raise HTTPException(status_code=400, detail="只支持 .docx 文件")
        
        # 恢复文档
        result = restore_from_backup(request.file_path, request.keep_backup)
        
        if not result["success"]:
            raise HTTPException(status_code=404, detail=result["message"])
        
        return {
            "code": 0,
            "data": result
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"恢复文档失败: {str(e)}")


@router.get("/docx/backup-info")
async def get_backup_info_api(file_path: str):
    """
    获取备份文件信息
    
    查询参数:
    - file_path: 文件绝对路径
    
    返回:
    - has_backup: 是否存在备份
    - backup_path: 备份文件路径
    - backup_exists: 备份是否存在
    - backup_size: 备份文件大小
    - backup_modified_time: 备份修改时间
    """
    try:
        # 安全检查
        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail=f"文件不存在: {file_path}")
        
        if not file_path.lower().endswith('.docx'):
            raise HTTPException(status_code=400, detail="只支持 .docx 文件")
        
        # 获取备份信息
        result = get_backup_info(file_path)
        
        return {
            "code": 0,
            "data": result
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取备份信息失败: {str(e)}")


@router.get("/docx/editor-config")
async def get_onlyoffice_editor_config(
    project_id: int,
    file_path: str,
    return_url: Optional[str] = None
):
    """
    获取 OnlyOffice 编辑器配置（用于在线编辑文档）
    
    查询参数:
    - project_id: 项目ID
    - file_path: 文件相对路径
    - return_url: 关闭编辑器后的返回URL（可选）
    
    返回:
    - config: OnlyOffice 编辑器配置对象
    - documentServerUrl: Document Server URL
    """
    from app.models.models import Project
    from sqlalchemy import select
    
    try:
        # 获取项目信息
        async with get_async_session() as session:
            result = await session.execute(
                select(Project).where(Project.id == project_id)
            )
            project = result.scalar_one_or_none()
            
            if not project:
                raise HTTPException(status_code=404, detail=f"项目不存在: {project_id}")
        
        # 构建完整文件路径
        # file_path 是相对路径，需要解码并与项目路径组合
        import urllib.parse
        decoded_path = urllib.parse.unquote(file_path)
        # 从 project.name 构建项目目录（假设项目目录名与项目名对应）
        project_dir_name = f"project_{project_id}"
        full_file_path = os.path.join(settings.UPLOAD_DIR, project_dir_name, decoded_path)
        
        # 安全检查
        if not os.path.exists(full_file_path):
            raise HTTPException(status_code=404, detail=f"文件不存在: {full_file_path}")
        
        if not full_file_path.lower().endswith('.docx'):
            raise HTTPException(status_code=400, detail="只支持 .docx 文件")
        
        # 构建文件URL（OnlyOffice 需要能访问的 URL）
        # 使用绝对 URL，因为 OnlyOffice Document Server 是云端服务
        file_name = os.path.basename(full_file_path)
        # 使用专门的下载接口
        relative_file_path = os.path.join(project_dir_name, decoded_path).replace(os.sep, '/')
        file_url = f"/api/plugins/docx/download?project_id={project_id}&file_path={urllib.parse.quote(decoded_path)}"
        
        # 保存回调URL
        callback_url = f"/api/plugins/docx/save-callback"
        
        # 构建编辑器配置
        config = {
            "type": "desktop",
            "documentType": "word",
            "document": {
                "fileType": "docx",
                "title": file_name,
                "url": file_url,
                "directUrl": file_url,
            },
            "editorConfig": {
                "mode": "edit",
                "callbackUrl": callback_url,
                "returnUrl": return_url or "/",
                "customization": {
                    "autosave": True,
                    "chat": False,
                    "comment": True,
                    "help": False,
                    "plugins": False,
                    "review": True,
                    "spellcheck_input_mode": True,
                },
                "user": {
                    "id": "user-1",
                    "name": "User"
                }
            },
            "token": "",  # 如果需要JWT，可以在这里生成
        }
        
        return {
            "code": 0,
            "data": {
                "config": config,
                "documentServerUrl": settings.ONLYOFFICE_SERVER_URL,
                "baseUrl": settings.BASE_URL,
                "filePath": full_file_path,
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取编辑器配置失败: {str(e)}")


@router.post("/docx/save-callback")
async def onlyoffice_save_callback(
    status: int = 1,
    url: Optional[str] = None,
    error: Optional[str] = None
):
    """
    OnlyOffice 文档保存回调
    
    OnlyOffice 保存文档后会调用此接口
    """
    try:
        # status: 0 - 正在保存, 1 - 保存完成, 2 - 保存失败
        if status == 1 and url:
            # 保存成功，可以在这里记录日志
            print(f"文档保存成功: {url}")
        elif status == 2:
            print(f"文档保存失败: {error}")
        
        return {"error": 0}
        
    except Exception as e:
        return {"error": str(e)}


@router.get("/docx/download")
async def download_docx(
    project_id: int,
    file_path: str
):
    """
    下载Word文档（用于OnlyOffice访问）
    
    查询参数:
    - project_id: 项目ID
    - file_path: 文件相对路径
    """
    from fastapi.responses import FileResponse
    
    try:
        # 解码并构建完整路径
        decoded_path = urllib.parse.unquote(file_path)
        project_dir_name = f"project_{project_id}"
        full_file_path = os.path.join(settings.UPLOAD_DIR, project_dir_name, decoded_path)
        
        if not os.path.exists(full_file_path):
            raise HTTPException(status_code=404, detail=f"文件不存在: {full_file_path}")
        
        if not full_file_path.lower().endswith('.docx'):
            raise HTTPException(status_code=400, detail="只支持 .docx 文件")
        
        file_name = os.path.basename(full_file_path)
        return FileResponse(
            path=full_file_path,
            filename=file_name,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"下载失败: {str(e)}")


# ============ 路由 ============

@router.post("/law/search")
async def search_laws(request: LawSearchRequest):
    """
    法规检索 - 根据关键词检索相关法规
    """
    url = f"{LAW_API_BASE}/api/qa/v3/search/queryListLaw"
    headers = {
        "Content-Type": "application/json",
        "appid": LAW_API_APPID,
        "secret": LAW_API_SECRET
    }
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, json=request.model_dump(), headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"法律API错误: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"请求失败: {str(e)}")


@router.get("/law/detail")
async def get_law_detail(lawId: str, merge: str = "true"):
    """
    法规详情 - 获取指定法规的完整内容
    """
    url = f"{LAW_API_BASE}/api/qa/v3/search/lawInfo"
    headers = {
        "appid": LAW_API_APPID,
        "secret": LAW_API_SECRET
    }
    params = {
        "lawId": lawId,
        "merge": merge
    }
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"法律API错误: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"请求失败: {str(e)}")


@router.post("/case/search")
async def search_cases(request: CaseSearchRequest):
    """
    案例检索 - 根据关键词检索相关法律案例
    """
    url = f"{LAW_API_BASE}/api/qa/v3/search/queryListCase"
    headers = {
        "Content-Type": "application/json",
        "appid": LAW_API_APPID,
        "secret": LAW_API_SECRET
    }
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, json=request.model_dump(), headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"法律API错误: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"请求失败: {str(e)}")


@router.get("/case/detail")
async def get_case_detail(caseId: str):
    """
    案例详情 - 获取案例的完整内容
    """
    url = f"{LAW_API_BASE}/api/qa/v3/search/caseInfo"
    headers = {
        "appid": LAW_API_APPID,
        "secret": LAW_API_SECRET
    }
    params = {
        "caseId": caseId
    }
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"法律API错误: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"请求失败: {str(e)}")


@router.post("/chat/completions")
async def chat_completions(request: ChatRequest):
    """
    智能体对话 - 与法律AI智能体进行对话
    """
    url = f"{LAW_API_BASE}/openapi/v1/agent/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {settings.CODEBUDDY_API_KEY or 'eGMUKpgdOhN11XEZdtkl8ZZhKcHTeM4G'}"
    }
    
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(url, json=request.model_dump(), headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"智能体API错误: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"请求失败: {str(e)}")


@router.get("/health")
async def plugin_health():
    """插件健康检查"""
    return {"status": "ok", "plugin": "law-api"}

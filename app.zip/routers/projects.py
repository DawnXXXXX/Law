"""
项目 API 路由
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from sqlalchemy.orm import selectinload
from typing import Optional, List
from datetime import datetime
import os
import shutil

from ..database import get_db
from ..models import Project, Folder, File
from ..schemas import (
    ProjectCreate, ProjectUpdate, ProjectResponse,
    ProjectDetailResponse, ProjectListResponse, FileTreeItem
)
from ..config import settings

router = APIRouter(prefix="/api/projects", tags=["项目管理"])


def build_file_tree(files: List[File], folders: List[Folder]) -> List[FileTreeItem]:
    """构建文件树（已废弃，统一使用物理存储）"""
    # 此函数已不再使用，保留用于兼容
    # 实际文件树通过 scan_directory_tree 获取
    return []


@router.get("", response_model=ProjectListResponse)
async def get_projects(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    keyword: Optional[str] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """获取项目列表"""
    query = select(Project)
    
    if keyword:
        query = query.filter(Project.name.contains(keyword))
    if status:
        query = query.filter(Project.status == status)
    
    # 获取总数
    count_query = select(Project)
    if keyword:
        count_query = count_query.filter(Project.name.contains(keyword))
    if status:
        count_query = count_query.filter(Project.status == status)
    
    total_result = await db.execute(count_query)
    total = len(total_result.scalars().all())
    
    # 分页
    query = query.order_by(desc(Project.updated_at))
    query = query.offset((page - 1) * page_size).limit(page_size)
    
    result = await db.execute(query)
    projects = result.scalars().all()
    
    return ProjectListResponse(
        total=total,
        items=[ProjectResponse.model_validate(p) for p in projects]
    )


@router.get("/recent", response_model=List[ProjectResponse])
async def get_recent_projects(
    limit: int = Query(3, ge=1, le=10),
    db: AsyncSession = Depends(get_db)
):
    """获取最近项目"""
    query = select(Project).order_by(desc(Project.updated_at)).limit(limit)
    result = await db.execute(query)
    projects = result.scalars().all()
    return [ProjectResponse.model_validate(p) for p in projects]


@router.post("", response_model=dict, status_code=201)
async def create_project(
    project: ProjectCreate,
    db: AsyncSession = Depends(get_db)
):
    """创建项目"""
    db_project = Project(
        name=project.name,
        description=project.description
    )
    db.add(db_project)
    await db.commit()
    await db.refresh(db_project)
    
    # 自动创建项目物理目录
    project_dir = os.path.join(settings.UPLOAD_DIR, f"project_{db_project.id}")
    os.makedirs(project_dir, exist_ok=True)
    print(f"[create_project] 创建项目目录: {project_dir}")
    
    return {
        "code": 0,
        "message": "项目创建成功",
        "data": {
            "project_id": db_project.id,
            "name": db_project.name,
            "created_at": db_project.created_at
        }
    }


def ensure_project_dir_local(project_id: int) -> str:
    """确保项目目录存在"""
    project_dir = os.path.join(settings.UPLOAD_DIR, f"project_{project_id}")
    os.makedirs(project_dir, exist_ok=True)
    return project_dir


def scan_directory_tree_local(base_path: str, relative_path: str = "") -> List[dict]:
    """递归扫描目录，返回树形结构"""
    items = []
    current_path = os.path.join(base_path, relative_path) if relative_path else base_path
    
    if not os.path.exists(current_path):
        return items
    
    # 排序：文件夹在前，文件在后
    entries = sorted(os.listdir(current_path), key=lambda x: (
        0 if os.path.isdir(os.path.join(current_path, x)) else 1,
        x.lower()
    ))
    
    for name in entries:
        full_path = os.path.join(current_path, name)
        rel_path = os.path.join(relative_path, name) if relative_path else name
        
        if os.path.isdir(full_path):
            items.append({
                "id": f"folder-{rel_path.replace(os.sep, '/')}",
                "type": "directory",
                "name": name,
                "path": rel_path,
                "children": scan_directory_tree_local(base_path, rel_path)
            })
        else:
            size = os.path.getsize(full_path)
            ext = os.path.splitext(name)[1].lower().lstrip('.')
            items.append({
                "id": f"file-{rel_path.replace(os.sep, '/')}",
                "type": "file",
                "name": name,
                "path": rel_path,
                "file_type": ext,
                "size": size
            })
    
    return items


@router.get("/{project_id}", response_model=ProjectDetailResponse)
async def get_project(
    project_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取项目详情（文件树使用物理存储）"""
    query = select(Project).where(Project.id == project_id)
    
    result = await db.execute(query)
    project = result.scalar_one_or_none()
    
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    
    # 确保项目目录存在并扫描物理存储获取文件树
    ensure_project_dir_local(project_id)
    project_dir = os.path.join(settings.UPLOAD_DIR, f"project_{project_id}")
    file_tree = scan_directory_tree_local(project_dir)
    
    return ProjectDetailResponse(
        id=project.id,
        name=project.name,
        description=project.description,
        status=project.status,
        summary=project.summary,
        created_at=project.created_at,
        updated_at=project.updated_at,
        file_tree=file_tree
    )


@router.put("/{project_id}")
async def update_project(
    project_id: int,
    project: ProjectUpdate,
    db: AsyncSession = Depends(get_db)
):
    """更新项目"""
    query = select(Project).where(Project.id == project_id)
    result = await db.execute(query)
    db_project = result.scalar_one_or_none()
    
    if not db_project:
        raise HTTPException(status_code=404, detail="项目不存在")
    
    update_data = project.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_project, key, value)
    
    db_project.updated_at = datetime.utcnow()
    await db.commit()
    
    return {"code": 0, "message": "更新成功"}


@router.delete("/{project_id}")
async def delete_project(
    project_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除项目（包括物理文件）"""
    query = select(Project).where(Project.id == project_id)
    result = await db.execute(query)
    project = result.scalar_one_or_none()
    
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    
    # 删除项目物理文件目录
    project_dir = os.path.join(settings.UPLOAD_DIR, f"project_{project_id}")
    if os.path.exists(project_dir):
        shutil.rmtree(project_dir)
    
    # 删除数据库记录（CASCADE会删除关联的文件、文件夹、会话等）
    await db.delete(project)
    await db.commit()
    
    return {"code": 0, "message": "项目已删除"}


@router.get("/{project_id}/export")
async def export_project(
    project_id: int,
    db: AsyncSession = Depends(get_db)
):
    """导出项目文件（ZIP压缩包）"""
    # 检查项目是否存在
    query = select(Project).where(Project.id == project_id)
    result = await db.execute(query)
    project = result.scalar_one_or_none()
    
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    
    # 检查项目目录是否存在
    project_dir = os.path.join(settings.UPLOAD_DIR, f"project_{project_id}")
    if not os.path.exists(project_dir):
        raise HTTPException(status_code=404, detail="项目文件不存在")
    
    # 创建临时ZIP文件
    import tempfile
    zip_filename = f"{project.name}.zip"
    zip_path = os.path.join(tempfile.gettempdir(), zip_filename)
    
    # 创建ZIP（包含项目目录中的所有文件）
    shutil.make_archive(
        zip_path.replace('.zip', ''),
        'zip',
        project_dir
    )
    
    # 返回文件流
    from fastapi.responses import FileResponse
    return FileResponse(
        path=zip_path,
        filename=zip_filename,
        media_type='application/zip'
    )

"""
法律文书生成对话服务
核心思想：所有意图识别交给大模型，意图作为变量持久化，支持意图变更检测

对话流程：
1. 用户请求 -> 大模型识别意图（文书生成）
2. Agent询问具体文书类型 + Widget选择模板
3. 根据模板收集参数，先从上下文提取，再追问缺失参数
4. 大模型持续检测意图变更
5. 参数完整后生成文书
6. 支持生成后微调修改
"""
import json
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum

# 导入 LangChain Memory 工具
from .langchain_core.memory import get_memory


class IntentPrimary(Enum):
    """一级意图"""
    DOCUMENT_GENERATION = "document_generation"
    DOCUMENT_MODIFICATION = "document_modification"
    DOCUMENT_REVIEW = "document_review"
    LEGAL_CONSULTATION = "legal_consultation"
    CASE_SEARCH = "case_search"
    CHITCHAT = "chitchat"


class IntentSecondary(Enum):
    """二级意图（文书相关）"""
    CONTRACT = "contract"
    LITIGATION = "litigation"
    ADMINISTRATIVE = "administrative"
    OTHER = "other"


class DocumentType(Enum):
    """具体文书类型"""
    DIVORCE_LAWSUIT = "divorce_lawsuit"  # 离婚起诉状
    CIVIL_LAWSUIT = "civil_lawsuit"  # 民事起诉状
    LABOR_ARBITRATION = "labor_arbitration"  # 劳动仲裁申请书
    EMPLOYMENT_CONTRACT = "employment_contract"  # 劳动合同
    RENTAL_CONTRACT = "rental_contract"  # 租赁合同
    POWER_OF_ATTORNEY = "power_of_attorney"  # 授权委托书
    OTHER = "other"


@dataclass
class IntentInfo:
    """意图信息结构"""
    primary: str = ""
    secondary: str = ""
    specific: str = ""
    confidence: float = 0.0
    reasoning: str = ""
    detected_at: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "primary": self.primary,
            "secondary": self.secondary,
            "specific": self.specific,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "detected_at": self.detected_at
        }


@dataclass
class IntentHistory:
    """意图历史记录"""
    timestamp: str
    intent: IntentInfo
    user_query: str
    status: str  # pending_specific, active, changed, completed


@dataclass
class DocumentParams:
    """文书参数结构"""
    doc_type: str = ""
    template_id: Optional[int] = None
    template_name: str = ""
    collected_fields: Dict[str, str] = field(default_factory=dict)
    pending_fields: List[str] = field(default_factory=list)
    last_updated: str = ""


@dataclass
class WorkflowPhase(Enum):
    """工作流阶段"""
    INTENT_RECOGNITION = "intent_recognition"  # 意图识别
    TEMPLATE_SELECTION = "template_selection"  # 模板选择
    INFO_COLLECTION = "info_collection"  # 信息收集
    GENERATION = "generation"  # 生成中
    MODIFICATION = "modification"  # 修改中
    COMPLETED = "completed"  # 完成


@dataclass
class DialogContext:
    """
    对话上下文（意图变量体系）
    这是核心数据结构，记录所有意图相关的变量
    """
    session_id: str
    conversation_id: int
    project_id: Optional[int] = None
    
    # 意图变量
    current_intent: IntentInfo = field(default_factory=IntentInfo)
    intent_history: List[IntentHistory] = field(default_factory=list)
    
    # 文书参数
    document_params: DocumentParams = field(default_factory=DocumentParams)
    
    # 工作流状态
    workflow_phase: str = WorkflowPhase.INTENT_RECOGNITION.value
    step: int = 1
    last_question: str = ""
    
    # 对话历史
    conversation_turns: List[Dict[str, Any]] = field(default_factory=list)
    
    # 生成的文档
    generated_document_path: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "conversation_id": self.conversation_id,
            "project_id": self.project_id,
            "current_intent": self.current_intent.to_dict(),
            "intent_history": [
                {
                    "timestamp": h.timestamp,
                    "intent": h.intent.to_dict(),
                    "user_query": h.user_query,
                    "status": h.status
                }
                for h in self.intent_history
            ],
            "document_params": {
                "doc_type": self.document_params.doc_type,
                "template_id": self.document_params.template_id,
                "template_name": self.document_params.template_name,
                "collected_fields": self.document_params.collected_fields,
                "pending_fields": self.document_params.pending_fields,
                "last_updated": self.document_params.last_updated
            },
            "workflow_phase": self.workflow_phase,
            "step": self.step,
            "last_question": self.last_question,
            "conversation_turns": self.conversation_turns,
            "generated_document_path": self.generated_document_path
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DialogContext":
        ctx = cls(
            session_id=data.get("session_id", ""),
            conversation_id=data.get("conversation_id", 0),
            project_id=data.get("project_id")
        )
        
        # 恢复意图信息
        if "current_intent" in data:
            intent_data = data["current_intent"]
            ctx.current_intent = IntentInfo(
                primary=intent_data.get("primary", ""),
                secondary=intent_data.get("secondary", ""),
                specific=intent_data.get("specific", ""),
                confidence=intent_data.get("confidence", 0.0),
                reasoning=intent_data.get("reasoning", ""),
                detected_at=intent_data.get("detected_at", "")
            )
        
        # 恢复历史
        if "intent_history" in data:
            for h in data["intent_history"]:
                ctx.intent_history.append(IntentHistory(
                    timestamp=h["timestamp"],
                    intent=IntentInfo(**h["intent"]),
                    user_query=h["user_query"],
                    status=h["status"]
                ))
        
        # 恢复文书参数
        if "document_params" in data:
            dp = data["document_params"]
            ctx.document_params = DocumentParams(
                doc_type=dp.get("doc_type", ""),
                template_id=dp.get("template_id"),
                template_name=dp.get("template_name", ""),
                collected_fields=dp.get("collected_fields", {}),
                pending_fields=dp.get("pending_fields", []),
                last_updated=dp.get("last_updated", "")
            )
        
        ctx.workflow_phase = data.get("workflow_phase", WorkflowPhase.INTENT_RECOGNITION.value)
        ctx.step = data.get("step", 1)
        ctx.last_question = data.get("last_question", "")
        ctx.conversation_turns = data.get("conversation_turns", [])
        ctx.generated_document_path = data.get("generated_document_path", "")
        
        return ctx


class IntentRecognizer:
    """
    意图识别器 - 大模型负责识别意图
    """
    
    # 意图识别提示词
    INTENT_RECOGNITION_PROMPT = """
你是一个专业的法律助手。请分析用户的查询内容，识别其意图。

## 用户查询
{user_query}

## 对话历史
{conversation_history}

## 意图分类体系

### 一级意图
1. document_generation - 文书生成（合同、诉讼状、申请书等）
2. document_modification - 文书修改
3. document_review - 文书审查
4. legal_consultation - 法律咨询
5. case_search - 案例检索
6. chitchat - 闲聊/问候

### 二级意图（仅针对文书生成）
- contract - 合同类文书
- litigation - 诉讼类文书（起诉状、答辩状等）
- administrative - 行政类文书
- other - 其他文书

### 具体文书类型
- divorce_lawsuit - 离婚起诉状
- civil_lawsuit - 民事起诉状
- labor_arbitration - 劳动仲裁申请书
- employment_contract - 劳动合同
- rental_contract - 租赁合同
- power_of_attorney - 授权委托书
- other - 其他

## 输出要求

请输出JSON格式（只输出JSON，不要其他内容）：
{
  "intent": {
    "primary": "一级意图",
    "secondary": "二级意图（如适用）",
    "specific": "具体文书类型（如适用）",
    "confidence": 0.95,
    "reasoning": "识别理由"
  },
  "extracted_info": {
    "从用户查询中提取的已有信息": {}
  },
  "missing_info": ["需要继续追问的信息"],
  "suggested_response": "建议的回复话术"
}
"""
    
    # 意图变更检测提示词
    INTENT_CHANGE_PROMPT = """
你是一个专业的法律助手。请分析用户的最新回复，判断是否发生了意图变更。

## 当前记录的意图
当前意图：{current_intent}
当前文书类型：{current_doc_type}

## 用户最新回复
{user_query}

## 对话历史摘要
{conversation_summary}

## 意图变更判断标准

意图变更包括：
1. 文书类型改变（如从离婚起诉状变为劳动仲裁）
2. 业务类型改变（如从文书生成变为法律咨询）
3. 任务目标改变（如从生成变为修改）

非意图变更包括：
1. 参数补充（继续提供之前意图所需的信息）
2. 追问回复（回答系统的问题）
3. 微调（如"稍微改一下"、"再加一句话"）
4. 确认生成（用户确认可以开始生成）

## 输出要求

请输出JSON格式（只输出JSON，不要其他内容）：
{
  "intent_changed": true或false,
  "change_type": "doc_type_changed/business_type_changed/task_changed/none",
  "new_intent": {
    "primary": "新的一级意图",
    "secondary": "新的二级意图",
    "specific": "新的具体类型",
    "confidence": 0.90
  },
  "change_reason": "变更原因说明",
  "should_preserve_params": true或false,
  "suggested_response": "建议的回复话术"
}
"""
    
    # 信息提取提示词
    INFO_EXTRACTION_PROMPT = """
你是一个专业的法律助手。请从用户的回复中提取文书生成所需的参数。

## 对话历史
{conversation_history}

## 用户回复
{user_reply}

## 当前意图
文书类型：{doc_type}
模板参数定义：{template_params}

## 已收集的参数
{collected_params}

## 参数提取要求

1. 仔细阅读用户回复，提取所有相关信息
2. 参数名使用中文描述（如"原告姓名"、"被告姓名"）
3. 对于身份证号、金额等敏感信息，如果用户提供了就提取
4. 如果某些信息用户没有提供，不要编造
5. 结合对话历史理解用户意图，尤其是当用户使用代词（如"他"、"她"、"该人"）或简略描述时

## 输出要求

请输出JSON格式（只输出JSON，不要其他内容）：
{
  "extracted_params": {{
    "参数名": "提取的值"
  }},
  "missing_required": ["缺失的必填参数"],
  "missing_optional": ["缺失的选填参数"],
  "extraction_notes": "提取说明"
}}
"""
    
    def __init__(self, ai_service=None):
        self.ai_service = ai_service
    
    async def recognize_intent(
        self,
        user_query: str,
        conversation_history: List[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        识别用户意图
        
        Args:
            user_query: 用户查询
            conversation_history: 对话历史
            
        Returns:
            意图识别结果
        """
        # 构建历史摘要
        history_summary = ""
        if conversation_history:
            for msg in conversation_history[-5:]:
                role = "用户" if msg.get("role") == "user" else "助手"
                history_summary += f"{role}：{msg.get('content', '')[:100]}...\n"
        
        # 填充提示词
        prompt = self.INTENT_RECOGNITION_PROMPT.format(
            user_query=user_query,
            conversation_history=history_summary or "（无历史记录）"
        )
        
        # 调用大模型
        if self.ai_service:
            response = await self.ai_service.chat_completion(prompt)
            return self._parse_intent_response(response)
        
        # 后备：简单关键词匹配
        return self._fallback_recognition(user_query)
    
    async def detect_intent_change(
        self,
        user_query: str,
        current_intent: IntentInfo,
        current_doc_type: str,
        conversation_history: List[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        检测意图变更
        
        Args:
            user_query: 用户最新回复
            current_intent: 当前记录的意图
            current_doc_type: 当前文书类型
            conversation_history: 对话历史
            
        Returns:
            意图变更检测结果
        """
        # 构建历史摘要
        history_summary = ""
        if conversation_history:
            for msg in conversation_history[-3:]:
                role = "用户" if msg.get("role") == "user" else "助手"
                history_summary += f"{role}：{msg.get('content', '')[:80]}...\n"
        
        # 填充提示词
        prompt = self.INTENT_CHANGE_PROMPT.format(
            current_intent=current_intent.primary,
            current_doc_type=current_doc_type,
            user_query=user_query,
            conversation_summary=history_summary or "（无历史记录）"
        )
        
        # 调用大模型
        if self.ai_service:
            response = await self.ai_service.chat_completion(prompt)
            return self._parse_change_response(response)
        
        # 后备：简单检测
        return {"intent_changed": False}
    
    async def extract_params(
        self,
        user_reply: str,
        doc_type: str,
        template_params: Dict[str, str],
        collected_params: Dict[str, str],
        conversation_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        从用户回复中提取参数
        
        Args:
            user_reply: 用户回复
            doc_type: 文书类型
            template_params: 模板参数定义
            collected_params: 已收集的参数
            conversation_id: 会话ID（用于获取 LangChain Memory 历史）
            
        Returns:
            提取结果
        """
        # 使用 LangChain Memory 工具获取对话历史
        history_text = ""
        if conversation_id is not None:
            memory_service = get_memory()
            history = await memory_service.get_chat_history(conversation_id)
            # 格式化为可读文本
            for msg in history[-10:]:  # 最近10条
                role = "用户" if msg.get("role") == "human" else "助手"
                content = msg.get("content", "")[:200]
                history_text += f"【{role}】: {content}\n"
        
        # 填充提示词
        prompt = self.INFO_EXTRACTION_PROMPT.format(
            conversation_history=history_text or "（无历史记录）",
            user_reply=user_reply,
            doc_type=doc_type,
            template_params=json.dumps(template_params, ensure_ascii=False, indent=2),
            collected_params=json.dumps(collected_params, ensure_ascii=False, indent=2)
        )
        
        # 调用大模型
        if self.ai_service:
            response = await self.ai_service.chat_completion(prompt)
            return self._parse_extraction_response(response)
        
        # 后备：简单提取
        return {"extracted_params": {}, "missing_required": list(template_params.keys())}
    
    def _parse_intent_response(self, response: str) -> Dict[str, Any]:
        """解析意图识别响应"""
        try:
            # 提取JSON
            json_str = self._extract_json(response)
            data = json.loads(json_str)
            
            return {
                "success": True,
                "intent": IntentInfo(
                    primary=data.get("intent", {}).get("primary", ""),
                    secondary=data.get("intent", {}).get("secondary", ""),
                    specific=data.get("intent", {}).get("specific", ""),
                    confidence=data.get("intent", {}).get("confidence", 0.0),
                    reasoning=data.get("intent", {}).get("reasoning", ""),
                    detected_at=datetime.now().isoformat()
                ),
                "extracted_info": data.get("extracted_info", {}),
                "missing_info": data.get("missing_info", []),
                "suggested_response": data.get("suggested_response", "")
            }
        except Exception as e:
            print(f"解析意图响应失败: {e}")
            return self._fallback_recognition("")
    
    def _parse_change_response(self, response: str) -> Dict[str, Any]:
        """解析意图变更响应"""
        try:
            json_str = self._extract_json(response)
            data = json.loads(json_str)
            
            new_intent = data.get("new_intent", {})
            return {
                "success": True,
                "intent_changed": data.get("intent_changed", False),
                "change_type": data.get("change_type", "none"),
                "new_intent": IntentInfo(
                    primary=new_intent.get("primary", ""),
                    secondary=new_intent.get("secondary", ""),
                    specific=new_intent.get("specific", ""),
                    confidence=new_intent.get("confidence", 0.0),
                    detected_at=datetime.now().isoformat()
                ) if new_intent else None,
                "change_reason": data.get("change_reason", ""),
                "should_preserve_params": data.get("should_preserve_params", False),
                "suggested_response": data.get("suggested_response", "")
            }
        except Exception as e:
            print(f"解析变更响应失败: {e}")
            return {"success": False, "intent_changed": False}
    
    def _parse_extraction_response(self, response: str) -> Dict[str, Any]:
        """解析参数提取响应"""
        try:
            json_str = self._extract_json(response)
            data = json.loads(json_str)
            
            return {
                "success": True,
                "extracted_params": data.get("extracted_params", {}),
                "missing_required": data.get("missing_required", []),
                "missing_optional": data.get("missing_optional", []),
                "extraction_notes": data.get("extraction_notes", "")
            }
        except Exception as e:
            print(f"解析提取响应失败: {e}")
            return {"success": False, "extracted_params": {}, "missing_required": []}
    
    def _extract_json(self, text: str) -> str:
        """从文本中提取JSON"""
        text = text.strip()
        
        # 尝试找到JSON块
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            if end > start:
                return text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            if end > start:
                return text[start:end].strip()
        elif "{" in text and "}" in text:
            start = text.find("{")
            end = text.rfind("}") + 1
            return text[start:end]
        
        return text
    
    def _fallback_recognition(self, user_query: str) -> Dict[str, Any]:
        """后备意图识别（简单关键词匹配）"""
        query = user_query.lower()
        
        # 检测文书生成意图
        if any(kw in query for kw in ["生成", "生成文书", "起草", "写一份", "帮我写"]):
            primary = "document_generation"
            
            # 检测具体类型
            specific = "other"
            if any(kw in query for kw in ["离婚", "起诉状"]):
                specific = "divorce_lawsuit"
            elif any(kw in query for kw in ["劳动", "仲裁"]):
                specific = "labor_arbitration"
            elif any(kw in query for kw in ["民事", "起诉"]):
                specific = "civil_lawsuit"
            
            return {
                "success": True,
                "intent": IntentInfo(
                    primary=primary,
                    secondary="other",
                    specific=specific,
                    confidence=0.7,
                    reasoning="通过关键词匹配识别",
                    detected_at=datetime.now().isoformat()
                ),
                "extracted_info": {},
                "missing_info": ["具体文书类型", "当事人信息"]
            }
        
        return {
            "success": True,
            "intent": IntentInfo(
                primary="legal_consultation",
                confidence=0.5,
                reasoning="未识别到明确意图"
            )
        }


class DocumentChatService:
    """
    文书生成对话服务
    核心：大模型负责意图识别，意图作为变量持久化
    """
    
    # 模板列表（按类型分组）
    TEMPLATE_CATEGORIES = {
        "litigation": {
            "name": "诉讼类",
            "templates": [
                {"id": "divorce_lawsuit", "name": "离婚起诉状", "icon": "⚖️", "keywords": ["离婚", "起诉状"]},
                {"id": "civil_lawsuit", "name": "民事起诉状", "icon": "📋", "keywords": ["民事", "起诉"]},
                {"id": "criminal_complaint", "name": "刑事自诉状", "icon": "🔨", "keywords": ["刑事", "自诉"]},
                {"id": "divorce_response", "name": "离婚答辩状", "icon": "🛡️", "keywords": ["答辩", "离婚"]}
            ]
        },
        "arbitration": {
            "name": "仲裁类",
            "templates": [
                {"id": "labor_arbitration", "name": "劳动仲裁申请书", "icon": "💼", "keywords": ["劳动", "仲裁"]},
                {"id": "property_dispute", "name": "财产纠纷仲裁", "icon": "💰", "keywords": ["财产", "仲裁"]}
            ]
        },
        "contract": {
            "name": "合同类",
            "templates": [
                {"id": "employment_contract", "name": "劳动合同", "icon": "📄", "keywords": ["劳动", "合同"]},
                {"id": "rental_contract", "name": "租赁合同", "icon": "🏠", "keywords": ["租赁", "合同"]},
                {"id": "purchase_contract", "name": "买卖合同", "icon": "🛒", "keywords": ["买卖", "合同"]}
            ]
        },
        "other": {
            "name": "其他",
            "templates": [
                {"id": "power_of_attorney", "name": "授权委托书", "icon": "📜", "keywords": ["委托", "授权"]},
                {"id": "letter_of_guarantee", "name": "保证书", "icon": "📃", "keywords": ["保证"]}
            ]
        }
    }
    
    # 通用文书参数定义
    COMMON_PARAMS = {
        "原告姓名": {"label": "原告姓名", "type": "text", "required": True, "description": "提起诉讼的一方"},
        "被告姓名": {"label": "被告姓名", "type": "text", "required": True, "description": "被起诉的一方"},
        "原告身份证号": {"label": "原告身份证号", "type": "text", "required": False, "description": "原告的有效身份证件号码"},
        "被告身份证号": {"label": "被告身份证号", "type": "text", "required": False, "description": "被告的有效身份证件号码"},
        "原告地址": {"label": "原告地址", "type": "text", "required": True, "description": "原告的现居住地址"},
        "被告地址": {"label": "被告地址", "type": "text", "required": True, "description": "被告的现居住地址或注册地址"}
    }
    
    # 文书类型特定参数
    DOCUMENT_SPECIFIC_PARAMS = {
        "divorce_lawsuit": {
            "婚姻状况": {"label": "婚姻状况", "type": "select", "required": True, "options": ["已婚", "已分居"], "description": "当前婚姻状态"},
            "结婚日期": {"label": "结婚日期", "type": "date", "required": True, "description": "结婚登记日期"},
            "子女情况": {"label": "子女情况", "type": "textarea", "required": False, "description": "子女姓名、年龄、抚养意向"},
            "财产情况": {"label": "财产情况", "type": "textarea", "required": False, "description": "夫妻共同财产概况"},
            "起诉原因": {"label": "起诉原因", "type": "textarea", "required": True, "description": "离婚的主要原因"}
        },
        "civil_lawsuit": {
            "案由": {"label": "案由", "type": "text", "required": True, "description": "纠纷类型"},
            "诉讼请求": {"label": "诉讼请求", "type": "textarea", "required": True, "description": "具体的诉讼请求"},
            "事实与理由": {"label": "事实与理由", "type": "textarea", "required": True, "description": "纠纷经过和理由"}
        },
        "labor_arbitration": {
            "申请人姓名": {"label": "申请人姓名", "type": "text", "required": True, "description": "劳动者的姓名"},
            "被申请人名称": {"label": "被申请人名称", "type": "text", "required": True, "description": "用人单位的名称"},
            "被申请人地址": {"label": "被申请人地址", "type": "text", "required": True, "description": "用人单位的注册地址"},
            "仲裁请求": {"label": "仲裁请求", "type": "textarea", "required": True, "description": "具体的仲裁请求事项"},
            "事实与理由": {"label": "事实与理由", "type": "textarea", "required": True, "description": "劳动纠纷的经过"}
        }
    }
    
    def __init__(self, ai_service=None):
        self.ai_service = ai_service
        self.intent_recognizer = IntentRecognizer(ai_service)
    
    def get_context(self, workflow_state: Dict[str, Any], session_id: str, conversation_id: int) -> DialogContext:
        """获取或创建对话上下文"""
        if workflow_state and "dialog_context" in workflow_state:
            return DialogContext.from_dict(workflow_state["dialog_context"])
        
        return DialogContext(
            session_id=session_id,
            conversation_id=conversation_id
        )
    
    def save_context(self, context: DialogContext) -> Dict[str, Any]:
        """保存对话上下文到工作流状态"""
        return {"dialog_context": context.to_dict()}
    
    async def process_message(
        self,
        message: str,
        context: DialogContext,
        conversation_history: List[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        处理用户消息
        
        Args:
            message: 用户消息
            context: 对话上下文
            conversation_history: 对话历史
            
        Returns:
            处理结果
        """
        result = {
            "content": "",
            "widget": None,
            "context": context,
            "needs_response": True
        }
        
        # 记录对话轮次
        context.conversation_turns.append({
            "role": "user",
            "content": message,
            "timestamp": datetime.now().isoformat()
        })
        
        # 根据当前阶段处理
        phase = context.workflow_phase
        
        if phase == WorkflowPhase.INTENT_RECOGNITION.value:
            result = await self._handle_intent_recognition(message, context, conversation_history)
        elif phase == WorkflowPhase.TEMPLATE_SELECTION.value:
            result = await self._handle_template_selection(message, context, conversation_history)
        elif phase == WorkflowPhase.INFO_COLLECTION.value:
            result = await self._handle_info_collection(message, context, conversation_history)
        elif phase == WorkflowPhase.GENERATION.value:
            result = await self._handle_generation(message, context, conversation_history)
        elif phase == WorkflowPhase.MODIFICATION.value:
            result = await self._handle_modification(message, context, conversation_history)
        elif phase == WorkflowPhase.COMPLETED.value:
            result = await self._handle_completed(message, context, conversation_history)
        
        return result
    
    async def _handle_intent_recognition(
        self,
        message: str,
        context: DialogContext,
        conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """处理意图识别阶段"""
        # 调用大模型识别意图
        intent_result = await self.intent_recognizer.recognize_intent(
            message, conversation_history
        )
        
        intent = intent_result["intent"]
        
        # 更新上下文中的意图
        context.current_intent = intent
        context.intent_history.append(IntentHistory(
            timestamp=datetime.now().isoformat(),
            intent=intent,
            user_query=message,
            status="pending_specific"
        ))
        
        # 判断是否为文书生成意图
        if intent.primary == "document_generation":
            # 询问具体文书类型
            context.workflow_phase = WorkflowPhase.TEMPLATE_SELECTION.value
            context.step = 1
            
            return {
                "content": "好的，请问您要生成什么类型的文书？",
                "widget": self._build_template_selector(),
                "context": context,
                "intent": intent.to_dict(),
                "needs_response": True
            }
        elif intent.primary == "document_modification":
            # 文书修改意图
            context.workflow_phase = WorkflowPhase.MODIFICATION.value
            return {
                "content": "好的，请告诉我您想如何修改文书？",
                "context": context,
                "intent": intent.to_dict(),
                "needs_response": True
            }
        else:
            # 其他意图，非本服务处理
            return {
                "content": intent_result.get("suggested_response", "我理解您的需求了，让我帮您处理。"),
                "context": context,
                "intent": intent.to_dict(),
                "intent_out_of_scope": True,
                "needs_response": True
            }
    
    async def _handle_template_selection(
        self,
        message: str,
        context: DialogContext,
        conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """处理模板选择阶段"""
        # 先检测是否有意图变更
        change_result = await self.intent_recognizer.detect_intent_change(
            message,
            context.current_intent,
            context.document_params.doc_type,
            conversation_history
        )
        
        if change_result.get("intent_changed"):
            return await self._handle_intent_change(change_result, context)
        
        # 从消息中提取用户选择的模板
        template_id = self._extract_template_from_message(message)
        
        if template_id:
            # 用户选择了模板
            context.document_params.doc_type = template_id
            context.document_params.template_name = self._get_template_name(template_id)
            context.document_params.template_id = self._get_template_db_id(template_id)
            
            # 获取该模板需要的参数
            params = self._get_template_params(template_id)
            context.document_params.pending_fields = list(params.keys())
            
            # 更新意图历史
            context.intent_history[-1].status = "active"
            context.current_intent.specific = template_id
            
            # 询问参数
            context.workflow_phase = WorkflowPhase.INFO_COLLECTION.value
            context.step = 1
            
            return {
                "content": self._build_param_collect_prompt(context),
                "widget": self._build_param_collector(context),
                "context": context,
                "intent": context.current_intent.to_dict(),
                "needs_response": True
            }
        
        # 用户没有明确选择，展示模板选择Widget
        return {
            "content": "请从以下模板中选择：",
            "widget": self._build_template_selector(),
            "context": context,
            "intent": context.current_intent.to_dict(),
            "needs_response": True
        }
    
    async def _handle_info_collection(
        self,
        message: str,
        context: DialogContext,
        conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """处理信息收集阶段"""
        # 检测意图变更
        change_result = await self.intent_recognizer.detect_intent_change(
            message,
            context.current_intent,
            context.document_params.doc_type,
            conversation_history
        )
        
        if change_result.get("intent_changed"):
            return await self._handle_intent_change(change_result, context)
        
        # 提取参数（使用 LangChain Memory 获取对话历史以便理解上下文）
        template_params = self._get_template_params(context.document_params.doc_type)
        extraction_result = await self.intent_recognizer.extract_params(
            message,
            context.document_params.doc_type,
            template_params,
            context.document_params.collected_fields,
            conversation_id=context.conversation_id
        )
        
        if extraction_result.get("success"):
            # 更新已收集的参数
            extracted = extraction_result.get("extracted_params", {})
            context.document_params.collected_fields.update(extracted)
            context.document_params.last_updated = datetime.now().isoformat()
            
            # 计算还缺失的参数
            required_params = [k for k, v in template_params.items() if v.get("required")]
            missing_required = [p for p in required_params if p not in context.document_params.collected_fields]
            
            if missing_required:
                # 继续追问
                context.document_params.pending_fields = missing_required
                context.step += 1
                
                return {
                    "content": self._build_param_collect_prompt(context),
                    "widget": self._build_param_collector(context),
                    "context": context,
                    "intent": context.current_intent.to_dict(),
                    "needs_response": True
                }
            else:
                # 所有必填参数已收集，可以生成
                context.workflow_phase = WorkflowPhase.GENERATION.value
                
                return {
                    "content": self._build_generation_confirm_prompt(context),
                    "widget": self._build_generation_confirm(context),
                    "context": context,
                    "intent": context.current_intent.to_dict(),
                    "needs_response": True
                }
        
        # 提取失败，继续追问
        return {
            "content": "抱歉，我没有理解清楚。请您再说明一下相关信息。",
            "context": context,
            "intent": context.current_intent.to_dict(),
            "needs_response": True
        }
    
    async def _handle_generation(
        self,
        message: str,
        context: DialogContext,
        conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """处理生成阶段"""
        # 检测是否确认生成或继续修改
        message_lower = message.lower()
        
        if any(kw in message_lower for kw in ["生成", "好的", "开始", "可以", "确认"]):
            # 确认生成
            from .workflow_tools import generate_document_from_template
            
            try:
                result = await generate_document_from_template(
                    document_type=context.document_params.template_name,
                    dispute_type=context.document_params.doc_type,
                    params=context.document_params.collected_fields
                )
                
                context.generated_document_path = result.get("file_path", "")
                context.workflow_phase = WorkflowPhase.COMPLETED.value
                context.intent_history[-1].status = "completed"
                
                return {
                    "content": self._build_generation_success_message(result),
                    "widget": self._build_generation_success_widget(result),
                    "context": context,
                    "intent": context.current_intent.to_dict(),
                    "needs_response": True,
                    "document_generated": True
                }
            except Exception as e:
                return {
                    "content": f"文书生成失败：{str(e)}",
                    "context": context,
                    "intent": context.current_intent.to_dict(),
                    "needs_response": True
                }
        
        # 用户还想修改参数
        return await self._handle_info_collection(message, context, conversation_history)
    
    async def _handle_modification(
        self,
        message: str,
        context: DialogContext,
        conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """处理修改阶段"""
        # 这里调用文档修改逻辑
        return {
            "content": "好的，我来帮您修改文书。",
            "context": context,
            "intent": context.current_intent.to_dict(),
            "needs_response": True
        }
    
    async def _handle_completed(
        self,
        message: str,
        context: DialogContext,
        conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """处理完成阶段"""
        # 检测是否有新的修改请求
        message_lower = message.lower()
        
        if any(kw in message_lower for kw in ["修改", "调整", "改一下", "改动"]):
            context.workflow_phase = WorkflowPhase.MODIFICATION.value
            return await self._handle_modification(message, context, conversation_history)
        
        # 检测是否开始新任务
        change_result = await self.intent_recognizer.detect_intent_change(
            message,
            context.current_intent,
            context.document_params.doc_type,
            conversation_history
        )
        
        if change_result.get("intent_changed"):
            return await self._handle_intent_change(change_result, context)
        
        return {
            "content": "文书已生成完成。请问还有什么需要帮助的吗？",
            "widget": {
                "type": "card",
                "title": "操作选项",
                "actions": [
                    {"type": "button", "label": "查看文书", "action": "open_document"},
                    {"type": "button", "label": "继续修改", "action": "modify_document"},
                    {"type": "button", "label": "生成其他文书", "action": "new_document"}
                ]
            },
            "context": context,
            "needs_response": True
        }
    
    async def _handle_intent_change(
        self,
        change_result: Dict[str, Any],
        context: DialogContext
    ) -> Dict[str, Any]:
        """处理意图变更"""
        new_intent = change_result.get("new_intent")
        should_preserve = change_result.get("should_preserve_params", False)
        
        # 记录意图变更
        context.intent_history.append(IntentHistory(
            timestamp=datetime.now().isoformat(),
            intent=new_intent,
            user_query="意图变更",
            status="changed"
        ))
        
        # 更新当前意图
        context.current_intent = new_intent
        
        # 决定是否保留参数
        if not should_preserve:
            # 清空之前的参数
            context.document_params = DocumentParams()
        
        # 根据新意图处理
        if new_intent.primary == "document_generation":
            context.workflow_phase = WorkflowPhase.TEMPLATE_SELECTION.value
            return {
                "content": change_result.get("suggested_response", "好的，请问您要生成什么类型的文书？"),
                "widget": self._build_template_selector(),
                "context": context,
                "intent": new_intent.to_dict(),
                "intent_changed": True,
                "needs_response": True
            }
        else:
            # 非文书生成意图
            return {
                "content": change_result.get("suggested_response", "好的，我理解您的需求了。"),
                "context": context,
                "intent": new_intent.to_dict(),
                "intent_changed": True,
                "intent_out_of_scope": True,
                "needs_response": True
            }
    
    def _build_template_selector(self) -> Dict[str, Any]:
        """构建模板选择Widget"""
        return {
            "type": "template_selector",
            "title": "请选择文书模板",
            "categories": list(self.TEMPLATE_CATEGORIES.values()),
            "actions": {
                "on_select": "select_template",
                "on_custom": "custom_document"
            }
        }
    
    def _build_param_collector(self, context: DialogContext) -> Dict[str, Any]:
        """构建参数收集Widget"""
        params = self._get_template_params(context.document_params.doc_type)
        required_params = [k for k, v in params.items() if v.get("required")]
        
        completed = []
        pending = []
        
        for param_key in required_params:
            param_info = params.get(param_key, {})
            if param_key in context.document_params.collected_fields:
                completed.append({
                    "name": param_info.get("label", param_key),
                    "value": context.document_params.collected_fields[param_key],
                    "key": param_key
                })
            else:
                pending.append({
                    "name": param_info.get("label", param_key),
                    "description": param_info.get("description", ""),
                    "key": param_key
                })
        
        return {
            "type": "param_collector",
            "title": f"正在收集【{context.document_params.template_name}】信息",
            "progress": {
                "completed": len(completed),
                "total": len(required_params),
                "percentage": int(len(completed) / len(required_params) * 100) if required_params else 100
            },
            "collected": completed,
            "pending": pending
        }
    
    def _build_param_collect_prompt(self, context: DialogContext) -> str:
        """构建参数收集提示"""
        params = self._get_template_params(context.document_params.doc_type)
        pending = context.document_params.pending_fields
        
        prompt = f"好的，您要生成【{context.document_params.template_name}】。\n\n"
        
        if context.document_params.collected_fields:
            prompt += "✅ 已收集的信息：\n"
            for key, value in context.document_params.collected_fields.items():
                prompt += f"   • {key}：{value}\n"
            prompt += "\n"
        
        if pending:
            prompt += "📝 请继续提供以下信息：\n"
            for i, param_key in enumerate(pending, 1):
                param_info = params.get(param_key, {})
                label = param_info.get("label", param_key)
                desc = param_info.get("description", "")
                prompt += f"   {i}. {label}"
                if desc:
                    prompt += f"（{desc}）"
                prompt += "\n"
        
        return prompt
    
    def _build_generation_confirm_prompt(self, context: DialogContext) -> str:
        """构建生成确认提示"""
        prompt = f"好的，所有信息已收集完毕！\n\n"
        prompt += "📋 已收集的信息汇总：\n"
        for key, value in context.document_params.collected_fields.items():
            prompt += f"   • {key}：{value}\n"
        prompt += "\n"
        prompt += "是否确认生成文书？"
        return prompt
    
    def _build_generation_confirm(self, context: DialogContext) -> Dict[str, Any]:
        """构建生成确认Widget"""
        return {
            "type": "dialog",
            "title": "确认生成",
            "content": "所有必填信息已收集完毕，是否确认生成文书？",
            "actions": [
                {"type": "button", "label": "确认生成", "action": "confirm_generate", "primary": True},
                {"type": "button", "label": "继续修改", "action": "continue_edit"}
            ]
        }
    
    def _build_generation_success_message(self, result: Dict[str, Any]) -> str:
        """构建生成成功消息"""
        return f"""✅ 文书生成成功！

📄 文件名：{result.get('file_name', '文书.docx')}
📁 保存位置：{result.get('file_path', '生成中...')}

是否有需要调整的地方？"""
    
    def _build_generation_success_widget(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """构建生成成功Widget"""
        return {
            "type": "document_generated",
            "title": "文书生成成功",
            "document": {
                "name": result.get("file_name", "文书.docx"),
                "path": result.get("file_path", ""),
                "preview_url": result.get("preview_url", "")
            },
            "actions": [
                {"type": "button", "label": "查看文书", "action": "open_preview", "primary": True},
                {"type": "button", "label": "下载文件", "action": "download"},
                {"type": "button", "label": "进行调整", "action": "start_modification"}
            ],
            "next_prompt": "是否有需要调整的地方？"
        }
    
    def _extract_template_from_message(self, message: str) -> Optional[str]:
        """从消息中提取用户选择的模板"""
        message_lower = message.lower()
        
        for category in self.TEMPLATE_CATEGORIES.values():
            for template in category.get("templates", []):
                # 检查模板名称
                if template["name"] in message:
                    return template["id"]
                
                # 检查关键词
                for kw in template.get("keywords", []):
                    if kw in message:
                        return template["id"]
        
        return None
    
    def _get_template_name(self, template_id: str) -> str:
        """获取模板名称"""
        for category in self.TEMPLATE_CATEGORIES.values():
            for template in category.get("templates", []):
                if template["id"] == template_id:
                    return template["name"]
        return template_id
    
    def _get_template_db_id(self, template_id: str) -> Optional[int]:
        """获取模板数据库ID（预留接口）"""
        # TODO: 从数据库查询
        return None
    
    def _get_template_params(self, doc_type: str) -> Dict[str, Dict[str, Any]]:
        """获取模板参数定义"""
        # 合并通用参数和特定参数
        params = dict(self.COMMON_PARAMS)
        
        # 添加特定参数
        specific = self.DOCUMENT_SPECIFIC_PARAMS.get(doc_type, {})
        params.update(specific)
        
        return params


# 单例
_document_chat_service: Optional[DocumentChatService] = None


def get_document_chat_service(ai_service=None) -> DocumentChatService:
    """获取文书对话服务实例"""
    global _document_chat_service
    if _document_chat_service is None:
        _document_chat_service = DocumentChatService(ai_service)
    return _document_chat_service
